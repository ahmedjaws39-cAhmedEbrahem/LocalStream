import java.util.Properties
import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
}

// Release signing. The keystore is a local secret, so nothing here names one directly: the
// credentials come from a properties file that is generated next to the keystore by
// tools\build-android.ps1 -Release (and is git-ignored), or from LS_RELEASE_* environment
// variables, which is what a CI machine would use.
//
// Without either the release build still runs, just unsigned - see the warning below.
val releaseSigning = Properties().apply {
    val candidates = listOf(
        rootProject.file("keystore.properties"),
        rootProject.projectDir.resolve("../tools/android-keystore/keystore.properties"),
    )
    candidates.firstOrNull { it.isFile }?.inputStream()?.use { load(it) }
}

fun releaseSigningValue(key: String, envKey: String): String? =
    System.getenv(envKey) ?: releaseSigning.getProperty(key)?.takeIf { it.isNotBlank() }

val releaseStoreFile = releaseSigningValue("storeFile", "LS_RELEASE_STORE_FILE")
val releaseStorePassword = releaseSigningValue("storePassword", "LS_RELEASE_STORE_PASSWORD")
val releaseKeyAlias = releaseSigningValue("keyAlias", "LS_RELEASE_KEY_ALIAS")
val releaseKeyPassword = releaseSigningValue("keyPassword", "LS_RELEASE_KEY_PASSWORD")

if (releaseStoreFile == null) {
    logger.warn(
        "No release keystore configured; the release bundle will be unsigned. " +
            "Run tools\\build-android.ps1 -Release to generate one."
    )
}

android {
    namespace = "com.localstream"

    // Google Play has required API 36 as the target since 31 August 2026, and the target can
    // never be ahead of what the app is compiled against - so both move together. Pinned
    // explicitly rather than left to the plugin's default, so the toolchain a release is built
    // with is the one written down here.
    compileSdk = 36
    buildToolsVersion = "36.0.0"

    defaultConfig {
        applicationId = "com.localstream"
        minSdk = 24
        targetSdk = 36
        versionCode = 1
        versionName = "1.0.0"
    }

    signingConfigs {
        if (releaseStoreFile != null) {
            create("release") {
                // An absolute path from the properties file; a relative one resolves against this
                // module directory (android/app). A Java properties file reads `\` as an escape, so
                // paths are stored with forward slashes - normalise anyway for the env-var case.
                storeFile = file(releaseStoreFile.replace('\\', '/'))
                storePassword = releaseStorePassword
                keyAlias = releaseKeyAlias
                keyPassword = releaseKeyPassword
            }
        }
    }

    buildTypes {
        debug {
            isMinifyEnabled = false
        }
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            signingConfig = signingConfigs.findByName("release")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    testOptions {
        unitTests {
            // The JVM tests run against the stubbed android.jar, where android.util.Log and the
            // rest of the framework throw instead of doing anything. Letting them return
            // defaults lets a test exercise real logic - a live socket, a real handshake - and log
            // its way through it, which is what the handshake tests do.
            isReturnDefaultValues = true
        }
    }

    buildFeatures {
        compose = true
        // The Help tab's diagnostics report states the released version, which comes from
        // BuildConfig.VERSION_NAME, so the report matches the installed build rather than a
        // hand-maintained string.
        buildConfig = true
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }

    lint {
        // Treat accessibility regressions as build failures: this project exists to be
        // screen-reader usable, so an unlabeled control is a defect, not a nit.
        warningsAsErrors = false
        abortOnError = true
        disable += "MissingTranslation"
    }
}

// Kotlin 2.x moved the JVM target out of android.kotlinOptions, which is deprecated, and into
// the Kotlin extension. It has to match compileOptions above, or the two halves of the module
// are compiled for different JVMs.
kotlin {
    compilerOptions {
        jvmTarget.set(JvmTarget.JVM_17)
    }
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.lifecycle.runtime.compose)
    implementation(libs.androidx.lifecycle.viewmodel.compose)

    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.compose.ui)
    implementation(libs.androidx.compose.ui.graphics)
    implementation(libs.androidx.compose.material3)
    implementation(libs.androidx.compose.material.icons.extended)

    implementation(libs.androidx.camera.core)
    implementation(libs.androidx.camera.camera2)
    implementation(libs.androidx.camera.lifecycle)

    implementation(libs.kotlinx.coroutines.android)

    testImplementation(libs.junit)
    testImplementation(libs.org.json)
}
