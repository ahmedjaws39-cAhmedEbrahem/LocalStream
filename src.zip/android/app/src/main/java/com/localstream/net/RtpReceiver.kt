﻿package com.localstream.net

import com.localstream.logging.AppLog
import com.localstream.protocol.H264Rtp
import com.localstream.protocol.LocalStream
import com.localstream.protocol.Rtp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.IOException
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.util.TreeMap
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Receives RTP from one broadcaster and emits frames ready for the decoders.
 *
 * Each track gets its own receive loop. That is not an optimisation: `DatagramSocket`
 * blocks, so a single loop servicing both sockets would sit in the audio `receive()` and
 * never touch the video queue until an audio packet happened to arrive.
 *
 * The audio path runs through a small reorder buffer because a single reordered Opus
 * packet is audibly damaging. The video path has no reorder buffer at all, because a late
 * frame is worthless and buffering it would display a picture that is already stale.
 */
class RtpReceiver(private val scope: CoroutineScope) {

    private val running = AtomicBoolean(false)

    private data class ExpectedSource(
        val address: InetAddress,
        val audioPort: Int,
        val videoPort: Int?,
        val audioSsrc: Int,
        val videoSsrc: Int?
    )

    @Volatile
    private var expectedSource: ExpectedSource? = null

    /**
     * Invoked (from the video receive loop thread) when a sequence gap is detected.
     *
     * A gap that lands mid-keyframe forces a discard, and the decoder then has no IDR until the
     * next one arrives - up to the whole keyframe interval on a sender that only emits them
     * periodically. Asking immediately means the picture returns in one round trip instead.
     */
    @Volatile
    var onVideoGap: (() -> Unit)? = null

    private var audioSocket: DatagramSocket? = null
    private var videoSocket: DatagramSocket? = null
    private var audioJob: Job? = null
    private var videoJob: Job? = null

    /**
     * Per-session frame channels.
     *
     * A [Channel] cannot be reopened once closed, so a fresh pair is created for every [open].
     * Reusing the previous pair is not merely wasteful: `trySend` on a closed channel fails,
     * the old flows have already completed, and the second session then carries no media at all
     * while still reporting itself as connected.
     */
    @Volatile
    private var videoFrames = Channel<ByteArray>(Channel.BUFFERED)

    /** Opus packets, released from the reorder buffer. */
    @Volatile
    private var audioFrames = Channel<ByteArray>(Channel.BUFFERED)

    val videoFramesFlow: Flow<ByteArray> get() = videoFrames.receiveAsFlow()
    val audioFramesFlow: Flow<ByteArray> get() = audioFrames.receiveAsFlow()

    @Volatile
    private var stats = Stats()

    @Volatile var sps: ByteArray? = null
        private set

    @Volatile var pps: ByteArray? = null
        private set

    val statistics: Stats get() = stats

    data class Ports(val audio: Int, val video: Int)

    /**
     * Opens the media sockets before the caller sends its `offer`, so no packet can arrive
     * before there is somewhere to put it.
     */
    @Throws(IOException::class)
    fun open(withVideo: Boolean): Ports {
        AppLog.info("RtpReceiver", "Opening RTP sockets (withVideo=$withVideo)")
        if (running.getAndSet(true)) return Ports(0, 0)
        expectedSource = null

        // Everything belonging to one session is minted here, so nothing from the previous
        // session can survive into this one: fresh queues, fresh counters, and no parameter
        // sets left over from a stream that is already gone. The queues are also captured by
        // the receive loops rather than read from the fields, so a lagging loop from the old
        // session can never deliver a frame into the new session's queue.
        val audioQueue = Channel<ByteArray>(Channel.BUFFERED)
        val videoQueue = Channel<ByteArray>(Channel.BUFFERED)
        audioFrames = audioQueue
        videoFrames = videoQueue
        sps = null
        pps = null
        stats = Stats()

        try {
            val audio = newSocket()
            audioSocket = audio
            var video = 0
            if (withVideo) {
                val v = newSocket()
                videoSocket = v
                video = v.localPort
            }
            audioJob = scope.launch(Dispatchers.IO) { audioLoop(audio, audioQueue) }
            if (withVideo) videoJob = scope.launch(Dispatchers.IO) { videoLoop(videoSocket!!, videoQueue) }
            return Ports(audio.localPort, video)
        } catch (e: IOException) {
            // open() is not a coroutine, so it cannot await the loops; tearing the sockets
            // down is enough to make the not-yet-started jobs no-ops.
            running.set(false)
            audioSocket?.close()
            videoSocket?.close()
            audioSocket = null
            videoSocket = null
            throw e
        }
    }

    private fun newSocket(): DatagramSocket = DatagramSocket(null).apply {
        reuseAddress = true
        // A generous receive buffer is what keeps a 1.5 Mbit video stream from shedding
        // packets during a Wi-Fi retransmit burst.
        receiveBufferSize = 512 * 1024
        bind(InetSocketAddress(0))
    }

    private suspend fun audioLoop(socket: DatagramSocket, frames: Channel<ByteArray>) {
        // Three frames of 20 ms is 60 ms of slack: enough to cover the reordering Wi-Fi
        // introduces, small enough to stay inside the latency budget.
        val reorder = AudioReorderBuffer(windowPackets = 3)
        val datagram = DatagramPacket(ByteArray(2048), 2048)

        while (running.get()) {
            try {
                datagram.length = datagram.data.size
                withContext(Dispatchers.IO) { socket.receive(datagram) }
            } catch (e: IOException) {
                if (running.get()) continue else break
            }
            // receive() is a Java void method; it reports the length by setting it on the
            // DatagramPacket it was handed.
            val length = datagram.length
            if (length <= 0) continue

            val packet = Rtp.parse(datagram.data, 0, length) ?: continue
            if (packet.payloadType != LocalStream.PAYLOAD_TYPE_AUDIO) continue
            val source = expectedSource ?: continue
            if (!isExpectedRtpSource(
                    datagram.address,
                    datagram.port,
                    packet.ssrc,
                    source.address,
                    source.audioPort,
                    source.audioSsrc
                )
            ) continue

            stats.onAudioPacket(packet.sequenceNumber)
            reorder.push(packet.sequenceNumber, packet.payload(datagram.data))
            reorder.drainTo { frames.trySend(it) }
        }
    }

private suspend fun videoLoop(socket: DatagramSocket, frames: Channel<ByteArray>) {
        val depacketizer = H264Rtp.Depacketizer(annexB = true)
        val datagram = DatagramPacket(ByteArray(2048), 2048)
        var lastSequence = -1
        var lastGapHookNanos = 0L

        while (running.get()) {
            try {
                datagram.length = datagram.data.size
                withContext(Dispatchers.IO) { socket.receive(datagram) }
            } catch (e: IOException) {
                if (running.get()) continue else break
            }
            val length = datagram.length
            if (length <= 0) continue

            val packet = Rtp.parse(datagram.data, 0, length) ?: continue
            if (packet.payloadType != LocalStream.PAYLOAD_TYPE_VIDEO) continue
            val source = expectedSource ?: continue
            val videoPort = source.videoPort ?: continue
            val videoSsrc = source.videoSsrc ?: continue
            if (!isExpectedRtpSource(
                    datagram.address,
                    datagram.port,
                    packet.ssrc,
                    source.address,
                    videoPort,
                    videoSsrc
                )
            ) continue

            if (lastSequence >= 0) {
                val expected = (lastSequence + 1) and 0xFFFF
                val delta = Rtp.sequenceDelta(packet.sequenceNumber, expected)
                if (delta != 0) {
                    // Video is deliberately not reordered for latency. Do not let a missing
                    // FU-A fragment contaminate the next access unit or decoder reference.
                    depacketizer.discardCurrentAccessUnit()
                    // Ask the broadcaster for a fresh IDR so the decoder can resynchronise
                    // now rather than whenever the next periodic keyframe happens to land.
                    // Throttled: the control channel is not a retransmission pipe, and a burst
                    // of missing packets must not become a burst of requests.
                    val now = System.nanoTime()
                    if (now - lastGapHookNanos > 250_000_000L) {
                        lastGapHookNanos = now
                        onVideoGap?.invoke()
                    }
                    if (delta >= 0x8000) continue
                }
            }
            lastSequence = packet.sequenceNumber
            stats.onVideoPacket(packet.sequenceNumber)
            val accessUnit = depacketizer.accept(packet.payload(datagram.data), packet.marker)
            if (accessUnit != null) {
                if (sps == null && depacketizer.sps != null) {
                    AppLog.info("RtpReceiver", "First SPS/PPS seen: sps=" + (depacketizer.sps?.size ?: 0) + " bytes, pps=" + (depacketizer.pps?.size ?: 0) + " bytes")
                }
                sps = depacketizer.sps
                pps = depacketizer.pps
                frames.trySend(accessUnit)
            }
        }
    }

    fun setExpectedSource(
        address: InetAddress,
        audioPort: Int,
        videoPort: Int?,
        audioSsrc: Int,
        videoSsrc: Int?
    ): Boolean {
        if (audioPort !in 1..65535 || audioSsrc == 0 ||
            (videoPort != null && (videoPort !in 1..65535 || videoSsrc == null || videoSsrc == 0)) ||
            (videoPort == null && videoSsrc != null)
        ) {
            return false
        }
        expectedSource = ExpectedSource(address, audioPort, videoPort, audioSsrc, videoSsrc)
        return true
    }

    suspend fun close() {
        running.set(false)
        expectedSource = null
        // Closing the socket is the only reliable way to unblock a pending receive().
        audioSocket?.close()
        videoSocket?.close()
        audioSocket = null
        videoSocket = null
        audioJob?.cancel()
        videoJob?.cancel()
        audioJob = null
        videoJob = null
        audioFrames.close()
        videoFrames.close()
    }

    /** Counters surfaced to the user and reported to the broadcaster once a second. */
    class Stats {
        @Volatile var audioPackets: Long = 0; private set
        @Volatile var videoPackets: Long = 0; private set
        @Volatile var lostPackets: Long = 0; private set
        @Volatile var keyframeRequests: Long = 0; private set
        @Volatile var jitterMillis: Double = 0.0; private set

        private var lastAudioSequence = -1
        private var lastVideoSequence = -1
        private var lastArrivalNanos = 0L

        fun onAudioPacket(sequence: Int) {
            audioPackets++
            lastAudioSequence = noteGap(lastAudioSequence, sequence)
        }

        fun onVideoPacket(sequence: Int) {
            videoPackets++
            lastVideoSequence = noteGap(lastVideoSequence, sequence)
            val now = System.nanoTime()
            if (lastArrivalNanos != 0L) {
                // Smooth it so the readout does not flicker frame to frame.
                val deltaMillis = (now - lastArrivalNanos) / 1_000_000.0
                jitterMillis = jitterMillis * 0.9 + deltaMillis * 0.1
            }
            lastArrivalNanos = now
        }

        fun onKeyframeRequest() {
            keyframeRequests++
        }

        private fun noteGap(previous: Int, sequence: Int): Int {
            if (previous >= 0) {
                val expected = previous + 1
                if (sequence != expected) {
                    val gap = Rtp.sequenceDelta(sequence, expected)
                    // A wild jump means the sender restarted or the stream desynchronised;
                    // counting every "missing" packet would report nonsense.
                    if (gap in 1..999) lostPackets += gap
                }
            }

            return sequence
        }
    }

    /**
     * Sequence-ordered release buffer for Opus.
     *
     * Holds packets until the next in sequence arrives, then releases everything that has
     * become contiguous. If the head of the queue is never filled \u2014 a packet genuinely
     * lost \u2014 the oldest buffered packet is released once the window is full, so a single
     * loss costs a click rather than unbounded latency.
     */
    private class AudioReorderBuffer(private val windowPackets: Int) {

        private val pending = TreeMap<Int, ByteArray>()
        private var nextSequence = -1

        fun push(sequence: Int, frame: ByteArray) {
            if (nextSequence < 0) nextSequence = sequence

            // A large forward jump means we have lost packets outright; resynchronise
            // rather than stalling waiting for a number that will never arrive.
            val forwardGap = Rtp.sequenceDelta(sequence, nextSequence)
            if (forwardGap > 0x8000 || forwardGap > windowPackets * 4) {
                nextSequence = sequence
                pending.clear()
            }

            if (Rtp.sequenceDelta(sequence, nextSequence) >= 0x8000) return // too old to matter
            pending[sequence] = frame
        }

        fun drainTo(emit: (ByteArray) -> Unit) {
            // Release the oldest packet when the window is full and the head is missing.
            if (pending.size > windowPackets) {
                val oldest = pending.firstKey()
                if (oldest != null && oldest != nextSequence) {
                    nextSequence = oldest + 1
                }
            }
            while (true) {
                val frame = pending.remove(nextSequence) ?: break
                nextSequence = (nextSequence + 1) and 0xFFFF
                emit(frame)
            }
        }
    }
}

internal fun isExpectedRtpSource(
    receivedAddress: InetAddress,
    receivedPort: Int,
    receivedSsrc: Int,
    expectedAddress: InetAddress,
    expectedPort: Int,
    expectedSsrc: Int
): Boolean =
    receivedPort == expectedPort &&
        receivedSsrc == expectedSsrc &&
        normalizedAddress(receivedAddress).contentEquals(normalizedAddress(expectedAddress))

private fun normalizedAddress(address: InetAddress): ByteArray {
    val bytes = address.address
    val mappedIpv4Prefix = byteArrayOf(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, -1)
    return if (bytes.size == 16 && bytes.copyOfRange(0, 12).contentEquals(mappedIpv4Prefix)) {
        bytes.copyOfRange(12, 16)
    } else {
        bytes
    }
}
