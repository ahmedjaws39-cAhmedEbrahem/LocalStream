package com.localstream.ui

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import com.localstream.engine.BroadcastService
import com.localstream.ui.theme.LocalStreamTheme

/**
 * Answers a viewer request from the lock screen.
 *
 * An activity rather than a notification action, because answering means judging whether you
 * recognise the device asking - and that cannot be done from two buttons on a lock screen. It
 * shows over the lockscreen and turns the screen on, so the presenter does not have to unlock
 * first, and it finishes as soon as the answer is sent.
 *
 * It does not reach the ViewModel: the broadcast, and the pending request, belong to the app's
 * existing ViewModel instance, and this is a separate task entry. So the answer is broadcast and
 * the main Activity, which is still alive, applies it - the same route the notification's Stop
 * button already uses.
 */
class AccessRequestActivity : ComponentActivity() {

    /**
     * The request on screen, or null once it has been answered.
     *
     * Compose state rather than two lazy reads of the intent: the activity is `singleTask`, so a
     * second request arrives as [onNewIntent] while this one is already showing. Reading the
     * intent lazily would have kept the first viewer's name on screen and answered for the first
     * request when the presenter pressed Allow for the second.
     */
    private var pending by mutableStateOf<AccessRequest?>(null)

    /**
     * The lock-screen request has to speak the chosen language too, and it is a separate task
     * entry from the main app, so it cannot inherit a context that was already wrapped.
     */
    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(AppLanguage.wrap(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            // The point of the activity. A request the presenter cannot see until they unlock is
            // a viewer who waits until someone realises they are being held at a door.
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        }
        pending = requestFrom(intent)
        // Touching the screen must not dismiss the lockscreen behind this; the two would
        // otherwise be shown together and the request would be half-covered by it.
        setContent {
            LocalStreamTheme {
                pending?.let { request ->
                    AccessRequestDialog(
                        request = request,
                        onAnswer = { allow ->
                            // Guarded so a tap that lands twice - once on the dialog, once as the
                            // activity is finishing - cannot answer twice. The second answer would
                            // name a request that no longer exists.
                            val current = pending
                            pending = null
                            if (current != null) {
                                sendAnswer(current.key, allow)
                            }
                            finish()
                        }
                    )
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        // singleTask: a second request reuses this activity rather than stacking another copy,
        // so the latest request is the one on screen and only one answer can ever be sent.
        setIntent(intent)
        pending = requestFrom(intent)
    }

    /** The request an intent is asking about, or null when it is malformed. */
    private fun requestFrom(intent: Intent?): AccessRequest? {
        val key = intent?.getLongExtra(EXTRA_KEY, -1L) ?: -1L
        if (key < 0L) return null
        return AccessRequest(key, intent?.getStringExtra(EXTRA_NAME).orEmpty())
    }

    private fun sendAnswer(key: Long, allow: Boolean) {
        sendBroadcast(
            Intent(BroadcastService.ACTION_ACCESS_REQUEST_ANSWER)
                .setPackage(packageName)
                .putExtra(EXTRA_KEY, key)
                .putExtra(EXTRA_ALLOW, allow)
        )
    }
}

/**
 * Delivers a lock-screen answer to the running app.
 *
 * A named receiver with a static register/unregister pair, because the activity is short-lived
 * and the window where it is listening - between `onCreate` and `onDestroy` - is exactly when
 * the answer is sent. Registering it in the ViewModel instead would keep it alive with no
 * activity to receive anything.
 */
class AccessAnswerReceiver(private val onAnswer: (key: Long, allow: Boolean) -> Unit) :
    BroadcastReceiver() {

    override fun onReceive(context: Context?, intent: Intent?) {
        if (intent?.action != BroadcastService.ACTION_ACCESS_REQUEST_ANSWER) return
        val key = intent.getLongExtra(EXTRA_KEY, -1L)
        if (key < 0L) return
        onAnswer(key, intent.getBooleanExtra(EXTRA_ALLOW, false))
    }

    companion object {
        fun register(context: Context, onAnswer: (Long, Boolean) -> Unit): AccessAnswerReceiver {
            val receiver = AccessAnswerReceiver(onAnswer)
            val filter = IntentFilter(BroadcastService.ACTION_ACCESS_REQUEST_ANSWER)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                ContextCompat.registerReceiver(
                    context,
                    receiver,
                    filter,
                    ContextCompat.RECEIVER_NOT_EXPORTED
                )
            } else {
                @Suppress("UnspecifiedRegisterReceiverFlag")
                context.registerReceiver(receiver, filter)
            }
            return receiver
        }
    }
}

