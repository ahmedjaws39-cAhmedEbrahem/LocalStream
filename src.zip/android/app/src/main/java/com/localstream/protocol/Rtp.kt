package com.localstream.protocol

/**
 * Minimal RTP (RFC 3550) packet codec.
 *
 * Only the 12-byte fixed header plus the CSRC list is supported; the extension header and
 * the padding bit are parsed but not used by this protocol.
 */
object Rtp {

    const val HEADER_BYTES = 12

    const val FLAG_MARKER = 0x80
    const val FLAG_EXTENSION = 0x10
    const val FLAG_PADDING = 0x20

    fun sequenceDelta(newer: Int, older: Int): Int = (newer - older) and 0xFFFF

    fun build(
        payloadType: Int,
        marker: Boolean,
        sequenceNumber: Int,
        timestamp: Int,
        ssrc: Int,
        payload: ByteArray,
        payloadOffset: Int = 0,
        payloadLength: Int = payload.size - payloadOffset
    ): ByteArray {
        val out = ByteArray(HEADER_BYTES + payloadLength)
        out[0] = 0x80.toByte() // V=2, P=0, X=0, CC=0
        out[1] = ((if (marker) FLAG_MARKER else 0) or (payloadType and 0x7F)).toByte()
        out[2] = ((sequenceNumber shr 8) and 0xFF).toByte()
        out[3] = (sequenceNumber and 0xFF).toByte()
        out[4] = ((timestamp shr 24) and 0xFF).toByte()
        out[5] = ((timestamp shr 16) and 0xFF).toByte()
        out[6] = ((timestamp shr 8) and 0xFF).toByte()
        out[7] = (timestamp and 0xFF).toByte()
        out[8] = ((ssrc shr 24) and 0xFF).toByte()
        out[9] = ((ssrc shr 16) and 0xFF).toByte()
        out[10] = ((ssrc shr 8) and 0xFF).toByte()
        out[11] = (ssrc and 0xFF).toByte()
        System.arraycopy(payload, payloadOffset, out, HEADER_BYTES, payloadLength)
        return out
    }

    /** Parsed view over a datagram received on an RTP socket. */
    data class Packet(
        val payloadType: Int,
        val marker: Boolean,
        val sequenceNumber: Int,
        val timestamp: Int,
        val ssrc: Int,
        val payloadOffset: Int,
        val payloadLength: Int
    ) {
        fun payload(data: ByteArray): ByteArray =
            data.copyOfRange(payloadOffset, payloadOffset + payloadLength)
    }

    /**
     * Returns null for anything that is not a plausible RTP packet.
     *
     * Being strict here matters: a stray non-RTP datagram on the media port would
     * otherwise be handed to the video decoder as a corrupt frame.
     */
    fun parse(data: ByteArray, offset: Int = 0, length: Int = data.size - offset): Packet? {
        if (length < HEADER_BYTES) return null
        val version = (data[offset].toInt() and 0xC0) shr 6
        if (version != 2) return null

        val csrcCount = data[offset].toInt() and 0x0F
        val hasExtension = (data[offset].toInt() and FLAG_EXTENSION) != 0
        val hasPadding = (data[offset].toInt() and FLAG_PADDING) != 0

        var payloadOffset = offset + HEADER_BYTES + csrcCount * 4
        var payloadLength = length - (payloadOffset - offset)

        if (hasPadding) {
            if (payloadLength <= 0) return null
            val padBytes = data[offset + length - 1].toInt() and 0xFF
            if (padBytes > payloadLength) return null
            payloadLength -= padBytes
        }

        if (hasExtension) {
            if (payloadLength < 4) return null
            val extWords = ((data[payloadOffset + 2].toInt() and 0xFF) shl 8) or
                (data[payloadOffset + 3].toInt() and 0xFF)
            payloadOffset += 4 + extWords * 4
            payloadLength -= 4 + extWords * 4
        }

        if (payloadLength < 0) return null
        if (offset + length > data.size) return null

        return Packet(
            payloadType = data[offset + 1].toInt() and 0x7F,
            marker = (data[offset + 1].toInt() and FLAG_MARKER) != 0,
            sequenceNumber = ((data[offset + 2].toInt() and 0xFF) shl 8) or
                (data[offset + 3].toInt() and 0xFF),
            timestamp = ((data[offset + 4].toInt() and 0xFF) shl 24) or
                ((data[offset + 5].toInt() and 0xFF) shl 16) or
                ((data[offset + 6].toInt() and 0xFF) shl 8) or
                (data[offset + 7].toInt() and 0xFF),
            ssrc = ((data[offset + 8].toInt() and 0xFF) shl 24) or
                ((data[offset + 9].toInt() and 0xFF) shl 16) or
                ((data[offset + 10].toInt() and 0xFF) shl 8) or
                (data[offset + 11].toInt() and 0xFF),
            payloadOffset = payloadOffset,
            payloadLength = payloadLength
        )
    }
}
