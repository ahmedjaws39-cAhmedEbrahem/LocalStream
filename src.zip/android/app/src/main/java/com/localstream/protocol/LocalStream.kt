package com.localstream.protocol

import java.security.SecureRandom
import java.util.Locale

/**
 * Constants and helpers for the LocalStream v1 wire protocol.
 *
 * See `docs/PROTOCOL.md` for the normative description. This file is the single place
 * where a value is defined; anything the C++ client also needs is deliberately kept as a
 * literal here rather than derived, so the two implementations can be diffed by eye.
 */
object LocalStream {

    const val PROTOCOL_VERSION: Int = 1

    /** RFC 6335 service type. 11 characters, letters only, within the 15-character limit. */
    const val SERVICE_TYPE: String = "_localstream._tcp.local."

    /**
     * The same service type in the form NsdManager accepts.
     *
     * NsdManager is handed a service type without a domain and appends `.local.` itself, so giving
     * it the fully qualified name from PROTOCOL.md builds a malformed type -- the domain ends up
     * duplicated -- and registration fails with a bare "error 0" that names neither the type nor
     * the cause. Derived rather than written out, so the two forms cannot drift apart again, which
     * is what made the mismatch invisible in the first place.
     *
     * The Windows client parses the DNS wire format itself and genuinely needs the fully qualified
     * name, so both forms are kept on purpose. See `docs/PROTOCOL.md`.
     */
    val NSD_SERVICE_TYPE: String = SERVICE_TYPE.removeSuffix(".local.")

    const val TXT_VERSION = "v"
    const val TXT_SESSION_ID = "id"
    const val TXT_NAME = "n"
    const val TXT_MODE = "m"
    const val TXT_VIDEO_CODEC = "vid"
    const val TXT_AUDIO_CODEC = "aud"
    const val TXT_VIDEO_BITRATE = "vbr"
    const val TXT_AUDIO_BITRATE = "abr"
    const val TXT_DIMENSIONS = "dim"
    const val TXT_FRAMERATE = "fps"
    const val TXT_VIDEO_PORT = "vp"
    const val TXT_AUDIO_PORT = "ap"
    const val TXT_CONTROL_PORT = "cp"
    const val TXT_STATE = "st"

    const val MODE_AUDIO_VIDEO = "av"
    const val MODE_AUDIO_ONLY = "a"

    const val CODEC_H264 = "h264"
    const val CODEC_OPUS = "opus"

    /** True while encoding; `0` means registered and discoverable but not streaming. */
    const val STATE_LIVE = "1"
    const val STATE_IDLE = "0"

    const val PAYLOAD_TYPE_VIDEO = 96
    const val PAYLOAD_TYPE_AUDIO = 97

    const val VIDEO_CLOCK_RATE = 90_000
    const val AUDIO_CLOCK_RATE = 48_000

    /** 20 ms of 48 kHz audio, the frame size used for every Opus packet we send. */
    const val OPUS_SAMPLES_PER_FRAME = 960

    /**
     * RTP payload budget. 1200 bytes leaves room inside a 1500-byte Ethernet MTU for
     * the UDP and IP headers without IP fragmentation.
     */
    const val RTP_MAX_PAYLOAD = 1200

    const val MAX_RECEIVERS_DEFAULT = 4

    private val random = SecureRandom()

    /** 8 hex characters of entropy, regenerated every time broadcasting starts. */
    fun newSessionId(): String {
        val bytes = ByteArray(4)
        random.nextBytes(bytes)
        return bytes.joinToString("") { String.format(Locale.ROOT, "%02x", it) }
    }

    /**
     * mDNS TXT values are restricted to printable ASCII, and '=' and ',' are structural.
     * Percent-encoding keeps the record parseable by any third-party DNS-SD browser.
     */
    fun escapeTxtValue(value: String): String {
        val out = StringBuilder(value.length)
        for (ch in value) {
            when {
                ch in ' '..'~' && ch != '=' && ch != ',' && ch != '\\' -> out.append(ch)
                else -> {
                    val bytes = ch.toString().toByteArray(Charsets.UTF_8)
                    for (b in bytes) out.append('%').append(String.format(Locale.ROOT, "%02X", b))
                }
            }
        }
        return out.toString()
    }

    fun unescapeTxtValue(value: String): String {
        val bytes = ArrayList<Byte>(value.length)
        var i = 0
        while (i < value.length) {
            val ch = value[i]
            if (ch == '%' && i + 2 < value.length) {
                val hex = value.substring(i + 1, i + 3)
                val parsed = hex.toIntOrNull(16)
                if (parsed != null) {
                    bytes.add(parsed.toByte())
                    i += 3
                    continue
                }
            }
            bytes.add(ch.toString().toByteArray(Charsets.UTF_8).first())
            i++
        }
        return String(bytes.toByteArray(), Charsets.UTF_8)
    }

    /**
     * Parses the TXT attributes `NsdManager` hands back, which arrive as an already-split
     * map of "key=value" byte arrays.
     */
    fun parseTxtAttributes(attributes: Map<String, ByteArray>): Map<String, String> {
        val result = HashMap<String, String>(attributes.size)
        for ((rawKey, rawValue) in attributes) {
            val key = rawKey.substringBefore('=')
            if (key.isEmpty()) continue
            result[key] = String(rawValue, Charsets.UTF_8)
        }
        return result
    }

    /**
     * Diagnostic SDP. Not on the media path — the negotiated RTP ports come from the
     * control-channel `accept` message. Kept in sync with the TXT record by construction,
     * because both are generated from the same [Description].
     */
    fun buildSdp(description: Description, controlPort: Int, ssrcVideo: Int, ssrcAudio: Int): String {
        val sb = StringBuilder()
        sb.append("v=0\r\n")
        sb.append("o=- ").append(description.sessionId).append(" 1 IN IP4 0.0.0.0\r\n")
        sb.append("s=LocalStream\r\n")
        sb.append("c=IN IP4 0.0.0.0\r\n")
        sb.append("t=0 0\r\n")
        sb.append("a=control:").append(controlPort).append("\r\n")
        sb.append("m=video 0 RTP/AVP ").append(PAYLOAD_TYPE_VIDEO).append("\r\n")
        sb.append("a=rtpmap:").append(PAYLOAD_TYPE_VIDEO).append(" H264/90000\r\n")
        sb.append("a=fmtp:").append(PAYLOAD_TYPE_VIDEO).append(" profile-level-id=42e01f\r\n")
        if (description.sps != null && description.pps != null) {
            sb.append("a=fmtp:").append(PAYLOAD_TYPE_VIDEO)
                .append(" sprop-parameter-sets=").append(base64(description.sps)).append(",")
                .append(base64(description.pps)).append("\r\n")
        }
        sb.append("a=mid:0\r\n")
        sb.append("a=ssrc:").append(ssrcVideo).append("\r\n")
        sb.append("m=audio 0 RTP/AVP ").append(PAYLOAD_TYPE_AUDIO).append("\r\n")
        sb.append("a=rtpmap:").append(PAYLOAD_TYPE_AUDIO).append(" opus/48000/")
            .append(description.audioChannels.coerceIn(1, 2)).append("\r\n")
        sb.append("a=fmtp:").append(PAYLOAD_TYPE_AUDIO).append(" useinbandfec=1\r\n")
        sb.append("a=mid:1\r\n")
        sb.append("a=ssrc:").append(ssrcAudio).append("\r\n")
        return sb.toString()
    }

    /**
     * Reads the Opus channel count out of an SDP, e.g. 2 for `a=rtpmap:97 opus/48000/2`.
     *
     * An Opus packet does not describe its own channel layout -- the decoder has to be told --
     * and the welcome's SDP is the only place the broadcaster states it. Assuming stereo is what
     * made a mono broadcast decode on the wrong layout, so the value is read rather than
     * defaulted. A missing or nonsensical value falls back to the 2 channels this client
     * advertises, which is also what a third-party broadcaster with no SDP would get.
     */
    fun audioChannelsFromSdp(sdp: String): Int {
        if (sdp.isEmpty()) return 2
        // Matched against the audio payload type specifically, so the video rtpmap on the next
        // line (`H264/90000`, only two fields) cannot be mistaken for the audio one.
        val prefix = "a=rtpmap:$PAYLOAD_TYPE_AUDIO "
        for (line in sdp.split('\n')) {
            val trimmed = line.trim()
            if (!trimmed.startsWith(prefix)) continue
            // `a=rtpmap:97 opus/48000/2` -- encoding, clock rate, then channels, per RFC 4566.
            val channels = trimmed.substring(prefix.length).split('/').getOrNull(2)
                ?.toIntOrNull() ?: continue
            if (channels in 1..2) return channels
        }
        return 2
    }

    private fun base64(data: ByteArray): String =
        android.util.Base64.encodeToString(data, android.util.Base64.NO_WRAP)

    /** The complete set of facts a broadcaster publishes about itself. */
    data class Description(
        val sessionId: String,
        val displayName: String,
        val mode: String,
        val live: Boolean,
        val videoBitrateKbps: Int,
        val audioBitrateKbps: Int,
        val width: Int,
        val height: Int,
        val frameRate: Int,
        val controlPort: Int,
        val audioPort: Int,
        val videoPort: Int,
        val audioChannels: Int = 1,
        val sps: ByteArray? = null,
        val pps: ByteArray? = null
    ) {
        val isAudioOnly: Boolean get() = mode == MODE_AUDIO_ONLY

        fun toTxt(): Map<String, String> = buildMap {
            put(TXT_VERSION, PROTOCOL_VERSION.toString())
            put(TXT_SESSION_ID, sessionId)
            put(TXT_NAME, escapeTxtValue(displayName))
            put(TXT_MODE, mode)
            put(TXT_AUDIO_CODEC, CODEC_OPUS)
            put(TXT_AUDIO_BITRATE, audioBitrateKbps.toString())
            put(TXT_CONTROL_PORT, controlPort.toString())
            put(TXT_AUDIO_PORT, audioPort.toString())
            put(TXT_STATE, if (live) STATE_LIVE else STATE_IDLE)
            if (!isAudioOnly) {
                put(TXT_VIDEO_CODEC, CODEC_H264)
                put(TXT_VIDEO_BITRATE, videoBitrateKbps.toString())
                put(TXT_DIMENSIONS, "${width}x${height}")
                put(TXT_FRAMERATE, frameRate.toString())
                put(TXT_VIDEO_PORT, videoPort.toString())
            }
        }

        override fun equals(other: Any?): Boolean = other is Description &&
            sessionId == other.sessionId &&
            displayName == other.displayName &&
            mode == other.mode &&
            live == other.live &&
            videoBitrateKbps == other.videoBitrateKbps &&
            audioBitrateKbps == other.audioBitrateKbps &&
            width == other.width &&
            height == other.height &&
            frameRate == other.frameRate &&
            controlPort == other.controlPort &&
            audioPort == other.audioPort &&
            videoPort == other.videoPort

        override fun hashCode(): Int {
            var result = sessionId.hashCode()
            result = 31 * result + displayName.hashCode()
            result = 31 * result + mode.hashCode()
            result = 31 * result + live.hashCode()
            result = 31 * result + controlPort
            result = 31 * result + width
            return result
        }
    }

    /** Parses a TXT record back into a [Description]. */
    fun descriptionFrom(txt: Map<String, String>): Description? {
        val version = txt[TXT_VERSION]?.toIntOrNull() ?: return null
        if (version != PROTOCOL_VERSION) return null
        val sessionId = txt[TXT_SESSION_ID] ?: return null
        val mode = txt[TXT_MODE] ?: return null
        if (mode != MODE_AUDIO_VIDEO && mode != MODE_AUDIO_ONLY) return null
        val controlPort = txt[TXT_CONTROL_PORT]?.toIntOrNull() ?: return null
        val audioPort = txt[TXT_AUDIO_PORT]?.toIntOrNull() ?: return null
        val name = txt[TXT_NAME]?.let { unescapeTxtValue(it) } ?: "Unknown"
        val live = txt[TXT_STATE] == STATE_LIVE

        return if (mode == MODE_AUDIO_ONLY) {
            Description(
                sessionId = sessionId,
                displayName = name,
                mode = mode,
                live = live,
                videoBitrateKbps = 0,
                audioBitrateKbps = txt[TXT_AUDIO_BITRATE]?.toIntOrNull() ?: 48,
                width = 0,
                height = 0,
                frameRate = 0,
                controlPort = controlPort,
                audioPort = audioPort,
                videoPort = 0
            )
        } else {
            val dim = txt[TXT_DIMENSIONS]?.split('x') ?: return null
            val w = dim.getOrNull(0)?.toIntOrNull() ?: return null
            val h = dim.getOrNull(1)?.toIntOrNull() ?: return null
            Description(
                sessionId = sessionId,
                displayName = name,
                mode = mode,
                live = live,
                videoBitrateKbps = txt[TXT_VIDEO_BITRATE]?.toIntOrNull() ?: 1200,
                audioBitrateKbps = txt[TXT_AUDIO_BITRATE]?.toIntOrNull() ?: 48,
                width = w,
                height = h,
                frameRate = txt[TXT_FRAMERATE]?.toIntOrNull() ?: 30,
                controlPort = controlPort,
                audioPort = audioPort,
                videoPort = txt[TXT_VIDEO_PORT]?.toIntOrNull() ?: 0
            )
        }
    }
}
