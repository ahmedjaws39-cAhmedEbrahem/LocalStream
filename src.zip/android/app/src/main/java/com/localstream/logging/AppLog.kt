package com.localstream.logging

import android.content.Context
import android.util.Log
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.UUID

/**
 * The app's log: what it did, when, and how it went.
 *
 * Same design as the Windows client on purpose. A report from one platform should be readable
 * by someone who has only ever seen the other, and a bug that shows up on both is the bug where
 * the two logs being in one format is worth the most.
 *
 * A line looks like:
 *
 * ```
 * 2026-10-05 09:14:02.481 +02:00 [INFO ] [BroadcastEngine] [T412] broadcast.started port=53525
 * ```
 *
 * The timestamp carries its UTC offset on purpose. A report is read on another machine, often in
 * another timezone, and a bare `09:14:02` cannot be lined up against anything else that day.
 *
 * The files are written with [android.util.Log] as well, so the same event is visible in logcat
 * while developing and in the file afterwards, and the lines in the two are identical.
 */
object AppLog {

    /** How severe a line is. Also what the level filter is set to. */
    enum class Level { DEBUG, INFO, WARNING, ERROR }

    /**
     * Everything the user can change, in one value.
     *
     * A value rather than a set of setters because the Help screen edits all of them at once and
     * has to show what is in force, and because they are written to disk together so a
     * half-saved set cannot be read back.
     */
    data class Settings(
        /** The automatic recording switch. Off means nothing reaches the disk at all. */
        val recordAutomatically: Boolean = true,
        /** Lines below this level are dropped before they are formatted. */
        val minimumLevel: Level = Level.DEBUG,
        /** Whether the time of day carries milliseconds. */
        val milliseconds: Boolean = true,
        /** `09:14:02.481 am` instead of `09:14:02.481 +02:00`. */
        val twelveHourClock: Boolean = false,
        /** How many days of files to keep. */
        val keepDays: Int = 7,
        /** Ceiling for one day's file, past which it rolls over. */
        val maxFileSizeMiB: Int = 4,
    )

    /** One `key=value` pair attached to an [event]. */
    private const val MAX_ROLLOVERS = 5
    private const val OPEN_ATTEMPTS_BEFORE_GIVING_UP = 3
    private const val MIN_KEEP_DAYS = 1
    private const val MAX_KEEP_DAYS = 90
    private const val MIN_SIZE_MIB = 1
    private const val MAX_SIZE_MIB = 64
    private const val PREFS_NAME = "logging"

    private val lock = Any()

    /** Kept open between writes: this is called from media threads, once per frame. */
    private var stream: FileOutputStream? = null
    private var openDate: String? = null
    private var folder: File? = null
    private var current = Settings()
    private var installed = false
    private var failedOpens = 0
    private var bytesWritten = 0L

    /** Identifies this run of the app, so a log holding several can be told apart. */
    var sessionId: String = ""
        private set

    /**
     * Starts recording.
     *
     * Called from `Application.onCreate`, which is the only place early enough: the engines are
     * constructed from a service and a broadcast that can start before any screen does, and a log
     * that misses the start is no use for the failure it was wanted for.
     *
     * @param directory where the files go, for tests. Empty means the app's own storage.
     */
    @JvmStatic
    @JvmOverloads
    fun install(context: Context, directory: File? = null) {
        synchronized(lock) {
            if (installed) return
            installed = true
            current = loadSettings(context)
            sessionId = UUID.randomUUID().toString().take(8)
            folder = directory ?: File(context.filesDir, "logs")
            if (current.recordAutomatically && ensureOpen(context)) {
                pruneOldFiles()
                val header = sessionHeader(current)
                writeRaw(header)
            }
        }
    }

    /** Flushes, closes the file and stops recording. */
    @JvmStatic
    fun shutdown() {
        synchronized(lock) {
            closeFile()
            installed = false
        }
    }

    /** The settings in force right now. */
    @JvmStatic
    fun settings(): Settings = synchronized(lock) { current }

    /**
     * Applies [next], writes it to the settings file and records the change in the log.
     *
     * Persisted rather than kept in memory so that turning recording off is still off tomorrow,
     * which is the entire point of a switch on a privacy control.
     */
    @JvmStatic
    fun setSettings(context: Context, next: Settings) {
        synchronized(lock) {
            val applied = next.copy(
                keepDays = next.keepDays.coerceIn(MIN_KEEP_DAYS, MAX_KEEP_DAYS),
                maxFileSizeMiB = next.maxFileSizeMiB.coerceIn(MIN_SIZE_MIB, MAX_SIZE_MIB),
            )
            val wasRecording = current.recordAutomatically
            current = applied
            saveSettings(context, applied)

            if (!installed) return
            if (!applied.recordAutomatically) {
                // Closed rather than only filtered: with recording off there should be nothing to
                // come back to, and an open handle is an open handle.
                closeFile()
                return
            }
            if (wasRecording) {
                pruneOldFiles()
                return
            }
            failedOpens = 0
            if (ensureOpen(context)) {
                // Not a header: nothing restarted. Writing a second "log started" block here
                // would put a second false start time in the middle of one run, and a report
                // quoting this file would carry it. Through appendLine rather than writeRaw:
                // the line needs its newline, and the file it lands in still has to roll over
                // when this one takes it past its ceiling.
                appendLine(
                    formatLine(
                        Level.INFO, "logging", "[logging.resumed] recording turned back on",
                        Thread.currentThread().id, Date(), current,
                    ),
                )
            }
        }
    }

    // --------------------------------------------------------------- writing a line

    @JvmStatic
    fun debug(category: String, message: String) = write(Level.DEBUG, category, message)

    @JvmStatic
    fun info(category: String, message: String) = write(Level.INFO, category, message)

    @JvmStatic
    fun warning(category: String, message: String) = write(Level.WARNING, category, message)

    @JvmStatic
    fun error(category: String, message: String) = write(Level.ERROR, category, message)

    /**
     * Records a named moment with its fields, rather than a sentence.
     *
     * `event("broadcast.started", mapOf("port" to "53525"))` writes
     * `[broadcast.started] port=53525`, which is greppable, countable and comparable between the
     * two apps. Sentences are for the user; the things worth searching for are events.
     */
    @JvmStatic
    @JvmOverloads
    fun event(name: String, fields: Map<String, String> = emptyMap()) {
        var line = "[$name]"
        for ((key, value) in fields) {
            line += " $key=${quoteIfNeeded(value)}"
        }
        write(Level.INFO, name, line)
    }

    @JvmStatic
    fun levelName(level: Level): String = when (level) {
        Level.DEBUG -> "Debug"
        Level.INFO -> "Info"
        Level.WARNING -> "Warning"
        Level.ERROR -> "Error"
    }

    /** Reads [name] back, case-insensitively, or null when it names no level. */
    @JvmStatic
    fun parseLevel(name: String): Level? = when (name.trim().lowercase(Locale.ROOT)) {
        "debug" -> Level.DEBUG
        "info" -> Level.INFO
        "warning", "warn" -> Level.WARNING
        "error" -> Level.ERROR
        else -> null
    }

    /** The five-character form that goes inside the brackets, padded so levels line up. */
    @JvmStatic
    fun levelTag(level: Level): String = when (level) {
        Level.DEBUG -> "DEBUG"
        Level.INFO -> "INFO "
        Level.WARNING -> "WARN "
        Level.ERROR -> "ERROR"
    }

    // ------------------------------------------------------------------ formatting

    /** The timestamp as it appears at the front of a line. */
    @JvmStatic
    fun formatTimestamp(date: Date, settings: Settings): String {
        val pattern = buildString {
            append("yyyy-MM-dd ")
            append(if (settings.twelveHourClock) "hh:mm:ss" else "HH:mm:ss")
            if (settings.milliseconds) append(".SSS")
            append(if (settings.twelveHourClock) " a" else " Z")
        }
        val formatted = SimpleDateFormat(pattern, Locale.US).apply {
            timeZone = TimeZone.getDefault()
        }.format(date)
        if (settings.twelveHourClock) {
            return formatted.uppercase(Locale.US)
        }
        // `Z` gives +0200; the Windows log uses +02:00, and one format for both keeps a report
        // from the two platforms readable with the same eyes.
        val offsetAt = formatted.length - 5
        return formatted.substring(0, offsetAt) + formatted.substring(offsetAt, offsetAt + 3) +
            ":" + formatted.substring(offsetAt + 3)
    }

    /** One complete line, without the trailing newline. */
    @JvmStatic
    fun formatLine(
        level: Level,
        category: String,
        message: String,
        threadId: Long,
        date: Date,
        settings: Settings,
    ): String = "%s [%s] [%s] [T%d] %s".format(
        formatTimestamp(date, settings),
        levelTag(level),
        category.ifEmpty { "app" },
        threadId,
        message,
    )

    // -------------------------------------------------------------------- the files

    /** The folder the files are written to. */
    @JvmStatic
    fun directory(): File? = synchronized(lock) { folder }

    /** The file being written right now. */
    @JvmStatic
    fun currentFile(): File? = synchronized(lock) { folder?.let { File(it, "$FILE_PREFIX${dayOf(Date())}.log") } }

    /** Every log file, newest first, including rolled-over parts. */
    @JvmStatic
    fun filesNewestFirst(): List<File> = synchronized(lock) {
        val dir = folder ?: return emptyList()
        val files = dir.listFiles { file -> file.name.startsWith(FILE_PREFIX) && file.name.endsWith(".log") }
        files.orEmpty().sortedByDescending { it.name }
    }

    /** Bytes in the file being written, which a report can quote as how much was recorded. */
    @JvmStatic
    fun currentFileSize(): Long = synchronized(lock) { bytesWritten }

    /**
     * The last [maxBytes] of the log, oldest file first so it reads in the order things happened.
     *
     * @param newestFileOnly when true, only today's file is read: the usual case for "what just
     *        happened", and what keeps a report from quoting a week of noise.
     * @param filesUsed filled with the files that contributed, so the report can name them.
     */
    @JvmStatic
    @JvmOverloads
    fun tail(
        maxBytes: Int,
        newestFileOnly: Boolean,
        filesUsed: MutableList<File>? = null,
    ): String {
        if (maxBytes <= 0) return ""
        var ordered = filesNewestFirst().reversed()
        if (newestFileOnly && ordered.size > 1) {
            ordered = listOf(ordered.last())
        }
        val out = StringBuilder()
        var budget = maxBytes
        for (file in ordered) {
            if (budget <= 0) break
            val text = try {
                val bytes = file.readBytes()
                val take = minOf(budget, bytes.size)
                String(bytes, bytes.size - take, take, Charsets.UTF_8)
            } catch (error: IOException) {
                continue
            }
            if (text.isEmpty()) continue
            out.append(text)
            budget -= minOf(budget, file.length().toInt())
            filesUsed?.add(file)
        }
        return out.toString()
    }

    /** Deletes the files older than [Settings.keepDays]. Exposed for the tests. */
    @JvmStatic
    fun pruneOldFiles() {
        synchronized(lock) {
            val dir = folder ?: return
            val cutoff = System.currentTimeMillis() - current.keepDays * MILLIS_PER_DAY
            for (file in dir.listFiles { f -> f.name.startsWith(FILE_PREFIX) } ?: emptyArray()) {
                val day = dayFromFileName(file.name) ?: continue
                if (day < cutoff) {
                    file.delete()
                }
            }
        }
    }

    // ----------------------------------------------------------------- the plumbing

    private fun write(level: Level, category: String, message: String) {
        val line = synchronized(lock) {
            if (!installed || !current.recordAutomatically) return
            if (level.ordinal < current.minimumLevel.ordinal) return
            formatLine(level, category, message, Thread.currentThread().id, Date(), current)
        }
        // Logcat first: if the file cannot be written the developer still sees it, and the two
        // never drift because they are the same string.
        Log.println(level.toAndroidPriority(), category, message)
        appendLine(line)
    }

    private fun appendLine(line: String) {
        synchronized(lock) {
            if (!ensureOpen(null)) return
            if (bytesWritten + line.length.toLong() + 1 > current.maxFileSizeMiB * BYTES_PER_MIB) {
                rotate()
                if (!ensureOpen(null)) return
            }
            writeRaw(line + "\n")
        }
    }

    private fun writeRaw(text: String) {
        synchronized(lock) {
            val target = stream ?: return
            val bytes = text.toByteArray(Charsets.UTF_8)
            try {
                target.write(bytes)
                target.flush()
                bytesWritten += bytes.size
            } catch (error: IOException) {
                // A failed write must not take the app down: the log is a diagnostic, and losing
                // one line is far better than losing the broadcast.
                closeFile()
                failedOpens++
            }
        }
    }

    /**
     * Opens today's file if it is not already open.
     *
     * @param context used only to reach the folder on the first call; after that the folder is
     *        already known and the file can be reopened without it.
     */
    private fun ensureOpen(context: Context?): Boolean {
        if (failedOpens >= OPEN_ATTEMPTS_BEFORE_GIVING_UP) return false
        val today = dayOf(Date())
        if (stream != null && openDate == today) return true
        closeFile()

        val dir = folder ?: return false
        if (!dir.exists() && !dir.mkdirs()) {
            failedOpens++
            return false
        }
        val file = File(dir, "$FILE_PREFIX$today.log")
        // Appended, never truncated: a second run on the same day adds to what the first wrote,
        // and the ceiling has to count the whole file.
        return try {
            stream = FileOutputStream(file, true)
            openDate = today
            bytesWritten = file.length()
            true
        } catch (error: IOException) {
            failedOpens++
            false
        }
    }

    private fun closeFile() {
        try {
            stream?.flush()
            stream?.close()
        } catch (error: IOException) {
            // Nothing useful to do: the handle is being dropped either way.
        }
        stream = null
        openDate = null
    }

    /** Moves the full file aside and starts a new one, keeping a few older parts. */
    private fun rotate() {
        val dir = folder ?: return
        val file = File(dir, "$FILE_PREFIX$openDate.log")
        closeFile()
        if (!file.exists()) return
        for (index in MAX_ROLLOVERS - 1 downTo 1) {
            val from = File(dir, "$file.$index")
            if (!from.exists()) continue
            val to = File(dir, "$file.${index + 1}")
            to.delete()
            from.renameTo(to)
        }
        val first = File(dir, "$file.1")
        first.delete()
        file.renameTo(first)
    }

    private fun sessionHeader(settings: Settings): String {
        val rule = "=".repeat(80)
        val version = "unknown"
        return listOf(
            rule,
            "LocalStream log",
            "version    : $version",
            "started    : ${formatTimestamp(Date(), settings)}",
            "session    : $sessionId",
            "device     : ${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}",
            "android    : ${android.os.Build.VERSION.RELEASE} (API ${android.os.Build.VERSION.SDK_INT})",
            "host       : ${System.getProperty("java.net.InetAddress.getLocalHost().hostName").orEmpty()}",
            "settings   : recording ${if (settings.recordAutomatically) "on" else "off"}, " +
                "level ${levelName(settings.minimumLevel)}, keep ${settings.keepDays} day(s), " +
                "${settings.maxFileSizeMiB} MiB per file",
            rule,
        ).joinToString("\n") + "\n"
    }

    private fun loadSettings(context: Context): Settings {
        val stored = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val defaults = Settings()
        return Settings(
            recordAutomatically = stored.getBoolean(KEY_RECORD, defaults.recordAutomatically),
            minimumLevel = parseLevel(stored.getString(KEY_LEVEL, null) ?: "")
                ?: defaults.minimumLevel,
            milliseconds = stored.getBoolean(KEY_MILLIS, defaults.milliseconds),
            twelveHourClock = stored.getBoolean(KEY_TWELVE, defaults.twelveHourClock),
            keepDays = stored.getInt(KEY_KEEP, defaults.keepDays)
                .coerceIn(MIN_KEEP_DAYS, MAX_KEEP_DAYS),
            maxFileSizeMiB = stored.getInt(KEY_SIZE, defaults.maxFileSizeMiB)
                .coerceIn(MIN_SIZE_MIB, MAX_SIZE_MIB),
        )
    }

    private fun saveSettings(context: Context, settings: Settings) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
            .putBoolean(KEY_RECORD, settings.recordAutomatically)
            .putString(KEY_LEVEL, levelName(settings.minimumLevel))
            .putBoolean(KEY_MILLIS, settings.milliseconds)
            .putBoolean(KEY_TWELVE, settings.twelveHourClock)
            .putInt(KEY_KEEP, settings.keepDays)
            .putInt(KEY_SIZE, settings.maxFileSizeMiB)
            .apply()
    }

    private fun Level.toAndroidPriority(): Int = when (this) {
        Level.DEBUG -> Log.DEBUG
        Level.INFO -> Log.INFO
        Level.WARNING -> Log.WARN
        Level.ERROR -> Log.ERROR
    }

    /** Quotes a value that contains a space, so a line is never ambiguous to split apart. */
    private fun quoteIfNeeded(value: String): String =
        if (value.contains(' ')) "\"$value\"" else value

    /** `yyyy-MM-dd` for [date] in the device's own timezone, which is what the files are named by. */
    private fun dayOf(date: Date): String =
        SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { timeZone = TimeZone.getDefault() }
            .format(date)

    /** The day a file belongs to, read from its name rather than its modified time. */
    private fun dayFromFileName(name: String): Long? {
        val start = name.indexOf(FILE_PREFIX)
        if (start != 0) return null
        val end = name.indexOf(".log")
        if (end <= start + FILE_PREFIX.length) return null
        val day = name.substring(start + FILE_PREFIX.length, end)
        val parsed = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            .apply { timeZone = TimeZone.getDefault(); isLenient = false }
            .runCatching { parse(day) }
            .getOrNull() ?: return null
        return calendarMillis(parsed)
    }

    private fun calendarMillis(date: Date): Long {
        val midnight = Calendar.getInstance().apply {
            time = date
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        return midnight.timeInMillis
    }

    private const val FILE_PREFIX = "LocalStream-"
    private const val BYTES_PER_MIB = 1024L * 1024L
    private const val MILLIS_PER_DAY = 24L * 60L * 60L * 1000L
    private const val KEY_RECORD = "recordAutomatically"
    private const val KEY_LEVEL = "minimumLevel"
    private const val KEY_MILLIS = "milliseconds"
    private const val KEY_TWELVE = "twelveHourClock"
    private const val KEY_KEEP = "keepDays"
    private const val KEY_SIZE = "maxFileSizeMiB"
}