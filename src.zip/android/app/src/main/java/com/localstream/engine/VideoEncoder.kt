﻿package com.localstream.engine

import android.content.Context
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.os.Build
import android.view.Surface
import com.localstream.logging.AppLog
import com.localstream.protocol.H264Rtp
import java.nio.ByteBuffer
import java.util.concurrent.atomic.AtomicBoolean

/** Encoder settings, all of which are published in the mDNS TXT record. */
data class VideoConfig(
    val width: Int = 1280,
    val height: Int = 720,
    val frameRate: Int = 30,
    val bitrateKbps: Int = 1500,
    val keyframeIntervalSeconds: Int = 2
) {
    init {
        require(width > 0 && height > 0) { "Video dimensions must be positive" }
        require(frameRate in 1..60) { "Frame rate must be between 1 and 60" }
    }
}

/**
 * H.264 encoder fed from a [Surface].
 *
 * Surface input keeps the capture and the encode entirely on the GPU: frames are never
 * copied back into app memory. The encoded output is pulled in AVCC form, which is exactly
 * what `H264Rtp.splitAvcc` expects.
 */
class VideoEncoder(private val context: Context) {

    private var codec: MediaCodec? = null
    private var inputSurface: Surface? = null
    private var drainThread: Thread? = null
    private val running = AtomicBoolean(false)
    private val draining = AtomicBoolean(false)

    private var onFrame: ((ByteArray) -> Unit)? = null
    private var onParameterSets: ((sps: ByteArray, pps: ByteArray) -> Unit)? = null

    /** The most recent parameter sets, repeated in-band on every keyframe. See [withParameterSets]. */
    @Volatile
    private var latestSps: ByteArray? = null

    @Volatile
    private var latestPps: ByteArray? = null

    /** Keeps the keyframe note to one line per session. */
    private var reportedKeyFrame = false

    /** Counts frames actually produced, for the bitrate and stats readouts. */
    @Volatile
    var framesEncoded: Long = 0
        private set

    /**
     * Output buffers the encoder produced but which could not be sent on.
     *
     * Some encoders emit an empty or unattached output buffer when they have nothing
     * ready; forwarding one would put a zero-length RTP packet on the wire, so they are
     * counted here instead. A rising figure means the device cannot encode at the
     * configured resolution and frame rate.
     */
    @Volatile
    var droppedFrames: Long = 0
        private set

    /**
     * The surface a capture source should render into. Only valid between [prepare] and
     * [release].
     */
    fun surface(): Surface? = inputSurface

    /** Creates the codec and its input surface. Does not start the drain thread. */
    fun prepare(config: VideoConfig) {
        val format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, config.width, config.height).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, config.bitrateKbps * 1000)
            setInteger(MediaFormat.KEY_FRAME_RATE, config.frameRate)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, config.keyframeIntervalSeconds)
            setInteger(
                MediaFormat.KEY_COLOR_STANDARD,
                MediaFormat.COLOR_STANDARD_BT601_NTSC
            )
            setInteger(MediaFormat.KEY_COLOR_RANGE, MediaFormat.COLOR_RANGE_LIMITED)
            setInteger(MediaFormat.KEY_COLOR_TRANSFER, MediaFormat.COLOR_TRANSFER_SDR_VIDEO)
            // Lets the encoder drop to a lower operating point when the screen is static,
            // which matters a great deal for a mostly-text screen share.
            setInteger(MediaFormat.KEY_OPERATING_RATE, 0)
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            // Keep producing frames at the configured rate even when the capture surface
            // has nothing new to offer. Screen capture only pushes buffers when the screen
            // visibly changes, so a still screen means the encoder emits nothing at all and a
            // viewer is left with a blank picture rather than a still one. This is the
            // encoder-side way to say "repeat the last frame"; it costs a keyframe-sized
            // packet per interval on a still screen, which is the trade for a receiver
            // always having something to draw.
            format.setLong(MediaFormat.KEY_REPEAT_PREVIOUS_FRAME_AFTER, 1_000_000L)
        }

        val encoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
        encoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        inputSurface = encoder.createInputSurface()
        encoder.start()
        codec = encoder
    }

    fun start(onFrame: (ByteArray) -> Unit, onParameterSets: (sps: ByteArray, pps: ByteArray) -> Unit) {
        val encoder = codec ?: error("prepare() must be called before start()")
        this.onFrame = onFrame
        this.onParameterSets = onParameterSets
        if (!running.compareAndSet(false, true)) return
        drainThread = Thread({ drain(encoder) }, "LocalStream-VideoEncode").apply {
            priority = Thread.MAX_PRIORITY
            start()
        }
    }

    private fun drain(encoder: MediaCodec) {
        val bufferInfo = MediaCodec.BufferInfo()

        // `draining` is cleared by release(), which then closes the codec; this flag makes
        // the loop exit instead of throwing when that happens mid-block.
        draining.set(true)
        while (running.get() && draining.get()) {
            val index = try {
                encoder.dequeueOutputBuffer(bufferInfo, DEQUEUE_TIMEOUT_US)
            } catch (e: IllegalStateException) {
                break
            }

            when {
                index == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                    // csd-0 and csd-1 are delivered on the first frame, and some encoders
                    // also emit them as a codec-config buffer; both are covered.
                    extractParameterSets(encoder.outputFormat)
                }

                index >= 0 -> {
                    val buffer = encoder.getOutputBuffer(index)
                    if (buffer != null && bufferInfo.size > 0) {
                        val isConfig = (bufferInfo.flags and
                            (MediaCodec.BUFFER_FLAG_CODEC_CONFIG or MediaCodec.BUFFER_FLAG_KEY_FRAME)) ==
                            MediaCodec.BUFFER_FLAG_CODEC_CONFIG

                        if (isConfig) {
                            // Parameter sets also arrive here on some encoders. The codec
                            // has already advertised them via INFO_OUTPUT_FORMAT_CHANGED on
                            // the devices this targets, so this is only a fallback.
                            extractParameterSets(encoder.outputFormat)
                        } else {
                            val data = ByteArray(bufferInfo.size)
                            buffer.position(bufferInfo.offset)
                            buffer.limit(bufferInfo.offset + bufferInfo.size)
                            buffer.get(data)
                            val isKeyFrame = bufferInfo.flags and
                                MediaCodec.BUFFER_FLAG_KEY_FRAME != 0
                            framesEncoded++
                            val outbound = H264Rtp.toAvcc(data).let { avcc ->
                                if (isKeyFrame) {
                                    H264Rtp.withParameterSets(avcc, latestSps, latestPps)
                                } else {
                                    avcc
                                }
                            }
                            if (isKeyFrame && !reportedKeyFrame) {
                                reportedKeyFrame = true
                                AppLog.info(
                                    "VideoEncoder",
                                    "Keyframe: ${data.size} bytes in, ${outbound.size} bytes out" +
                                        " (SPS=${latestSps?.size}, PPS=${latestPps?.size})"
                                )
                            }
                            onFrame?.invoke(outbound)
                        }
                    } else {
                        // Nothing usable came out; counting it makes a struggling device
                        // visible in the stats instead of silently looking healthy.
                        droppedFrames++
                    }
                    encoder.releaseOutputBuffer(index, false)
                }
            }
        }
    }

    private fun extractParameterSets(format: MediaFormat) {
        // MediaFormat exposes no constants for the codec-specific-data keys; these are the
        // literal strings defined by the platform's AVC encoder contract.
        val sps = format.byteArrayOf("csd-0")?.let(H264Rtp::stripStartCode) ?: return
        val pps = format.byteArrayOf("csd-1")?.let(H264Rtp::stripStartCode) ?: return
        if (sps.isEmpty() || pps.isEmpty()) return
        latestSps = sps
        latestPps = pps
        AppLog.info("VideoEncoder", "Parameter sets from output format: SPS=${sps.size} bytes, PPS=${pps.size} bytes")
        onParameterSets?.invoke(sps, pps)
    }

    /**
     * Reads a codec-specific-data buffer from a format.
     *
     * `MediaFormat` has no typed accessor for csd entries; they are stored as ByteBuffers
     * positioned at the end after parsing, so the bytes have to be read from the current
     * position rather than the whole buffer.
     */
    private fun MediaFormat.byteArrayOf(key: String): ByteArray? {
        val buffer = getByteBuffer(key) ?: return null
        val data = ByteArray(buffer.remaining())
        buffer.get(data)
        return data
    }

    /**
     * Asks for an IDR on the next frame.
     *
     * This is the single biggest contributor to join latency: without it a receiver that
     * connects mid-GOP has to wait for the periodic keyframe interval to expire.
     */
    fun requestKeyframe() {
        val encoder = codec ?: return
        try {
            encoder.setParameters(
                android.os.Bundle().apply {
                    putInt(MediaCodec.PARAMETER_KEY_REQUEST_SYNC_FRAME, 0)
                }
            )
        } catch (e: IllegalStateException) {
            AppLog.warning("VideoEncoder", "Could not request a keyframe: $e")
        }
    }

    /**
     * Applies a new bitrate without tearing the encoder down.
     *
     * Reconfiguring would reset the encoder and force an IDR, which would be visible to
     * every receiver as a freeze.
     */
    fun setBitrate(bitrateKbps: Int) {
        val encoder = codec ?: return
        try {
            encoder.setParameters(
                android.os.Bundle().apply {
                    putInt(MediaCodec.PARAMETER_KEY_VIDEO_BITRATE, bitrateKbps * 1000)
                }
            )
        } catch (e: IllegalStateException) {
            AppLog.warning("VideoEncoder", "Could not change bitrate: $e")
        }
    }

    fun setFrameRate(frameRate: Int) {
        val encoder = codec ?: return
        try {
            encoder.setParameters(
                android.os.Bundle().apply {
                    putInt(MediaFormat.KEY_FRAME_RATE, frameRate)
                }
            )
        } catch (e: IllegalStateException) {
            AppLog.warning("VideoEncoder", "Could not change frame rate: $e")
        }
    }

    fun stop() {
        running.set(false)
        drainThread?.join(1000)
        drainThread = null
        onFrame = null
        onParameterSets = null
    }

    fun release() {
        stop()
        draining.set(false)
        runCatching { inputSurface?.release() }
        inputSurface = null
        runCatching { codec?.stop() }
        runCatching { codec?.release() }
        codec = null
        // Belong to the codec that has just gone: a later session must not prepend the
        // previous one's resolution's parameter sets to its keyframes.
        latestSps = null
        latestPps = null
    }

    companion object {
        private const val DEQUEUE_TIMEOUT_US = 10_000L
        private const val HD_COLOR_STANDARD_HEIGHT = 720
    }
}
