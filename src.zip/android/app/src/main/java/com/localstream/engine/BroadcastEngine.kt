package com.localstream.engine

import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjection
import com.localstream.logging.AppLog
import com.localstream.net.ControlServer
import com.localstream.net.RtpSender
import com.localstream.protocol.ControlMessage
import com.localstream.protocol.LocalStream
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.net.InetAddress
import java.util.concurrent.atomic.AtomicBoolean

/** Everything the UI needs to know about a running or prospective broadcast. */
data class BroadcastState(
      val isBroadcasting: Boolean = false,
      val mode: String = LocalStream.MODE_AUDIO_VIDEO,
      val isIdleAdvertised: Boolean = false,
      /**
       * The port a viewer connects to, or 0 before the control server is listening.
       *
       * Surfaced to the UI because it is the one thing a viewer needs when discovery cannot
       * find this broadcast: they have to be able to read it off this screen and type it in.
       */
val controlPort: Int = 0,
      val receiverCount: Int = 0,
    val framesPerSecond: Int = 0,
    val kilobitsPerSecond: Int = 0,
    val droppedFrames: Long = 0,
    val error: String? = null,
    /**
     * Who may join. Carried in the state rather than held by the UI so the two cannot disagree:
     * the UI writes it through [BroadcastEngine.setAccess] and reads the accepted value back
     * here, so a refused change is visible rather than merely ignored.
     */
    val accessMode: String = ControlMessage.ACCESS_PUBLIC
)

/**
 * The broadcast engine.
 *
 * Owns the capture sources, the encoders, the RTP sender and the control server, and keeps
 * them consistent with each other across mode changes.
 *
 * The key design decision is that the video pipeline is started once, at the beginning of
 * a broadcast, and simply *left running* when the user switches to audio-only. Stopping and
 * restarting it would force a fresh IDR and drop the audio clock, so a receiver would see
 * a freeze every time the presenter toggled the mode. In audio-only the encoder output is
 * simply not forwarded.
 */
class BroadcastEngine(
    private val context: Context,
    private val scope: CoroutineScope,
    private val lifecycleOwner: EngineLifecycleOwner,
    private val deviceName: String
) {

    private val videoEncoder = VideoEncoder(context)
    private val audioEncoder = AudioCaptureEncoder()
    private val screenSource = ScreenCaptureSource(context)
    private var cameraSource: CameraCaptureSource? = null

    /**
     * The consent-granted capture permission, shared by screen mirroring and device-audio
     * capture because Android allows only one projection per approval.
     */
    private val projectionController = ProjectionController(context)

    private val rtpSender = RtpSender()

    /**
     * Mirrors [ControlServer.port].
     *
     * Held separately because the control server's own callbacks need to read the port, and
     * referencing the property from inside its initialiser makes the compiler chase a
     * recursive type.
     */
    @Volatile
    private var publishedControlPort: Int = 0

    // The type is written out because the access callbacks answer a viewer by calling back into
    // this same server: leaving it to inference makes the compiler chase its own tail.
    private val controlServer: ControlServer = ControlServer(
        scope = scope,
        descriptionProvider = { description() },
        sdpProvider = {
            LocalStream.buildSdp(
                description(),
                publishedControlPort,
                rtpSender.ssrcVideo,
                rtpSender.ssrcAudio
            )
        },
        audioSsrcProvider = { rtpSender.ssrcAudio },
        videoSsrcProvider = { rtpSender.ssrcVideo },
        onOffer = { address, audioPort, videoPort -> rtpSender.addTarget(address, audioPort, videoPort) },
        onRemove = { address, audioPort, videoPort -> rtpSender.removeTarget(address, audioPort, videoPort) },
        onKeyframeRequest = { videoEncoder.requestKeyframe() },
        onBitrateRequest = { videoKbps, audioKbps -> applyBitrate(videoKbps, audioKbps) },
        onModeRequest = { requested ->
            // The local presenter owns the mode, so a receiver's request is declined by
            // leaving the mode alone. ControlServer answers with the authoritative mode,
            // which tells the requester it was declined without an extra message type.
            AppLog.info("BroadcastEngine", "Receiver asked for mode $requested; the presenter decides")
        },
        onReceiverStats = { /* surfaced in the UI through BroadcastState */ },
        onReceiverConnected = { name ->
            // Announced rather than merely counted: a presenter needs to know someone
            // arrived, and a screen reader is the only channel that reaches them when the
            // app is not in the foreground.
            announce("$name connected")
        },
        onReceiverDisconnected = { name ->
            announce("$name disconnected")
        },
        onAccessRequest = ::raiseAccessRequest,
        onAccessRequestCancelled = { requestKey, name -> dropAccessRequest(requestKey, name) }
    )

    /**
     * Hands a viewer request to the UI, or refuses it when nothing can answer.
     *
     * A method rather than an inline lambda because it has to call back into [controlServer] to
     * refuse: a lambda in the server's own initialiser would be reading the property that is
     * still being constructed. A bound reference costs nothing at that point - the reference is
     * taken, not called - and by the time a request can arrive the field is long since assigned.
     *
     * Raised on a session coroutine, so it is handed to the UI rather than acted on here. The UI
     * is responsible for prompting in a way that reaches a presenter whose app is in the
     * background; the engine only knows that someone is waiting.
     */
    private fun raiseAccessRequest(requestKey: Long, name: String) {
        val listener = accessRequestListener
        if (listener != null) {
            listener(requestKey, name)
            return
        }
        // Nobody can answer, so the viewer is refused rather than left waiting for a decision
        // that cannot come. Counted as a rejection, because from the viewer's side it is one:
        // they asked and were turned down.
        AppLog.warning("BroadcastEngine", "Refusing $name: nothing is listening for access requests")
        controlServer.resolveAccessRequest(requestKey, allow = false)
    }

/**
     * Set by the UI to raise a prompt. Null when nothing is listening, which the control server
     * treats as "nobody can answer" and so refuses the viewer rather than leaving them waiting
     * for a decision that cannot come.
     */
    @Volatile
    var accessRequestListener: ((requestKey: Long, name: String) -> Unit)? = null

    /**
     * Set by the UI to withdraw a prompt whose viewer has gone.
     *
     * The control server raises this when a waiting viewer's connection ends before the
     * presenter answers. Without it the prompt would outlive the request and sit in front of
     * every later one, so the presenter is asked about a viewer who is no longer there.
     */
    @Volatile
    var accessRequestCancelledListener: ((requestKey: Long, name: String) -> Unit)? = null

    private fun dropAccessRequest(requestKey: Long, name: String) {
        accessRequestCancelledListener?.invoke(requestKey, name)
    }

    /**
     * The access mode currently in force, mirrored into [state] for the UI to read back.
     * Read by the UI after a refused change so it can put its control where the broadcast is.
     */
    val accessMode: String get() = controlServer.accessMode

    /**
     * Changes who may join, live. Viewers already admitted keep their stream.
     *
     * @return false when [password] does not fit a password-protected broadcast, in which case
     *   nothing changes. Validated here rather than only in the UI so a half-typed password can
     *   never reach the wire.
     */
    fun setAccess(mode: String, password: String): Boolean {
        if (mode != ControlMessage.ACCESS_PUBLIC &&
            mode != ControlMessage.ACCESS_APPROVAL &&
            mode != ControlMessage.ACCESS_PASSWORD
        ) {
            return false
        }
        if (mode == ControlMessage.ACCESS_PASSWORD && !ControlMessage.isValidPassword(password)) {
            return false
        }
        controlServer.setAccess(mode, password)
        publishState()
        return true
    }

    /** Answers a pending viewer request. See [accessRequestListener]. */
    fun resolveAccessRequest(requestKey: Long, allow: Boolean) {
        controlServer.resolveAccessRequest(requestKey, allow)
    }

    /**
     * Shuts the broadcast to viewers while a password is still being chosen.
     *
     * Called the moment password mode is picked, before a usable password exists. The alternative
     * is leaving the control channel on its previous - possibly public - setting until the
     * password is applied, which admits viewers to a broadcast the presenter has already said
     * should be locked. The broadcast stays shut until [setAccess] hands over a real password.
     */
    fun holdAccessForPendingPassword() {
        controlServer.holdForPassword()
        publishState()
    }

    private val broadcasting = AtomicBoolean(false)
    private var mode = LocalStream.MODE_AUDIO_VIDEO
    private var videoSource = VideoSource.SCREEN
    private var audioSource = AudioSource.MICROPHONE
    private var normalizeAudio = false
    private var config = VideoConfig()

    @Volatile
    private var sessionId: String = LocalStream.newSessionId()

    var stateListener: ((BroadcastState) -> Unit)? = null
    var announcementListener: ((String) -> Unit)? = null

    /**
     * Asks the host for a fresh `MediaProjection` grant, calling the result with it.
     *
     * The engine cannot obtain one itself; the Activity must. Supplied by the ViewModel,
     * which in turn asks the Activity — the same route the initial broadcast start uses,
     * so there is one code path for the prompt rather than two.
     */
    var projectionRequester: ((resume: (Intent?) -> Unit) -> Unit)? = null

    @Volatile
    var state: BroadcastState = BroadcastState()
        private set

    fun description(): LocalStream.Description = LocalStream.Description(
        sessionId = sessionId,
        displayName = deviceName,
        mode = mode,
        live = broadcasting.get(),
        videoBitrateKbps = if (mode == LocalStream.MODE_AUDIO_ONLY) 0 else config.bitrateKbps,
        audioBitrateKbps = audioBitrateKbps,
        width = if (mode == LocalStream.MODE_AUDIO_ONLY) 0 else config.width,
        height = if (mode == LocalStream.MODE_AUDIO_ONLY) 0 else config.height,
        frameRate = if (mode == LocalStream.MODE_AUDIO_ONLY) 0 else config.frameRate,
        controlPort = publishedControlPort,
        audioPort = rtpSender.audioPort,
        videoPort = rtpSender.videoPort,
        audioChannels = if (audioSource == AudioSource.DEVICE) 2 else 1,
        sps = sps,
        pps = pps
    )

    private var audioBitrateKbps = 48
    private var sps: ByteArray? = null
    private var pps: ByteArray? = null

    /**
     * Opens the sockets and control server, then starts advertising as idle.
     *
     * Advertising before the user presses Start is deliberate: a viewer can see the device
     * in the list and know a presenter is about to go live, which a screen-reader user
     * cannot infer from an empty list.
     */
    fun prepare() {
        // The system can revoke capture at any time from the casting notification. Nothing can
        // usefully continue once that happens, so the broadcast is ended rather than left with
        // a frozen screen or silent audio. The callback arrives on the projection's own thread.
        projectionController.onStopped = {
            scope.launch { stop() }
        }
        sessionId = LocalStream.newSessionId()
        rtpSender.open(withVideo = true)
        rtpSender.frameRate = config.frameRate
        controlServer.open()
        publishedControlPort = controlServer.port
        publishState()
    }

    /**
     * Starts the pipeline.
     *
     * @param projectionToken the MediaProjection result. Required when the screen is being
     *        shared or the device's own audio is the source, because both are authorised by
     *        the same capture consent.
     */
    fun start(projectionToken: Intent?, onError: (String) -> Unit) {
        if (!broadcasting.compareAndSet(false, true)) return

        try {
            rtpSender.frameRate = config.frameRate
            videoEncoder.prepare(config)
            val surface = videoEncoder.surface()
                ?: throw IllegalStateException("The video encoder produced no surface.")

            // Screen mirroring and device-audio capture both need the same projection, and the
            // consent token can only be redeemed once, so it is acquired here and shared.
            val needsScreen =
                mode == LocalStream.MODE_AUDIO_VIDEO && videoSource == VideoSource.SCREEN
            val needsDeviceAudio = audioSource == AudioSource.DEVICE
            val projection: MediaProjection? = if (needsScreen || needsDeviceAudio) {
                val token = projectionToken
                    ?: throw IllegalStateException(
                        if (needsScreen) {
                            "Screen capture permission is required."
                        } else {
                            "Screen-capture permission is required to broadcast the device's sound."
                        }
                    )
                projectionController.acquire(token)
            } else {
                null
            }

            if (mode == LocalStream.MODE_AUDIO_VIDEO) {
                // CameraX binds to a lifecycle; the owner is started here rather than at
                // construction so a merely-prepared engine holds no camera binding.
                lifecycleOwner.start()
                when (videoSource) {
                    VideoSource.SCREEN -> screenSource.start(
                        projection
                            ?: throw IllegalStateException("Screen capture permission is required."),
                        surface,
                        null
                    )
                    VideoSource.CAMERA -> {
                        val camera = CameraCaptureSource(context, lifecycleOwner)
                        cameraSource = camera
                        camera.start(surface)
                    }
                }
            }

            videoEncoder.start(
                onFrame = { accessUnit ->
                    // In audio-only the frame is discarded here. The encoder keeps running
                    // so that switching back does not cost a keyframe.
                    if (mode == LocalStream.MODE_AUDIO_VIDEO) {
                        rtpSender.sendVideo(accessUnit)
                    }
                },
                onParameterSets = { newSps, newPps ->
                    sps = newSps
                    pps = newPps
                }
            )

            audioEncoder.start(
                onFrame = { opusPacket -> rtpSender.sendAudio(opusPacket) },
                bitrateKbps = audioBitrateKbps,
                // Device audio is a stereo mix; the microphone is captured mono and Opus is
                // happy carrying either, so the channel count follows the source.
                channels = if (needsDeviceAudio) 2 else 1,
                source = audioSource,
                projection = if (needsDeviceAudio) projection else null,
                normalize = normalizeAudio
            )

            announce("Broadcast started")
            startStatsSampling()
            publishState()
        } catch (e: Exception) {
            broadcasting.set(false)
            AppLog.error("BroadcastEngine", "Could not start broadcasting: $e")
            stopSilently()
            onError(e.message ?: "Could not start broadcasting.")
            publishState(error = e.message)
        }
    }

    fun stop() {
        if (!broadcasting.compareAndSet(true, false)) {
            return
        }
        statsJob?.cancel()
        statsJob = null
        measuredFramesPerSecond = 0
        measuredKbps = 0
        announce("Broadcast stopped")
        stopSilently()
        // Tell every connected viewer the broadcast is over and close their control sockets.
        // Without this the socket stays open, the viewer keeps showing "Connected." over a
        // stream that has no media left, and its receive page never learns to search again.
        // The listener itself stays open: the device is still advertised as idle, so a new
        // viewer can connect and wait for the next Start.
        controlServer.closeAll(ControlMessage.BYE_SHUTDOWN)
        // Rejections and bans belong to the broadcast, not to the app: a viewer who was barred
        // from the session that just ended is judged afresh by the next one.
        controlServer.clearAccessHistory()
        publishState()
    }

    private fun stopSilently() {
        // Moved before releasing the camera: CameraX unbinds by observing the lifecycle, and
        // it must still be alive to see the teardown.
        cameraSource?.stop()
        cameraSource = null
        lifecycleOwner.stop()

        audioEncoder.release()
        screenSource.stop()
        // Released last: audio capture may still have been reading from it, and screen capture
        // may be holding virtual displays off it (released just above).
        projectionController.stop()
        videoEncoder.release()
        sps = null
        pps = null
        rtpSender.removeAllTargets()
    }

    /**
     * Switches between audio-only and audio+video.
     *
     * The audio track is untouched in both directions, so a viewer hears no glitch and the
     * video decoder is created or destroyed without renegotiating anything.
     *
     * Turning video *off* is immediate. Turning it *back on* may need a user gesture: a
     * `MediaProjection` grant cannot be reused, and Android only issues a new one from a
     * foreground Activity. When the source is the camera this is transparent; when it is the
     * screen, [projectionRequester] is invoked and the switch completes once the user
     * responds. Either way the broadcast itself keeps running throughout.
     */
    fun setMode(newMode: String, onError: (String) -> Unit) {
        if (newMode == mode) return
        if (newMode != LocalStream.MODE_AUDIO_ONLY && newMode != LocalStream.MODE_AUDIO_VIDEO) return

        if (newMode == LocalStream.MODE_AUDIO_VIDEO && !broadcasting.get()) {
            // Nothing to enable: the next start will pick the mode up from here.
            mode = newMode
            announce("Mode: audio and video")
            publishState()
            return
        }

        if (newMode == LocalStream.MODE_AUDIO_VIDEO && !videoPipelineRunning()) {
            // Turning video on mid-broadcast means starting capture for the first time.
            val surface = videoEncoder.surface()
            if (surface == null) {
                onError("The video encoder is not running. Stop and restart the broadcast.")
                return
            }
            try {
                when (videoSource) {
                    VideoSource.CAMERA -> {
                        val camera = CameraCaptureSource(context, lifecycleOwner)
                        cameraSource = camera
                        camera.start(surface)
                    }
                    VideoSource.SCREEN -> {
                        val existing = projectionController.active
                        if (existing != null) {
                            // A projection is already held, typically for device-audio capture,
                            // so screen sharing starts from it without a second prompt.
                            screenSource.start(existing, surface, null)
                            completeModeSwitch(newMode)
                            return
                        }
                        val request = projectionRequester
                        if (request == null) {
                            onError(
                                "Screen capture permission has to be granted at broadcast start. " +
                                    "Stop the broadcast, then start again in audio and video mode."
                            )
                            return
                        }
                        // Announced before the prompt, so a screen-reader user knows why the
                        // system dialog is appearing over the app.
                        announce("Screen capture permission is needed to turn video back on")
                        request { token ->
                            if (token == null) {
                                onError(
                                    "Screen capture permission was not granted, so the " +
                                        "broadcast is staying audio only."
                                )
                            } else {
                                try {
                                    screenSource.start(
                                        projectionController.acquire(token),
                                        surface,
                                        null
                                    )
                                    completeModeSwitch(newMode)
                                } catch (e: Exception) {
                                    onError(e.message ?: "Screen capture could not be started.")
                                }
                            }
                        }
                        return
                    }
                }
            } catch (e: Exception) {
                onError(e.message ?: "The video source could not be started.")
                return
            }
        }

        completeModeSwitch(newMode)
    }

    /** The part of a mode switch that does not depend on capture having been (re)started. */
    private fun completeModeSwitch(newMode: String) {
        mode = newMode
        // Tell every receiver the authoritative state, then start or stop emitting.
        controlServer.sendModeChanged(mode)
        if (newMode == LocalStream.MODE_AUDIO_VIDEO) {
            videoEncoder.requestKeyframe()
        } else {
            // Capture is genuinely stopped, not merely muted: leaving MediaProjection or the
            // camera open in audio-only would keep the indicator light on for a user who
            // believes they have turned video off.
            screenSource.stop()
            cameraSource?.stop()
            cameraSource = null
            // If nothing else is using the projection - device-audio capture would be - release
            // it so the system's capture indicator goes away and the OS can reclaim it.
            if (audioSource != AudioSource.DEVICE) {
                projectionController.stop()
            }
        }
        announce(
            if (newMode == LocalStream.MODE_AUDIO_ONLY) "Mode: audio only"
            else "Mode: audio and video"
        )
        publishState()
    }

    private fun videoPipelineRunning(): Boolean =
        videoEncoder.surface() != null && (mode == LocalStream.MODE_AUDIO_VIDEO)

    private fun applyBitrate(videoKbps: Int?, audioKbps: Int?) {
        if (videoKbps != null && videoKbps > 0) {
            config = config.copy(bitrateKbps = videoKbps)
            videoEncoder.setBitrate(videoKbps)
        }
        if (audioKbps != null && audioKbps > 0) {
            audioBitrateKbps = audioKbps
            audioEncoder.setBitrate(audioKbps)
        }
    }

    fun setVideoConfig(newConfig: VideoConfig) {
        config = newConfig
        if (broadcasting.get()) {
            videoEncoder.setBitrate(newConfig.bitrateKbps)
            videoEncoder.setFrameRate(newConfig.frameRate)
            rtpSender.frameRate = newConfig.frameRate
        }
        publishState()
    }

    fun setAudioBitrate(kbps: Int) {
        audioBitrateKbps = kbps
        if (broadcasting.get()) audioEncoder.setBitrate(kbps)
    }

    fun setVideoSource(source: VideoSource) {
        videoSource = source
    }

    fun setAudioSource(source: AudioSource) {
        audioSource = source
    }

    fun setNormalizeAudio(enabled: Boolean) {
        normalizeAudio = enabled
    }

    /** Tears everything down, including discovery advertisement. */
    fun release() {
        stop()
        controlServer.closeAll(ControlMessage.BYE_SHUTDOWN)
        controlServer.close()
        rtpSender.close()
    }

    private fun publishState(error: String? = state.error) {
        state = BroadcastState(
            isBroadcasting = broadcasting.get(),
            mode = mode,
            isIdleAdvertised = !broadcasting.get() && publishedControlPort > 0,
            controlPort = publishedControlPort,
            receiverCount = controlServer.receiverCount,
            framesPerSecond = measuredFramesPerSecond,
            kilobitsPerSecond = measuredKbps,
            droppedFrames = videoEncoder.droppedFrames,
            error = error,
            // Read from the server rather than kept here, so a change made through any route
            // is reported the same way and this class holds no second copy to fall out of step.
            accessMode = controlServer.accessMode
        )
        stateListener?.invoke(state)
    }

    /**
     * Samples the encoders once a second to produce the rate figures.
     *
     * Rates are measured rather than read from configuration: a configured bitrate says
     * what the encoder was asked for, not what it achieved, and those differ whenever the
     * content is easy to encode or the device is thermal throttling. What a presenter
     * needs to see is the second one.
     */
    private fun startStatsSampling() {
        statsJob?.cancel()
        statsJob = scope.launch {
            var lastVideoFrames = 0L
            var lastAt = System.nanoTime()

            while (isActive) {
                delay(STATS_INTERVAL_MS)

                val now = System.nanoTime()
                val seconds = (now - lastAt) / 1_000_000_000.0
                if (seconds <= 0.0) continue

                val videoFrames = videoEncoder.framesEncoded

                val videoFps = if (mode == LocalStream.MODE_AUDIO_VIDEO) {
                    ((videoFrames - lastVideoFrames) / seconds).toInt()
                } else {
                    0
                }

                measuredFramesPerSecond = videoFps
                // The bitrate is sampled by the sender itself, which averages over the same
                // interval; asking it here keeps the figure on one clock.
                measuredKbps = rtpSender.currentBitrateKbps()

                lastVideoFrames = videoFrames
                lastAt = now

                publishState()

                // Pushed to the receivers as well as kept locally. A viewer is the one person
                // who can tell a stalled encoder from a stalled network -- their picture is the
                // only evidence -- and the Windows presenter sends exactly this, so a viewer
                // that connects to an Android broadcaster saw no figures at all without it.
                controlServer.sendStats(
                    ControlMessage.BroadcasterStats(
                        framesPerSecond = videoFps,
                        kilobitsPerSecond = measuredKbps,
                        packetLossPercent = 0.0,
                        receiverCount = controlServer.receiverCount.toLong(),
                        droppedFrames = 0L
                    )
                )
            }
        }
    }

    @Volatile
    private var measuredFramesPerSecond: Int = 0

    @Volatile
    private var measuredKbps: Int = 0

    private var statsJob: Job? = null

    private fun announce(message: String) {
        announcementListener?.invoke(message)
    }

    companion object {
        private const val STATS_INTERVAL_MS = 1_000L
    }
}
