package com.localstream.net

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.net.wifi.WifiManager
import com.localstream.logging.AppLog
import com.localstream.protocol.LocalStream
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import java.io.Closeable
import java.net.Inet4Address
import java.net.InetAddress
import java.net.NetworkInterface
import java.util.concurrent.atomic.AtomicBoolean

/** A broadcaster seen on the network. */
data class DiscoveredStream(
    val instanceName: String,
    val description: LocalStream.Description,
    val address: Inet4Address
) {
    /**
     * Stable identity across TXT refreshes. NsdManager reports removals by instance name
     * only, so the key has to stay consistent between an add and its matching removal.
     */
    val key: String get() = instanceName
}

sealed interface DiscoveryEvent {
    data class Found(val stream: DiscoveredStream) : DiscoveryEvent
    data class Removed(val instanceName: String) : DiscoveryEvent
    data class Failed(val reason: String) : DiscoveryEvent
}

/**
 * mDNS browsing and registration backed by `NsdManager`.
 *
 * A multicast lock is held while browsing or advertising: without it the Wi-Fi driver
 * filters inbound multicast whenever the screen is off, and discovery silently returns
 * nothing — which is exactly when a user most needs to find a stream.
 */
class ServiceDiscovery(private val context: Context) {

    private val nsdManager: NsdManager? =
        context.getSystemService(Context.NSD_SERVICE) as? NsdManager

    private var multicastLock: WifiManager.MulticastLock? = null
    private val browsing = AtomicBoolean(false)
    private val registered = AtomicBoolean(false)

    private var registrationListener: NsdManager.RegistrationListener? = null

    /**
     * Emits every stream found on the network, including ones already present when
     * collection starts. Removals arrive as [DiscoveryEvent.Removed].
     */
    fun browse(): Flow<DiscoveryEvent> = callbackFlow {
        val manager = nsdManager
        if (manager == null) {
            trySend(DiscoveryEvent.Failed("This device has no network service discovery."))
            close()
            return@callbackFlow
        }

        acquireMulticastLock()
        if (!browsing.compareAndSet(false, true)) {
            trySend(DiscoveryEvent.Failed("Already searching for broadcasters."))
            close()
            return@callbackFlow
        }

        val listener = object : NsdManager.DiscoveryListener {

            override fun onStartDiscoveryFailed(serviceType: String, errorCode: Int) {
                browsing.set(false)
                trySend(
                    DiscoveryEvent.Failed(
                        "Searching for broadcasters failed (error $errorCode). " +
                            "Check that both devices are on the same Wi-Fi network."
                    )
                )
            }

            override fun onStopDiscoveryFailed(serviceType: String, errorCode: Int) {
                browsing.set(false)
            }

            override fun onDiscoveryStarted(serviceType: String) = Unit

            override fun onDiscoveryStopped(serviceType: String) {
                browsing.set(false)
            }

            override fun onServiceFound(serviceInfo: NsdServiceInfo) {
                AppLog.info("ServiceDiscovery", "onServiceFound: ${serviceInfo.serviceName} type=${serviceInfo.serviceType}")
                // The blocking resolveService overload was removed in API 34, so
                // resolution is asynchronous. Failures are ignored: a peer whose service
                // cannot be resolved is one the receiver cannot use anyway.
                manager.resolveService(
                    serviceInfo,
                    object : NsdManager.ResolveListener {
                        override fun onResolveFailed(serviceInfo: NsdServiceInfo, errorCode: Int) {
                            AppLog.warning("ServiceDiscovery", "onResolveFailed ${serviceInfo.serviceName}: error $errorCode")
                        }

                        override fun onServiceResolved(serviceInfo: NsdServiceInfo) {
                            val stream = toStream(serviceInfo)
                            AppLog.info(
                                "ServiceDiscovery",
                                "onServiceResolved ${serviceInfo.serviceName} " +
                                    "host=${serviceInfo.host} port=${serviceInfo.port} " +
                                    "stream=${stream != null}"
                            )
                            if (stream == null) return
                            // A broadcast published by this device is never a peer it can
                            // receive from. The caller's name-based self-check misses stale
                            // records: each run advertises a fresh session-scoped name, and
                            // NsdManager does not always send a goodbye when a process dies, so
                            // an orphaned advertisement for this very device can outlive the run
                            // that made it. The owning address is unambiguous, so it is the
                            // backstop.
                            if (isLocalAddress(stream.address)) {
                                AppLog.info("ServiceDiscovery", "Ignoring broadcast from our own address ${stream.address.hostAddress}")
                                return
                            }
                            trySend(DiscoveryEvent.Found(stream))
                        }
                    }
                )
            }

            override fun onServiceLost(serviceInfo: NsdServiceInfo) {
                AppLog.info("ServiceDiscovery", "onServiceLost: ${serviceInfo.serviceName}")
                trySend(DiscoveryEvent.Removed(serviceInfo.serviceName ?: ""))
            }
        }

        manager.discoverServices(LocalStream.NSD_SERVICE_TYPE, NsdManager.PROTOCOL_DNS_SD, listener)

        awaitClose {
            try {
                manager.stopServiceDiscovery(listener)
            } catch (e: IllegalArgumentException) {
                // Discovery was never started.
            }
            browsing.set(false)
            releaseMulticastLockIfIdle()
        }
    }

    /**
     * Invokes [listener] whenever the device's default network becomes available again.
     *
     * A browse running when the network drops can stay wedged: NsdManager does not always resume
     * on its own, so a returning LAN has to prompt a fresh search. The returned handle
     * unregisters the callback; closing it more than once is harmless.
     */
    fun observeNetworkAvailability(listener: () -> Unit): Closeable {
        val manager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            ?: return Closeable {}
        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) = listener()
        }
        return try {
            manager.registerDefaultNetworkCallback(callback)
            Closeable { runCatching { manager.unregisterNetworkCallback(callback) } }
        } catch (e: RuntimeException) {
            // A device with no connectivity service, or a permission that was stripped. Browsing
            // still works; only the automatic recovery is lost.
            AppLog.warning("ServiceDiscovery", "Could not watch network changes: ${e.message}")
            Closeable {}
        }
    }

    private fun toStream(info: NsdServiceInfo): DiscoveredStream? {
        val instance = info.serviceName ?: run {
            AppLog.warning("ServiceDiscovery", "Resolved record has no service name")
            return null
        }
        val host = info.host
        if (host == null) {
            AppLog.warning("ServiceDiscovery", "Resolved record $instance has no host")
            return null
        }
        val address = host as? Inet4Address
        if (address == null) {
            AppLog.warning("ServiceDiscovery", "Resolved record $instance has non-IPv4 host $host")
            return null
        }

        val txt = LocalStream.parseTxtAttributes(info.attributes)
        val description = LocalStream.descriptionFrom(txt)
        if (description == null) {
            // A peer that answers with a TXT record this build cannot read is skipped
            // rather than shown as a broken entry, but it is worth recording why.
            AppLog.warning("ServiceDiscovery", "Resolved record $instance has an unreadable TXT record: $txt")
            return null
        }

        return DiscoveredStream(
            instanceName = instance,
            description = description,
            address = address
        )
    }

    /**
     * Publishes this device as a broadcaster.
     *
     * @param onRegistered called once the record is live, and again on every republish.
     * @param onError called with a human-readable reason.
     */
    fun register(
        descriptionProvider: () -> LocalStream.Description,
        onRegistered: () -> Unit,
        onError: (String) -> Unit
    ) {
        val manager = nsdManager ?: return
        if (!registered.compareAndSet(false, true)) return
        acquireMulticastLock()

        manager.registerService(
            buildInfo(descriptionProvider()),
            NsdManager.PROTOCOL_DNS_SD,
            registrationListener(onRegistered, onError)
        )
    }

    /**
     * Republishes the TXT record without changing the instance name.
     *
     * NsdManager treats a second register for the same name as a failure rather than an
     * update, so the old registration is dropped first.
     */
    fun updateRegistration(
        descriptionProvider: () -> LocalStream.Description,
        onUpdated: () -> Unit,
        onError: (String) -> Unit
    ) {
        val manager = nsdManager ?: return
        dropRegistration(manager)
        acquireMulticastLock()

        manager.registerService(
            buildInfo(descriptionProvider()),
            NsdManager.PROTOCOL_DNS_SD,
            registrationListener(onUpdated, onError)
        )
    }

    private fun buildInfo(description: LocalStream.Description): NsdServiceInfo =
        NsdServiceInfo().apply {
            // The session id is part of the service name so that a restarted broadcast is a
            // new DNS-SD instance. NsdManager keys its cache on the service name: re-announcing
            // the same name reads as an update to a record peers have already resolved, so they
            // keep serving the previous control port, which belongs to a dead process. The
            // friendly name still comes from the TXT record, so this never reaches the UI.
            serviceName = instanceName(description.sessionId)
            serviceType = LocalStream.NSD_SERVICE_TYPE
            port = description.controlPort
            description.toTxt().forEach { (key, value) -> setAttribute(key, value) }
        }

    /**
     * The advertised service name for one broadcast, unique per session.
     *
     * Exposed so a browser can recognise its own advertisement by exact name. Matching on the
     * bare [INSTANCE_NAME] prefix would also hide every other LocalStream device, because they
     * all share it; only this session id is unique to this one.
     */
    internal fun instanceName(sessionId: String): String =
        if (sessionId.isBlank()) INSTANCE_NAME else "$INSTANCE_NAME-$sessionId"

    /** True when [address] belongs to one of this device's own interfaces. */
    private fun isLocalAddress(address: InetAddress): Boolean =
        runCatching {
            NetworkInterface.getNetworkInterfaces().asSequence()
                .flatMap { it.inetAddresses.asSequence() }
                .any { !it.isLoopbackAddress && it.hostAddress == address.hostAddress }
        }.getOrDefault(false)

    private fun registrationListener(
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ): NsdManager.RegistrationListener = object : NsdManager.RegistrationListener {

        override fun onServiceRegistered(serviceInfo: NsdServiceInfo) {
            registered.set(true)
            onSuccess()
        }

        override fun onRegistrationFailed(serviceInfo: NsdServiceInfo, errorCode: Int) {
            registered.set(false)
            onError("Could not advertise this broadcast (error $errorCode).")
        }

        override fun onServiceUnregistered(serviceInfo: NsdServiceInfo) = Unit

        override fun onUnregistrationFailed(serviceInfo: NsdServiceInfo, errorCode: Int) = Unit
    }.also { registrationListener = it }

    /** Withdraws the advertisement, sending the mDNS goodbye so peers drop it at once. */
    fun unregister() {
        val manager = nsdManager ?: return
        dropRegistration(manager)
        releaseMulticastLockIfIdle()
    }

    private fun dropRegistration(manager: NsdManager) {
        registrationListener?.let { listener ->
            try {
                manager.unregisterService(listener)
            } catch (e: IllegalArgumentException) {
                // Not registered.
            }
        }
        registrationListener = null
        registered.set(false)
    }

    fun release() {
        unregister()
    }

    private fun acquireMulticastLock() {
        if (multicastLock?.isHeld == true) return
        val wifi = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
            ?: return
        multicastLock = wifi.createMulticastLock("localstream-mdns").apply {
            setReferenceCounted(true)
            acquire()
        }
    }

    private fun releaseMulticastLockIfIdle() {
        // Reference counted and only dropped once neither side is active, so that a
        // viewer browsing while someone broadcasts does not lose discovery.
        if (browsing.get() || registered.get()) return
        multicastLock?.let { if (it.isHeld) it.release() }
        multicastLock = null
    }

    companion object {
        const val INSTANCE_NAME = "LocalStream"
    }
}
