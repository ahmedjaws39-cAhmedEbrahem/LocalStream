﻿package com.localstream.ui

const val EXTRA_KEY = "com.localstream.extra.ACCESS_REQUEST_KEY"
const val EXTRA_NAME = "com.localstream.extra.ACCESS_REQUEST_NAME"
const val EXTRA_ALLOW = "com.localstream.extra.ACCESS_REQUEST_ALLOW"
