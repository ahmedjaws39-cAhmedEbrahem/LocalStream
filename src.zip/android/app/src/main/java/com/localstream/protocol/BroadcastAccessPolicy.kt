package com.localstream.protocol

/**
 * Whether the presenter's broadcast may go live given the access setting they chose.
 *
 * Access is changed live, but choosing password mode and locking the broadcast with a password
 * are two separate steps: the mode is only handed to the engine once a usable password exists,
 * and until then the choice sits on the screen unapplied. Going live in that window would
 * publish the broadcast unlocked while the page still said a password was required, which is the
 * one outcome a viewer must never meet. This is the rule the start path consults, kept out of the
 * ViewModel so it can be exercised without an `Application` behind it.
 */
object BroadcastAccessPolicy {

    sealed interface StartDecision {
        /** The access setting already in force is the one to go live with. */
        object Proceed : StartDecision

        /** The password the presenter typed has to be applied before the broadcast goes live. */
        data class ApplyPassword(val password: String) : StartDecision

        /** The presenter asked for a password, but none worth locking the broadcast with exists. */
        data class Refuse(val message: String) : StartDecision
    }

    fun beforeStart(accessPending: Boolean, accessMode: String, password: String): StartDecision {
        // Nothing is waiting to be applied: the engine already holds the chosen access.
        if (!accessPending) return StartDecision.Proceed

        // Only password mode can be pending (the validator refuses a password and leaves the
        // choice unapplied). Anything else is already in force and is safe to start.
        if (accessMode != ControlMessage.ACCESS_PASSWORD) return StartDecision.Proceed

        return if (ControlMessage.isValidPassword(password)) {
            StartDecision.ApplyPassword(password)
        } else {
            StartDecision.Refuse(
                "Set a password of " + ControlMessage.PASSWORD_MIN_LENGTH + " to " +
                    ControlMessage.PASSWORD_MAX_LENGTH +
                    " characters and use it before starting the broadcast."
            )
        }
    }
}
