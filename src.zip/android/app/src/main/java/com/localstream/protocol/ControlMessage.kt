package com.localstream.protocol

import org.json.JSONException
import org.json.JSONObject

/**
 * Control-channel messages.
 *
 * Wire format is newline-delimited JSON, one object per line, as specified in
 * `docs/PROTOCOL.md` section 4. Parsing is deliberately lenient about unknown fields but
 * strict about `t`, and an unrecognised `t` yields null so the caller can ignore it rather
 * than tearing down a healthy session when a newer peer adds a message type.
 */
sealed interface ControlMessage {

    val type: String

    fun toJson(): JSONObject

    // ------------------------------------------------------------- receiver -> broadcaster

    data class Hello(
        val protocolVersion: Int,
        val name: String,
        val userAgent: String
    ) : ControlMessage {
        override val type = "hello"
        override fun toJson() = JSONObject().apply {
            put("t", type)
            put("v", protocolVersion)
            put("role", "receiver")
            put("name", name)
            put("ua", userAgent)
        }
    }

    /** The receiver's own bound UDP ports. Sent after the sockets are already open. */
    data class Offer(
        val sessionId: String,
        val audioPort: Int,
        val videoPort: Int?
    ) : ControlMessage {
        override val type = "offer"
        override fun toJson() = JSONObject().apply {
            put("t", type)
            put("id", sessionId)
            put("ap", audioPort)
            if (videoPort != null) put("vp", videoPort)
        }
    }

    data class KeyframeRequest(val sessionId: String) : ControlMessage {
        override val type = "keyframe"
        override fun toJson() = JSONObject().apply {
            put("t", type)
            put("id", sessionId)
        }
    }

    data class BitrateRequest(
        val videoKbps: Int?,
        val audioKbps: Int?
    ) : ControlMessage {
        override val type = "bitrate"
        override fun toJson() = JSONObject().apply {
            put("t", type)
            videoKbps?.let { put("vbr", it) }
            audioKbps?.let { put("abr", it) }
        }
    }

    /**
     * A *request* to change mode. The broadcaster's [ModeChanged] is authoritative; a
     * request is a suggestion the broadcaster may decline.
     *
     * Distinguished from [ModeChanged] on the wire by `"r": true`. Without that flag the
     * two are byte-identical, and a receiver-side parse cannot tell a request from a
     * command — which would make a request silently become a command.
     */
    data class ModeRequest(val mode: String) : ControlMessage {
        override val type = "mode"
        override fun toJson() = JSONObject().apply {
            put("t", type)
            put("m", mode)
            put("r", true)
        }
    }

    data class ReceiverStats(
        val packets: Long,
        val lost: Long,
        val jitterMillis: Double,
        val keyframeRequests: Long
    ) : ControlMessage {
        override val type = "stats"
        override fun toJson() = JSONObject().apply {
            put("t", type)
            put("pkt", packets)
            put("lost", lost)
            put("jitter", Math.round(jitterMillis * 10.0) / 10.0)
            put("nack", keyframeRequests)
        }
    }

    // ------------------------------------------------------------- broadcaster -> receiver

    data class Welcome(
        val sessionId: String,
        val displayName: String,
        val mode: String,
        val sdp: String,
        /**
         * One of [ACCESS_PUBLIC] / [ACCESS_APPROVAL] / [ACCESS_PASSWORD].
         *
         * A missing `access` field means the broadcaster predates access control, and reads as
         * public: an older broadcaster admitted everyone, so its silence must not be read as a
         * refusal. The receiver still enforces whatever this says, so a locked broadcast cannot
         * be entered by ignoring the field.
         */
        val access: String = ACCESS_PUBLIC
    ) : ControlMessage {
        override val type = "welcome"
        override fun toJson() = JSONObject().apply {
            put("t", type)
            put("v", LocalStream.PROTOCOL_VERSION)
            put("id", sessionId)
            put("name", displayName)
            put("m", mode)
            put("sdp", sdp)
            // Omitted when public: an absent field already means public, so sending it would be
            // a byte per session for no behavioural difference.
            if (access != ACCESS_PUBLIC) put("access", access)
        }
    }

    /**
     * Supplies the broadcaster's password. Sent after `welcome` and before `offer`, and only
     * in [ACCESS_PASSWORD] mode. The broadcaster answers [AuthResult]; an `offer` must not be
     * sent until that result grants access.
     */
    data class AuthRequest(val sessionId: String, val password: String) : ControlMessage {
        override val type = "auth"
        override fun toJson() = JSONObject().apply {
            put("t", type)
            put("id", sessionId)
            put("pw", password)
        }
    }

    /** The broadcaster's answer to [AuthRequest]. [granted] is authoritative. */
    data class AuthResult(val granted: Boolean, val reason: String = "") : ControlMessage {
        override val type = "authResult"
        override fun toJson() = JSONObject().apply {
            put("t", type)
            put("ok", granted)
            if (reason.isNotEmpty()) put("reason", reason)
        }
    }

    data class Accept(
        val audioPort: Int,
        val videoPort: Int?,
        val audioSsrc: Int,
        val videoSsrc: Int?
    ) : ControlMessage {
        override val type = "accept"
        override fun toJson() = JSONObject().apply {
            put("t", type)
            put("ap", audioPort)
            put("vp", videoPort ?: JSONObject.NULL)
            put("as", audioSsrc)
            put("vs", videoSsrc ?: JSONObject.NULL)
        }
    }

    data class Deny(val code: String, val reason: String) : ControlMessage {
        override val type = "deny"
        override fun toJson() = JSONObject().apply {
            put("t", type)
            put("code", code)
            put("reason", reason)
        }
    }

    /** Authoritative: the broadcast mode is now [mode]. */
    data class ModeChanged(val mode: String) : ControlMessage {
        override val type = "mode"
        override fun toJson() = JSONObject().apply {
            put("t", type)
            put("m", mode)
        }
    }

    data class BroadcasterStats(
        val framesPerSecond: Int,
        val kilobitsPerSecond: Int,
        val packetLossPercent: Double,
        val receiverCount: Long,
        val droppedFrames: Long
    ) : ControlMessage {
        override val type = "stats"
        override fun toJson() = JSONObject().apply {
            put("t", type)
            put("fps", framesPerSecond)
            put("kbps", kilobitsPerSecond)
            put("pl", Math.round(packetLossPercent * 100.0) / 100.0)
            put("nrt", receiverCount)
            put("dropped", droppedFrames)
        }
    }

    data class Bye(val reason: String) : ControlMessage {
        override val type = "bye"
        override fun toJson() = JSONObject().apply {
            put("t", type)
            put("reason", reason)
        }
    }

    companion object {
        const val DENY_VERSION = "version"
        const val DENY_CAPACITY = "capacity"
        const val DENY_SHUTDOWN = "shutdown"
        const val DENY_MODE = "mode"

        /** The broadcaster refused this receiver's request to view the broadcast. */
        const val DENY_ACCESS = "access"

        /** The password was refused, or one was required and none arrived. */
        const val DENY_AUTH = "auth"

        /**
         * This receiver exhausted its rejections and is barred until the broadcast ends.
         * Terminal: reconnecting cannot succeed, so the UI must not offer a retry.
         */
        const val DENY_BLOCKED = "blocked"

        const val BYE_SHUTDOWN = "shutdown"
        const val BYE_MODE_CHANGE = "mode-change"
        const val BYE_CAPACITY = "capacity"
        const val BYE_KICKED = "kicked"
        const val BYE_ERROR = "error"
        const val BYE_USER_LEFT = "user"

        const val ACCESS_PUBLIC = "public"

        /** A receiver may ask, and the broadcaster decides per request. */
        const val ACCESS_APPROVAL = "approval"

        /** A receiver must supply the broadcaster's password before it is admitted. */
        const val ACCESS_PASSWORD = "password"

        /** Password length limits. Enforced by the broadcaster; mirrored here so the receiver
         * can validate before sending and size its input field. */
        const val PASSWORD_MIN_LENGTH = 4
        const val PASSWORD_MAX_LENGTH = 10

        /**
         * Rejections a receiver may accumulate in [ACCESS_APPROVAL] mode before the broadcaster
         * bars it. The broadcaster holds the count; a receiver that reconnects does not reset it.
         */
        const val MAX_REJECTIONS = 3

        /** True when the password satisfies [PASSWORD_MIN_LENGTH] / [PASSWORD_MAX_LENGTH]. */
        @JvmStatic
        fun isValidPassword(password: String): Boolean =
            password.length in PASSWORD_MIN_LENGTH..PASSWORD_MAX_LENGTH

        /** Returns null when the type is unknown or the payload is malformed. */
        @JvmStatic
        fun parse(line: String): ControlMessage? = try {
            fromJson(JSONObject(line))
        } catch (e: JSONException) {
            null
        }

        fun fromJson(json: JSONObject): ControlMessage? = when (json.optString("t")) {
            "hello" -> Hello(
                protocolVersion = json.optInt("v", 0),
                name = json.optString("name", "Receiver"),
                userAgent = json.optString("ua", "unknown")
            )

            "offer" -> Offer(
                sessionId = json.optString("id"),
                audioPort = json.optInt("ap"),
                videoPort = if (json.isNull("vp")) null else json.optInt("vp").takeIf { it > 0 }
            )

            "auth" -> AuthRequest(
                sessionId = json.optString("id"),
                password = json.optString("pw")
            )

            "authResult" -> AuthResult(
                granted = json.optBoolean("ok"),
                reason = json.optString("reason")
            )

            "keyframe" -> KeyframeRequest(json.optString("id"))

            "bitrate" -> BitrateRequest(
                videoKbps = json.optInt("vbr").takeIf { it > 0 },
                audioKbps = json.optInt("abr").takeIf { it > 0 }
            )

            // `"r": true` marks a receiver's request; its absence marks the broadcaster's
            // authoritative change. Both use type "mode".
            "mode" -> if (json.optBoolean("r")) {
                ModeRequest(json.optString("m"))
            } else {
                ModeChanged(json.optString("m"))
            }

            "stats" -> {
                // `stats` is sent in both directions; the role disambiguates it, and the
                // field names differ, so pick the variant that actually has data.
                if (json.has("pkt")) {
                    ReceiverStats(
                        packets = json.optLong("pkt"),
                        lost = json.optLong("lost"),
                        jitterMillis = json.optDouble("jitter", 0.0),
                        keyframeRequests = json.optLong("nack")
                    )
                } else {
                    BroadcasterStats(
                        framesPerSecond = json.optInt("fps"),
                        kilobitsPerSecond = json.optInt("kbps"),
                        packetLossPercent = json.optDouble("pl", 0.0),
                        receiverCount = json.optLong("nrt"),
                        droppedFrames = json.optLong("dropped")
                    )
                }
            }

            "welcome" -> Welcome(
                sessionId = json.optString("id"),
                displayName = json.optString("name", "Broadcaster"),
                mode = json.optString("m", LocalStream.MODE_AUDIO_VIDEO),
                sdp = json.optString("sdp"),
                // Absent on an older broadcaster, which means public.
                access = normalizeAccess(json.optString("access"))
            )

            "accept" -> Accept(
                audioPort = json.optInt("ap"),
                videoPort = if (json.isNull("vp")) null else json.optInt("vp").takeIf { it > 0 },
                audioSsrc = json.optInt("as"),
                videoSsrc = if (json.isNull("vs")) null else json.optInt("vs").takeIf { it != 0 }
            )

            "deny" -> Deny(json.optString("code"), json.optString("reason"))

            "bye" -> Bye(json.optString("reason", BYE_USER_LEFT))

            else -> null
        }

        /**
         * Coerces a wire value to a known access mode, defaulting to public.
         *
         * A receiver-side fail-open, and it is only safe because the *broadcaster* never reads
         * this: its own policy comes from local settings, so a peer cannot downgrade a locked
         * broadcast by sending a value this rejects.
         */
        private fun normalizeAccess(value: String?): String = when (value) {
            ACCESS_APPROVAL -> ACCESS_APPROVAL
            ACCESS_PASSWORD -> ACCESS_PASSWORD
            else -> ACCESS_PUBLIC
        }
    }
}
