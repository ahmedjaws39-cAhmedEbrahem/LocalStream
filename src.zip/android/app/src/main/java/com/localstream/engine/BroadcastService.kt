package com.localstream.engine

import com.localstream.ui.AccessRequestActivity

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.localstream.LocalStreamApp
import com.localstream.R
import com.localstream.logging.AppLog
import com.localstream.ui.MainActivity
import java.util.concurrent.atomic.AtomicReference
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Deferred

/**
 * Keeps the broadcast alive while the app is in the background.
 *
 * Deliberately thin: the engine itself lives in the ViewModel, and this service does not
 * touch it. Its only jobs are to be a foreground process (so the OS does not reclaim the
 * encoder) and to put a Stop action in the shade, so a broadcast can always be ended
 * without hunting for the app.
 */
class BroadcastService : Service() {

    /**
     * The ongoing-broadcast notification is built with `getString`, so its text has to come from
     * a context that speaks the chosen language. A service outlives the activity that started it,
     * so the wrapping happens here rather than being inherited.
     */
    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(com.localstream.ui.AppLanguage.wrap(newBase))
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            // The notification's Stop button cannot reach the ViewModel directly, so it
            // stops the service and tells the Activity to tear the engine down.
            sendBroadcast(Intent(ACTION_STOP_BROADCAST).setPackage(packageName))
            stopSelf()
            return START_NOT_STICKY
        }

        startForegroundCompat(
            buildNotification(),
            intent?.getIntExtra(EXTRA_FOREGROUND_TYPE, 0) ?: 0
        )
        signalPromoted()
        // Not sticky: a broadcast that was killed should not silently resume, because the
        // capture permission and the advertised ports would both be stale.
        return START_NOT_STICKY
    }

    private fun startForegroundCompat(notification: Notification, foregroundType: Int) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            // The type has to name what is actually being captured. Claiming mediaProjection
            // for a broadcast that never asked for (and holds no) screen-capture consent is a
            // SecurityException on Android 14, which crashed an audio-only or camera broadcast
            // the moment it started. The caller computes the mask from the live settings; zero
            // means a caller from before this was threaded through, where the old
            // mediaProjection-only behaviour is the safest guess.
            val type = if (foregroundType != 0) {
                foregroundType
            } else {
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            }
            startForeground(NOTIFICATION_ID, notification, type)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun buildNotification(): Notification {
        val contentIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val stopIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, BroadcastService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, LocalStreamApp.NOTIFICATION_CHANNEL_ID)
            .setContentTitle(getString(R.string.notification_title))
            .setContentText("Viewers on your network can receive this stream")
            .setSmallIcon(R.drawable.ic_notification)
            .setContentIntent(contentIntent)
            .addAction(
                R.drawable.ic_notification,
                getString(R.string.notification_stop),
                stopIntent
            )
            // Ongoing: the stream has not stopped, and a dismissible notification would
            // suggest it has.
            .setOngoing(true)
            .setSilent(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .build()
    }

    companion object {
        const val ACTION_STOP = "com.localstream.action.STOP_SERVICE"

        /** Broadcast by the service so the UI can stop the engine. */
        const val ACTION_STOP_BROADCAST = "com.localstream.action.STOP_BROADCAST"

        /** Broadcast by the lock-screen prompt so the UI can answer a viewer. */
        const val ACTION_ACCESS_REQUEST_ANSWER = "com.localstream.action.ACCESS_REQUEST_ANSWER"

        private const val NOTIFICATION_ID = 1001
        private const val ACCESS_NOTIFICATION_ID = 1002

        /**
         * Foreground-service types the broadcast actually needs, as a bit mask of
         * `ServiceInfo.FOREGROUND_SERVICE_TYPE_*`.
         *
         * Handed to `onStartCommand` so the promotion names the right capture. All the types it
         * can contain are declared on the service in the manifest.
         */
        const val EXTRA_FOREGROUND_TYPE = "com.localstream.extra.FOREGROUND_TYPE"

        /**
         * Raises a viewer request as an alert, waking the screen if need be.
         *
         * Static rather than an instance method because the caller is the control server, on a
         * socket thread, and starting or updating a service from there would be a
         * `BackgroundServiceStartNotAllowedException` waiting to happen.
         *
         * The notification stays until it is answered. A request that vanishes after a few
         * seconds has left a viewer waiting with no way for the presenter to find out, so
         * [clearAccessRequest] is the only thing that takes it down.
         */
        fun notifyAccessRequest(context: Context, key: Long, viewerName: String) {
            val fullScreen = PendingIntent.getActivity(
                context,
                key.toInt(),
                Intent(context, com.localstream.ui.AccessRequestActivity::class.java)
                    .putExtra(com.localstream.ui.EXTRA_KEY, key)
                    .putExtra(com.localstream.ui.EXTRA_NAME, viewerName),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )

            // Answerable without unlocking: an action button is not a judgement, and the full
            // screen intent is right there if the presenter wants to look first.
            val allow = answerIntent(context, key, allow = true)
            val reject = answerIntent(context, key, allow = false)

            val notification =
                NotificationCompat.Builder(context, LocalStreamApp.ACCESS_NOTIFICATION_CHANNEL_ID)
                    .setContentTitle(context.getString(R.string.access_request_title))
                    .setContentText("$viewerName is waiting to watch")
                    .setSmallIcon(R.drawable.ic_notification)
                    .setPriority(NotificationCompat.PRIORITY_HIGH)
                    .setCategory(NotificationCompat.CATEGORY_CALL)
                    .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                    // Full-screen intent first: on a locked device this is the difference
                    // between a prompt the presenter sees now and a banner they might not.
                    .setFullScreenIntent(fullScreen, true)
                    .setContentIntent(fullScreen)
                    .addAction(R.drawable.ic_notification, context.getString(R.string.access_allow), allow)
                    .addAction(R.drawable.ic_notification, context.getString(R.string.access_reject), reject)
                    .setAutoCancel(false)
                    .setOngoing(true)
                    .build()

            try {
                NotificationManagerCompat.from(context).notify(ACCESS_NOTIFICATION_ID, notification)
            } catch (e: SecurityException) {
                // POST_NOTIFICATIONS refused, or the full-screen-intent permission withdrawn on
                // Android 14+. The in-app dialog still appears, so this is a downgrade rather
                // than a failure; it is logged because a presenter who never sees an alert and
                // cannot work out why is the whole cost of it.
                AppLog.warning("BroadcastService", "Could not post the viewer request notification: $e")
            }
        }

        private fun answerIntent(context: Context, key: Long, allow: Boolean): PendingIntent {
            // Sent straight to the running app. The broadcast is package-scoped and the
            // receiver is not exported, so nothing outside this app can answer for it.
            val intent = Intent(ACTION_ACCESS_REQUEST_ANSWER)
                .setPackage(context.packageName)
                .putExtra(com.localstream.ui.EXTRA_KEY, key)
                .putExtra(com.localstream.ui.EXTRA_ALLOW, allow)
            return PendingIntent.getBroadcast(
                context,
                // Distinct request code per answer: PendingIntent ignores the extras of a new
                // request that matches an existing one, so "reject" would otherwise be sent as
                // whatever the "allow" intent was built with.
                (key.toInt() * 2) + if (allow) 1 else 0,
                intent,
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
        }

        /** Takes the request alert down once it has been answered. */
        fun clearAccessRequest(context: Context) {
            NotificationManagerCompat.from(context).cancel(ACCESS_NOTIFICATION_ID)
        }

        /**
         * The promotion currently in flight.
         *
         * Held so [start] can hand back a future for the one request it is servicing. A
         * broadcast that is stopped before it promotes cancels it through here, which stops
         * the caller waiting for a signal that will never arrive.
         */
        private val pending = AtomicReference<CompletableDeferred<Unit>?>(null)

        /**
         * Starts the service and returns a future that completes once the platform has
         * accepted the foreground promotion.
         *
         * The wait is not optional. `startForegroundService()` only hands the request to the
         * system, and the resulting `onStartCommand` is delivered to this app's main looper
         * later; `MediaProjection.start()` is refused until the service has actually promoted
         * with `FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION`. Assuming the service command lands
         * before the work that follows it makes this a race that passes on a fast device and
         * fails on a loaded one, so the caller suspends on this instead of guessing.
         */
        fun start(context: Context, foregroundType: Int): Deferred<Unit> {
            val promoted = CompletableDeferred<Unit>()
            pending.set(promoted)
            val intent = Intent(context, BroadcastService::class.java)
                .putExtra(EXTRA_FOREGROUND_TYPE, foregroundType)
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(intent)
                } else {
                    context.startService(intent)
                }
            } catch (e: Exception) {
                pending.compareAndSet(promoted, null)
                promoted.completeExceptionally(e)
            }
            return promoted
        }

        fun stop(context: Context) {
            // A start that never got to promote is abandoned here rather than left with a
            // caller suspended on it.
            pending.getAndSet(null)?.cancel()
            context.stopService(Intent(context, BroadcastService::class.java))
        }

        private fun signalPromoted() {
            pending.getAndSet(null)?.complete(Unit)
        }
    }
}
