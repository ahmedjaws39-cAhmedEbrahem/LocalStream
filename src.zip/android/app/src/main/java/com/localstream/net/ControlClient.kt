﻿package com.localstream.net

import com.localstream.logging.AppLog
import com.localstream.protocol.ControlMessage
import com.localstream.protocol.LocalStream
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

/** Progress of a connection attempt, surfaced directly to the UI. */
sealed interface ConnectionState {
    data object Idle : ConnectionState
    data object Connecting : ConnectionState
    data class Connected(val broadcasterName: String, val mode: String) : ConnectionState
    /**
     * The broadcaster wants a password. [wrongAttempt] is true when the previous one was
     * refused, so the prompt can say so without the user having to remember what happened.
     */
    data class AwaitingPassword(val broadcasterName: String, val wrongAttempt: Boolean) :
        ConnectionState

    /** The `offer` has been sent and the broadcaster is deciding. No timeout: the presenter may be away. */
    data class AwaitingApproval(val broadcasterName: String) : ConnectionState

    data class Rejected(val reason: String) : ConnectionState
    data class Failed(val reason: String) : ConnectionState
    data class Disconnected(val reason: String) : ConnectionState

    /**
     * Refused for the rest of this broadcast, after too many rejections.
     *
     * Terminal on purpose: the broadcaster has said not to ask again, so the viewer is told why
     * and left to do something else rather than being offered a retry that cannot succeed.
     */
    data class Blocked(val reason: String) : ConnectionState
}

/** Thrown when the viewer backs out of a password prompt. Not an error, and never spoken. */
class ConnectCancelled(message: String) : IOException(message)

/**
 * Receiver side of the control channel.
 *
 * Drives the handshake in `docs/PROTOCOL.md` section 4.1: connect, `hello`, wait for
 * `welcome`, then `offer` the already-bound media ports and wait for `accept`. Media
 * starts arriving immediately after `accept`, which is why the RTP sockets are opened
 * before the TCP connection is even made.
 */
class ControlClient(private val scope: CoroutineScope) {

    private val running = AtomicBoolean(false)
    private var socket: Socket? = null
    private var readerJob: Job? = null

    /**
     * Bumped on every connect and disconnect. A read loop carries the value it was started
     * with and refuses to publish a state or mode once the connection has moved on. Without
     * it, a reader still draining after [disconnect] could overwrite the state of the session
     * that replaced it - the "old connection still lingering" failure.
     */
    private val connectionGeneration = AtomicLong(0)

    private val _state = MutableStateFlow<ConnectionState>(ConnectionState.Idle)
    val state: StateFlow<ConnectionState> = _state.asStateFlow()

    /**
     * Inbound messages awaiting consumption.
     *
     * A [Channel] rather than a `SharedFlow`: a flow with `replay = 0` drops anything
     * emitted while no collector is attached, and the handshake is exactly the case where
     * that happens \u2014 `welcome` can arrive before [nextMessage] is reached. A channel
     * retains it.
     */
    private var inbound = Channel<ControlMessage>(capacity = 32)

    /** Inbound messages after the handshake has completed. */
    val incoming: Flow<ControlMessage> get() = inbound.receiveAsFlow()

    private val _broadcasterName = MutableStateFlow("")
    val broadcasterName: StateFlow<String> = _broadcasterName.asStateFlow()

private val _mode = MutableStateFlow(LocalStream.MODE_AUDIO_VIDEO)
    val mode: StateFlow<String> = _mode.asStateFlow()

    /**
     * The access mode the broadcaster advertised in its `welcome`, defaulting to open for an older
     * broadcaster that does not send the field at all.
     */
    private val _access = MutableStateFlow(ControlMessage.ACCESS_PUBLIC)
    val access: StateFlow<String> = _access.asStateFlow()

    /**
     * The handshake this client is running, so [disconnect] can cancel it.
     *
     * Approval mode waits without a timeout, so the coroutine parked in the handshake can outlive
     * the user's decision to leave; cancelling it is what makes the Disconnect control take effect
     * immediately instead of after a timeout nobody is still watching.
     */
    @Volatile
    private var handshakeJob: Job? = null

    @Volatile
    private var sessionId: String = ""

    /**
     * The refusal this connection was given, if any.
     *
     * Held apart from [state] because a refusal and a step of the handshake can be in flight at
     * the same moment: a broadcaster that answers the offer with a `deny` can answer it so fast
     * that the `deny` is read and classified before this coroutine has published the state saying
     * "waiting". Recording it here gives the handshake one place to look, so the state a refusal
     * is reported through cannot be overwritten by a step that was already under way - which
     * would leave the viewer told they were refused and, at the same time, still waiting.
     */
    @Volatile
    private var refusal: ConnectionState? = null

    /** The broadcaster's reason for [refusal], or null if this connection has not been refused. */
    private fun refusalReason(): String? = when (val recorded = refusal) {
        is ConnectionState.Rejected -> recorded.reason
        is ConnectionState.Blocked -> recorded.reason
        else -> null
    }

    /**
     * The `welcome`'s SDP, kept because it is the only place the broadcaster's audio channel
     * count appears. The `accept` carries the ports but no layout, and an Opus packet carries
     * none either, so the decoder would otherwise have to guess.
     */
    @Volatile
    private var welcomeSdp: String = ""

/**
     * Connects and completes the handshake.
     *
     * @param passwordProvider supplies the broadcast password when the broadcaster asks for one,
     *        and is called again after each refusal. Returning null means the viewer cancelled.
     * @return the ports the broadcaster will send to, or null if the handshake failed.
     */
    suspend fun connect(
        host: String,
        controlPort: Int,
        receiverName: String,
        audioPort: Int,
        videoPort: Int?,
        passwordProvider: suspend (wrongAttempt: Boolean) -> String? = { null }
    ): Result<Handshake> {
        disconnect()
        // A fresh queue and a fresh generation for this connection. The previous session's
        // queue may still hold unread push messages, and a handshake that consumed one of
        // those - a stale `bye`, say - would fail for no real reason.
        val channel = Channel<ControlMessage>(capacity = 32)
        inbound = channel
        val generation = connectionGeneration.incrementAndGet()
        welcomeSdp = ""
        refusal = null
        _access.value = ControlMessage.ACCESS_PUBLIC
        _state.value = ConnectionState.Connecting
        handshakeJob = currentCoroutineContext()[Job]

        val newSocket = Socket()
        try {
            withContext(Dispatchers.IO) {
                newSocket.tcpNoDelay = true
                newSocket.connect(InetSocketAddress(host, controlPort), 5000)
            }
            AppLog.info("ControlClient", "Control socket open to $host:$controlPort (audio $audioPort, video $videoPort)")
        } catch (e: IOException) {
            AppLog.error("ControlClient", "Control socket to $host:$controlPort failed: $e")
            _state.value = ConnectionState.Failed("Could not reach the broadcaster: ${e.message}")
            return Result.failure(e)
        }

        socket = newSocket
        running.set(true)
        readerJob = scope.launch(Dispatchers.IO) { readLoop(generation, channel) }

        return try {
            sendQuietly(ControlMessage.Hello(LocalStream.PROTOCOL_VERSION, receiverName, userAgent()))
            sessionId = readUntilWelcome()
            AppLog.info("ControlClient", "Welcome received, session $sessionId (access ${_access.value})")

            // Password first: the broadcaster holds the offer and sends nothing until the viewer
            // is authenticated, so offering ports it will ignore would only waste a round trip.
            val needsApproval = _access.value == ControlMessage.ACCESS_APPROVAL
            if (_access.value == ControlMessage.ACCESS_PASSWORD) {
                authenticate(passwordProvider)
            }

            sendQuietly(ControlMessage.Offer(sessionId, audioPort, videoPort))
            if (needsApproval && refusal == null) {
                _state.value = ConnectionState.AwaitingApproval(broadcasterName.value)
                // The reader can classify a denial between the check above and the write, and
                // then its `Rejected` would sit under this `AwaitingApproval`. Written again
                // from here so the last of the two writes belongs to whoever saw the refusal,
                // which is the only ordering that cannot leave the viewer waiting on a decision
                // the broadcaster has already given.
                refusal?.let { _state.value = it }
                AppLog.info("ControlClient", "Offer sent, waiting for the broadcaster to decide")
            }
            // No timeout on the approval wait: the presenter may be across the room, and the
            // viewer is told they are waiting. The socket closing is the other way out.
            val handshake = readUntilAccept(timeoutMillis = if (needsApproval) null else HANDSHAKE_TIMEOUT_MS)
            AppLog.info("ControlClient", "Handshake accepted: audio ${handshake.audioPort}, video ${handshake.videoPort}")
            if (refusal == null) {
                _state.value = ConnectionState.Connected(broadcasterName.value, _mode.value)
            }
            Result.success(handshake)
        } catch (e: CancellationException) {
            // The viewer left, or the view model went away. Not a failure to report.
            AppLog.info("ControlClient", "Handshake cancelled")
            running.set(false)
            socket?.close()
            socket = null
            _state.value = ConnectionState.Idle
            Result.failure(e)
        } catch (e: Exception) {
            AppLog.error("ControlClient", "Handshake failed: $e")
            running.set(false)
            socket?.close()
            socket = null
            // A refusal the read loop already classified - rejected or banned - keeps that state,
            // so the UI can tell "try again later" from "do not try again". Read from the
            // refusal rather than the state, because a step of this handshake may have
            // overwritten the state after the refusal was recorded - and published again from
            // here for the same reason: the refusal is the outcome, and a state the handshake
            // put up before it was recorded must not be the one the viewer is left looking at.
            val recorded = refusal
            if (recorded != null) {
                _state.value = recorded
            } else {
                val current = _state.value
                if (current !is ConnectionState.Blocked && current !is ConnectionState.Rejected) {
                    _state.value =
                        ConnectionState.Failed(e.message ?: "The broadcaster refused the connection.")
                }
            }
            Result.failure(e)
        } finally {
            handshakeJob = null
        }
    }

    /**
     * Sends passwords until one is accepted.
     *
     * The prompt is driven from here rather than left to a retry loop in the UI, so every refusal
     * comes back as a fresh [ConnectionState.AwaitingPassword] and the field starts empty each
     * time: a viewer who mistyped cannot resubmit the wrong password by reflex.
     */
    private suspend fun authenticate(passwordProvider: suspend (Boolean) -> String?) {
        var wrongAttempt = false
        while (true) {
            // A refusal that arrived while the previous attempt's password was being entered
            // must not be answered with a fresh prompt: there is no longer anything to prompt
            // for, and the viewer would be left typing into a session that is already over.
            val alreadyRefused = refusalReason()
            if (alreadyRefused != null) throw IOException(alreadyRefused)
            _state.value =
                ConnectionState.AwaitingPassword(broadcasterName.value, wrongAttempt)
            val password = passwordProvider(wrongAttempt)
                ?: throw ConnectCancelled("The password prompt was cancelled.")
            sendQuietly(ControlMessage.AuthRequest(sessionId, password))
            // Read until the broadcaster gives its verdict, skipping the push messages it is
            // entitled to send meanwhile. While the prompt is open the reader keeps queueing
            // stats, so a single read after the request usually returns one of those rather
            // than the AuthResult; treating it as a refusal would re-prompt the viewer before
            // the password was ever judged, and a correct password would never be accepted.
            while (true) {
                when (val answer = nextMessage(timeoutMillis = PASSWORD_TIMEOUT_MS)) {
                    is ControlMessage.AuthResult -> {
                        if (answer.granted) return
                        AppLog.warning("ControlClient", "Password refused: ${answer.reason}")
                        wrongAttempt = true
                        break
                    }
                    // The broadcaster opened the broadcast while the viewer was typing, so the
                    // password is no longer asked for. Accepting what was already agreed is right.
                    is ControlMessage.Accept -> return
                    else -> AppLog.debug("ControlClient", "Skipping ${answer::class.simpleName} while authenticating")
                }
            }
        }
    }

    data class Handshake(
        val audioPort: Int,
        val videoPort: Int?,
        val audioSsrc: Int,
        val videoSsrc: Int?,
        val peerAddress: InetAddress,
        /** The broadcaster's audio channel count, from the welcome's SDP. */
        val audioChannels: Int
    )

    /**
     * Waits for the greeting, ignoring anything else that arrives first.
     *
     * The broadcaster is entitled to push messages (stats, mode changes) as soon as it
     * recognises a session, and those can be interleaved with its own handshake replies.
     * Reading exactly one message and insisting it be the `welcome` makes the client
     * fail on a perfectly legal stream, so unexpected messages are skipped rather than
     * treated as a protocol error. Each skip re-arms the timeout via [nextMessage].
     */
private suspend fun readUntilWelcome(): String {
        while (true) {
            when (val message = nextMessage()) {
                is ControlMessage.Welcome -> {
                    _broadcasterName.value = message.displayName
                    _mode.value = message.mode
                    _access.value = message.access
                    welcomeSdp = message.sdp
                    return message.sessionId
                }
                // The greeting is the first thing a broadcaster owes us; an `accept`
                // before it means the two sides disagree about the session state.
                is ControlMessage.Accept -> throw IOException("The broadcaster accepted the session before greeting it.")
                else -> AppLog.debug("ControlClient", "Skipping ${message::class.simpleName} while waiting for the greeting")
            }
        }
    }

    /**
     * Waits for the port acceptance, skipping unrelated push messages the same way.
     *
     * @param timeoutMillis null to wait indefinitely, used for approval mode.
     */
    private suspend fun readUntilAccept(timeoutMillis: Long?): Handshake {
        while (true) {
            when (val message = nextMessage(timeoutMillis)) {
                is ControlMessage.Accept -> return Handshake(
                    message.audioPort,
                    message.videoPort,
                    message.audioSsrc,
                    message.videoSsrc,
                    socket?.inetAddress
                        ?: throw IOException("The broadcaster's network address is unavailable."),
                    LocalStream.audioChannelsFromSdp(welcomeSdp)
                )
                is ControlMessage.Welcome -> throw IOException("The broadcaster greeted the session twice.")
                else -> AppLog.debug("ControlClient", "Skipping ${message::class.simpleName} while waiting for the acceptance")
            }
        }
    }
    /**
     * Takes the next message, failing fast on a `deny` or `bye`.
     *
     * Anything already buffered in [inbound] is used before waiting, so a message that
     * arrived during the handshake is never lost.
     *
     * @param timeoutMillis null to wait indefinitely. A cancel or a closed socket is the only
     *        way out of an untimed wait, and [disconnect] does both.
     */
    private suspend fun nextMessage(timeoutMillis: Long? = HANDSHAKE_TIMEOUT_MS): ControlMessage {
        while (true) {
            val message = if (timeoutMillis == null) {
                inbound.receive()
            } else {
                withTimeoutOrNull(timeoutMillis) { inbound.receive() }
                    ?: throw IOException("The broadcaster stopped responding.")
            }

            when (message) {
                is ControlMessage.Deny -> throw IOException(message.reason)
                is ControlMessage.Bye -> throw IOException("The broadcaster ended the session: ${message.reason}")
                else -> return message
            }
        }
    }

    private suspend fun readLoop(generation: Long, channel: Channel<ControlMessage>) {
        val current = socket ?: return
        val reader = BufferedReader(InputStreamReader(current.getInputStream(), Charsets.UTF_8))
        // Set when a `deny` ends the session, so the socket below is closed as part of the
        // refusal rather than left to a later teardown.
        var refused = false
        try {
            while (running.get() && isCurrent(generation)) {
                val line = withContext(Dispatchers.IO) { reader.readLine() }
                if (line == null) {
                    AppLog.info("ControlClient", "Control socket closed by the broadcaster")
                    break
                }
                if (line.isEmpty()) continue
                val message = ControlMessage.parse(line)
                if (message == null) {
                    AppLog.warning("ControlClient", "Unparseable control line: $line")
                    continue
                }
                AppLog.debug("ControlClient", "Control message in: ${message::class.simpleName}")

                when (message) {
                    is ControlMessage.ModeChanged ->
                        if (isCurrent(generation)) _mode.value = message.mode
                    is ControlMessage.Deny -> {
                        // A ban is terminal and gets its own state so the UI says "not this
                        // time" instead of inviting a retry the broadcaster will refuse too.
                        val classified =
                            if (message.code == ControlMessage.DENY_BLOCKED) {
                                ConnectionState.Blocked(message.reason)
                            } else {
                                ConnectionState.Rejected(message.reason)
                            }
                        // Recorded before the state is published, and for this generation even
                        // when it is stale: a reader that has been superseded must not leave a
                        // handshake of its own believing it was not refused.
                        if (isCurrent(generation)) {
                            refusal = classified
                            _state.value = classified
                        }
                        // A refusal is the end of the session, not one more message in it. The
                        // broadcaster has nothing further to send a viewer it has turned away,
                        // so the socket is closed here rather than left holding a connection
                        // that carries no stream and cannot be ended by the viewer waiting on
                        // it. The denial is handed to the handshake before the socket goes, so a
                        // handshake parked waiting for a decision it will now never get wakes
                        // with the reason instead of waiting for ever.
                        AppLog.info("ControlClient", "Refused by the broadcaster (${message.code}): ${message.reason}")
                        channel.send(message)
                        refused = true
                        break
                    }
                    is ControlMessage.Bye -> {
                        if (isCurrent(generation)) {
                            _state.value = ConnectionState.Disconnected(message.reason)
                        }
                        break
                    }
                    else -> Unit
                }
                // The channel is the one this loop was started with, so a superseded reader
                // can only ever write to its own dead queue, never the live one.
                channel.send(message)
            }
            if (refused) {
                // Stopped before the close, so that closing the socket reads as the teardown it
                // is: with `running` still set, the reader below would report a dropped
                // connection over the refusal and lose the reason the viewer needs to see.
                running.set(false)
                try {
                    current.close()
                } catch (e: IOException) {
                    AppLog.debug("ControlClient", "Control socket already closed after a refusal")
                }
                socket = null
            } else if (running.get() && isCurrent(generation)) {
                _state.value = ConnectionState.Disconnected("The broadcaster closed the connection.")
            }
        } catch (e: IOException) {
            if (isCurrent(generation) && running.get()) {
                AppLog.error("ControlClient", "Control socket failed: $e")
                _state.value = ConnectionState.Failed(e.message ?: "The connection was lost.")
            } else {
                // Expected: disconnect() closes the socket, which unblocks readLine with a
                // "Socket closed". That is not a failure, and this reader no longer owns the
                // state, so it is not worth an error-level stack trace.
                AppLog.debug("ControlClient", "Control socket closed during teardown")
            }
        }
    }

    private fun isCurrent(generation: Long): Boolean = connectionGeneration.get() == generation

    suspend fun requestKeyframe() {
        sendQuietly(ControlMessage.KeyframeRequest(sessionId))
    }

    suspend fun requestBitrate(videoKbps: Int?, audioKbps: Int?) {
        sendQuietly(ControlMessage.BitrateRequest(videoKbps, audioKbps))
    }

    suspend fun requestMode(mode: String) {
        sendQuietly(ControlMessage.ModeRequest(mode))
    }

    suspend fun sendStats(stats: ControlMessage.ReceiverStats) {
        sendQuietly(stats)
    }

    private suspend fun sendQuietly(message: ControlMessage) {
        val current = socket ?: return
        if (current.isClosed) return
        try {
            withContext(Dispatchers.IO) {
                current.getOutputStream().apply {
                    write(message.toJson().toString().toByteArray(Charsets.UTF_8))
                    write("\n".toByteArray(Charsets.UTF_8))
                    flush()
                }
            }
        } catch (e: IOException) {
            // The read loop will notice the socket dying and update the state.
        }
    }

    fun disconnect(reason: String = ControlMessage.BYE_USER_LEFT) {
        // Invalidate any in-flight reader before the state flip, so a session being torn down
        // cannot publish Failed/Disconnected over the one that replaces it.
connectionGeneration.incrementAndGet()
        // A refusal belongs to the connection that was refused. Clearing it here keeps the next
        // attempt from inheriting a verdict that was never meant for it.
        refusal = null
        // An approval-mode handshake waits with no timeout, so leaving it parked would keep the
        // connection reported as joining after the user has walked away.
        handshakeJob?.cancel()
        handshakeJob = null
        if (!running.getAndSet(false)) {
            _state.value = ConnectionState.Idle
            return
        }
        val current = socket
        socket = null
        readerJob?.cancel()
        readerJob = null
        _state.value = ConnectionState.Idle

        // The Bye write must not run on the caller's thread: disconnect() is called from the
        // main thread (the UI, and the state collector that observes the peer closing), and a
        // socket write there trips StrictMode's NetworkOnMainThreadException. Cancel the reader
        // first, then send and close on the IO dispatcher.
        scope.launch(Dispatchers.IO) {
            try {
                current?.getOutputStream()?.apply {
                    write((ControlMessage.Bye(reason).toJson().toString() + "\n").toByteArray(Charsets.UTF_8))
                    flush()
                }
            } catch (e: IOException) {
                // Already gone.
            }
            try {
                current?.close()
            } catch (e: IOException) {
                // Already gone.
            }
        }
    }

    companion object {
        fun userAgent(): String = "LocalStream-Android/1.0.0"

/** How long the broadcaster has to answer each half of the handshake. */
        private const val HANDSHAKE_TIMEOUT_MS = 15_000L

        /**
         * How long a typed password may go unanswered.
         *
         * Longer than [HANDSHAKE_TIMEOUT_MS] and, unlike it, not infinite: someone has to be able
         * to close a prompt left open by a phone call.
         */
        private const val PASSWORD_TIMEOUT_MS = 60_000L
    }
}
