package com.localstream.protocol

import java.io.ByteArrayOutputStream

/**
 * H.264 RTP packetization (RFC 6184).
 *
 * Converts the AVCC access units produced by `MediaCodec` into RTP payloads, and back.
 * Only the single-NAL, STAP-A and FU-A modes are implemented, which is everything
 * MediaCodec emits.
 */
object H264Rtp {

    const val NAL_SLICE_NON_IDR = 1
    const val NAL_SLICE_IDR = 5
    const val NAL_SEI = 6
    const val NAL_SPS = 7
    const val NAL_PPS = 8
    const val NAL_AUD = 9

    const val TYPE_STAP_A = 24
    const val TYPE_STAP_B = 25
    const val TYPE_MTAP_16 = 26
    const val TYPE_MTAP_24 = 27
    const val TYPE_FU_A = 28
    const val TYPE_FU_B = 29

    private val START_CODE = byteArrayOf(0, 0, 0, 1)

    fun isParameterSet(nalType: Int): Boolean = nalType == NAL_SPS || nalType == NAL_PPS

    /**
     * Removes an Annex B start code if the buffer begins with one.
     *
     * The AVC contract says `csd-0`/`csd-1` are bare NAL units, but encoders shipped on real
     * devices (observed on Samsung's `OMX.qcom.video.encoder.avc`, Android 13) prefix them
     * with `00 00 00 01`. Left in place, that prefix becomes the NAL header byte: the type
     * reads as 0 instead of 7, a receiver never recognises the unit as a parameter set, and
     * no decoder can ever be opened.
     */
    fun stripStartCode(nal: ByteArray): ByteArray {
        if (nal.size < 4) return nal
        if (nal[0] != 0.toByte() || nal[1] != 0.toByte()) return nal
        return when {
            nal[2] == 1.toByte() -> nal.copyOfRange(3, nal.size)
            nal[2] == 0.toByte() && nal[3] == 1.toByte() -> nal.copyOfRange(4, nal.size)
            else -> nal
        }
    }

    /** True when the buffer starts with a 3- or 4-byte Annex B start code. */
    fun hasStartCode(buffer: ByteArray, at: Int = 0): Boolean {
        if (at + 3 > buffer.size) return false
        if (buffer[at] != 0.toByte() || buffer[at + 1] != 0.toByte()) return false
        if (buffer[at + 2] == 1.toByte()) return true
        return buffer[at + 2] == 0.toByte() && at + 4 <= buffer.size && buffer[at + 3] == 1.toByte()
    }

    private fun startCodeLength(buffer: ByteArray, at: Int): Int =
        if (buffer[at + 2] == 1.toByte()) 3 else 4

    /**
     * Converts an encoder output buffer into the length-prefixed AVCC form [splitAvcc] reads.
     *
     * Byte-buffer output is documented as length-prefixed, and encoders that honour it pass
     * straight through. Several emit Annex B instead, and feeding that to a length-prefixed
     * reader is not a smaller mistake than it looks: the leading start code reads as a
     * length of 1, so the slice is taken to be a single header byte, the real length is
     * nonsense, and the picture is dropped before it is ever packetised. A receiver then sees
     * video packets arriving and no decodable frames, which is indistinguishable from loss.
     */
    fun toAvcc(buffer: ByteArray): ByteArray {
        if (!hasStartCode(buffer)) return buffer

        val units = ArrayList<ByteArray>(4)
        var unitStart = startCodeLength(buffer, 0)
        var at = unitStart
        while (at < buffer.size) {
            if (hasStartCode(buffer, at)) {
                if (at > unitStart) {
                    units.add(buffer.copyOfRange(unitStart, at))
                }
                at += startCodeLength(buffer, at)
                unitStart = at
                continue
            }
            at++
        }
        if (unitStart < buffer.size) {
            units.add(buffer.copyOfRange(unitStart, buffer.size))
        }
        if (units.isEmpty()) return buffer

        var total = 0
        for (unit in units) total += 4 + unit.size
        val out = ByteArray(total)
        var p = 0
        for (unit in units) {
            out[p++] = (unit.size ushr 24).toByte()
            out[p++] = (unit.size ushr 16).toByte()
            out[p++] = (unit.size ushr 8).toByte()
            out[p++] = unit.size.toByte()
            unit.copyInto(out, p)
            p += unit.size
        }
        return out
    }

    /**
     * Prepends the parameter sets to an access unit, in AVCC form.
     *
     * The parameter sets are repeated in-band on every keyframe because a receiver that joins
     * after the first one has no other way to learn them, and `MediaCodec` never repeats them
     * in the bitstream on its own.
     */
    fun withParameterSets(accessUnit: ByteArray, sps: ByteArray?, pps: ByteArray?): ByteArray {
        if (sps == null || pps == null || sps.isEmpty() || pps.isEmpty()) return accessUnit
        val out = ByteArray(4 + sps.size + 4 + pps.size + accessUnit.size)
        var at = 0
        for (nal in arrayOf(sps, pps)) {
            out[at++] = (nal.size ushr 24).toByte()
            out[at++] = (nal.size ushr 16).toByte()
            out[at++] = (nal.size ushr 8).toByte()
            out[at++] = nal.size.toByte()
            nal.copyInto(out, at)
            at += nal.size
        }
        accessUnit.copyInto(out, at)
        return out
    }

    /**
     * Aggregation and fragmentation formats this codec does not implement. Anything else is
     * treated as a single-NAL unit packet.
     */
    private fun isAggregateOrFragment(type: Int): Boolean =
        type == TYPE_STAP_A || type == TYPE_STAP_B || type == TYPE_MTAP_16 ||
            type == TYPE_MTAP_24 || type == TYPE_FU_A || type == TYPE_FU_B

    /**
     * Splits an AVCC buffer (a run of 4-byte big-endian length prefixes, each followed by
     * one NAL unit) into the individual NAL units.
     */
    fun splitAvcc(buffer: ByteArray, offset: Int = 0, length: Int = buffer.size - offset): List<ByteArray> {
        val nals = ArrayList<ByteArray>(4)
        var pos = offset
        val end = offset + length
        while (pos + 4 <= end) {
            var nalLength = 0
            for (i in 0 until 4) nalLength = (nalLength shl 8) or (buffer[pos + i].toInt() and 0xFF)
            pos += 4
            if (nalLength <= 0 || pos + nalLength > end) break
            nals.add(buffer.copyOfRange(pos, pos + nalLength))
            pos += nalLength
        }
        return nals
    }

    fun nalType(nal: ByteArray): Int = nal[0].toInt() and 0x1F

    /**
     * Encapsulates the NAL units of one access unit into RTP payloads.
     *
     * The caller assigns sequence numbers and sets the marker bit on the final payload,
     * per RFC 6184 section 5.1.
     */
    fun packetize(nals: List<ByteArray>): List<ByteArray> {
        if (nals.isEmpty()) return emptyList()
        if (nals.size == 1 && nals[0].size <= LocalStream.RTP_MAX_PAYLOAD) {
            return listOf(nals[0])
        }

        val payloads = ArrayList<ByteArray>()

        // STAP-A aggregates the leading non-VCL NALs (AUD/SPS/PPS) with the slice, so a
        // receiver that just joined gets its parameter sets and a decodable picture in a
        // single datagram. Only worth doing when a VCL NAL follows, otherwise the marker
        // bit would never arrive and the aggregated units would sit in the reassembly
        // buffer forever.
        val leading = ArrayList<ByteArray>()
        var leadingBytes = 1
        var leadingStopsBeforeVcl = true
        for (nal in nals) {
            val type = nalType(nal)
            if (isParameterSet(type) || type == NAL_AUD || type == NAL_SEI) {
                if (leadingBytes + 2 + nal.size > LocalStream.RTP_MAX_PAYLOAD) {
                    leadingStopsBeforeVcl = false
                    break
                }
                leading.add(nal)
                leadingBytes += 2 + nal.size
            } else {
                leadingStopsBeforeVcl = false
                break
            }
        }

        if (leading.size >= 2 && !leadingStopsBeforeVcl) {
            val stap = ByteArray(leadingBytes)
            // F=0, NRI=0: the aggregate's NRI is not meaningful when it mixes parameter
            // sets with a slice; receivers key off the individual NAL headers instead.
            stap[0] = TYPE_STAP_A.toByte()
            var p = 1
            for (nal in leading) {
                stap[p++] = ((nal.size shr 8) and 0xFF).toByte()
                stap[p++] = (nal.size and 0xFF).toByte()
                System.arraycopy(nal, 0, stap, p, nal.size)
                p += nal.size
            }
            payloads.add(stap)
            for (nal in nals.subList(leading.size, nals.size)) {
                payloads.addAll(fragmentIfNeeded(nal))
            }
            return payloads
        }

        for (nal in nals) payloads.addAll(fragmentIfNeeded(nal))
        return payloads
    }

    /** Single-NAL where it fits, FU-A fragments where it does not. */
    private fun fragmentIfNeeded(nal: ByteArray): List<ByteArray> {
        if (nal.size <= LocalStream.RTP_MAX_PAYLOAD) return listOf(nal)

        val nalType = nalType(nal)
        val indicator = ((nal[0].toInt() and 0xE0) or TYPE_FU_A).toByte()
        val body = nal.copyOfRange(1, nal.size) // the FU indicator replaces the NAL header
        val maxFragment = LocalStream.RTP_MAX_PAYLOAD - 2

        val payloads = ArrayList<ByteArray>()
        var sent = 0
        while (sent < body.size) {
            val chunk = minOf(maxFragment, body.size - sent)
            val start = sent == 0
            val end = sent + chunk >= body.size
            val out = ByteArray(2 + chunk)
            out[0] = indicator
            out[1] = ((if (start) 0x80 else 0) or (if (end) 0x40 else 0) or nalType).toByte()
            System.arraycopy(body, sent, out, 2, chunk)
            payloads.add(out)
            sent += chunk
        }
        return payloads
    }

    /**
     * Reassembles RTP payloads into Annex-B access units for the decoder.
     *
     * The marker bit is the only frame boundary signal, per RFC 6184 section 5.1: it is
     * set on the last packet of every access unit, including single-NAL units. Anything
     * still unterminated when the stream is torn down is discarded — a half-received
     * picture is worthless and buffering it would only add latency.
     */
    class Depacketizer(private val annexB: Boolean = true) {

        private val current = ByteArrayOutputStream(64 * 1024)
        private val fragment = ByteArrayOutputStream(64 * 1024)
        private var fragmentActive = false

        /** The most recent SPS/PPS seen, for use as the decoder's csd-0/csd-1. */
        var sps: ByteArray? = null
            private set
        var pps: ByteArray? = null
            private set

        /** Drops only the partial access unit while retaining learned decoder parameters. */
        fun discardCurrentAccessUnit() {
            current.reset()
            fragment.reset()
            fragmentActive = false
        }

        /**
         * Feeds one RTP payload.
         *
         * @return the completed access unit when [marker] closes a frame, otherwise null.
         */
        fun accept(payload: ByteArray, marker: Boolean): ByteArray? {
            if (payload.isEmpty()) return null
            val type = payload[0].toInt() and 0x1F

            when {
                type == TYPE_STAP_A -> {
                    var p = 1
                    while (p + 2 <= payload.size) {
                        val nalSize = ((payload[p].toInt() and 0xFF) shl 8) or
                            (payload[p + 1].toInt() and 0xFF)
                        p += 2
                        if (nalSize <= 0 || p + nalSize > payload.size) break
                        val nal = payload.copyOfRange(p, p + nalSize)
                        p += nalSize
                        captureParameterSet(nalType(nal), nal)
                        appendNal(nal)
                    }
                }

                type == TYPE_FU_A -> {
                    if (payload.size < 2) return null
                    val fuHeader = payload[1].toInt()
                    val start = (fuHeader and 0x80) != 0
                    val end = (fuHeader and 0x40) != 0
                    val nalType = fuHeader and 0x1F

                    if (start) {
                        // A new fragment supersedes any abandoned one; partial pictures are
                        // dropped rather than completed from mismatched pieces.
                        if (fragmentActive) discardCurrent()
                        fragment.reset()
                        fragmentActive = true
                        fragment.write(byteArrayOf(((payload[0].toInt() and 0xE0) or nalType).toByte()))
                    }
                    if (!fragmentActive) return null
                    fragment.write(payload.copyOfRange(2, payload.size))
                    if (end) {
                        val nal = fragment.toByteArray()
                        fragment.reset()
                        fragmentActive = false
                        captureParameterSet(nalType, nal)
                        appendNal(nal)
                    }
                }

                isAggregateOrFragment(type) -> {
                    // STAP-B, MTAP16/24 and FU-B are RTP payload-format extensions that no
                    // encoder this client talks to produces, so they are ignored.
                }
                else -> {
                    // A single-NAL unit packet. Not only slices: an access unit carrying just
                    // SPS/PPS and no picture is sent as individual packets, and a receiver that
                    // dropped non-VCL types here would never learn the parameter sets.
                    captureParameterSet(type, payload)
                    appendNal(payload)
                }
            }

            return if (marker) finish() else null
        }

        private fun captureParameterSet(type: Int, nal: ByteArray) {
            when (type) {
                NAL_SPS -> sps = nal
                NAL_PPS -> pps = nal
            }
        }

        private fun appendNal(nal: ByteArray) {
            if (annexB) {
                current.write(START_CODE)
                current.write(nal)
            } else {
                current.write((nal.size shr 24) and 0xFF)
                current.write((nal.size shr 16) and 0xFF)
                current.write((nal.size shr 8) and 0xFF)
                current.write(nal.size and 0xFF)
                current.write(nal)
            }
        }

        private fun discardCurrent() {
            current.reset()
            fragmentActive = false
        }

        private fun finish(): ByteArray? {
            if (fragmentActive) {
                // Marker arrived mid-fragment: this frame is truncated, so drop it.
                fragmentActive = false
                current.reset()
                return null
            }
            if (current.size() == 0) return null
            val accessUnit = current.toByteArray()
            current.reset()
            return accessUnit
        }
    }
}
