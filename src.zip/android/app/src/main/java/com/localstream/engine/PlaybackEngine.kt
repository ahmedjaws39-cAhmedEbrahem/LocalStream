﻿package com.localstream.engine

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.media.MediaCodec
import android.media.MediaFormat
import android.view.Surface
import com.localstream.logging.AppLog
import com.localstream.protocol.LocalStream
import com.localstream.protocol.OpusHead
import java.nio.ByteBuffer
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

/**
 * Presets for the receive-side buffer.
 *
 * The buffer is how much of the stream may wait before it is played: both the audio packets and
 * the video frames are held to the same duration. More absorbs more network jitter without a
 * break, at the cost of a longer delay between the broadcaster and this device; less keeps the
 * stream closer to live. [millis] is measured against 20 ms Opus frames for audio and a nominal
 * 30 fps frame for video.
 */
enum class ReceiveBuffer(val millis: Int, val label: String) {
    LOW_LATENCY(200, "Low latency"),
    BALANCED(500, "Balanced"),
    SMOOTH(1000, "Smooth"),
    MAXIMUM(2000, "Maximum");

    companion object {
        /** The preset for [millis], or [BALANCED] when it matches no preset. */
        fun forMillis(millis: Int): ReceiveBuffer =
            entries.firstOrNull { it.millis == millis } ?: BALANCED
    }
}

/**
 * Decodes an incoming stream: H.264 into a [Surface], Opus into an [AudioTrack].
 *
 * This drives `MediaCodec` directly rather than going through ExoPlayer. ExoPlayer's
 * extractors are built around containers \u2014 MP4, MPEG-TS, Matroska \u2014 and the RTSP extractors
 * additionally expect SDP-driven session setup. A raw RTP stream has neither, so using
 * ExoPlayer here would mean writing a custom `DataSource` *and* a custom `Extractor`
 * anyway. Driving the decoders directly is less code and removes a dependency.
 */
class PlaybackEngine(private val context: Context) {

    private var audioDecoder: MediaCodec? = null
    private var audioTrack: AudioTrack? = null

    /** True once the audio prebuffer has filled and the track is playing. */
    @Volatile
    private var audioStarted = false

    /**
     * True while playback is paused because the queue ran dry. Held until a small cushion
     * refills, so resuming does not underrun again immediately.
     */
    @Volatile
    private var audioStarved = false

    /** Nanotime when the audio prebuffer wait gives up and playback starts regardless. */
    @Volatile
    private var audioStartDeadlineNanos = 0L

    /** Nanotime of the last PCM write to the track, for stall detection. */
    @Volatile
    private var lastAudioWriteNanos = 0L

    /** Reused output buffer, so a decode does not allocate a ByteArray per frame. */
    private var audioScratch = ByteArray(0)

    /** How many times playback ran dry and was paused. */
    @Volatile
    var audioUnderruns: Long = 0L
        private set

    private var videoThread: Thread? = null
    private var audioThread: Thread? = null

    private val videoRunning = AtomicBoolean(false)
    private val audioRunning = AtomicBoolean(false)

    /**
     * Bumped on every [startVideo]. A decode thread carries the value it was started with and
     * refuses to create or drive anything once the live generation has moved on. Without this, a
     * thread still finishing a slow codec setup could wake after a replacement has already set
     * [videoRunning] back to true, mistake the new run for its own, and drive a decoder bound to
     * the surface that was just destroyed - which presents as a black picture.
     */
    private val videoGeneration = AtomicLong(0)

    private var videoInputSurface: Surface? = null

    /**
     * Identifies the `SurfaceView` the live decoder is bound to.
     *
     * A `SurfaceView` is destroyed and recreated whenever its composable enters or leaves the
     * tree - toggling fullscreen, rotating, switching tabs - and the incoming surface can be
     * created before the outgoing one is destroyed. Stamping each surface lets a late
     * [stopVideo] from the outgoing view recognise that it no longer owns the decoder and leave
     * the new one alone.
     */
    @Volatile
    private var videoSurfaceToken: Any? = null

    @Volatile
    private var videoWidth = 0
    @Volatile
    private var videoHeight = 0

    @Volatile
    var framesDecoded: Long = 0
        private set

    /**
     * Starts (or rebinds) the video pipeline to [targetSurface].
     *
     * [token] identifies the calling `SurfaceView` so a later [stopVideo] from a replaced view
     * cannot tear down this one. Only the surface and the token are recorded here: the decoder
     * cannot be created until SPS and PPS arrive - they are mandatory decoder configuration - and
     * it is created later, on the decode thread, rather than on whichever network thread happened
     * to deliver them.
     */
    fun startVideo(token: Any, targetSurface: Surface) {
        // Invalidate the outgoing pipeline before anything else. A thread from a previous surface
        // may still be inside a slow codec setup; retiring its generation first means that even
        // when [videoRunning] goes back on below, the old thread cannot mistake the new run for
        // its own. Doing this ahead of stopVideoPipeline is what closes the window between the
        // join timing out and the new thread starting.
        val generation = videoGeneration.incrementAndGet()
        videoSurfaceToken = token
        stopVideoPipeline()

        videoRunning.set(true)
        videoInputSurface = targetSurface
        pendingSps = null
        pendingPps = null
        presentationTimeUs = 0L
        // Hold decoding until the video buffer has filled, matching the audio delay so the two
        // stay in sync. The deadline keeps a trickling stream from never painting.
        videoStarted = false
        videoStartDeadlineNanos =
            System.nanoTime() + (prebufferFrames * NOMINAL_FRAME_MS + STARTUP_GRACE_MS) * 1_000_000L
        val run = VideoRun(targetSurface, generation)
        videoThread = Thread({ videoLoop(run) }, "LocalStream-VideoDecode").apply {
            priority = Thread.MAX_PRIORITY
            start()
        }
    }

    /**
     * Stops only the video pipeline, leaving audio playing, if [token] still owns it.
     *
     * Called when a `SurfaceView`'s surface is destroyed. A view that has already been replaced
     * must not stop the decoder a newer surface has taken over, so a mismatched token is ignored
     * - the surface is simply gone. [stop] ignores the token and always ends the session.
     */
    fun stopVideo(token: Any) {
        if (videoSurfaceToken !== token) return
        videoSurfaceToken = null
        stopVideoPipeline()
    }

    private fun stopVideoPipeline() {
        videoRunning.set(false)
        // Wait briefly for the decode thread to wind down. It owns its decoder and releases it on
        // the way out, so nothing is stopped out from under the thread. If the join times out - a
        // hardware codec that is slow to start - correctness does not depend on it: the generation
        // bump in startVideo stops the lagging thread from touching the next run, and it frees its
        // own decoder as soon as that setup finishes.
        val thread = videoThread
        videoThread = null
        if (thread != null && thread !== Thread.currentThread()) {
            thread.join(JOIN_TIMEOUT_MS)
        }
        videoInputSurface = null
        synchronized(videoInput) { videoInput.clear() }
        pendingSps = null
        pendingPps = null
        presentationTimeUs = 0L
    }

    @Volatile
    private var pendingSps: ByteArray? = null

    @Volatile
    private var pendingPps: ByteArray? = null

    /**
     * Hands one access unit to the decode thread. Called from the network thread.
     *
     * Nothing here touches [MediaCodec]. The codec is single-threaded by construction: one
     * thread creates it, feeds it, and drains it. That removes the whole class of
     * "IllegalStateException in a codec" failures that come from driving one codec from
     * two threads.
     *
     * @return true if the frame was accepted for decoding.
     */
    fun submitVideo(accessUnit: ByteArray, sps: ByteArray?, pps: ByteArray?, hasVideo: Boolean): Boolean {
        if (!hasVideo || !videoRunning.get()) {
            return false
        }

        // Parameter sets are recorded for the decode thread, which owns codec creation.
        if (sps != null) pendingSps = sps
        if (pps != null) pendingPps = pps

        // Bounded to the configured receive buffer, and the oldest frame is discarded when full:
        // for live video a late frame has no value, so shedding the least useful one is always
        // better than adding latency.
        synchronized(videoInput) {
            if (videoInput.size >= maxQueuedFrames) {
                videoInput.removeFirst()
            }
            videoInput.addLast(accessUnit)
        }
        return true
    }

    private val videoInput = ArrayDeque<ByteArray>()

    /** True once the video prebuffer has filled, so decoding starts with a cushion. */
    @Volatile
    private var videoStarted = false

    /** Nanotime when the video prebuffer wait gives up and decoding starts regardless. */
    @Volatile
    private var videoStartDeadlineNanos = 0L

    /**
     * The decode thread's main loop.
     *
     * Waits for parameter sets, creates the decoder, then pumps queued frames in and
     * rendered frames out for as long as the pipeline is running.
     */
    private fun videoLoop(run: VideoRun) {
        val bufferInfo = MediaCodec.BufferInfo()
        var lastWaitLogNanos = 0L
        try {
            while (isCurrent(run)) {
                if (!videoStarted) {
                    val queued = synchronized(videoInput) { videoInput.size }
                    if (queued >= prebufferFrames || System.nanoTime() >= videoStartDeadlineNanos) {
                        videoStarted = true
                    } else {
                        val now = System.nanoTime()
                        if (now - lastWaitLogNanos > 2_000_000_000L) {
                            lastWaitLogNanos = now
                            AppLog.debug("PlaybackEngine", "prebuffer waiting queued=$queued need=$prebufferFrames deadline=${(videoStartDeadlineNanos - now) / 1_000_000}ms")
                        }
                        Thread.sleep(PREBUFFER_POLL_MS)
                        continue
                    }
                }
                if (run.decoder == null) {
                    run.decoder = createVideoDecoderWhenReady(run) ?: continue
                }

                val decoder = run.decoder ?: continue
                pumpInput(decoder)
                if (!drainOutput(decoder, bufferInfo)) {
                    // The codec rejected a dequeue and cannot be trusted; drop it so the next
                    // pass builds a fresh one rather than feeding a dead codec.
                    run.release()
                }
            }
        } finally {
            // The run owns its decoder and surface, so it is also the only thing that frees
            // them. That is what lets a superseded thread wind down safely after its join timed
            // out without ever touching the run that replaced it.
            run.release()
        }
    }

    /** Whether [run] is still the live pipeline, as opposed to one a newer surface superseded. */
    private fun isCurrent(run: VideoRun): Boolean =
        videoRunning.get() && videoGeneration.get() == run.generation

    /**
     * One decode run's private state.
     *
     * The decoder and the surface it renders into are held here rather than on the engine
     * because both belong to a single surface lifetime. Keeping them per-run is what stops an
     * outgoing thread from steering the incoming one's decoder at the surface that was just
     * destroyed - the failure that turns a fullscreen toggle black.
     */
    private class VideoRun(val surface: Surface, val generation: Long) {
        var decoder: MediaCodec? = null

        fun release() {
            val codec = decoder ?: return
            decoder = null
            runCatching { codec.stop() }
            runCatching { codec.release() }
        }
    }

    private fun pumpInput(decoder: MediaCodec) {
        val frame = synchronized(videoInput) { videoInput.removeFirstOrNull() } ?: return

        val index = try {
            decoder.dequeueInputBuffer(QUEUE_TIMEOUT_US)
        } catch (e: IllegalStateException) {
            return
        }
        // No free input buffer right now; keep the frame queued for the next pass rather
        // than dropping it, so a brief codec stall does not cost a frame.
        if (index < 0) {
            synchronized(videoInput) { videoInput.addFirst(frame) }
            return
        }

        val buffer = decoder.getInputBuffer(index) ?: return
        buffer.clear()
        buffer.put(frame)
        // Presentation time is derived from arrival order rather than carried over the
        // wire: with no reorder buffer, arrival order is decode order by construction.
        decoder.queueInputBuffer(index, 0, frame.size, nextPresentationTimeUs(), 0)
    }

    private fun drainOutput(decoder: MediaCodec, bufferInfo: MediaCodec.BufferInfo): Boolean {
        val index = try {
            decoder.dequeueOutputBuffer(bufferInfo, QUEUE_TIMEOUT_US)
        } catch (e: IllegalStateException) {
            AppLog.warning("PlaybackEngine", "Video decoder rejected a dequeue; recreating it: $e")
            return false
        }

        when {
            index == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                val format = decoder.outputFormat
                videoWidth = format.getInteger(MediaFormat.KEY_WIDTH)
                videoHeight = format.getInteger(MediaFormat.KEY_HEIGHT)
                AppLog.debug("PlaybackEngine", "output format changed ${videoWidth}x$videoHeight")
            }
            index == MediaCodec.INFO_TRY_AGAIN_LATER -> {
                // No output yet; nothing to release.
            }
            index >= 0 -> {
                framesDecoded++
                // The decoder renders into the surface itself; releasing with
                // render=true is what schedules the frame for display.
                decoder.releaseOutputBuffer(index, true)
            }
        }
        return true
    }

    /**
     * Creates the decoder as soon as both parameter sets have arrived.
     *
     * @return the decoder, or null when it is not ready or [run] has been superseded.
     */
    private fun createVideoDecoderWhenReady(run: VideoRun): MediaCodec? {
        val sps = pendingSps
        val pps = pendingPps
        if (sps == null || pps == null) {
            waitForParameterSets()
            return null
        }
        // The surface is the run's own, so a run that has been superseded can never be tricked
        // into rendering into the surface that replaced it.
        if (!isCurrent(run)) return null

        val format = MediaFormat.createVideoFormat(
            MediaFormat.MIMETYPE_VIDEO_AVC,
            if (videoWidth > 0) videoWidth else DEFAULT_WIDTH,
            if (videoHeight > 0) videoHeight else DEFAULT_HEIGHT
        ).apply {
            setByteBuffer("csd-0", ByteBuffer.wrap(sps))
            setByteBuffer("csd-1", ByteBuffer.wrap(pps))
        }

        val decoder = try {
            MediaCodec.createDecoderByType(MediaFormat.MIMETYPE_VIDEO_AVC).apply {
                configure(format, run.surface, null, 0)
                start()
            }
        } catch (e: Exception) {
            // Some devices ship no AVC decoder at all. Report it and stop retrying, rather
            // than spinning and logging forever.
            AppLog.error("PlaybackEngine", "Could not start the video decoder: $e")
            pendingSps = null
            pendingPps = null
            waitForParameterSets()
            return null
        }

        // A newer surface may have arrived while the codec was being set up; if so this decoder
        // belongs to nothing. Free it here rather than handing it to the run that replaced this
        // one, which would be the very mix-up the generation check exists to prevent.
        if (!isCurrent(run)) {
            runCatching { decoder.stop() }
            runCatching { decoder.release() }
            return null
        }

        AppLog.info("PlaybackEngine", "Video decoder started")
        return decoder
    }

    private fun waitForParameterSets() {
        if (videoRunning.get()) Thread.sleep(PARAMETER_SET_POLL_MS)
    }

    private var presentationTimeUs = 0L
    private val frameDurationUs = 33_333L

    private fun nextPresentationTimeUs(): Long {
        val value = presentationTimeUs
        presentationTimeUs += frameDurationUs
        return value
    }

    /**
     * The channel count the broadcaster declared, applied when the first packet lazily starts the
     * decoder. Defaults to stereo for a peer that never told us; the welcome's SDP normally does.
     */
    @Volatile
    private var outputChannels: Int = 2

    fun setOutputChannels(channels: Int) {
        outputChannels = channels.coerceIn(1, 2)
    }

    /**
     * Sets the receive-side buffer, in milliseconds, for audio and video together.
     *
     * The value is a real latency budget: playback holds each pipeline until this much media is
     * queued, so a stall of up to the configured duration is ridden out instead of breaking
     * playback. A small headroom above it is the drop threshold, so a burst that refills the
     * queue never sheds a packet that has not played yet. A retune applies to media that arrives
     * after it, without restarting either pipeline; a prebuffer already under way is not disturbed.
     */
    fun setReceiveBufferMs(millis: Int) {
        val packets = (millis / PACKET_MS).coerceIn(1, MAX_RECEIVE_BUFFER_PACKETS)
        val frames = (millis / NOMINAL_FRAME_MS).coerceIn(1, MAX_RECEIVE_BUFFER_FRAMES)
        prebufferPackets = packets
        prebufferFrames = frames
        maxQueuedPackets = packets + (packets / 4).coerceAtLeast(HEADROOM_MIN)
        maxQueuedFrames = frames + (frames / 4).coerceAtLeast(HEADROOM_MIN)
    }

    /** Starts the Opus decoder and its output track. */
    fun startAudio(channels: Int = 2) {
        if (audioRunning.getAndSet(true)) return

        val channelCount = channels.coerceIn(1, 2)
        val channelMask =
            if (channelCount == 2) AudioFormat.CHANNEL_OUT_STEREO else AudioFormat.CHANNEL_OUT_MONO

        val minBuffer = AudioTrack.getMinBufferSize(
            LocalStream.AUDIO_CLOCK_RATE,
            channelMask,
            AudioFormat.ENCODING_PCM_16BIT
        )
        if (minBuffer <= 0) {
            audioRunning.set(false)
            return
        }

        val track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    // Movie, not Speech: speech is tuned for intelligibility over
                    // intelligibility *per bit*, which would sound harsh on a presentation
                    // and can trigger platform audio effects such as ducking.
                    .setContentType(AudioAttributes.CONTENT_TYPE_MOVIE)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(LocalStream.AUDIO_CLOCK_RATE)
                    .setChannelMask(channelMask)
                    .build()
            )
            .setBufferSizeInBytes(minBuffer * 2)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        audioTrack = track

        val format = MediaFormat.createAudioFormat(
            MediaFormat.MIMETYPE_AUDIO_OPUS,
            LocalStream.AUDIO_CLOCK_RATE,
            channelCount
        ).apply {
            // RFC 7587 keeps any header off the wire, but the Android decoder is configured
            // from a container-style MediaFormat. It needs the *unified* CSD (OpusHead plus
            // codec delay and seek pre-roll) as csd-0, or it reads those from the first audio
            // packets and discards all output. See OpusHead.buildCodecConfig.
            setByteBuffer("csd-0", ByteBuffer.wrap(OpusHead.buildCodecConfig(channelCount)))
        }

        try {
            val decoder = MediaCodec.createDecoderByType(MediaFormat.MIMETYPE_AUDIO_OPUS)
            decoder.configure(format, null, null, 0)
            decoder.start()
            audioDecoder = decoder
        } catch (e: Exception) {
            AppLog.error("PlaybackEngine", "Could not start the audio decoder: $e")
            audioRunning.set(false)
            return
        }

        // Playback is opened by the decode thread once the prebuffer has filled, not here:
        // starting on the first packet leaves nothing to absorb jitter, which is what makes the
        // opening seconds stutter on Wi-Fi.
        audioStarted = false
        audioStarved = false
        lastAudioWriteNanos = 0L
        audioUnderruns = 0L
        audioStartDeadlineNanos =
            System.nanoTime() + (prebufferPackets * PACKET_MS + STARTUP_GRACE_MS) * 1_000_000L
        audioThread = Thread({ audioLoop() }, "LocalStream-AudioDecode").apply { start() }
    }

    /**
     * Hands one Opus packet to the decode thread. Called from the network thread.
     *
     * Like the video path, nothing here touches the codec: the audio thread is its only
     * driver.
     */
    fun submitAudio(frame: ByteArray) {
        if (!audioRunning.get()) startAudio(outputChannels)
        if (!audioRunning.get()) return

        // Bounded to the configured receive buffer. Past that the stream is already too far
        // behind for a live presentation, and holding more would only add latency.
        synchronized(audioInput) {
            if (audioInput.size >= maxQueuedPackets) {
                audioInput.removeFirst()
            }
            audioInput.addLast(frame)
        }
    }

    private val audioInput = ArrayDeque<ByteArray>()

    /**
     * How many 20 ms Opus packets may wait before the oldest is dropped. Set from the receive
     * buffer with a little headroom above the prebuffer; see [setReceiveBufferMs].
     */
    @Volatile
    private var maxQueuedPackets: Int = DEFAULT_RECEIVE_BUFFER_MS / PACKET_MS

    /**
     * How many video frames may wait before the oldest is dropped, at a nominal 30 fps; see
     * [setReceiveBufferMs].
     */
    @Volatile
    private var maxQueuedFrames: Int = DEFAULT_RECEIVE_BUFFER_MS / NOMINAL_FRAME_MS

    /**
     * How many packets must be queued before audio playback starts. Equal to the configured
     * receive buffer, so the preset is the latency the user actually asked for.
     */
    @Volatile
    private var prebufferPackets: Int = DEFAULT_RECEIVE_BUFFER_MS / PACKET_MS

    /** How many frames must be queued before video decoding starts; see [prebufferPackets]. */
    @Volatile
    private var prebufferFrames: Int = DEFAULT_RECEIVE_BUFFER_MS / NOMINAL_FRAME_MS

    init {
        setReceiveBufferMs(DEFAULT_RECEIVE_BUFFER_MS)
    }

    private fun audioLoop() {
        val track = audioTrack ?: return
        val bufferInfo = MediaCodec.BufferInfo()

        while (audioRunning.get()) {
            val decoder = audioDecoder ?: break

            // Startup: hold playback until the prebuffer has filled, so the first frames are not
            // consumed the instant they arrive. The deadline keeps a stream that never reaches
            // the full depth - a slow or lossy link - from staying silent forever.
            if (!audioStarted) {
                val queued = synchronized(audioInput) { audioInput.size }
                if (queued >= prebufferPackets || System.nanoTime() >= audioStartDeadlineNanos) {
                    audioStarted = true
                    lastAudioWriteNanos = System.nanoTime()
                    runCatching { track.play() }
                } else {
                    Thread.sleep(PREBUFFER_POLL_MS)
                    continue
                }
            }

            // Starvation: pause rather than let the playback head run past the buffer, which is
            // what clicks. Resume needs only a small cushion, not the whole prebuffer, or every
            // stall would cost the full latency.
            if (audioStarved) {
                val queued = synchronized(audioInput) { audioInput.size }
                if (queued >= audioResumePackets()) {
                    audioStarved = false
                    lastAudioWriteNanos = System.nanoTime()
                    runCatching { track.play() }
                } else {
                    Thread.sleep(PREBUFFER_POLL_MS)
                    continue
                }
            }

            pumpAudioInput(decoder)
            drainAudioOutput(decoder, track, bufferInfo)

            if (!audioStarved &&
                System.nanoTime() - lastAudioWriteNanos > STARVATION_GRACE_MS * 1_000_000L
            ) {
                audioStarved = true
                audioUnderruns++
                runCatching { track.pause() }
            }
        }
    }

    /** A fraction of the prebuffer is enough to resume after a stall, floored at one packet. */
    private fun audioResumePackets(): Int = (prebufferPackets / 4).coerceAtLeast(1)

    private fun pumpAudioInput(decoder: MediaCodec) {
        val frame = synchronized(audioInput) { audioInput.removeFirstOrNull() } ?: return

        val index = try {
            decoder.dequeueInputBuffer(QUEUE_TIMEOUT_US)
        } catch (e: IllegalStateException) {
            return
        }
        if (index < 0) {
            synchronized(audioInput) { audioInput.addFirst(frame) }
            return
        }

        val buffer = decoder.getInputBuffer(index) ?: return
        buffer.clear()
        buffer.put(frame)
        // Opus frames are self-delimiting and timestamp-free, so the decoder derives timing
        // from the declared 20 ms frame size.
        decoder.queueInputBuffer(index, 0, frame.size, 0L, 0)
    }

    private fun drainAudioOutput(
        decoder: MediaCodec,
        track: AudioTrack,
        bufferInfo: MediaCodec.BufferInfo
    ) {
        val index = try {
            decoder.dequeueOutputBuffer(bufferInfo, QUEUE_TIMEOUT_US)
        } catch (e: IllegalStateException) {
            AppLog.warning("PlaybackEngine", "Audio decoder rejected a dequeue; stopping: $e")
            return
        }
        if (index < 0) return

        val buffer = decoder.getOutputBuffer(index)
        if (buffer != null && bufferInfo.size > 0) {
            // Reuse one scratch array rather than allocate per frame; the size is steady, so
            // this settles after the first few frames.
            if (audioScratch.size < bufferInfo.size) audioScratch = ByteArray(bufferInfo.size)
            buffer.position(bufferInfo.offset)
            buffer.limit(bufferInfo.offset + bufferInfo.size)
            buffer.get(audioScratch, 0, bufferInfo.size)
            // write() blocks once the buffer is full, which is the natural pacing for
            // playback; no additional sleep or timing loop is needed.
            track.write(audioScratch, 0, bufferInfo.size)
            lastAudioWriteNanos = System.nanoTime()
        }
        decoder.releaseOutputBuffer(index, false)
    }

    fun stop() {
        videoSurfaceToken = null
        stopVideoPipeline()

        audioRunning.set(false)
        // Join before releasing: the audio thread owns the decoder and the track, and releasing
        // one out from under it is exactly the race this design exists to avoid.
        audioThread?.join(500)
        audioThread = null

        runCatching { audioDecoder?.stop() }
        runCatching { audioDecoder?.release() }
        audioDecoder = null
        runCatching { audioTrack?.stop() }
        runCatching { audioTrack?.release() }
        audioTrack = null
        synchronized(audioInput) { audioInput.clear() }
    }

    companion object {
        private const val QUEUE_TIMEOUT_US = 10_000L

        /** How often a pipeline waiting on its prebuffer re-checks the queue. */
        private const val PREBUFFER_POLL_MS = 20L

        /**
         * How much longer than the configured buffer a start waits for its prebuffer to fill
         * before beginning anyway, so a link that cannot sustain the chosen depth still plays.
         */
        private const val STARTUP_GRACE_MS = 1_500L

        /**
         * How long with nothing written to the track counts as an underrun. Comfortably longer
         * than one Opus frame, so ordinary decode latency is not mistaken for a stall.
         */
        private const val STARVATION_GRACE_MS = 100L

        /** Least headroom kept above the prebuffer, so a burst does not shed unplayed packets. */
        private const val HEADROOM_MIN = 2

        /**
         * How long a video start waits for the outgoing decode thread to finish. Long enough to
         * cover a hardware codec winding down, short enough not to stall the toggle when it does
         * not. Correctness does not depend on the join succeeding: a superseded thread is
         * stopped by its generation, not by the join.
         */
        private const val JOIN_TIMEOUT_MS = 1_000L

        /**
         * How long the decode thread waits before re-checking for parameter sets. Short
         * enough that a stream that starts with video is visible almost immediately.
         */
        private const val PARAMETER_SET_POLL_MS = 20L

        private const val DEFAULT_WIDTH = 1280
        private const val DEFAULT_HEIGHT = 720

        /** One Opus frame is 20 ms, so a buffer in packets converts to milliseconds via this. */
        const val PACKET_MS = 20

        /** A nominal video frame at 30 fps, so a buffer in frames converts via this. */
        const val NOMINAL_FRAME_MS = 33

        /** Default receive buffer, in ms: half a second, matching the Windows receiver. */
        const val DEFAULT_RECEIVE_BUFFER_MS = 500

        /** Upper bound on the receive buffer, so a stray value cannot queue unbounded audio. */
        private const val MAX_RECEIVE_BUFFER_PACKETS = 1000

        /** Upper bound on the receive buffer in video frames, so a stray value stays bounded. */
        private const val MAX_RECEIVE_BUFFER_FRAMES = 600
    }
}
