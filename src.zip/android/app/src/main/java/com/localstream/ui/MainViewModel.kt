﻿package com.localstream.ui

import android.Manifest
import android.app.Application
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.localstream.LocalStreamApp
import com.localstream.R
import com.localstream.engine.AudioSource
import com.localstream.engine.BroadcastEngine
import com.localstream.engine.BroadcastService
import com.localstream.engine.BroadcastState
import com.localstream.engine.EngineLifecycleOwner
import com.localstream.engine.PlaybackEngine
import com.localstream.engine.ReceiveAlerts
import com.localstream.engine.ReceiveBuffer
import com.localstream.engine.VideoConfig
import com.localstream.engine.VideoSource
import com.localstream.logging.AppLog
import com.localstream.net.ConnectionState
import com.localstream.net.ConnectCancelled
import com.localstream.net.ControlClient
import com.localstream.net.DiscoveredStream
import com.localstream.net.DiscoveryEvent
import com.localstream.net.RtpReceiver
import com.localstream.net.ServiceDiscovery
import com.localstream.protocol.BroadcastAccessPolicy
import com.localstream.protocol.ControlMessage
import com.localstream.protocol.LocalStream
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeout

/**
 * Which top-level tab is showing.
 *
 * No label of its own: a tab's name is user-visible text, so it has to come from a resource and
 * be read from the composition, which an enum cannot do. MainScreen resolves the name per entry.
 */
enum class MainTab {
    BROADCAST,
    RECEIVE,
    HELP
}

/** Everything the UI renders, in one immutable snapshot. */
data class UiState(
    val tab: MainTab = MainTab.BROADCAST,
    val deviceName: String,
    val mode: String = LocalStream.MODE_AUDIO_VIDEO,
    val isBroadcasting: Boolean = false,
        val isAdvertising: Boolean = false,
        /**
         * The port a viewer connects to, shown so a viewer who cannot use discovery can read it
         * off this screen and type it in on theirs.
         */
        val controlPort: Int = 0,
    val videoSource: VideoSource = VideoSource.SCREEN,
    val videoConfig: VideoConfig = VideoConfig(),
    val audioSource: AudioSource = AudioSource.MICROPHONE,
    val audioBitrateKbps: Int = 48,
    /** Whether the broadcast audio level is normalised. See AudioNormalizer. */
    val normalizeAudio: Boolean = false,
val receiverCount: Int = 0,
    /**
     * Who may join. Written through [setAccess] and read back from the engine, so a refused
     * change is visible in the UI instead of silently leaving the control showing something
     * the broadcast is not doing.
     */
    val accessMode: String = ControlMessage.ACCESS_PUBLIC,
    /**
     * The password typed for a password-protected broadcast. Held here rather than in a control
     * so it can be validated before it is handed to the engine, and cleared as soon as the
     * engine has it: it lives in the engine for the life of the broadcast and nowhere else.
     */
    val accessPassword: String = "",
    /**
     * The page shows a mode the broadcast is not in yet.
     *
     * Only ever true for password mode: the choice is made before there is a password to lock the
     * broadcast with, and applying it on the spot would either lock everyone out or refuse the tap
     * and leave no way to reach password mode at all. The controls say so in as many words, and
     * the engine's own mode is left alone until the presenter applies one.
     */
    val accessPending: Boolean = false,

    val isScanning: Boolean = false,
    val broadcasters: List<DiscoveredStream> = emptyList(),
    val connectedKey: String? = null,
val isConnecting: Boolean = false,
        /**
         * Set while the broadcaster has asked for its password and the viewer has not answered.
         * The Activity turns this into a dialog and answers through [submitPassword].
         */
        val passwordPrompt: PasswordPrompt? = null,
        /** Waiting for the presenter to answer a request to watch. */
        val isAwaitingApproval: Boolean = false,
        /**
         * Refused for the rest of this broadcast. Held so the receive screen can say why and not
         * just offer a reconnect that will be refused the same way.
         */
        val blockedReason: String? = null,
        val connectionMessage: String? = null,
    val isReceivingVideo: Boolean = false,
    val receivedFrames: Long = 0,
    val packetLoss: Long = 0,
    /** Receive-side buffer for audio and video, in milliseconds. See ReceiveBuffer. */
    val receiveBufferMs: Int = PlaybackEngine.DEFAULT_RECEIVE_BUFFER_MS,

    val announcement: String? = null,
    val announcementIsError: Boolean = false,
    val needsProjectionToken: Boolean = false,
    /**
     * Runtime permissions the user asked for by pressing Start, non-empty only while the system
     * prompt is about to appear. The Activity watches it exactly the way it watches
     * [needsProjectionToken]: a ViewModel cannot launch a permission dialog itself.
     */
    val permissionsRequest: List<String> = emptyList(),
    /**
     * A viewer asking to watch a broadcast set to ask-first. Non-null while the presenter has an
     * unanswered request, and the screen-reader focus target when it is set.
     *
     * Held as state rather than raised as an event because the request is *not* over when the
     * presenter looks at it: it waits, and a rotation or a brief trip out of the app must not
     * lose it.
     */
    val accessRequest: AccessRequest? = null
)

/**
 * A viewer waiting for permission to watch.
 *
 * @param key identifies the request, so the answer reaches the viewer who asked even if a
 *        second request arrives while the first is still on screen.
 */
data class AccessRequest(val key: Long, val viewerName: String)

/**
 * A broadcast waiting to be let in.
 *
 * @param wrongAttempt true when the last password was refused, so the prompt can say so instead
 *        of the viewer wondering why the field cleared itself.
 */
data class PasswordPrompt(val broadcasterName: String, val wrongAttempt: Boolean)

/**
 * Owns both engines and every piece of state the UI renders.
 *
 * Engines live here rather than in the Activity so that a rotation or a process-recreation
 * does not tear down a live broadcast. The foreground service is a separate, deliberately
 * thin object whose only jobs are keeping the process alive and offering a Stop action in
 * the notification shade.
 */
class MainViewModel(application: Application) : AndroidViewModel(application) {

    /**
     * The application, which is also the [android.content.Context] every user-visible string is
     * read through.
     *
     * The announcements this ViewModel produces are spoken by the screen reader, so they have to
     * come from resources like everything else on screen - and a ViewModel has no composition to
     * call `stringResource` in. `AppLanguage.wrap` sets the default locale for the whole process,
     * so reading through the application answers in the language the user chose.
     */
    private val app = application as LocalStreamApp
    private val scope = viewModelScope

    private val discovery = ServiceDiscovery(application)
    private val controlClient = ControlClient(scope)
    private val rtpReceiver = RtpReceiver(scope)

    /**
     * Owned here, not by the Activity.
     *
     * Playback has to outlive a configuration change: an encoder/decoder restarted on every
     * rotation would drop a second of audio and force the viewer to renegotiate.
     */
    val playback = PlaybackEngine(application)

    /**
     * Volatile is defensive: this view model's scope is the main dispatcher, so the completion
     * callback in [startScanning] runs on the same thread that reads the field in [rescan].
     */
    @Volatile
    private var discoveryJob: Job? = null
    private var statsJob: Job? = null
    private var rtpPumpJob: Job? = null
    private var controlJob: Job? = null

    /** Set once the ViewModel is being cleared, so a late trigger cannot restart browsing. */
    @Volatile
    private var isCleared = false

    /**
     * The in-flight teardown of the media path. [connectTo] joins it before opening anything,
     * so a reconnect cannot race the previous session's close.
     */
    private var teardownJob: Job? = null

    private var pendingProjectionToken: Intent? = null

    /**
     * The password the handshake is waiting for, if one is on screen.
     *
     * Completed with null when the viewer cancels. Held as a deferred rather than a poll loop so
     * the handshake simply parks until there is an answer, which is also why it survives a
     * rotation: the dialog comes back because the state comes back, not because the wait is
     * restarted.
     */
    private var passwordAnswer: CompletableDeferred<String?>? = null

    /** Receives answers from the lock-screen prompt. See the init block. */
    private var accessAnswerReceiver: AccessAnswerReceiver? = null

    /**
     * Set while a mode switch is waiting on the capture prompt, so the token that comes back
     * resumes the switch rather than starting a new broadcast.
     */
    private var pendingModeResume: ((Intent?) -> Unit)? = null

    /**
     * True while the broadcast the user just pressed Start on is waiting for the microphone or
     * camera prompt, so the start resumes by itself once access is granted rather than asking
     * for a second press of the same button.
     */
    private var pendingStartAfterPermissions = false

    /**
     * Set when the broadcast is stopped before its service has finished promoting.
     *
     * The service is started at the press of Start and the engine only begins once it has
     * promoted, so a Stop in that window arrives while something is still on its way up. The
     * coroutine waiting for the promotion would otherwise carry on and start a broadcast the
     * user has already ended, and the service it was waiting for would outlive it.
     */
    private var stopRequested = false


    private val _state = MutableStateFlow(UiState(deviceName = defaultDeviceName()))
    val state: StateFlow<UiState> = _state.asStateFlow()

    private val broadcastEngine = BroadcastEngine(
        context = application,
        scope = scope,
        lifecycleOwner = EngineLifecycleOwner(),
        deviceName = defaultDeviceName()
    ).also { engine ->
        engine.stateListener = { broadcast -> applyBroadcastState(broadcast) }
        engine.announcementListener = { message -> announce(message) }
engine.projectionRequester = { resume ->
            pendingModeResume = resume
            update { it.copy(needsProjectionToken = true) }
        }
        // Arrives on a control-server coroutine, so it is marshalled onto the main dispatcher
        // before it touches state. The engine has already told the control server to wait, so
        // the viewer is not lost if the UI takes a moment to render this.
        engine.accessRequestListener = { key, name ->
            scope.launch {
                // Alert first, then state. A presenter who has the phone in their pocket is
                // reached by the notification; the dialog is for the phone already in their hand,
                // and neither depends on the other having worked.
                BroadcastService.notifyAccessRequest(app, key, name)
                accessRequestQueue.addLast(AccessRequest(key, name))
                showNextAccessRequest()
                announce(app.getString(R.string.announce_viewer_wants_to_watch, name))
            }
        }
        // A viewer who gives up while their prompt is up takes the prompt with them: left on
        // screen it would stand in front of the requests that came after, and the presenter
        // would be answering for someone who has already gone.
        engine.accessRequestCancelledListener = { key, name ->
            scope.launch { withdrawAccessRequest(key, name) }
        }
    }

    /**
     * Requests still waiting for an answer, in the order they arrived.
     *
     * The control server holds each one, so nothing is lost by asking about them one at a time.
     * What cannot be lost is the asking: a request with nowhere to go would wait for ever.
     */
    private val accessRequestQueue = ArrayDeque<AccessRequest>()

    /**
     * Puts the next waiting viewer in front of the presenter, or leaves the prompt alone.
     *
     * Guarded by whether one is already up, because every caller runs at a moment where the
     * prompt may have to change: a new request, an answer, a viewer leaving, the broadcast
     * stopping. It runs on the main dispatcher, where the state it updates is read.
     */
    private fun showNextAccessRequest() {
        val next = accessRequestQueue.removeFirstOrNull() ?: return
        update { current ->
            if (current.accessRequest == null) {
                current.copy(accessRequest = next)
            } else {
                current
            }
        }
        if (_state.value.accessRequest != next) accessRequestQueue.addFirst(next)
    }

    /** Drops a request the viewer has abandoned, showing whoever is next behind it. */
    private fun withdrawAccessRequest(key: Long, name: String) {
        val shown = _state.value.accessRequest
        if (shown?.key == key) {
            update { it.copy(accessRequest = null) }
        } else {
            accessRequestQueue.removeAll { it.key == key }
            return
        }
        BroadcastService.clearAccessRequest(app)
        showNextAccessRequest()
        AppLog.debug("MainViewModel", "$name stopped waiting to watch")
    }

    /**
     * Kept for the ViewModel's life so a LAN that comes back is noticed even after a browse has
     * wedged. [rescan] decides whether it matters for the tab the user is on.
     */
    private val networkWatch = discovery.observeNetworkAvailability { rescan() }

    private fun defaultDeviceName(): String =
        Build.MODEL?.takeIf { it.isNotBlank() } ?: app.getString(R.string.device_name_this_device)

    // ------------------------------------------------------------------ discovery

    /** Begins browsing. Idempotent. */
    private fun startScanning() {
        if (discoveryJob != null) return
        update { it.copy(isScanning = true) }
        val job = scope.launch {
            discovery.browse().collect { event ->
                when (event) {
                    is DiscoveryEvent.Found -> {
                        val previous = _state.value.broadcasters
                        // This device advertises itself as idle so that a viewer can see a
                        // presenter getting ready; it must not then offer to connect to itself.
                        // The match is exact and session-scoped: every LocalStream advertisement
                        // shares the "LocalStream" prefix, so a prefix test would also hide every
                        // other device running this app.
                        val ownInstance =
                            discovery.instanceName(broadcastEngine.description().sessionId)
                        if (event.stream.instanceName == ownInstance) {
                            AppLog.info("MainViewModel", "Ignoring our own advertisement ${event.stream.instanceName}")
                            return@collect
                        }
                        val merged = (previous.filterNot { it.key == event.stream.key } + event.stream)
                            .sortedBy { it.description.displayName.lowercase() }
                        val isNew = previous.none { it.key == event.stream.key }
                        update { it.copy(broadcasters = merged) }
                        if (isNew) {
                            announce(app.getString(R.string.announce_broadcaster_found, event.stream.description.displayName))
                        }
                    }

                    is DiscoveryEvent.Removed -> {
                        val removed = _state.value.broadcasters.firstOrNull { it.key == event.instanceName }
                        update {
                            it.copy(broadcasters = it.broadcasters.filterNot { s -> s.key == event.instanceName })
                        }
                        removed?.let {
                            announce(app.getString(R.string.announce_broadcaster_gone, it.description.displayName))
                        }
                    }

                    is DiscoveryEvent.Failed -> {
                        update { it.copy(isScanning = false) }
                        announceError(event.reason)
                    }
                }
            }
            update { it.copy(isScanning = false) }
        }
        discoveryJob = job
        // A browse can end on its own - the flow fails, or NsdManager stops it - and a
        // completed job left in this field would block every later startScanning().
        job.invokeOnCompletion { if (discoveryJob === job) discoveryJob = null }
    }

    private fun stopScanning() {
        discoveryJob?.cancel()
        discoveryJob = null
        update { it.copy(isScanning = false) }
    }

    /**
     * Restarts browsing so the list reflects the network as it is now.
     *
     * [startScanning] is idempotent, which is right for the periodic path but wrong for the
     * recovery ones: a browse that is still "running" after a network drop is exactly the stale
     * state this has to clear. The previous browse is cancelled and awaited first, because
     * NsdManager refuses a second browse while it still thinks one is active. No-op off the
     * Receive tab, and after teardown.
     */
    fun rescan() {
        if (isCleared) return
        scope.launch {
            if (_state.value.tab != MainTab.RECEIVE) return@launch
            // Drop the current rows before looking again. A broadcaster that has stopped will
            // never be reported as removed once the browse restarts, so without this a stale
            // row for a dead source stays on screen and invites a connection that cannot work.
            update { it.copy(broadcasters = emptyList()) }
            val previous = discoveryJob
            discoveryJob = null
            previous?.cancel()
            previous?.join()
            startScanning()
        }
    }

    // ------------------------------------------------------------------ broadcasting

    /**
     * Opens the sockets and advertises this device without going live yet.
     *
     * Doing this early is an accessibility affordance: a viewer can see the device sitting
     * idle in the list and know a presenter is about to start, which they could not infer
     * from an empty list.
     */
    fun prepareBroadcasting() {
        if (_state.value.isAdvertising) return
        broadcastEngine.prepare()
        discovery.register(
            descriptionProvider = { broadcastEngine.description() },
            onRegistered = {
                update { it.copy(isAdvertising = true) }
                republishDescription()
            },
            onError = { announceError(it) }
        )
    }

    /**
     * The foreground-service types the broadcast actually captures.
     *
     * Android 14 refuses a promotion that names a capture the app is not authorised for, so the
     * type has to match the live settings rather than being a fixed `mediaProjection`. Screen
     * mirroring and device-audio capture both ride the screen-capture consent; a camera stream is
     * a camera; and a microphone stream is a microphone. The result is never zero, because a
     * broadcast always has at least one audio source.
     */
    private fun foregroundServiceType(state: UiState): Int {
        var type = 0
        val video = state.mode == LocalStream.MODE_AUDIO_VIDEO
        if (video && state.videoSource == VideoSource.SCREEN) {
            type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
        }
        if (video && state.videoSource == VideoSource.CAMERA) {
            type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
        }
        if (state.audioSource == AudioSource.DEVICE) {
            // Device audio is captured through AudioPlaybackCapture, which needs the screen-capture
            // consent just as mirroring does.
            type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
        } else {
            type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        }
        return type
    }

    /**
     * Starts the broadcast.
     *
     * When video is on and the source is the screen, a MediaProjection token is required.
     * If the Activity has not supplied one, the UI is told to request it; the pending
     * request is then completed by [onProjectionToken].
     */
    fun startBroadcast() {
        val current = _state.value
        stopRequested = false

        // A password that was chosen but never applied leaves the engine public. Going live now
        // would publish the broadcast unlocked while the screen still said a password was
        // required, and a viewer would be let in without being asked for one. So the typed
        // password is applied first, and a password too short to apply stops the start outright
        // rather than opening the broadcast without it.
        when (
            val decision = BroadcastAccessPolicy.beforeStart(
                accessPending = current.accessPending,
                accessMode = current.accessMode,
                password = current.accessPassword
            )
        ) {
            is BroadcastAccessPolicy.StartDecision.Refuse -> {
                announceError(decision.message)
                return
            }

            is BroadcastAccessPolicy.StartDecision.ApplyPassword -> {
                if (!broadcastEngine.setAccess(current.accessMode, decision.password)) {
                    announceError(app.getString(R.string.error_access_not_applied))
                    return
                }
                update { it.copy(accessPassword = "", accessPending = false) }
                announce(app.getString(R.string.announce_password_set))
            }

            is BroadcastAccessPolicy.StartDecision.Proceed -> Unit
        }

        // The microphone and the camera are ordinary runtime permissions: the manifest grants
        // nothing, and Android only ever grants them from its own dialog. Without this gate the
        // first press of Start would die inside the encoder with a `SecurityException` instead of
        // meeting the prompt that can actually say yes, so this runs before anything else -
        // including the capture-token request it may be followed by.
        val missingPermissions = requiredPermissions(current)
            .filterNot { Permissions.granted(app, it) }
        if (missingPermissions.isNotEmpty()) {
            pendingStartAfterPermissions = true
            update { it.copy(permissionsRequest = missingPermissions) }
            return
        }

        val needsVideo = current.mode == LocalStream.MODE_AUDIO_VIDEO
        // Screen mirroring and device-audio capture are both authorised by the same
        // screen-capture consent, so either one needs the token.
        val wantsScreen = needsVideo && current.videoSource == VideoSource.SCREEN
        val wantsDeviceAudio = current.audioSource == AudioSource.DEVICE
        val needsProjection = wantsScreen || wantsDeviceAudio

        if (needsProjection && pendingProjectionToken == null) {
            update { it.copy(needsProjectionToken = true) }
            return
        }

        broadcastEngine.setVideoSource(current.videoSource)
        broadcastEngine.setVideoConfig(current.videoConfig)
        broadcastEngine.setAudioSource(current.audioSource)
        broadcastEngine.setAudioBitrate(current.audioBitrateKbps)
        broadcastEngine.setNormalizeAudio(current.normalizeAudio)

        // Must be foreground before the encoder starts: Android kills a background process
        // that begins capture without one, and a silent death mid-broadcast is far worse
        // than a visible failure here.
        val promotion = BroadcastService.start(app, foregroundServiceType(current))

        scope.launch {
            try {
                withTimeout(PROMOTION_TIMEOUT_MS) { promotion.await() }
            } catch (e: CancellationException) {
                // Stopped while the service was still coming up. Nothing to start.
                return@launch
            } catch (e: Exception) {
                BroadcastService.stop(app)
                announceError(
                    app.getString(
                        R.string.error_service_never_foreground,
                        e.message ?: e::class.java.simpleName
                    )
                )
                return@launch
            }

            if (stopRequested) {
                // Stopped while the service was still coming up. The service has now promoted,
                // so it is stopped again from here: stopBroadcast's own call could not have
                // caught a start Android had not delivered yet, and a foreground service with
                // no broadcast behind it is the leak this is guarding.
                BroadcastService.stop(app)
                return@launch
            }

            // The engine start has to stay on the main thread: it drives a LifecycleRegistry
            // and CameraX, both of which assert on it. The promotion has already happened by
            // this point, so nothing races the service any more.
            broadcastEngine.start(pendingProjectionToken) { error ->
                // Same ordering constraint, opposite direction: a stop issued inline can
                // beat the service's own start, and the OS then kills the process for
                // never having promoted.
                Handler(Looper.getMainLooper()).post { BroadcastService.stop(app) }
                announceError(error)
            }
            pendingProjectionToken = null
            update { it.copy(needsProjectionToken = false) }
            republishDescription()
        }
    }

    fun onProjectionToken(intent: Intent?) {
        val resume = pendingModeResume
        if (resume != null) {
            pendingModeResume = null
            update { it.copy(needsProjectionToken = false) }
            resume(intent)
            return
        }

        pendingProjectionToken = intent
        if (intent != null) {
            startBroadcast()
        } else {
            announceError(app.getString(R.string.error_projection_denied))
        }
    }

    /** Clears the flag that makes the Activity launch the system capture prompt. */
    fun consumeProjectionRequest() {
        update { it.copy(needsProjectionToken = false) }
    }

    /** Clears the flag that makes the Activity launch the runtime permission prompt. */
    fun consumePermissionRequest() {
        update { it.copy(permissionsRequest = emptyList()) }
    }

    /**
     * The prompt the Activity launched has come back, for the broadcast's permissions and for
     * the ones asked for at start-up alike.
     *
     * A granted set resumes the Start the user already pressed - pressing it a second time
     * would be the one thing the system dialog did not need to do. A refusal is reported
     * through [onPermissionsDenied] so the message names what was lost and what still works.
     */
    fun onPermissionsResult(granted: Map<String, Boolean>) {
        val denied = granted.filterValues { !it }.keys
        if (denied.isNotEmpty()) {
            pendingStartAfterPermissions = false
            onPermissionsDenied(denied)
            return
        }
        if (pendingStartAfterPermissions) {
            pendingStartAfterPermissions = false
            startBroadcast()
        }
    }

    /**
     * The runtime permissions the chosen sources of this broadcast actually need.
     *
     * [Manifest.permission.RECORD_AUDIO] is unconditional: every broadcast carries audio, and
     * Android requires it for device-audio playback capture as much as for the microphone, not
     * only when the source is the mic. It is never asked for on the receive tab, because a
     * viewer never records anything.
     */
    private fun requiredPermissions(current: UiState): List<String> = buildList {
        add(Manifest.permission.RECORD_AUDIO)
        if (current.mode == LocalStream.MODE_AUDIO_VIDEO &&
            current.videoSource == VideoSource.CAMERA
        ) {
            add(Manifest.permission.CAMERA)
        }
    }


    /**
     * Reports refused permissions.
     *
     * Each message names what was lost and what still works, because a blanket "permission
     * denied" leaves the user guessing whether the app is usable at all.
     */
    fun onPermissionsDenied(denied: Set<String>) {
        val consequences = denied.mapNotNull { permission ->
            when (permission) {
                Manifest.permission.RECORD_AUDIO ->
                    app.getString(R.string.error_denied_microphone)
                Manifest.permission.CAMERA ->
                    app.getString(R.string.error_denied_camera)
                Manifest.permission.POST_NOTIFICATIONS ->
                    app.getString(R.string.error_denied_notifications)
                Manifest.permission.NEARBY_WIFI_DEVICES ->
                    app.getString(R.string.error_denied_nearby_wifi)
                else -> null
            }
        }
        if (consequences.isEmpty()) return
        announceError(
            app.getString(R.string.error_permissions_not_granted, consequences.joinToString("; "))
        )
    }

    fun stopBroadcast() {
        // Remembered before the engine is touched: a Start whose promotion is still in flight
        // has a coroutine waiting on it, and that one has to know it is no longer wanted.
        stopRequested = true
        broadcastEngine.stop()
        // The service exists to keep this broadcast alive and to offer its stop action. Both
        // are over now, and leaving it in the foreground would park an ongoing "Broadcasting"
        // notification over an app that says it is not broadcasting.
        BroadcastService.stop(app)
        // An unanswered request cannot survive the broadcast it was asked about, so the alert
        // goes with it rather than offering to allow someone into a stream that has ended.
        BroadcastService.clearAccessRequest(app)
        accessRequestQueue.clear()
        update { it.copy(accessRequest = null) }
        republishDescription()
    }

    fun setMode(audioAndVideo: Boolean) {
        val newMode = if (audioAndVideo) LocalStream.MODE_AUDIO_VIDEO else LocalStream.MODE_AUDIO_ONLY
        if (_state.value.mode == newMode) return
        update { it.copy(mode = newMode) }
        broadcastEngine.setMode(newMode) { error ->
            announceError(error)
            // The engine refused; put the toggle back where it was so what the user sees
            // still matches reality.
            update { it.copy(mode = if (newMode == LocalStream.MODE_AUDIO_ONLY) LocalStream.MODE_AUDIO_VIDEO else LocalStream.MODE_AUDIO_ONLY) }
        }
        republishDescription()
    }
    fun setVideoSource(source: VideoSource) {
        update { it.copy(videoSource = source) }
        broadcastEngine.setVideoSource(source)
    }

    fun setAudioSource(source: AudioSource) {
        if (_state.value.audioSource == source) return
        update { it.copy(audioSource = source) }
        broadcastEngine.setAudioSource(source)
        // Heard, not merely told: the setting changes what the broadcast carries, so its new
        // value is spoken rather than left for the user to find on the control again.
        announce(
            app.getString(
                if (source == AudioSource.DEVICE) R.string.announce_audio_source_device
                else R.string.announce_audio_source_microphone
            )
        )
    }

    fun setVideoConfig(config: VideoConfig) {
        update { it.copy(videoConfig = config) }
        broadcastEngine.setVideoConfig(config)
    }

    fun setAudioBitrate(kbps: Int) {
        update { it.copy(audioBitrateKbps = kbps) }
        broadcastEngine.setAudioBitrate(kbps)
    }

    /**
     * Applies a change of access mode, live. Viewers already admitted keep their stream.
     *
     * @return null on success, or the message to show the user. Returning the reason rather than
     *   announcing it here keeps the caller in charge of a screen-reader-friendly announcement
     *   at the moment the user acted.
     */
    private fun setAccess(mode: String, password: String): String? {
        // Validated here as well as in the engine, so the field the user is looking at can be
        // marked wrong before the value is handed anywhere.
        if (mode == ControlMessage.ACCESS_PASSWORD && !ControlMessage.isValidPassword(password)) {
            // Choosing the option is not the same as locking the broadcast, and with an empty
            // field there is nothing to lock it with. Refusing here made password mode
            // unreachable: the field that would have filled it in only appears once the mode is
            // selected. So the choice is kept on screen, unapplied, and the engine is told to shut
            // the broadcast in the meantime - a chosen password must not read as "public" while it
            // is being typed.
            if (mode != _state.value.accessMode || password != _state.value.accessPassword ||
                !_state.value.accessPending
            ) {
                update {
                    it.copy(accessMode = mode, accessPassword = password, accessPending = true)
                }
                // Lock the broadcast now rather than when the password is applied. Leaving the
                // control channel on its previous setting would let viewers in to a broadcast the
                // presenter has already chosen to protect - the very window the password is meant
                // to close.
                broadcastEngine.holdAccessForPendingPassword()
                announce(
                    if (password.isEmpty()) {
                        app.getString(R.string.announce_password_mode_chosen)
                    } else {
                        app.getString(
                            R.string.announce_password_too_short,
                            ControlMessage.PASSWORD_MIN_LENGTH,
                            ControlMessage.PASSWORD_MAX_LENGTH
                        )
                    }
                )
            }
            return null
        }
        if (mode == _state.value.accessMode && password == _state.value.accessPassword &&
            !_state.value.accessPending
        ) {
            return null
        }
        if (!broadcastEngine.setAccess(mode, password)) {
            return app.getString(R.string.error_access_not_applied)
        }
        update { it.copy(accessMode = mode, accessPassword = "", accessPending = false) }
        announce(
            when (mode) {
                ControlMessage.ACCESS_APPROVAL ->
                    app.getString(R.string.announce_access_approval)
                ControlMessage.ACCESS_PASSWORD ->
                    app.getString(R.string.announce_access_password)
                else -> app.getString(R.string.announce_access_public)
            }
        )
        return null
    }

    fun applyAccessPassword() {
        applyAccess(_state.value.accessMode, _state.value.accessPassword)
    }

    /** Applies a change and speaks about a refusal, for the two paths the UI offers. */
    fun applyAccess(mode: String, password: String) {
        setAccess(mode, password)?.let { announceError(it) }
    }

    /** Records the password in the field without applying it, so typing does not change the mode. */
    fun setAccessPassword(password: String) {
        update { it.copy(accessPassword = password) }
    }

    // ------------------------------------------------------------------ viewer access

    /**
     * Shows the password prompt and parks until the viewer answers.
     *
     * Called from the handshake coroutine, not the UI, so the connection's state stays the single
     * thing that decides what is on screen: a second connect cannot raise a second prompt because
     * connectTo refuses to start while one is in flight.
     */
    private suspend fun awaitPassword(broadcasterName: String, wrongAttempt: Boolean): String? {
        val answer = CompletableDeferred<String?>()
        passwordAnswer = answer
        update {
            it.copy(
                passwordPrompt = PasswordPrompt(broadcasterName, wrongAttempt),
                isConnecting = true
            )
        }
        AppLog.info("MainViewModel", "Password requested by $broadcasterName (wrongAttempt=$wrongAttempt)")
        val password = answer.await()
        passwordAnswer = null
        update { it.copy(passwordPrompt = null) }
        return password
    }

    /**
     * Sends the typed password to the broadcaster.
     *
     * A refused password comes back as a new prompt rather than as an error here, so nothing has
     * to be guessed at: if the prompt is still up, the answer was not accepted.
     */
    fun submitPassword(password: String) {
        val answer = passwordAnswer ?: return
        if (!ControlMessage.isValidPassword(password)) {
            // Announced rather than only shown: a screen-reader user who cannot see the field
            // go red would otherwise have no way of knowing why nothing happened.
            announceError(
                app.getString(
                    R.string.error_password_length,
                    ControlMessage.PASSWORD_MIN_LENGTH,
                    ControlMessage.PASSWORD_MAX_LENGTH
                )
            )
            return
        }
        passwordAnswer = null
        update { it.copy(passwordPrompt = null) }
        answer.complete(password)
    }

    /** Dismisses the prompt without connecting. */
    fun cancelPasswordPrompt() {
        val answer = passwordAnswer ?: run {
            update { it.copy(passwordPrompt = null) }
            return
        }
        passwordAnswer = null
        update { it.copy(passwordPrompt = null, isConnecting = false, connectedKey = null) }
        answer.complete(null)
    }

    /**
     * Gives up on waiting for a presenter to answer.
     *
     * The waiting panel is only up while a broadcaster is deciding, so there is no password answer
     * to complete and nothing to clear: giving up means hanging up. It goes through [disconnect] so
     * the socket, the parked handshake and the media path come down together. Cancelling only the
     * panel would leave the viewer waiting forever on a broadcast that is no longer asking.
     */
    fun cancelAccessWait() {
        disconnect()
    }

    /** Answers a pending viewer request. Called from the prompt and from its notification. */
    fun resolveAccessRequest(key: Long, allow: Boolean) {
        // Read before clearing: the name is what the announcement names, and by the time the
        // answer has been delivered the prompt is gone.
        val viewer = _state.value.accessRequest
            ?.takeIf { it.key == key }
            ?.viewerName
        // Cleared before the answer goes out: the engine drops unanswered requests when the
        // broadcast stops, and a prompt left on screen after that would be answering nothing.
        if (_state.value.accessRequest?.key == key) {
            update { it.copy(accessRequest = null) }
        }
        broadcastEngine.resolveAccessRequest(key, allow)
        // The alert has done its job either way; leaving it up would imply the request were
        // still open when the viewer has already been told.
        BroadcastService.clearAccessRequest(app)
        // Whoever asked while this one was on screen gets their turn now.
        showNextAccessRequest()
        val who = viewer ?: app.getString(R.string.announce_the_viewer)
        announce(
            if (allow) app.getString(R.string.announce_viewer_allowed, who)
            else app.getString(R.string.announce_viewer_rejected, who)
        )
    }

    init {
        observeHandshakeProgress()

        // The lock-screen prompt cannot reach this ViewModel directly, so it broadcasts its
        // answer. Registered here, beside the engine that will honour it, and unregistered in
        // onCleared so a stopped app is not still listening.
        accessAnswerReceiver = AccessAnswerReceiver.register(app) { key, allow ->
            resolveAccessRequest(key, allow)
        }
    }

    fun setNormalizeAudio(enabled: Boolean) {
        if (_state.value.normalizeAudio == enabled) return
        update { it.copy(normalizeAudio = enabled) }
        broadcastEngine.setNormalizeAudio(enabled)
        // Heard, not merely told: the setting changes what the broadcast carries, so its new
        // value is spoken rather than left for the user to find on the control again.
        announce(
            if (enabled) app.getString(R.string.announce_normalize_audio_on)
            else app.getString(R.string.announce_normalize_audio_off)
        )
    }

    fun setTab(tab: MainTab) {
        update { it.copy(tab = tab) }
        // Entering the tab starts a fresh search rather than trusting the cache: the network may
        // have changed while the user was on the Broadcast tab, and a stale row is a connection
        // that cannot work.
        if (tab == MainTab.RECEIVE) rescan() else stopScanning()
    }

    // ------------------------------------------------------------------ receiving

    /**
     * Connects to a broadcaster.
     *
     * The RTP sockets are opened first so the ports can be offered in the handshake and no
     * packet can arrive before there is a socket to receive it.
     */
    fun connect(stream: DiscoveredStream) {
        connectTo(
            key = stream.key,
            host = stream.address.hostAddress ?: stream.address.hostName,
            controlPort = stream.description.controlPort,
            displayName = stream.description.displayName,
            wantsVideo = stream.description.mode == LocalStream.MODE_AUDIO_VIDEO
        )
    }

    /**
     * Connects to a broadcaster by address, for when discovery cannot find it.
     *
     * mDNS needs a multicast responder on UDP 5353, and a firewall that lets the query in. Plenty
     * of networks allow neither, and the broadcaster is sitting right there with a control port
     * printed on its screen. This is the way out, so discovery is not a hard requirement.
     */
    fun connectManually(host: String, controlPort: Int) {
        connectTo(
            key = "manual:$host:$controlPort",
            host = host,
            controlPort = controlPort,
            displayName = host,
            wantsVideo = true
        )
    }

    private fun connectTo(
        key: String,
        host: String,
        controlPort: Int,
        displayName: String,
        wantsVideo: Boolean
    ): Unit {
        if (_state.value.isConnecting) return
        AppLog.info("MainViewModel", "connectTo $host:$controlPort (video=$wantsVideo)")

// A previous refusal belongs to the attempt that earned it: reconnecting is a fresh start,
        // and leaving it on screen would tell the viewer they are still banned from a broadcast
        // they have not tried to join again.
        update {
            it.copy(
                isConnecting = true,
                connectedKey = key,
                blockedReason = null
            )
        }
        // A refusal from the last attempt has been answered by making this one; leaving its
        // bubble up would put the old reason beside the new attempt.
        ReceiveAlerts.clear(app)
        scope.launch {
            try {
                // Wait out any teardown still running from the previous session, so this
                // session's sockets and queues cannot be shut down by it.
                teardownJob?.join()
                val ports = rtpReceiver.open(withVideo = wantsVideo)
                val result = controlClient.connect(
                    host = host,
                    controlPort = controlPort,
                    receiverName = defaultDeviceName(),
                    audioPort = ports.audio,
                    videoPort = if (wantsVideo) ports.video else null,
                    passwordProvider = { wrongAttempt ->
                        awaitPassword(displayName, wrongAttempt)
                    }
                )
                result.onFailure { error ->
                    // Backing out of a prompt, or a session torn down while one was open, is the
                    // user's own doing. Silence keeps a cancel from being announced as a failure.
                    if (error is ConnectCancelled || error is CancellationException) {
                        AppLog.info("MainViewModel", "Connect to $host cancelled: ${error.message}")
                        update { it.copy(isConnecting = false, connectedKey = null) }
                        return@launch
                    }
                    update { it.copy(isConnecting = false, connectedKey = null) }
                    announceError(error.message ?: app.getString(R.string.error_could_not_connect))
                    return@launch
                }

                val handshake = result.getOrThrow()
                if (!rtpReceiver.setExpectedSource(
                        address = handshake.peerAddress,
                        audioPort = handshake.audioPort,
                        videoPort = handshake.videoPort,
                        audioSsrc = handshake.audioSsrc,
                        videoSsrc = handshake.videoSsrc
                    )
                ) {
                    controlClient.disconnect("The broadcaster returned invalid media source details.")
                    rtpReceiver.close()
                    throw IllegalStateException(
                        app.getString(R.string.error_invalid_media_details)
                    )
                }
                // The broadcaster states its audio channel count in the welcome's SDP, and the
                // decoder cannot infer it from the Opus packets. Set before the pump starts so
                // the first packet configures the decoder at the right layout.
                playback.setOutputChannels(handshake.audioChannels)
                // The buffer must be set before the pump starts so the first packets use it.
                playback.setReceiveBufferMs(_state.value.receiveBufferMs)
                announce(app.getString(R.string.announce_connected, displayName))
                update {
                    it.copy(
                        isConnecting = false,
                        connectedKey = key,
                        isReceivingVideo = wantsVideo
                    )
                }
                pumpRtp()
                // A sequence gap killed the in-flight access unit; ask for a keyframe so the
                // decoder can resynchronise instead of idling until the periodic IDR arrives.
                rtpReceiver.onVideoGap = ::requestVideoKeyframe
                observeControlChannel()
                requestKeyframe()
                startStatsReporting()
            } catch (e: Exception) {
                update { it.copy(isConnecting = false, connectedKey = null) }
                announceError(e.message ?: app.getString(R.string.error_could_not_connect))
            }
        }
    }

    private fun pumpRtp() {
        if (rtpPumpJob != null) return
        rtpPumpJob = scope.launch {
            launch {
                rtpReceiver.audioFramesFlow.collect { frame ->
                    playback.submitAudio(frame)
                }
            }
            launch {
                rtpReceiver.videoFramesFlow.collect { accessUnit ->
                    playback.submitVideo(
                        accessUnit = accessUnit,
                        sps = rtpReceiver.sps,
                        pps = rtpReceiver.pps,
                        hasVideo = true
                    )
                }
            }
        }
    }

    private suspend fun requestKeyframe() {
        // Without this the decoder would not have SPS/PPS and could not be configured at
        // all, so a joining receiver is stuck until the periodic IDR interval expires.
        controlClient.requestKeyframe()
    }

    /**
     * Asks the broadcaster for a fresh keyframe.
     *
     * Sent whenever the video surface is (re)created - entering or leaving fullscreen, or
     * rotating the device - so the picture returns at once instead of waiting out the fallback
     * keyframe interval. Safe to call when no session is running.
     */
    fun requestVideoKeyframe() {
        if (_state.value.connectedKey == null) return
        scope.launch { runCatching { controlClient.requestKeyframe() } }
    }

    /**
     * Sets the receive-side audio buffer.
     *
     * Applied live to a running connection and remembered for the next one, so the control never
     * has to be disabled mid-session. A larger buffer absorbs more jitter at a longer delay.
     */
    fun setReceiveBufferMs(millis: Int) {
        if (_state.value.receiveBufferMs == millis) return
        update { it.copy(receiveBufferMs = millis) }
        playback.setReceiveBufferMs(millis)
        // Heard, not merely told: the buffer changes what the user will hear, so its new value
        // is spoken rather than left for the user to find on the control again.
        announce(
            app.getString(
                R.string.announce_receive_buffer,
                app.getString(ReceiveBuffer.forMillis(millis).labelResource())
            )
        )
    }

    /**
     * The localised name of a buffer preset.
     *
     * [ReceiveBuffer] lives in the engine, which has no resources of its own, so the mapping from
     * a preset to the words for it is made here, where the chosen language is in force.
     */
    private fun ReceiveBuffer.labelResource(): Int = when (this) {
        ReceiveBuffer.LOW_LATENCY -> R.string.receive_buffer_low_latency
        ReceiveBuffer.BALANCED -> R.string.receive_buffer_balanced
        ReceiveBuffer.SMOOTH -> R.string.receive_buffer_smooth
        ReceiveBuffer.MAXIMUM -> R.string.receive_buffer_maximum
    }

    /**
     * Consumes the control channel after the handshake.
     *
     * The handshake itself reads `welcome` and `accept` directly. Everything after it arrives
     * here, and without a collector those messages sit in the client's queue: the buffer fills,
     * the reader blocks, and an authoritative mode change is never applied.
     */
    private fun observeControlChannel() {
        if (controlJob != null) return
        controlJob = scope.launch {
            launch {
                controlClient.state.collect { state ->
                    val reason = when (state) {
                        is ConnectionState.Rejected -> state.reason
                        is ConnectionState.Failed -> state.reason
                        is ConnectionState.Disconnected ->
                            app.getString(R.string.error_broadcaster_ended, state.reason)
                        else -> null
                    }
                    if (reason != null) {
                        announceError(reason)
                        disconnect()
                    }
                }
            }
            controlClient.incoming.collect { message ->
                when (message) {
                    is ControlMessage.ModeChanged -> applyRemoteMode(message.mode)
                    is ControlMessage.BroadcasterStats -> update {
                        it.copy(
                            connectionMessage = app.getString(
                                R.string.receive_live_stats,
                                message.framesPerSecond,
                                message.kilobitsPerSecond
                            ) + lossSuffix(message.packetLossPercent)
                        )
                    }
                    else -> Unit
                }
            }
        }
    }

    private fun lossSuffix(percent: Double): String =
        if (percent < 0.1) "" else app.getString(
            R.string.receive_packet_loss_suffix,
            "%.1f".format(percent)
        )

    /**
     * Applies a mode change announced by the broadcaster.
     *
     * The broadcaster is authoritative, so this is not negotiable. It can only ever turn video
     * *off* here: this receiver bound its media sockets before connecting, and an audio-only
     * session never opened a video socket at all. Adding video means reconnecting, which is
     * said out loud rather than left to look like a broken stream.
     */
    private fun applyRemoteMode(mode: String) {
        val previous = _state.value.mode
        if (previous == mode) return

        val nowHasVideo = mode == LocalStream.MODE_AUDIO_VIDEO
        update { it.copy(mode = mode, isReceivingVideo = nowHasVideo && it.isReceivingVideo) }

        if (!nowHasVideo) {
            announce(app.getString(R.string.announce_switched_to_audio_only))
        } else if (previous == LocalStream.MODE_AUDIO_ONLY) {
            announce(app.getString(R.string.announce_video_added))
        }
    }

    private fun startStatsReporting() {
        if (statsJob != null) return
        statsJob = scope.launch {
            while (true) {
                kotlinx.coroutines.delay(1000)
                val stats = rtpReceiver.statistics
                controlClient.sendStats(
                    ControlMessage.ReceiverStats(
                        packets = stats.audioPackets + stats.videoPackets,
                        lost = stats.lostPackets,
                        jitterMillis = stats.jitterMillis,
                        keyframeRequests = stats.keyframeRequests
                    )
                )
                update {
                    it.copy(receivedFrames = playback.framesDecoded, packetLoss = stats.lostPackets)
                }
            }
        }
    }

    fun disconnect() {
        AppLog.info("MainViewModel", "disconnect() called")
        controlClient.disconnect()
        // A prompt parked on screen would keep answering a handshake that no longer exists.
        passwordAnswer?.complete(null)
        passwordAnswer = null
        update {
            it.copy(
                passwordPrompt = null,
                isAwaitingApproval = false,
                isConnecting = false
            )
        }
        // Stop the consumers before the producer goes away, so nothing is fed while closing.
        rtpPumpJob?.cancel()
        rtpPumpJob = null
        rtpReceiver.onVideoGap = null
        statsJob?.cancel()
        statsJob = null
        controlJob?.cancel()
        controlJob = null
        // Tear the media path down on one job and keep a handle to it. A connect that follows
        // immediately must not race this close: opening the receiver before the previous one
        // has finished closing would let the close shut down the new session's sockets and
        // queues. connectTo awaits this before it opens anything.
        teardownJob?.cancel()
        teardownJob = scope.launch {
            rtpReceiver.close()
            playback.stop()
        }
        update {
            it.copy(
                connectedKey = null,
                isReceivingVideo = false,
                receivedFrames = 0,
                packetLoss = 0,
                connectionMessage = null
            )
        }
        // The user disconnecting, and the broadcaster stopping, both land here. Either way the
        // list has to be live again so there is something to reconnect to.
        rescan()
    }

    // ------------------------------------------------------------------ announcements

    /**
     * Pushes a message to the accessibility layer.
     *
     * Consumed by a `liveRegion` in the Compose tree, so TalkBack speaks it without the
     * user having to go looking for what changed.
     */
    private fun announce(message: String) {
        update { it.copy(announcement = message, announcementIsError = false) }
    }

    private fun announceError(message: String) {
        update { it.copy(announcement = message, announcementIsError = true) }
    }

    private fun applyBroadcastState(broadcast: BroadcastState) {
        // Errors are announced rather than stamped onto the banner, and only when they are new.
        // Stamping them here re-asserted the same message on every statistics tick, and once the
        // engine recovered it relabelled the identical text as a success - the flag flipped while
        // the words stayed, so the banner's colour stopped meaning what it said. The banner now
        // holds the last real announcement until something else announces.
        val error = broadcast.error
        if (error != null && error != _state.value.announcement) {
            announceError(error)
        }
        // The engine can end the broadcast on its own - a revoked capture permission, an
        // encoder that failed - with nothing calling stopBroadcast. The service exists only
        // for as long as there is a stream to keep alive, so the end of one takes it down
        // from here as well. Only on the way down: while the engine is starting, the service
        // is still promoting, and stopping it then would kill a broadcast that was never
        // allowed to come up.
        if (_state.value.isBroadcasting && !broadcast.isBroadcasting) {
            BroadcastService.stop(app)
        }
        update {
            it.copy(
                isBroadcasting = broadcast.isBroadcasting,
                isAdvertising = broadcast.isIdleAdvertised,
                controlPort = broadcast.controlPort,
                receiverCount = broadcast.receiverCount,
                // The engine is the authority on the mode: it drops back to public when a
                // broadcast stops. Without this the radios would keep showing the mode the
                // presenter last chose, and the next broadcast would go out unlocked while the
                // page claimed a password was set. A choice that is still waiting to be applied
                // is left alone, or the next statistics tick would undo the selection the
                // presenter is in the middle of making.
                accessMode = if (it.accessPending) it.accessMode else broadcast.accessMode
            )
        }
    }

    private fun republishDescription() {
        discovery.updateRegistration(
            descriptionProvider = { broadcastEngine.description() },
            onUpdated = { update { it.copy(isAdvertising = true) } },
            onError = { announceError(it) }
        )
    }

    private fun update(block: (UiState) -> UiState) {
        _state.update(block)
    }

    /**
     * Reports the parts of the handshake that happen before the control channel is consumed.
     *
     * Separate from [observeControlChannel] because that one only starts once a session is
     * established, and waiting for a password or for permission is exactly the window before
     * that: without this the viewer would sit on "connecting" with nothing to act on.
     */
    private fun observeHandshakeProgress() {
        scope.launch {
            controlClient.state.collect { state ->
                val waiting = state is ConnectionState.AwaitingApproval
                if (waiting != _state.value.isAwaitingApproval) {
                    update { it.copy(isAwaitingApproval = waiting) }
                    // Spoken, because "the presenter has not answered yet" is otherwise
                    // indistinguishable from a connection that has hung.
                    announce(
                        if (waiting) app.getString(R.string.announce_waiting_for_broadcaster)
                        else app.getString(R.string.announce_broadcaster_answered)
                    )
                }
                if (state is ConnectionState.Blocked && state.reason != _state.value.blockedReason) {
                    update { it.copy(blockedReason = state.reason) }
                }
                reportRefusal(state)
            }
        }
    }

    /**
     * The last refusal posted, so one refusal produces one notice however many times the state
     * carrying it is re-read. Cleared as soon as the state is anything else, which a retry
     * makes it, so refusing the same viewer twice says so twice.
     */
    private var lastRefusalReason: String? = null

    /**
     * Says a refusal outside the app, because it is the one thing in the handshake that happens
     * with the viewer doing nothing.
     *
     * Watched here rather than in the connect path because a refusal can also arrive after the
     * handshake - a broadcast put behind a password while someone is already admitted - and that
     * one has to be said just as much as the one that stopped a connection being made.
     */
    private fun reportRefusal(state: ConnectionState) {
        val blocked = state as? ConnectionState.Blocked
        val refused = state as? ConnectionState.Rejected
        if (blocked == null && refused == null) {
            lastRefusalReason = null
            return
        }
        val reason = blocked?.reason ?: refused!!.reason
        if (reason == lastRefusalReason) return
        lastRefusalReason = reason
        ReceiveAlerts.showRefusal(
            app,
            controlClient.broadcasterName.value,
            reason,
            blocked != null
        )
    }

    override fun onCleared() {
        super.onCleared()
        // Stop responding to triggers before tearing anything down, so a network callback that
        // fires mid-teardown cannot start a new browse.
        isCleared = true
        networkWatch.close()
        accessAnswerReceiver?.let { app.unregisterReceiver(it) }
        accessAnswerReceiver = null
        // The ViewModel is cleared only when the task is finishing, so this is the one
        // place that can guarantee no audio keeps flowing after the app closes.
        BroadcastService.stop(app)
        stopScanning()
        disconnect()
        broadcastEngine.release()
        playback.stop()
        discovery.release()
    }

    private companion object {
        /**
         * How long a foreground promotion may take before it is treated as failed.
         *
         * Generous, because the cost of waiting is invisible while the cost of giving up is
         * a broadcast that never starts; a device that cannot promote in five seconds is not
         * going to promote at all.
         */
        const val PROMOTION_TIMEOUT_MS = 5_000L
    }
}
