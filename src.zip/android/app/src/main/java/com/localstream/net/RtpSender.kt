package com.localstream.net

import com.localstream.protocol.H264Rtp
import com.localstream.protocol.LocalStream
import com.localstream.protocol.Rtp
import java.io.IOException
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.random.Random

/**
 * Sends RTP streams to every connected receiver.
 *
 * Both sockets are bound before any receiver connects and the ports are published in the
 * TXT record, so switching between audio-only and audio+video at runtime never needs a
 * renegotiation round trip: the video socket is already open and simply starts being
 * written to.
 *
 * One socket is shared by all receivers. Sequence numbers and timestamps therefore define
 * a single stream that every receiver sees, which is what lets a receiver drop in later
 * and request a keyframe without resynchronising anyone else.
 */
class RtpSender {

    private val running = AtomicBoolean(false)

    private var audioSocket: DatagramSocket? = null
    private var videoSocket: DatagramSocket? = null

    private val audioSsrc = Random.nextInt(1, Int.MAX_VALUE)
    private val videoSsrc = Random.nextInt(1, Int.MAX_VALUE)

    private val audioSequence = SequenceCounter()
    private val videoSequence = SequenceCounter()
    private val audioTimestamp = TimestampCounter()
    private val videoTimestamp = TimestampCounter()

    /** Receivers to fan out to, keyed by the address their `offer` came from. */
    private val audioTargets = LinkedHashMap<InetSocketAddress, Boolean>()
    private val videoTargets = LinkedHashMap<InetSocketAddress, Boolean>()

    var audioPort: Int = 0
        private set
    var videoPort: Int = 0
        private set

    /** Output frame rate, kept in step with the encoder so RTP timestamps stay correct. */
    var frameRate: Int = 30
        set(value) {
            field = value.coerceIn(1, 60)
        }

    /** Ticks between video frames at the 90 kHz RTP clock. */
    private val frameDuration90kHz: Int
        get() = LocalStream.VIDEO_CLOCK_RATE / frameRate.coerceAtLeast(1)

    val ssrcAudio: Int get() = audioSsrc
    val ssrcVideo: Int get() = videoSsrc

    /** Total RTP payload bytes actually sent to receivers. */
    private val bytesSent = java.util.concurrent.atomic.AtomicLong(0)

    /**
     * The bitrate the stream is actually achieving, averaged over roughly one second.
     *
     * Averaged rather than instantaneous: a per-frame figure would flicker so fast it could
     * not be read aloud by a screen reader.
     */
    fun currentBitrateKbps(): Int {
        val now = System.nanoTime()
        val previous = lastRateSampleAt
        if (previous == 0L) {
            lastRateSampleAt = now
            lastRateSampleBytes = bytesSent.get()
            return 0
        }
        val seconds = (now - previous) / 1_000_000_000.0
        if (seconds < 0.5) return lastBitrateKbps

        val total = bytesSent.get()
        val kbps = ((total - lastRateSampleBytes) * 8.0 / 1000.0 / seconds).toInt()
        lastRateSampleAt = now
        lastRateSampleBytes = total
        lastBitrateKbps = kbps
        return kbps
    }

    @Volatile
    private var lastRateSampleAt = 0L

    @Volatile
    private var lastRateSampleBytes = 0L

    @Volatile
    private var lastBitrateKbps = 0

    /**
     * Binds both media sockets. Must be called before publishing, because the ports are
     * advertised in the TXT record and in the `welcome` handshake.
     */
    @Throws(IOException::class)
    fun open(withVideo: Boolean) {
        if (running.getAndSet(true)) return
        try {
            audioSocket = DatagramSocket(null).apply {
                reuseAddress = true
                bind(InetSocketAddress(0))
            }
            audioPort = audioSocket!!.localPort

            if (withVideo) {
                videoSocket = DatagramSocket(null).apply {
                    reuseAddress = true
                    bind(InetSocketAddress(0))
                }
                videoPort = videoSocket!!.localPort
            }
        } catch (e: IOException) {
            close()
            throw e
        }
    }

    /**
     * Registers a receiver's destination. Called in response to its `offer`; the caller is
     * responsible for having already sent `accept`, since the first packet can leave
     * immediately afterwards.
     */
    fun addTarget(address: InetAddress, audioPort: Int, videoPort: Int?) {
        audioTargets[InetSocketAddress(address, audioPort)] = true
        if (videoPort != null && videoPort > 0) {
            videoTargets[InetSocketAddress(address, videoPort)] = true
        }
    }

    fun removeTarget(address: InetAddress, audioPort: Int, videoPort: Int?) {
        audioTargets.remove(InetSocketAddress(address, audioPort))
        if (videoPort != null && videoPort > 0) {
            videoTargets.remove(InetSocketAddress(address, videoPort))
        }
    }

    fun removeAllTargets() {
        audioTargets.clear()
        videoTargets.clear()
    }

    /**
     * Sends one Opus frame. [frame] is a raw Opus packet as produced by the encoder; per
     * RFC 7587 the RTP payload is the packet itself, with no OpusHead prefix.
     */
    fun sendAudio(frame: ByteArray) {
        if (!running.get()) return
        val socket = audioSocket ?: return
        if (audioTargets.isEmpty()) return

        // The timestamp is advanced regardless of whether anyone is listening, so that a
        // receiver that joins later is in sync with the audio clock.
        val timestamp = audioTimestamp.advance(LocalStream.OPUS_SAMPLES_PER_FRAME)
        val packet = Rtp.build(
            payloadType = LocalStream.PAYLOAD_TYPE_AUDIO,
            marker = false,
            sequenceNumber = audioSequence.next(),
            timestamp = timestamp,
            ssrc = audioSsrc,
            payload = frame
        )
        broadcast(socket, packet, audioTargets.keys)
    }

    /**
     * Sends one video access unit in AVCC form (the layout `MediaCodec` emits).
     * The marker bit goes on the final RTP payload of the frame, per RFC 6184.
     */
    fun sendVideo(accessUnit: ByteArray) {
        if (!running.get()) return
        val socket = videoSocket ?: return
        if (videoTargets.isEmpty()) return

        val nals = H264Rtp.splitAvcc(accessUnit)
        if (nals.isEmpty()) return

        val payloads = H264Rtp.packetize(nals)
        if (payloads.isEmpty()) return

        val timestamp = videoTimestamp.peek()
        val lastIndex = payloads.size - 1
        for ((index, payload) in payloads.withIndex()) {
            val packet = Rtp.build(
                payloadType = LocalStream.PAYLOAD_TYPE_VIDEO,
                marker = index == lastIndex,
                sequenceNumber = videoSequence.next(),
                timestamp = timestamp,
                ssrc = videoSsrc,
                payload = payload
            )
            broadcast(socket, packet, videoTargets.keys)
        }
        videoTimestamp.advance(frameDuration90kHz)
    }

    private fun broadcast(socket: DatagramSocket, payload: ByteArray, targets: Set<InetSocketAddress>) {
        for (target in targets) {
            try {
                socket.send(DatagramPacket(payload, payload.size, target))
                // Counted once per packet sent on the wire, not per access unit, so the
                // figure matches what a network sniffer would report.
                bytesSent.addAndGet(payload.size.toLong())
            } catch (e: IOException) {
                // A receiver that vanished mid-send is removed by its control-channel
                // disconnect; dropping the datagram here keeps the other receivers live.
            }
        }
    }

    fun close() {
        running.set(false)
        audioSocket?.close()
        audioSocket = null
        videoSocket?.close()
        videoSocket = null
        audioPort = 0
        videoPort = 0
        removeAllTargets()
    }

    private class SequenceCounter {
        private var value = Random.nextInt(0, 0xFFFF)
        fun next(): Int {
            value = (value + 1) and 0xFFFF
            return value
        }
    }

    /**
     * Advances a 32-bit RTP timestamp, wrapping like the wire format requires.
     *
     * Video ticks once per frame at 90 kHz (3000 per tick at 30 fps); audio ticks by the
     * sample count of each Opus frame. The two clocks are independent, as RTP expects.
     */
    private class TimestampCounter {
        private var value = Random.nextInt()

        fun peek(): Int = value

        fun advance(delta: Int): Int {
            value += delta
            return value
        }
    }
}
