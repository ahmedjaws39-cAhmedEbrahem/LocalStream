package com.localstream.ui

import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.os.Build
import java.util.Locale

/**
 * The languages the app can be read in, and the plumbing that puts the chosen one in front of
 * the resource system.
 *
 * English is the language the sources are written in and the fallback for everything else, so it
 * is listed first and needs no translation file. The others have a `values-<code>` folder.
 *
 * The choice is stored as a language code, or as the empty string for "follow the system". The
 * empty string is not the same as "English": a person whose phone is set to Arabic and who has
 * never touched the picker gets Arabic, while a person who picked English gets English whatever
 * the phone says.
 *
 * There is deliberately no list of languages whose translation does not exist. Offering one would
 * be a promise the build cannot keep, and picking it would silently leave the app in English with
 * no way for the person to tell why.
 */
object AppLanguage {

    /** Code for "use whatever the phone is set to". */
    const val SYSTEM: String = ""

    data class Language(val code: String, val nativeName: String)

    /** English first, then the translated languages. */
    val available: List<Language> = listOf(
        Language("en", "English"),
        Language("ar", "العربية"),
        Language("fr", "Français"),
        Language("ru", "Русский"),
        Language("tr", "Türkçe")
    )

    private const val PREFS = "localstream_ui"
    private const val KEY = "language"

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    /** The stored choice: a language code, or [SYSTEM]. */
    fun preferred(context: Context): String =
        prefs(context).getString(KEY, SYSTEM) ?: SYSTEM

    fun setPreferred(context: Context, code: String) {
        prefs(context).edit().putString(KEY, code).apply()
    }

    /**
     * The language actually in force: the choice if one was made, otherwise the phone's own,
     * otherwise English. [Locale.getDefault] is the whole system configuration, so a person who
     * has set Arabic only for apps gets Arabic here too.
     */
    fun effective(context: Context): String {
        val chosen = preferred(context)
        if (chosen.isNotEmpty()) return chosen
        val system = Locale.getDefault().language
        return if (available.any { it.code == system }) system else "en"
    }

    /** True for languages written right to left. */
    fun isRightToLeft(code: String): Boolean = code == "ar"

    /** The locale that matches [effective], for [wrap]. */
    fun localeFor(context: Context): Locale {
        val code = effective(context)
        return if (code == "en") Locale.ENGLISH else Locale.forLanguageTag(code)
    }

    /**
     * A context whose resources answer in the chosen language.
     *
     * Compose reads `stringResource` through the context the composition is created with, and so
     * do `getString` in an activity or a service, so every entry point has to wrap itself. The
     * returned context keeps the original one as its base, which is what carries the resources,
     * the theme and the app's own file paths across.
     */
    fun wrap(base: Context): Context {
        val locale = localeFor(base)
        Locale.setDefault(locale)
        val configuration = Configuration(base.resources.configuration)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            configuration.setLocale(locale)
            configuration.setLayoutDirection(locale)
        } else {
            @Suppress("DEPRECATION")
            configuration.locale = locale
            @Suppress("DEPRECATION")
            configuration.setLayoutDirection(locale)
        }
        return base.createConfigurationContext(configuration)
    }

    /**
     * The tutorial page that matches the chosen language.
     *
     * The pages are assets rather than resources because they are opened by a browser, not
     * rendered by the app, so they have to be whole files with their own styling and their own
     * `lang` and `dir`. English is the fallback: a language without a page gets the English one
     * rather than nothing.
     */
    fun tutorialAsset(context: Context): String {
        val code = effective(context)
        val candidate = "Tutorial-$code.html"
        return try {
            context.assets.open(candidate).close()
            candidate
        } catch (missing: java.io.IOException) {
            "Tutorial.html"
        }
    }

    /**
     * The activities that have to be told the language changed.
     *
     * A running broadcast must not be torn down by a language change, so [LOCALSTREAM_RECREATE]
     * tells the activity to rebuild its own composition without going through the service.
     */
    const val EXTRA_RECREATE = "com.localstream.ui.EXTRA_RECREATE"

    /**
     * Asks [activityClass] to come back so its strings are read again, and returns the intent
     * flags that clear whatever was on screen before. Used when the choice is changed from the
     * Help tab while the app is in the foreground.
     */
    fun recreateIntent(context: Context, activityClass: Class<*>): Intent =
        Intent(context, activityClass)
            .putExtra(EXTRA_RECREATE, true)
            .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
}

/**
 * The activity this context belongs to, or null when there is none.
 *
 * Compose hands composables a context that is usually the activity but is not guaranteed to be,
 * and a context wrapper can sit in between. Changing the language needs the activity itself:
 * `recreate()` on it rebuilds the composition, and therefore re-reads every string, without
 * touching the broadcast service, which is a separate component and carries on running.
 */
fun Context.findActivity(): android.app.Activity? {
    var current: Context? = this
    while (current is android.content.ContextWrapper) {
        if (current is android.app.Activity) return current
        current = current.baseContext
    }
    return null
}