package com.localstream.engine

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaCodec
import android.media.MediaFormat
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.os.Build
import com.localstream.logging.AppLog
import com.localstream.protocol.LocalStream
import java.nio.ByteBuffer
import java.util.concurrent.atomic.AtomicBoolean

/** Where the audio a broadcast carries comes from. */
enum class AudioSource {
    /** The device's microphone. Needs `RECORD_AUDIO` and nothing else. */
    MICROPHONE,

    /**
     * The sound the device is playing, captured through a `MediaProjection`.
     *
     * Android 10 and above only, and it needs the same screen-capture consent the screen
     * source does, because playback capture is authorised by a projection rather than by a
     * dedicated permission.
     */
    DEVICE
}

/**
 * Audio capture and Opus encoding, driven as one pipeline.
 *
 * The source is either the microphone or the device's own playback, chosen by [AudioSource];
 * both are read through `AudioRecord`, so everything downstream of the recorder is identical.
 * `AudioRecord` is read in blocking mode on a dedicated thread and handed straight to
 * `MediaCodec` as 20 ms frames. Reading and encoding in the same loop avoids a second
 * copy and, more importantly, keeps the audio clock honest: a backlogged buffer would show
 * up as ever-growing delay between a speaker's mouth and their voice arriving at a viewer.
 */
class AudioCaptureEncoder {

    private var recorder: AudioRecord? = null
    private var codec: MediaCodec? = null
    private var captureThread: Thread? = null
    private var drainThread: Thread? = null

    private val running = AtomicBoolean(false)
    private val draining = AtomicBoolean(false)

    private var onFrame: ((ByteArray) -> Unit)? = null

    /**
     * Starts capture and encoding.
     *
     * @throws android.Manifest.permission-denied style [SecurityException] if RECORD_AUDIO
     *         has not been granted.
     */
    @SuppressLint("MissingPermission")
    fun start(
        onFrame: (ByteArray) -> Unit,
        bitrateKbps: Int,
        channels: Int = 1,
        source: AudioSource = AudioSource.MICROPHONE,
        projection: MediaProjection? = null,
        normalize: Boolean = false
    ) {
        if (!running.compareAndSet(false, true)) return
        this.onFrame = onFrame

        val channelCount = channels.coerceIn(1, 2)
        val channelMask = if (channelCount == 2) AudioFormat.CHANNEL_IN_STEREO
        else AudioFormat.CHANNEL_IN_MONO
        val minBuffer = AudioRecord.getMinBufferSize(
            SAMPLE_RATE,
            channelMask,
            AudioFormat.ENCODING_PCM_16BIT
        )
        if (minBuffer <= 0) {
            running.set(false)
            throw IllegalStateException("This device cannot record 48 kHz audio.")
        }
        // Four frames of slack; the encoder consumes faster than real time, so this only
        // has to absorb scheduling jitter, not buffering worth speaking of.
        val bufferBytes = minBuffer * 2

        val record = when (source) {
            AudioSource.MICROPHONE -> AudioRecord.Builder()
                .setAudioSource(MediaRecorder.AudioSource.MIC)
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(SAMPLE_RATE)
                        .setChannelMask(channelMask)
                        .build()
                )
                .setBufferSizeInBytes(bufferBytes)
                .build()

            AudioSource.DEVICE -> {
                // The positive version check is what makes this safe to write: the helper
                // lives in its own object so this file still loads on API levels that have no
                // playback capture at all, and the guard keeps lint from flagging the call.
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    val grant = projection
                    if (grant == null) {
                        running.set(false)
                        throw IllegalStateException(
                            "Broadcasting the device's sound needs screen-capture permission."
                        )
                    }
                    PlaybackCapture.buildRecord(grant, SAMPLE_RATE, channelCount, bufferBytes)
                } else {
                    running.set(false)
                    throw IllegalStateException(
                        "Broadcasting the device's sound needs Android 10 or newer."
                    )
                }
            }
        }

        if (record.state != AudioRecord.STATE_INITIALIZED) {
            record.release()
            running.set(false)
            throw IllegalStateException(
                if (source == AudioSource.DEVICE) {
                    "The device's sound could not be captured. This app may not allow it."
                } else {
                    "The microphone could not be opened. Another app may be using it."
                }
            )
        }

        val format = MediaFormat.createAudioFormat(
            MediaFormat.MIMETYPE_AUDIO_OPUS,
            SAMPLE_RATE,
            channelCount
        ).apply {
            setInteger(MediaFormat.KEY_BIT_RATE, bitrateKbps * 1000)
            setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, FRAME_BYTES * 8)
        }

        val encoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_OPUS)
        encoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        encoder.start()

        recorder = record
        codec = encoder
        draining.set(true)

        record.startRecording()
        val normalizer = if (normalize) AudioNormalizer() else null
        captureThread = Thread({ capture(record, encoder, channelCount, normalizer) }, "LocalStream-AudioCapture").apply { start() }
        drainThread = Thread({ drain(encoder) }, "LocalStream-AudioEncode").apply { start() }
    }

    private fun capture(record: AudioRecord, encoder: MediaCodec, channelCount: Int, normalizer: AudioNormalizer?) {
        val frameBytes = FRAME_BYTES * channelCount
        val pcm = ByteArray(frameBytes)
        val bufferInfo = MediaCodec.BufferInfo()
        var presentationTimeUs = 0L
        val samplesPerFrameUs = (FRAME_BYTES.toLong() * 1_000_000L) / SAMPLE_RATE

        while (running.get() && draining.get()) {
            // Blocking read: the byte-array overload returns the number of bytes captured, which
            // is almost always a full frame once the stream has started. Filling the buffer from
            // `accumulated` bytes and advancing by the same unit is what keeps the frame whole;
            // mixing bytes and shorts leaves the tail of every frame stale.
            var accumulated = 0
            while (accumulated < frameBytes && running.get()) {
                val bytes = record.read(pcm, accumulated, frameBytes - accumulated)
                if (bytes <= 0) {
                    if (bytes == AudioRecord.ERROR_DEAD_OBJECT || bytes == AudioRecord.ERROR_INVALID_OPERATION) {
                        running.set(false)
                    }
                    break
                }
                accumulated += bytes
            }
            val read = accumulated
            if (read < frameBytes) continue

            // The captured level is normalised before encoding, so a receiver hears a steady
            // volume no matter the device or the system volume. The frame is a whole number of
            // 16-bit samples, which is what the normaliser reads and writes.
            normalizer?.process(pcm, frameBytes / 2)

            val index = try {
                encoder.dequeueInputBuffer(DEQUEUE_TIMEOUT_US)
            } catch (e: IllegalStateException) {
                break
            }
            if (index < 0) continue

            val input: ByteBuffer = encoder.getInputBuffer(index) ?: continue
            input.clear()
            input.put(pcm, 0, frameBytes)
            encoder.queueInputBuffer(
                index,
                0,
                frameBytes,
                presentationTimeUs,
                0
            )
            presentationTimeUs += samplesPerFrameUs
        }
    }

    private fun drain(encoder: MediaCodec) {
        val bufferInfo = MediaCodec.BufferInfo()
        while (running.get() && draining.get()) {
            val index = try {
                encoder.dequeueOutputBuffer(bufferInfo, DEQUEUE_TIMEOUT_US)
            } catch (e: IllegalStateException) {
                break
            }
            if (index < 0) continue

            val buffer = encoder.getOutputBuffer(index)
            if (buffer != null && bufferInfo.size > 0) {
                val isConfig =
                    (bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0
                if (!isConfig) {
                    val data = ByteArray(bufferInfo.size)
                    buffer.position(bufferInfo.offset)
                    buffer.limit(bufferInfo.offset + bufferInfo.size)
                    buffer.get(data)
                    // This is the raw Opus packet, which per RFC 7587 goes into the RTP
                    // payload with no OpusHead prefix.
                    onFrame?.invoke(data)
                }
            }
            encoder.releaseOutputBuffer(index, false)
        }
    }

    fun setBitrate(bitrateKbps: Int) {
        val encoder = codec ?: return
        try {
            encoder.setParameters(
                android.os.Bundle().apply {
                    // Audio encoders use the plain "bitrate" key; there is no
                    // MediaCodec constant for it, so MediaFormat's is the documented source.
                    putInt(MediaFormat.KEY_BIT_RATE, bitrateKbps * 1000)
                }
            )
        } catch (e: IllegalStateException) {
            AppLog.warning("AudioCaptureEncoder", "Could not change the audio bitrate: $e")
        }
    }

    fun stop() {
        running.set(false)
        draining.set(false)
        runCatching { recorder?.stop() }
        captureThread?.join(500)
        drainThread?.join(500)
        captureThread = null
        drainThread = null
    }

    fun release() {
        stop()
        runCatching { recorder?.release() }
        recorder = null
        runCatching { codec?.stop() }
        runCatching { codec?.release() }
        codec = null
        onFrame = null
    }

    companion object {
        const val SAMPLE_RATE = 48_000

        /** 20 ms of 48 kHz mono 16-bit PCM. */
        const val FRAME_BYTES = LocalStream.OPUS_SAMPLES_PER_FRAME * 2

        private const val DEQUEUE_TIMEOUT_US = 10_000L
    }
}
