package com.localstream.engine

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import com.localstream.logging.AppLog

/**
 * Owns the one [MediaProjection] a broadcast is allowed to hold.
 *
 * A projection is needed for two unrelated things: mirroring the screen, and recording the
 * sound the device is playing. Android 14 lets a consent token be turned into a projection
 * exactly once, so the two features cannot each create their own -- a broadcast that shares
 * the screen *and* the device's audio would otherwise need the user to approve the capture
 * dialog twice, and the second approval would be refused. One object therefore owns the
 * projection for the whole broadcast and hands the same instance to whichever capture
 * sources need it.
 *
 * The projection is deliberately not stopped when screen sharing ends: device-audio capture
 * may still be using it. It is released when the broadcast stops, or by the engine once it
 * knows nothing needs it any more.
 */
class ProjectionController(private val context: Context) {

    private var projection: MediaProjection? = null
    private var thread: HandlerThread? = null

    @Volatile
    private var stopping = false

    /** Invoked when the system revokes the projection, e.g. from the casting notification. */
    var onStopped: (() -> Unit)? = null

    /** The live projection, or null when none has been granted or it has been released. */
    val active: MediaProjection? get() = projection

    /**
     * Turns a consent token into a projection, or returns the one already held.
     *
     * @throws IllegalStateException if the user refused the capture permission.
     */
    @Throws(IllegalStateException::class)
    fun acquire(token: Intent): MediaProjection {
        projection?.let { return it }

        val worker = HandlerThread("LocalStream-Projection").apply { start() }
        thread = worker
        val handler = Handler(worker.looper)

        val manager = context.getSystemService(Context.MEDIA_PROJECTION_SERVICE)
            as MediaProjectionManager
        val created = obtainProjection(manager, token)
            ?: run {
                worker.quitSafely()
                thread = null
                throw IllegalStateException("Screen capture permission was refused.")
            }

        // A projection whose callbacks throw on the calling thread is silently killed by the
        // platform, which surfaces as a broadcast that stops for no reason. The callback is
        // registered with an explicit handler: null would mean this object's calling thread,
        // which is a coroutine dispatcher with no Looper.
        created.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                AppLog.info("ProjectionController", "The projection was stopped by the system")
                projection = null
                if (!stopping) onStopped?.invoke()
            }
        }, handler)

        projection = created
        return created
    }

    /** Releases the projection. Safe to call when none is held, or more than once. */
    fun stop() {
        val current = projection
        projection = null
        // The flag suppresses onStopped for the stop this call is causing; a projection the
        // system revokes on its own must still reach the engine.
        stopping = true
        runCatching { current?.stop() }
        stopping = false
        thread?.quitSafely()
        thread = null
    }

    /**
     * Obtains a [MediaProjection] on every supported API level.
     *
     * `MediaProjectionManager.getMediaProjection(int, Intent)` is only public from API 34.
     * The method it replaced has always existed but is hidden, and it reads its result code
     * out of a `Bundle` inside the intent rather than as a separate argument. Rather than
     * raise the minimum SDK to 34 and drop a third of the devices this is meant for, the
     * pre-34 path reconstructs that bundle and calls the hidden method reflectively.
     *
     * This is the standard workaround; it is a direct call to a framework method that has
     * existed unchanged since API 17, and it is removed entirely once `minSdk` reaches 34.
     */
    private fun obtainProjection(
        manager: MediaProjectionManager,
        token: Intent
    ): MediaProjection? {
        // The framework reports a refusal by returning null, and it decides refusal from
        // this code. A token that never carried it reads as RESULT_CANCELED, so the
        // default has to be the cancelling one: better a clear failure here than a
        // projection that silently never delivers frames.
        val resultCode = token.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            return manager.getMediaProjection(resultCode, token)
        }

        val resultData = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            token.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            token.getParcelableExtra(EXTRA_RESULT_DATA)
        }

        val extras = Bundle().apply {
            putInt(EXTRA_RESULT_CODE, resultCode)
            putParcelable(EXTRA_RESULT_DATA, resultData)
        }
        val wrapped = Intent(token).putExtras(
            Bundle().apply {
                putParcelable(EXTRA_RESULT, extras)
            }
        )
        val method = MediaProjectionManager::class.java.getDeclaredMethod(
            "getMediaProjection",
            Int::class.javaPrimitiveType,
            Intent::class.java
        )
        method.isAccessible = true
        return method.invoke(manager, resultCode, wrapped) as? MediaProjection
    }

    companion object {
        private const val EXTRA_RESULT = "android.media.projection.extra.EXTRA_RESULT"
        private const val EXTRA_RESULT_CODE = "android.intent.extra.EXTRA_RESULT_CODE"
        private const val EXTRA_RESULT_DATA = "android.intent.extra.EXTRA_RESULT_DATA"

        /**
         * Wraps an ActivityResult's data into the token shape [acquire] expects.
         *
         * The ActivityResult contract delivers the result code separately from the data
         * intent, while `MediaProjectionManager.getMediaProjection` looks for it *inside*
         * the token. Handing [acquire] the bare data intent is indistinguishable from a
         * refusal, so the code has to be put back before the engine ever sees it.
         */
        fun tokenFrom(
            resultCode: Int,
            data: Intent
        ): Intent = Intent(data).putExtra(EXTRA_RESULT_CODE, resultCode)
    }
}
