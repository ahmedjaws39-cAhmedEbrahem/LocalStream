package com.localstream.engine

import android.content.Context
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.projection.MediaProjection
import android.os.Handler
import android.os.HandlerThread
import android.util.DisplayMetrics
import android.view.Surface
import android.view.WindowManager
import com.localstream.logging.AppLog
import java.util.concurrent.atomic.AtomicBoolean

/** Where video frames come from. */
enum class VideoSource { SCREEN, CAMERA }

/**
 * Screen capture via a [MediaProjection] owned by [ProjectionController].
 *
 * The projection renders straight into the encoder's input surface, so no frame is ever
 * read back into app memory. A second `VirtualDisplay` off the same projection feeds the
 * local preview, because a live broadcast with no visible preview is disorienting for
 * sighted users and makes self-shot audio/video impossible to frame.
 *
 * The projection itself is not this object's to create or stop: it may also be feeding
 * device-audio capture, so its lifetime belongs to [ProjectionController]. This class only
 * creates and releases the virtual displays that read from it.
 */
class ScreenCaptureSource(private val context: Context) {

    private var encoderDisplay: VirtualDisplay? = null
    private var previewDisplay: VirtualDisplay? = null
    private var virtualThread: HandlerThread? = null
    private val active = AtomicBoolean(false)

    @Throws(Exception::class)
    fun start(projection: MediaProjection, encoderSurface: Surface, previewSurface: Surface?) {
        if (!active.compareAndSet(false, true)) return

        val thread = HandlerThread("LocalStream-Screen").apply { start() }
        virtualThread = thread
        val handler = Handler(thread.looper)

        val metrics = displayMetrics()
        val width = metrics.first
        val height = metrics.second
        val density = metrics.third

        encoderDisplay = projection.createVirtualDisplay(
            "localstream-encoder",
            width,
            height,
            density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            encoderSurface,
            null,
            handler
        )

        if (previewSurface != null) {
            previewDisplay = projection.createVirtualDisplay(
                "localstream-preview",
                width,
                height,
                density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                previewSurface,
                null,
                handler
            )
        }

        AppLog.info("ScreenCaptureSource", "Screen capture started at ${width}x$height")
    }

    private fun displayMetrics(): Triple<Int, Int, Int> {
        val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getRealMetrics(metrics)
        return Triple(metrics.widthPixels, metrics.heightPixels, metrics.densityDpi)
    }

    fun stop() {
        if (!active.compareAndSet(true, false)) return
        runCatching { encoderDisplay?.release() }
        runCatching { previewDisplay?.release() }
        encoderDisplay = null
        previewDisplay = null
        virtualThread?.quitSafely()
        virtualThread = null
    }
}
