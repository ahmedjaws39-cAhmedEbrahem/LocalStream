package com.localstream.net

import com.localstream.logging.AppLog
import com.localstream.protocol.ControlMessage
import com.localstream.protocol.LocalStream
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.net.SocketTimeoutException
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Broadcaster side of the control channel.
 *
 * One TCP server, one connection per receiver, newline-delimited JSON in both directions.
 * The server owns the authoritative answers: it decides whether a receiver is admitted
 * (`deny`), and it is the only party that may announce a mode change (`mode`), so a
 * receiver can request but never force a switch.
 */
class ControlServer(
    private val scope: CoroutineScope,
    private val descriptionProvider: () -> LocalStream.Description,
    private val sdpProvider: () -> String,
    private val audioSsrcProvider: () -> Int,
    private val videoSsrcProvider: () -> Int,
    private val onOffer: (InetAddress, audioPort: Int, videoPort: Int?) -> Unit,
    private val onRemove: (InetAddress, audioPort: Int, videoPort: Int?) -> Unit,
    private val onKeyframeRequest: () -> Unit,
    private val onBitrateRequest: (videoKbps: Int?, audioKbps: Int?) -> Unit,
    private val onModeRequest: (mode: String) -> Unit,
    private val onReceiverStats: (ControlMessage.ReceiverStats) -> Unit,
    private val onReceiverConnected: (name: String) -> Unit,
    private val onReceiverDisconnected: (name: String) -> Unit,
    private val onAccessRequest: (requestKey: Long, name: String) -> Unit,
    private val onAccessRequestCancelled: (requestKey: Long, name: String) -> Unit,
    private val maxReceivers: Int = LocalStream.MAX_RECEIVERS_DEFAULT
) {

    private val running = AtomicBoolean(false)
    private var serverSocket: ServerSocket? = null
    private var acceptJob: Job? = null
    private val sessions = java.util.Collections.synchronizedList(ArrayList<Session>())

    /**
     * Who may join. Volatile because it is written from the UI thread and read on a session
     * coroutine; a session that saw a stale value for one handshake would offer to let a
     * viewer in that the broadcaster had already decided to lock out.
     */
    @Volatile
    var accessMode: String = ControlMessage.ACCESS_PUBLIC

    /**
     * Kept as a plain string because that is what the comparison against an incoming auth needs.
     * Never logged, never written to disk, and dropped when the broadcast stops.
     */
    @Volatile
    private var accessPassword: String = ""

    /**
     * Rejections per peer address, for this broadcast only.
     *
     * Keyed by address rather than by connection because the rule is about a device: a viewer
     * who has spent their rejections and reconnects must not get a clean slate. Cleared by
     * [clearAccessHistory] when the broadcast stops, so the next broadcast judges afresh.
     */
    private val rejections =
        java.util.Collections.synchronizedMap(java.util.concurrent.ConcurrentHashMap<InetAddress, Int>())

    /** Pending approval requests, keyed by the id handed to [onAccessRequest]. */
    /**
     * Pending approval requests, keyed by the id handed to [onAccessRequest].
     *
     * The value is `Boolean?` rather than `Boolean` so that teardown can be told apart from a
     * refusal. Completing these with `false` when a broadcast stops would record a rejection the
     * user never chose, which would count against that viewer in the *next* broadcast.
     */
    private val pendingRequests =
        java.util.Collections.synchronizedMap(HashMap<Long, CompletableDeferred<Boolean?>>())

    private val requestCounter = java.util.concurrent.atomic.AtomicLong(1)

    var port: Int = 0
        private set

    val receiverCount: Int get() = sessions.size

    // ------------------------------------------------------------------ access control

    /**
     * Changes who may join. Safe while broadcasting: it applies to the next request, and viewers
     * already admitted keep their stream.
     */
    fun setAccess(mode: String, password: String) {
        accessMode = mode
        accessPassword = password
    }

    /**
     * Shuts the broadcast while the presenter is still choosing a password.
     *
     * A chosen-but-unusable password is not the same as "public": the presenter has said they want
     * a password, and a viewer admitted in the gap would be watching a broadcast meant to be
     * locked, without ever being asked. With no usable password stored, [checkPassword] refuses
     * every attempt and an `offer` that skipped the step is denied, so the broadcast stays shut
     * until a real password is set. Viewers are told a password is required, which is exactly what
     * the presenter intends - they simply cannot supply the one that does not exist yet.
     *
     * The mode is announced as [ControlMessage.ACCESS_PASSWORD] so the lock is visible on the wire,
     * not just inside this process.
     */
    fun holdForPassword() {
        accessMode = ControlMessage.ACCESS_PASSWORD
        accessPassword = ""
    }

    /** Forgets rejections and bans. Called when a broadcast ends, so the next one starts clean. */
    fun clearAccessHistory() {
        rejections.clear()
        // Anything still waiting is released as "no decision", so no viewer is left hanging and no
        // strike is recorded against a decision the user never made.
        synchronized(pendingRequests) {
            pendingRequests.values.forEach { it.complete(null) }
            pendingRequests.clear()
        }
    }

    /**
     * Answers a request raised by [onAccessRequest].
     *
     * Ignored when the key is unknown, which is the normal case if the viewer gave up or the
     * broadcast stopped while the prompt was on screen.
     */
    fun resolveAccessRequest(requestKey: Long, allow: Boolean) {
        val waiting = pendingRequests.remove(requestKey) ?: return
        waiting.complete(allow)
    }

    /**
     * Waits out the presenter's decision while still noticing a viewer who gives up.
     *
     * The read loop is parked on the decision, so a socket that closes behind the presenter's
     * back would hold their prompt on screen forever - and, because the UI shows one prompt at a
     * time, strand every later request behind it. The socket is therefore probed between waits:
     * a viewer waiting to be let in sends nothing, so the only thing a short read can find is
     * the end of the stream.
     *
     * Returns the decision, or null when there was none - the broadcast ended, or the viewer
     * hung up. Neither is a refusal and neither may spend one of the viewer's three.
     */
    private suspend fun awaitDecision(
        socket: Socket,
        requestKey: Long,
        name: String,
        decision: CompletableDeferred<Boolean?>
    ): Boolean? {
        while (!decision.isCompleted) {
            withTimeoutOrNull(DecisionPollMs) { decision.await() }
            if (!decision.isCompleted && peerGone(socket)) {
                pendingRequests.remove(requestKey)
                decision.complete(null)
                // Told so the prompt does not outlive the request behind it: the presenter
                // would otherwise be asked about a viewer who is no longer there.
                onAccessRequestCancelled(requestKey, name)
            }
        }
        pendingRequests.remove(requestKey)
        return decision.await()
    }

    /**
     * Whether the peer has hung up.
     *
     * A one-millisecond read timeout makes the check a poll rather than a wait: bytes still to
     * arrive time out, a closed stream returns -1 at once. The timeout is put back afterwards so
     * the session's own reader is unaffected.
     */
    private fun peerGone(socket: Socket): Boolean {
        if (socket.isClosed || !socket.isConnected) return true
        return try {
            if (socket.getInputStream().available() > 0) return false
            socket.soTimeout = DecisionProbeMs
            socket.getInputStream().read() < 0
        } catch (e: SocketTimeoutException) {
            false
        } catch (e: IOException) {
            true
        } finally {
            socket.soTimeout = 0
        }
    }

    @Throws(IOException::class)
    fun open() {
        if (running.getAndSet(true)) return
        val socket = ServerSocket()
        socket.reuseAddress = true
        socket.bind(InetSocketAddress(0))
        serverSocket = socket
        port = socket.localPort
        acceptJob = scope.launch(Dispatchers.IO) { acceptLoop() }
    }

    private suspend fun acceptLoop() {
        val server = serverSocket ?: return
        while (running.get()) {
            val client = try {
                withContext(Dispatchers.IO) { server.accept() }
            } catch (e: IOException) {
                if (running.get()) continue else break
            }
            scope.launch(Dispatchers.IO) { handleSession(client) }
        }
    }

    private suspend fun handleSession(socket: Socket) {
        // Advertised to the receiver's `offer` handler as the port we send media to.
        var offeredAudio = 0
        var offeredVideo = 0
        var name = "Receiver"
        // Per connection, not per peer: a second connection from an admitted device still has to
        // authenticate for itself.
        var authenticated = false
        val session = Session(socket)
        session.startWriter(scope)
        sessions.add(session)

        val reader = BufferedReader(InputStreamReader(socket.getInputStream(), Charsets.UTF_8))
        AppLog.debug("ControlServer", "Receiver connected from ${socket.inetAddress}")
        try {
            while (running.get() && !socket.isClosed) {
                val line = try {
                    withContext(Dispatchers.IO) { reader.readLine() } ?: break
                } catch (e: IOException) {
                    break
                }
                if (line.isEmpty()) continue

                val message = ControlMessage.parse(line) ?: continue

                when (message) {
                    is ControlMessage.Hello -> {
                        name = message.name
                        if (message.protocolVersion != LocalStream.PROTOCOL_VERSION) {
                            session.send(
                                ControlMessage.Deny(
                                    ControlMessage.DENY_VERSION,
                                    "This broadcaster speaks protocol version " +
                                        "${LocalStream.PROTOCOL_VERSION}; the receiver asked for " +
                                        "${message.protocolVersion}. Update one of the apps."
                                )
                            )
                            break
                        }
                        val description = descriptionProvider()
                        if (sessions.size > maxReceivers) {
                            session.send(
                                ControlMessage.Deny(
                                    ControlMessage.DENY_CAPACITY,
                                    "This broadcast already has the maximum of $maxReceivers receivers."
                                )
                            )
                            break
                        }
                        session.send(
                            ControlMessage.Welcome(
                                sessionId = description.sessionId,
                                displayName = description.displayName,
                                mode = description.mode,
                                sdp = sdpProvider(),
                                access = accessMode
                            )
                        )
                        onReceiverConnected(name)
                    }

                    is ControlMessage.AuthRequest -> {
                        // Answered without suspending the read loop, so a wrong password costs a
                        // round trip and the viewer can simply retype.
                        val result = checkPassword(message.password)
                        // Set only on a grant, and only for this connection: a second connection
                        // from the same device authenticates for itself.
                        authenticated = result.granted
                        session.send(result)
                    }

                    is ControlMessage.Offer -> {
                        // The ports are recorded before anything is admitted, so the teardown
                        // path can withdraw the RTP target whether or not the offer was accepted.
                        offeredAudio = message.audioPort
                        offeredVideo = message.videoPort ?: 0
                        val address = socket.inetAddress

                        when (accessMode) {
                            ControlMessage.ACCESS_APPROVAL -> {
                                // Over the limit: refused without troubling the user with a
                                // prompt for someone who is already barred.
                                if (rejections[address] ?: 0 >= ControlMessage.MAX_REJECTIONS) {
                                    denyBlocked(session)
                                    break
                                }
                                val key = requestCounter.getAndIncrement()
                                val decision = CompletableDeferred<Boolean?>()
                                pendingRequests[key] = decision
                                onAccessRequest(key, name)
                                // Suspended, not blocked: the connection stays open and the
                                // session's own writer keeps running, so the answer can be
                                // delivered whenever the user acts — or never, if they ignore it.
                                val allowed = awaitDecision(socket, key, name, decision)
                                // Null means the broadcast ended while the prompt was up. That is
                                // not a refusal, so it must not spend one of the viewer's three.
                                if (allowed == null) {
                                    break
                                }
                                if (!allowed) {
                                    denyRejected(session, address)
                                    break
                                }
                                // The mode can change while a prompt is up - that is what
                                // allowing a live change is for - so an approval given under an
                                // older mode is not consent to walk past a password set since.
                                if (accessMode != ControlMessage.ACCESS_APPROVAL &&
                                    accessMode != ControlMessage.ACCESS_PUBLIC
                                ) {
                                    session.send(
                                        ControlMessage.Deny(
                                            ControlMessage.DENY_AUTH,
                                            "This broadcast needs a password now. " +
                                                "Reconnect to enter it."
                                        )
                                    )
                                    break
                                }
                            }

                            ControlMessage.ACCESS_PASSWORD -> {
                                // A peer that skipped `auth` must not get in by omission, so
                                // the missing step is named rather than called a wrong password.
                                if (!authenticated) {
                                    session.send(
                                        ControlMessage.Deny(
                                            ControlMessage.DENY_AUTH,
                                            "This broadcast is password protected."
                                        )
                                    )
                                    break
                                }
                            }
                        }

                        onOffer(address, offeredAudio, message.videoPort)
                        val description = descriptionProvider()
                        session.send(
                            ControlMessage.Accept(
                                audioPort = description.audioPort,
                                videoPort = description.videoPort.takeIf { it > 0 },
                                audioSsrc = audioSsrcProvider(),
                                videoSsrc = description.videoPort.takeIf { it > 0 }
                                    ?.let { videoSsrcProvider() }
                            )
                        )
                    }

                    is ControlMessage.KeyframeRequest -> onKeyframeRequest()

                    is ControlMessage.BitrateRequest -> onBitrateRequest(message.videoKbps, message.audioKbps)

                    is ControlMessage.ModeRequest -> {
                        // A request, not a command. Whatever the broadcaster decides, the
                        // requester is told: replying with the authoritative mode answers
                        // the question either way, so a refused request is never silent.
                        onModeRequest(message.mode)
                        session.send(ControlMessage.ModeChanged(descriptionProvider().mode))
                    }

                    is ControlMessage.ReceiverStats -> onReceiverStats(message)

                    is ControlMessage.Bye -> break

                    else -> Unit
                }
            }
        } catch (e: Exception) {
            // Without this the failure is invisible: the session ends in `finally`, the
            // receiver sees only a closed socket, and the broadcast looks like a network
            // problem rather than a bug here.
            AppLog.error("ControlServer", "Control session with ${socket.inetAddress} failed: $e")
        } finally {
            sessions.remove(session)
            if (offeredAudio > 0) {
                onRemove(
                    socket.inetAddress,
                    offeredAudio,
                    if (offeredVideo > 0) offeredVideo else null
                )
            }
            // Graceful: anything already queued — a `deny`, a `bye` — is flushed first, and
            // the writer closes the socket once it is done with it.
            session.close()
            onReceiverDisconnected(name)
            AppLog.debug("ControlServer", "Receiver ${socket.inetAddress} disconnected")
        }
    }

    // ------------------------------------------------------------- outbound broadcasts

    fun sendModeChanged(mode: String) =
        broadcast(ControlMessage.ModeChanged(mode))

    fun sendStats(stats: ControlMessage.BroadcasterStats) =
        broadcast(stats)

    fun closeAll(reason: String) {
        broadcast(ControlMessage.Bye(reason))
        sessions.forEach { it.close() }
        sessions.clear()
    }

    fun close() {
        running.set(false)
        // Hard teardown: nothing queued is worth delivering once the broadcast is going
        // away, so the sockets are dropped rather than drained. Iterated over a snapshot, as
        // [broadcast] does: aborting a socket makes its session coroutine drop itself from the
        // list, and iterating the live list let that land mid-loop.
        val snapshot = synchronized(sessions) { ArrayList(sessions) }
        snapshot.forEach { it.abort() }
        sessions.clear()
        try {
            serverSocket?.close()
        } catch (e: IOException) {
            // Already closed.
        }
        serverSocket = null
        acceptJob?.cancel()
        acceptJob = null
        port = 0
    }

    private fun broadcast(message: ControlMessage) {
        val snapshot = synchronized(sessions) { ArrayList(sessions) }
        snapshot.forEach { it.send(message) }
    }

    /**
     * Answers a password attempt. The viewer has not been admitted at this point, so a wrong
     * password costs nothing but the round trip.
     */
    private fun checkPassword(supplied: String): ControlMessage.AuthResult =
        if (accessMode != ControlMessage.ACCESS_PASSWORD) {
            // Sent only in password mode. A viewer offering a password to an unlocked broadcast
            // has probably misread a welcome, and saying so is more useful than a bare refusal.
            ControlMessage.AuthResult(false, "This broadcast is not password protected.")
        } else if (accessPassword.isNotEmpty() && supplied == accessPassword) {
            ControlMessage.AuthResult(true)
        } else {
            // Reached both for a wrong password and while the presenter is still choosing one
            // ([holdForPassword] stores no password). Nothing is admitted either way.
            ControlMessage.AuthResult(false, "That password is not correct.")
        }

    /**
     * Records a rejection and refuses.
     *
     * The count is per address, so reconnecting on a new socket does not hand back the attempts
     * already spent. It goes away with the broadcast, not with the app.
     */
    private fun denyRejected(session: Session, address: InetAddress) {
        val count = (rejections[address] ?: 0) + 1
        rejections[address] = count
        if (count >= ControlMessage.MAX_REJECTIONS) {
            denyBlocked(session)
            return
        }
        val remaining = ControlMessage.MAX_REJECTIONS - count
        session.send(
            ControlMessage.Deny(
                ControlMessage.DENY_ACCESS,
                if (remaining == 1) {
                    "The broadcaster declined your request to watch. This is your last attempt."
                } else {
                    "The broadcaster declined your request to watch. $remaining attempts remaining."
                }
            )
        )
    }

    /**
     * The final refusal: over the limit, so the viewer is told not to try again and the
     * connection ends without offering a path back.
     */
    private fun denyBlocked(session: Session) {
        session.send(
            ControlMessage.Deny(
                ControlMessage.DENY_BLOCKED,
                "You have been blocked from this broadcast after " +
                    "${ControlMessage.MAX_REJECTIONS} rejected requests. " +
                    "Do not try again; the broadcaster rejected you."
            )
        )
    }

    /**
     * One receiver's connection. Writes are serialised so messages cannot interleave.
     */
    private class Session(private val socket: Socket) {
        private val outgoing = Channel<String>(Channel.BUFFERED)
        private var writerJob: Job? = null

        fun send(message: ControlMessage) {
            // trySend, not send: a full buffer must never block the broadcaster's caller,
            // which is often the encoder's frame callback. Control messages are small and
            // rare, so a dropped one under extreme load is preferable to stalling media.
            outgoing.trySend(message.toJson().toString() + "\n")
        }

        fun startWriter(scope: CoroutineScope) {
            writerJob = scope.launch(Dispatchers.IO) {
                val writer = socket.getOutputStream().bufferedWriter(Charsets.UTF_8)
                try {
                    // Closing the channel ends this loop only after every queued line has
                    // been written and flushed, so a final `bye` or `deny` is not lost.
                    for (line in outgoing) {
                        writer.write(line)
                        writer.flush()
                    }
                    writer.flush()
                } catch (e: IOException) {
                    // The receiver went away mid-write; the read loop will notice.
                } finally {
                    runCatching { writer.close() }
                    // The writer is the sole owner of the socket's lifetime. Anything else
                    // closing it concurrently would truncate a message mid-flush.
                    runCatching { socket.close() }
                }
            }
        }

        /** Graceful: lets queued messages flush before the socket goes away. */
        fun close() {
            outgoing.close()
        }

        /** Immediate: for teardown where the peer is already gone and nothing matters. */
        fun abort() {
            outgoing.close()
            writerJob?.cancel()
            try {
                socket.close()
            } catch (e: IOException) {
                // Already closed.
            }
        }
    }

    private companion object {
        /** How long to wait for an answer before checking whether the viewer is still there. */
        const val DecisionPollMs = 500L

        /** Read timeout for that check: long enough to read a byte that has arrived, no more. */
        const val DecisionProbeMs = 1
    }
}
