package com.localstream.engine

import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry

/**
 * A [LifecycleOwner] the engine can drive itself.
 *
 * CameraX requires one to bind to, and the engine is owned by the ViewModel rather than by
 * an Activity — so there is no component to borrow one from. Tying the camera to an
 * Activity's lifecycle would also mean the camera dies on every rotation, mid-broadcast.
 *
 * The owner is held in STARTED for as long as the engine is running and moved to DESTROYED
 * when it is torn down, which is the only transition CameraX actually acts on.
 */
class EngineLifecycleOwner : LifecycleOwner {

    private val registry = LifecycleRegistry(this).apply {
        currentState = Lifecycle.State.INITIALIZED
    }

    override val lifecycle: Lifecycle get() = registry

    fun start() {
        registry.currentState = Lifecycle.State.STARTED
    }

    fun stop() {
        registry.currentState = Lifecycle.State.DESTROYED
    }
}
