package com.localstream.ui

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.PowerManager
import android.provider.Settings
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver

/**
 * Battery optimisation, as Android sees it.
 *
 * A broadcast is a foreground service, which keeps it from being killed but not from being
 * frozen. While the screen is off the device dozes, and the encoder, the wake lock and the
 * sockets all stop making progress, so a viewer is left watching a picture that has stopped
 * moving while the presenter's phone sits in a pocket. Being exempt from battery optimisation
 * is what keeps a stream that nobody is looking at still running - and what keeps a viewer
 * waiting to be let in able to reach the presenter.
 *
 * The setting belongs to Android rather than to this app, so nothing here is stored and
 * nothing here is a preference: the state is read back from the platform, and every change is
 * made on a system screen the user is sent to. That is why the switch built on this is a
 * report of Android's state rather than a copy of it, and why it has to be re-read when the
 * user returns from that screen.
 */
object BatteryOptimization {

    /**
     * Whether Android has been asked to leave this app alone.
     *
     * False when the platform will not answer - no power service, or the query throws - because
     * "Android may put this app to sleep" is both the safe thing to tell someone and the state
     * the app is really in when the answer cannot be read.
     */
    fun isExempt(context: Context): Boolean = runCatching {
        val power = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
        power?.isIgnoringBatteryOptimizations(context.packageName) == true
    }.getOrDefault(false)

    /**
     * The system screen that asks for the exemption.
     *
     * This is the one screen that names this app directly rather than dropping the user in a
     * list, and it is only reachable because the manifest declares
     * `REQUEST_IGNORE_BATTERY_OPTIMIZATIONS`. Manufacturer builds that ship no such screen
     * resolve nothing for it, which is what the caller's fallback to [listIntent] is for.
     *
     * The lint rule silenced here is Google Play's acceptable-use policy for that permission,
     * not a defect in this code: an exemption may only be asked for when staying awake is the
     * app's core job, and a broadcast that dozes is a broadcast that has stopped for everyone
     * watching it. Play judges that at submission time; a build for a phone or a private
     * distribution is unaffected. The app asks rather than demands, so a phone that refuses
     * this screen still broadcasts, and the switch on the Help tab says what Android decided.
     */
    @SuppressLint("BatteryLife")
    fun requestIntent(context: Context): Intent =
        Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
            .setData(Uri.fromParts("package", context.packageName, null))

    /**
     * Android's list of every app that may still be optimised.
     *
     * The only route back: there is no intent that withdraws an exemption, so switching this
     * off has to hand the user the list and let them pick this app out of it.
     */
    fun listIntent(): Intent = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
}

/**
 * The exemption, kept current across a trip to a system screen.
 *
 * Read once when the screen appears and again on every resume, because the answer is only ever
 * changed somewhere else: the user leaves for Android's own screen, changes it, and comes back.
 * Without the second read the switch would still be showing the state from before they left,
 * which is the one thing a switch must never do.
 */
@Composable
fun rememberBatteryOptimizationExempt(): Boolean {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    var exempt by remember { mutableStateOf(BatteryOptimization.isExempt(context)) }

    DisposableEffect(lifecycleOwner, context) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                exempt = BatteryOptimization.isExempt(context)
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    return exempt
}
