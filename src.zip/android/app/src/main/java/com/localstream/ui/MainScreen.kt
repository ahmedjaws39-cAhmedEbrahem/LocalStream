package com.localstream.ui

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.view.WindowManager
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.PrimaryTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.localstream.R
import com.localstream.engine.BroadcastService
import com.localstream.engine.PlaybackEngine
import com.localstream.protocol.ControlMessage
import com.localstream.ui.theme.LocalStreamTheme

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LocalStreamApp(viewModel: MainViewModel) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val playback = viewModel.playback

    LocalStreamTheme {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.background
        ) {
            MainScreen(
                state = state,
                playback = playback,
                onTabChange = viewModel::setTab,
                onPrepareBroadcasting = viewModel::prepareBroadcasting,
                onStartBroadcast = viewModel::startBroadcast,
                onStopBroadcast = viewModel::stopBroadcast,
                onModeChange = viewModel::setMode,
                onAudioSourceChange = viewModel::setAudioSource,
                onVideoSourceChange = viewModel::setVideoSource,
                onVideoConfigChange = viewModel::setVideoConfig,
                onAudioBitrateChange = viewModel::setAudioBitrate,
                onNormalizeAudioChange = viewModel::setNormalizeAudio,
                onAccessChange = { mode ->
                    // A new mode takes the password that is already typed, so switching to
                    // "require a password" and typing straight away is one flow, not two.
                    viewModel.applyAccess(
                        mode,
                        if (mode == ControlMessage.ACCESS_PASSWORD) state.accessPassword else ""
                    )
                },
                onAccessPasswordChange = viewModel::setAccessPassword,
                onApplyAccessPassword = viewModel::applyAccessPassword,
                onConnect = viewModel::connect,
                onConnectManually = viewModel::connectManually,
                onDisconnect = viewModel::disconnect,
                onRescan = viewModel::rescan,
                onReceiveBufferChange = viewModel::setReceiveBufferMs,
                onSubmitPassword = viewModel::submitPassword,
                onCancelPassword = viewModel::cancelPasswordPrompt,
                onCancelAccessWait = viewModel::cancelAccessWait,
                onAccessRequestAnswer = viewModel::resolveAccessRequest,
                onRequestVideoKeyframe = viewModel::requestVideoKeyframe
            )
        }
    }
}

/**
 * Receives the service's stop request.
 *
 * A named class rather than an anonymous object, so the callback is stored once instead of
 * being captured on every recomposition of the enclosing screen.
 */
private class StopBroadcastReceiver(private val onStop: () -> Unit) : BroadcastReceiver() {
    override fun onReceive(context: Context?, intent: Intent?) {
        if (intent?.action == BroadcastService.ACTION_STOP_BROADCAST) onStop()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MainScreen(
    state: UiState,
    playback: PlaybackEngine,
    onTabChange: (MainTab) -> Unit,
    onPrepareBroadcasting: () -> Unit,
    onStartBroadcast: () -> Unit,
    onStopBroadcast: () -> Unit,
    onModeChange: (Boolean) -> Unit,
    onAudioSourceChange: (com.localstream.engine.AudioSource) -> Unit,
    onVideoSourceChange: (com.localstream.engine.VideoSource) -> Unit,
    onVideoConfigChange: (com.localstream.engine.VideoConfig) -> Unit,
    onAudioBitrateChange: (Int) -> Unit,
    onNormalizeAudioChange: (Boolean) -> Unit,
    onAccessChange: (String) -> Unit,
    onAccessPasswordChange: (String) -> Unit,
    onApplyAccessPassword: () -> Unit,
    onConnect: (com.localstream.net.DiscoveredStream) -> Unit,
    onConnectManually: (String, Int) -> Unit,
    onDisconnect: () -> Unit,
    onRescan: () -> Unit,
    onReceiveBufferChange: (Int) -> Unit,
    onSubmitPassword: (String) -> Unit,
    onCancelPassword: () -> Unit,
    onCancelAccessWait: () -> Unit,
    onAccessRequestAnswer: (Long, Boolean) -> Unit,
    onRequestVideoKeyframe: () -> Unit
) {
    var selectedTab by rememberSaveable { mutableIntStateOf(0) }
    val tabs = MainTab.entries

    // Fullscreen video. The flag is only meaningful while a video session is live, and everything
    // that ends the session - disconnecting, or the broadcaster dropping video - has to drop out
    // of fullscreen with it, or the next connection would open straight into it.
    var isFullscreen by rememberSaveable { mutableStateOf(false) }
    val fullscreenActive = isFullscreen && state.connectedKey != null && state.isReceivingVideo
    LaunchedEffect(fullscreenActive) {
        if (!fullscreenActive) isFullscreen = false
    }

    // Register for discovery and open the media sockets as soon as the app comes up, so a
    // viewer who opens the app while a broadcast is already running sees it immediately
    // rather than after a round trip through the UI.
    LaunchedEffect(Unit) {
        onPrepareBroadcasting()
    }

    // The stop action in the notification cannot reach the ViewModel directly, so the
    // service broadcasts this instead.
    val context = LocalContext.current
    val stopBroadcast = onStopBroadcast
    DisposableEffect(context) {
        val receiver = StopBroadcastReceiver { stopBroadcast() }
        val filter = IntentFilter(BroadcastService.ACTION_STOP_BROADCAST)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.registerReceiver(
                context,
                receiver,
                filter,
                ContextCompat.RECEIVER_NOT_EXPORTED
            )
        } else {
            @Suppress("UnspecifiedRegisterReceiverFlag")
            context.registerReceiver(receiver, filter)
        }
        onDispose { context.unregisterReceiver(receiver) }
    }

    // Immersive video while fullscreen: hide the system bars and keep the screen awake so a long
    // presentation does not dim out mid-frame. Both are restored the moment fullscreen ends and on
    // dispose, so no later screen inherits them.
    val view = LocalView.current
    DisposableEffect(fullscreenActive) {
        val window = (view.context as Activity).window
        val controller = WindowCompat.getInsetsController(window, view)
        if (fullscreenActive) {
            controller.systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            controller.hide(WindowInsetsCompat.Type.systemBars())
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        } else {
            controller.show(WindowInsetsCompat.Type.systemBars())
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
        onDispose {
            controller.show(WindowInsetsCompat.Type.systemBars())
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }

    // Back leaves fullscreen instead of the app. Enabled only while fullscreen, so it never
    // shadows the normal back behaviour.
    BackHandler(enabled = fullscreenActive) { isFullscreen = false }

    Box(Modifier.fillMaxSize()) {
        if (fullscreenActive) {
            // The picture takes the whole display, system bars and tabs included, exactly as a
            // video player's fullscreen does.
            VideoStage(
                playback = playback,
                isFullscreen = true,
                onToggleFullscreen = { isFullscreen = false },
                onSurfaceReady = onRequestVideoKeyframe,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            // Padded out of the system bars, which the window draws under (edge to edge). The
            // fullscreen video above deliberately skips this so the picture reaches the edges.
            Column(Modifier.fillMaxSize().safeDrawingPadding()) {
                PrimaryTabRow(selectedTabIndex = selectedTab) {
                    tabs.forEachIndexed { index, tab ->
                        val tabTitle = tab.localizedLabel()
                        val tabDescription = stringResource(R.string.cd_tab, tabTitle)
                        Tab(
                            selected = selectedTab == index,
                            onClick = {
                                selectedTab = index
                                onTabChange(tab)
                            },
                            modifier = Modifier.semantics {
                                contentDescription = tabDescription
                            },
                            text = {
                                Text(
                                    text = tabTitle,
                                    style = MaterialTheme.typography.titleMedium
                                )
                            }
                        )
                    }
                }

                Text(
                    text = tabs[selectedTab].localizedLabel(),
                    style = MaterialTheme.typography.headlineMedium,
                    modifier = Modifier
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                        .semantics { heading() }
                )

                when (tabs[selectedTab]) {
                    MainTab.BROADCAST -> BroadcasterScreen(
                        state = state,
                        onStart = onStartBroadcast,
                        onStop = onStopBroadcast,
                        onModeChange = onModeChange,
                        onAudioSourceChange = onAudioSourceChange,
                        onVideoSourceChange = onVideoSourceChange,
                        onVideoConfigChange = onVideoConfigChange,
                        onAudioBitrateChange = onAudioBitrateChange,
                        onNormalizeAudioChange = onNormalizeAudioChange,
                        onAccessChange = onAccessChange,
                        onAccessPasswordChange = onAccessPasswordChange,
                        onApplyAccessPassword = onApplyAccessPassword,
                        modifier = Modifier.fillMaxSize()
                    )

                    MainTab.RECEIVE -> ReceiverScreen(
                        state = state,
                        playback = playback,
                        onEnterFullscreen = { isFullscreen = true },
                        onVideoSurfaceReady = onRequestVideoKeyframe,
                        onConnect = onConnect,
                        onConnectManually = onConnectManually,
                        onDisconnect = onDisconnect,
                        onRescan = onRescan,
                        onReceiveBufferChange = onReceiveBufferChange,
                        onCancelAccessWait = onCancelAccessWait,
                        modifier = Modifier.fillMaxSize()
                    )

                    MainTab.HELP -> HelpScreen(
                        state = state,
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }
        }

        // Above the tabs, not inside either one. A viewer asking to watch is answered from
        // whichever screen the presenter happens to be on, and a presenter answering a password
        // prompt is by definition on the Receive tab; putting either dialog in a tab would mean
        // a request that goes unseen exactly when the app is busy.
        state.passwordPrompt?.let { prompt ->
            PasswordDialog(
                prompt = prompt,
                onSubmit = onSubmitPassword,
                onCancel = onCancelPassword
            )
        }

        state.accessRequest?.let { request ->
            AccessRequestDialog(
                request = request,
                onAnswer = { allow -> onAccessRequestAnswer(request.key, allow) }
            )
        }
    }
}

/**
 * The tab's name in the language the app is set to.
 *
 * The enum cannot hold a resource id and be useful to the ViewModel at the same time, so the
 * mapping lives here, next to the only code that puts a tab name on screen.
 */
@Composable
private fun MainTab.localizedLabel(): String = when (this) {
    MainTab.BROADCAST -> stringResource(R.string.tab_broadcast)
    MainTab.RECEIVE -> stringResource(R.string.tab_receive)
    MainTab.HELP -> stringResource(R.string.tab_help)
}
