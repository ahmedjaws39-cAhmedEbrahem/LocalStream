package com.localstream.ui

import android.os.Build
import androidx.annotation.StringRes
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.localstream.R
import com.localstream.engine.AudioSource
import com.localstream.engine.VideoConfig
import com.localstream.engine.VideoSource
import com.localstream.hapticsEnabled
import com.localstream.protocol.ControlMessage
import com.localstream.protocol.LocalStream
import com.localstream.ui.components.AnnouncementBanner
import com.localstream.ui.components.BroadcastModeSwitch
import com.localstream.ui.components.LabelledSlider
import com.localstream.ui.components.LabelledSwitch
import com.localstream.ui.components.LabelledValue
import com.localstream.ui.components.MinTouchTarget
import com.localstream.ui.components.SectionHeading
import com.localstream.ui.components.StatusDot
import kotlin.math.roundToInt

/**
 * The broadcaster tab.
 *
 * Layout rules applied throughout:
 *  - every control is at least [MinTouchTarget] tall and has a spoken name;
 *  - every value is either a text label or carries a `contentDescription`, never both;
 *  - a setting that changes what the user will *hear* also announces its new state, so a
 *    screen-reader user does not have to swipe back to confirm the change took effect.
 */
@Composable
fun BroadcasterScreen(
    state: UiState,
    onStart: () -> Unit,
    onStop: () -> Unit,
    onModeChange: (Boolean) -> Unit,
    onAudioSourceChange: (AudioSource) -> Unit,
    onVideoSourceChange: (VideoSource) -> Unit,
    onVideoConfigChange: (VideoConfig) -> Unit,
    onAudioBitrateChange: (Int) -> Unit,
    onNormalizeAudioChange: (Boolean) -> Unit,
    onAccessChange: (String) -> Unit,
    onAccessPasswordChange: (String) -> Unit,
    onApplyAccessPassword: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(vertical = 8.dp)
    ) {
        AnnouncementBanner(
            message = state.announcement,
            isError = state.announcementIsError
        )

        SectionHeading(stringResource(R.string.broadcast_status_heading))

        StatusCard(state)

        Spacer(Modifier.height(8.dp))

        // ------------------------------------------------------------- the main control
        // One buzz for the app's most consequential action, and none when a screen reader is
        // running: TalkBack treats touch feedback as an event of its own, so `hapticsEnabled`
        // (cleared in LocalStreamApp when touch exploration is on) is what keeps both off.
        val haptics = LocalHapticFeedback.current
        val stopBroadcastingDescription = stringResource(R.string.cd_stop_broadcasting)
        val startBroadcastDescription = stringResource(R.string.broadcast_start)
        if (state.isBroadcasting) {
            Button(
                onClick = {
                    if (hapticsEnabled) {
                        haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                    }
                    onStop()
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .heightIn(min = 64.dp)
                    .semantics {
                        role = Role.Button
                        contentDescription = stopBroadcastingDescription
                    },
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.error,
                    contentColor = MaterialTheme.colorScheme.onError
                )
            ) {
                Icon(Icons.Filled.Stop, contentDescription = null, modifier = Modifier.size(28.dp))
                Spacer(Modifier.width(12.dp))
                Text(
                    stringResource(R.string.broadcast_stop),
                    style = MaterialTheme.typography.titleMedium
                )
            }
        } else {
            Button(
                onClick = {
                    if (hapticsEnabled) {
                        haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                    }
                    onStart()
                },
                enabled = state.isAdvertising,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .heightIn(min = 64.dp)
                    .semantics {
                        role = Role.Button
                        contentDescription = startBroadcastDescription
                    }
            ) {
                Icon(Icons.Filled.Videocam, contentDescription = null, modifier = Modifier.size(28.dp))
                Spacer(Modifier.width(12.dp))
                Text(
                    stringResource(R.string.broadcast_start),
                    style = MaterialTheme.typography.titleMedium
                )
            }
        }

        // `isAdvertising` means "advertised while idle", which is deliberately false during a
        // broadcast, so gating on it alone made this hint appear over a live broadcast. It is a
        // starting-up message and belongs only to the window before either state is true.
        if (!state.isAdvertising && !state.isBroadcasting) {
            Text(
                text = stringResource(R.string.broadcast_preparing),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .semantics { liveRegion = LiveRegionMode.Polite }
            )
        }

        Spacer(Modifier.height(16.dp))
        SectionHeading(stringResource(R.string.broadcast_mode_heading))

        BroadcastModeSwitch(
            audioAndVideo = state.mode == LocalStream.MODE_AUDIO_VIDEO,
            onChange = onModeChange,
            enabled = !state.isBroadcasting || state.videoSource == VideoSource.CAMERA
        )

        Text(
            text = if (state.isBroadcasting) {
                stringResource(R.string.broadcast_mode_locked_hint)
            } else {
                stringResource(R.string.broadcast_mode_changeable_hint)
            },
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 16.dp)
        )

        Spacer(Modifier.height(16.dp))
        SectionHeading(stringResource(R.string.access_section_heading))

        AccessSection(
            mode = state.accessMode,
            password = state.accessPassword,
            pending = state.accessPending,
            onModeChange = onAccessChange,
            onPasswordChange = onAccessPasswordChange,
            onApplyPassword = onApplyAccessPassword
        )

        Spacer(Modifier.height(16.dp))
        SectionHeading(stringResource(R.string.broadcast_audio_source))
        AudioSourcePicker(
            selected = state.audioSource,
            enabled = !state.isBroadcasting,
            onSelect = onAudioSourceChange
        )

        Spacer(Modifier.height(16.dp))
        SectionHeading(stringResource(R.string.broadcast_audio_level))
        LabelledSwitch(
            label = stringResource(R.string.broadcast_normalize_audio),
            checked = state.normalizeAudio,
            enabled = !state.isBroadcasting,
            onCheckedChange = onNormalizeAudioChange,
            description = stringResource(R.string.broadcast_normalize_audio_description),
            // Without this TalkBack says only "on", which is the switch state and not the
            // consequence. The state names the behaviour that follows, the way
            // BroadcastModeSwitch names the mode instead of the switch.
            stateDescription = if (state.normalizeAudio) {
                stringResource(R.string.broadcast_normalize_audio_state_steady)
            } else {
                stringResource(R.string.broadcast_normalize_audio_state_source)
            }
        )

        if (state.mode == LocalStream.MODE_AUDIO_VIDEO) {
            Spacer(Modifier.height(16.dp))
            SectionHeading(stringResource(R.string.broadcast_video_source))
            VideoSourcePicker(
                selected = state.videoSource,
                enabled = !state.isBroadcasting,
                onSelect = onVideoSourceChange
            )

            Spacer(Modifier.height(16.dp))
            SectionHeading(stringResource(R.string.broadcast_quality_heading))
            QualityControls(
                config = state.videoConfig,
                audioBitrateKbps = state.audioBitrateKbps,
                onVideoConfigChange = onVideoConfigChange,
                onAudioBitrateChange = onAudioBitrateChange
            )
        }
    }
}

/**
 * Who may watch: anyone, ask first, or a password.
 *
 * Real radio buttons rather than the faux ones elsewhere on this screen, because each option
 * changes what a viewer will be able to do and the choice has to be announced as a selection,
 * not as a button press that may or may not have worked.
 *
 * The three options are applied the moment they are chosen - there is no mode to confirm -
 * because leaving a pending choice next to a live broadcast would be indistinguishable from
 * applying it. The password is the exception: it needs a field and a deliberate act, so it is
 * offered as its own control with the reason a change is needed.
 */
@Composable
private fun AccessSection(
    mode: String,
    password: String,
    pending: Boolean,
    onModeChange: (String) -> Unit,
    onPasswordChange: (String) -> Unit,
    onApplyPassword: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
    ) {
        ACCESS_OPTIONS.forEach { option ->
            val isSelected = option.mode == mode
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = MinTouchTarget)
                    .selectable(
                        selected = isSelected,
                        role = Role.RadioButton,
                        onClick = { onModeChange(option.mode) }
                    )
                    .padding(vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                RadioButton(selected = isSelected, onClick = null)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        stringResource(option.titleRes),
                        style = MaterialTheme.typography.bodyLarge
                    )
                    Text(
                        text = stringResource(option.explanationRes),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        if (mode == ControlMessage.ACCESS_PASSWORD) {
            Spacer(Modifier.height(8.dp))

            val length = password.length
            val complete = ControlMessage.isValidPassword(password)
            val passwordProgressDescription = stringResource(
                R.string.cd_access_password_progress,
                length,
                ControlMessage.PASSWORD_MAX_LENGTH
            )
            OutlinedTextField(
                value = password,
                onValueChange = { typed ->
                    // Capped as you type rather than after it: a password that cannot be used
                    // should not be typeable, and silently dropping the extra characters is
                    // kinder than accepting a value that is then refused.
                    if (typed.length <= ControlMessage.PASSWORD_MAX_LENGTH) {
                        onPasswordChange(typed)
                    }
                },
                label = { Text(stringResource(R.string.access_password_field_label)) },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                isError = length > 0 && !complete,
                supportingText = {
                    Text(
                        text = when {
                            length == 0 ->
                                stringResource(
                                    R.string.access_password_length_range,
                                    ControlMessage.PASSWORD_MIN_LENGTH,
                                    ControlMessage.PASSWORD_MAX_LENGTH
                                )
                            complete -> stringResource(R.string.access_password_ready)
                            else -> stringResource(
                                R.string.access_password_too_short,
                                ControlMessage.PASSWORD_MIN_LENGTH
                            )
                        }
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = MinTouchTarget)
                    // The field is cleared once the broadcast has the password, so its own value
                    // must never be its accessible name or the label would read as blank.
                    .semantics {
                        contentDescription = passwordProgressDescription
                    }
            )

            if (mode == ControlMessage.ACCESS_PASSWORD) {
                Spacer(Modifier.height(8.dp))
                val applyPasswordDescription = stringResource(R.string.cd_access_password_apply)
                Button(
                    onClick = onApplyPassword,
                    enabled = complete,
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = MinTouchTarget)
                        .semantics {
                            role = Role.Button
                            contentDescription = applyPasswordDescription
                        }
                ) {
                    Text(stringResource(R.string.access_use_password))
                }
            }

            Text(
                text = if (pending) {
                    stringResource(R.string.access_password_pending_hint)
                } else {
                    stringResource(R.string.access_password_applied_hint)
                },
                style = MaterialTheme.typography.bodyMedium,
                color = if (pending) {
                    MaterialTheme.colorScheme.error
                } else {
                    MaterialTheme.colorScheme.onSurfaceVariant
                },
                modifier = Modifier.padding(top = 8.dp)
            )
        }
    }
}

/** One access option, with the sentence that explains what a viewer will meet. */
private data class AccessOption(
    val mode: String,
    @StringRes val titleRes: Int,
    @StringRes val explanationRes: Int
)

private val ACCESS_OPTIONS = listOf(
    AccessOption(
        ControlMessage.ACCESS_PUBLIC,
        R.string.access_option_public_title,
        R.string.access_option_public_explanation
    ),
    AccessOption(
        ControlMessage.ACCESS_APPROVAL,
        R.string.access_option_approval_title,
        R.string.access_option_approval_explanation
    ),
    AccessOption(
        ControlMessage.ACCESS_PASSWORD,
        R.string.access_option_password_title,
        R.string.access_option_password_explanation
    )
)

@Composable
private fun StatusCard(state: UiState) {
    val broadcastingText = stringResource(
        if (state.isBroadcasting) R.string.broadcast_status_broadcasting
        else R.string.broadcast_status_not_broadcasting
    )
    val receiversText = stringResource(
        if (state.receiverCount == 1) R.string.cd_receiver_one else R.string.cd_receivers_many
    )
    val modeText = stringResource(
        if (state.mode == LocalStream.MODE_AUDIO_ONLY) R.string.broadcast_mode_audio_only_lowercase
        else R.string.broadcast_mode_audio_video_lowercase
    )
    val statusDescription = if (state.controlPort > 0) {
        stringResource(
            R.string.cd_status_card_control_port,
            broadcastingText,
            state.receiverCount,
            receiversText,
            modeText,
            state.controlPort
        )
    } else {
        stringResource(
            R.string.cd_status_card,
            broadcastingText,
            state.receiverCount,
            receiversText,
            modeText
        )
    }
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .semantics(mergeDescendants = true) {
                // One node for the whole card, so it is read as a sentence instead of five
                // fragments. The control port is folded in because this description *replaces*
                // the children's text: without it a screen reader would never hear the one
                // number a viewer who cannot find the broadcast has to type.
                contentDescription = statusDescription
                liveRegion = LiveRegionMode.Polite
            }
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            StatusDot(live = state.isBroadcasting)
            Spacer(Modifier.width(12.dp))
            Text(
                text = if (state.isBroadcasting) {
                    stringResource(R.string.broadcast_status_broadcasting)
                } else {
                    stringResource(R.string.broadcast_status_ready)
                },
                style = MaterialTheme.typography.titleLarge
            )
        }
        LabelledValue(stringResource(R.string.broadcast_receivers), state.receiverCount.toString())
        LabelledValue(
            label = stringResource(R.string.broadcast_mode_heading),
            value = if (state.mode == LocalStream.MODE_AUDIO_ONLY) {
                stringResource(R.string.broadcast_mode_audio_only)
            } else {
                stringResource(R.string.broadcast_mode_audio_video)
            }
        )
        LabelledValue(stringResource(R.string.broadcast_device_name), state.deviceName)

        // Shown only once there is a port to show, and phrased as the fallback it is: a viewer
        // who cannot see this broadcast listed needs the address and the port to type in by hand.
        if (state.controlPort > 0) {
            Text(
                text = stringResource(R.string.broadcast_control_port_hint, state.controlPort),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
            )
        }
    }
}

/**
 * Camera versus screen.
 *
 * Each option is a radio button as far as a screen reader is concerned: it carries
 * `Role.RadioButton` and a `stateDescription`, so which one is selected is announced on focus
 * and again on activation. The visible label is left as the node's name - a `contentDescription`
 * here would have been read *instead* of "Screen"/"Camera", hiding the very word the user can
 * see, which is exactly the label-in-name failure the button is meant to avoid.
 */
@Composable
private fun VideoSourcePicker(
    selected: VideoSource,
    enabled: Boolean,
    onSelect: (VideoSource) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
    ) {
        VideoSource.entries.forEach { source ->
            val isSelected = source == selected
            val selectionState = stringResource(
                if (isSelected) R.string.cd_selected else R.string.cd_not_selected
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = MinTouchTarget)
                    .padding(vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                FilledTonalButton(
                    onClick = { onSelect(source) },
                    enabled = enabled,
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = MinTouchTarget)
                        .semantics {
                            role = Role.RadioButton
                            stateDescription = selectionState
                        }
                ) {
                    Text(
                        text = if (isSelected) "● " else "○ ",
                        style = MaterialTheme.typography.titleMedium
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = if (source == VideoSource.SCREEN) {
                            stringResource(R.string.broadcast_source_screen)
                        } else {
                            stringResource(R.string.broadcast_source_camera)
                        },
                        style = MaterialTheme.typography.bodyLarge
                    )
                }
            }
        }
    }
}

/**
 * Microphone versus the device's own sound.
 *
 * Real radio buttons rather than the faux ones the video picker uses, because the second
 * option is unavailable below Android 10 and a disabled radio button communicates that far
 * better than a greyed-out button with a spoken caveat. Each row is `selectable`, so a screen
 * reader announces the role and whether the option is currently checked.
 */
@Composable
private fun AudioSourcePicker(
    selected: AudioSource,
    enabled: Boolean,
    onSelect: (AudioSource) -> Unit
) {
    val deviceAudioSupported = Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
    ) {
        AudioSource.entries.forEach { source ->
            val isSelected = source == selected
            val canSelect = enabled &&
                (source == AudioSource.MICROPHONE || deviceAudioSupported)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = MinTouchTarget)
                    .selectable(
                        selected = isSelected,
                        enabled = canSelect,
                        role = Role.RadioButton,
                        onClick = { onSelect(source) }
                    )
                    .padding(vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                RadioButton(selected = isSelected, onClick = null, enabled = canSelect)
                Spacer(Modifier.width(12.dp))
                Text(
                    text = if (source == AudioSource.MICROPHONE) {
                        stringResource(R.string.broadcast_source_microphone)
                    } else {
                        stringResource(R.string.broadcast_source_device_audio)
                    },
                    style = MaterialTheme.typography.bodyLarge
                )
            }
        }

        if (!deviceAudioSupported) {
            Text(
                text = stringResource(R.string.broadcast_device_audio_unsupported),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(vertical = 4.dp)
            )
        }
    }
}

@Composable
private fun QualityControls(
    config: VideoConfig,
    audioBitrateKbps: Int,
    onVideoConfigChange: (VideoConfig) -> Unit,
    onAudioBitrateChange: (Int) -> Unit
) {
    Column(Modifier.padding(horizontal = 16.dp)) {
        LabelledValue(
            label = stringResource(R.string.broadcast_video_quality),
            value = stringResource(
                R.string.broadcast_video_quality_value,
                config.width,
                config.height,
                config.frameRate,
                config.bitrateKbps
            )
        )
        LabelledValue(
            label = stringResource(R.string.broadcast_audio_quality),
            value = stringResource(R.string.broadcast_bitrate_value, audioBitrateKbps)
        )

        Spacer(Modifier.height(8.dp))

        LabelledSlider(
            label = stringResource(R.string.broadcast_video_bitrate),
            valueLabel = stringResource(R.string.broadcast_bitrate_value, config.bitrateKbps),
            value = config.bitrateKbps.toFloat(),
            range = 200f..4000f,
            steps = 18,
            onChange = { onVideoConfigChange(config.copy(bitrateKbps = it.roundToInt())) }
        )

        LabelledSlider(
            label = stringResource(R.string.broadcast_audio_bitrate),
            valueLabel = stringResource(R.string.broadcast_bitrate_value, audioBitrateKbps),
            value = audioBitrateKbps.toFloat(),
            range = 16f..128f,
            steps = 7,
            onChange = { onAudioBitrateChange(it.roundToInt()) }
        )

        LabelledSlider(
            label = stringResource(R.string.broadcast_video_framerate),
            valueLabel = stringResource(R.string.broadcast_framerate_value, config.frameRate),
            value = config.frameRate.toFloat(),
            range = 10f..60f,
            steps = 9,
            onChange = { onVideoConfigChange(config.copy(frameRate = it.roundToInt())) }
        )
    }
}
