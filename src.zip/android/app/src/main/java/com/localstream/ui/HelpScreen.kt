package com.localstream.ui

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import androidx.annotation.StringRes
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import com.localstream.BuildConfig
import com.localstream.R
import com.localstream.logging.AppLog
import com.localstream.ui.components.AnnouncementBanner
import com.localstream.ui.components.LabelledSlider
import com.localstream.ui.components.LabelledSwitch
import com.localstream.ui.components.MinTouchTarget
import com.localstream.ui.components.SectionHeading
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.net.InetAddress
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

/**
 * The help tab: the tutorial, the log settings, and a report to send on with a question.
 *
 * The same two jobs the Windows help page does, with the same words for them, because someone
 * who has read one of the two apps should not have to learn the other from scratch. Where a
 * platform genuinely differs - Windows opens a folder in Explorer, Android has no such thing -
 * the button keeps its name and does the nearest thing that works, and says what it did.
 *
 * Settings are applied the moment they are changed and written to disk by
 * [AppLog.setSettings], so there is no Save button whose absence could be read as "the changes
 * were thrown away".
 */
@Composable
fun HelpScreen(
    state: UiState,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var settings by remember { mutableStateOf(AppLog.settings()) }
    var status by rememberSaveable { mutableStateOf("") }
    var statusIsError by rememberSaveable { mutableStateOf(false) }

    // Shown before anything is written, so a reader who only wants to know where these files
    // will end up is not left holding a copy they never asked for.
    val tutorialPath = remember { tutorialFile(context).absolutePath }
    val logFolder = remember { AppLog.directory()?.absolutePath.orEmpty() }
    val reportsFolder = remember { reportsDirectory(context).absolutePath }

    // Read from the platform, and re-read every time this screen resumes: the exemption can
    // only be changed on a system screen, which means leaving the app and coming back.
    val batteryExempt = rememberBatteryOptimizationExempt()

    fun apply(next: AppLog.Settings) {
        settings = next
        AppLog.setSettings(context, next)
    }

    fun report(message: String, isError: Boolean = false) {
        status = message
        statusIsError = isError
    }

    fun openTutorial(context: Context) {
        val uri = runCatching {
            val file = tutorialFile(context)
            // The page that matches the chosen language, so somebody reading the app in Arabic
            // is not handed the English one. AppLanguage falls back to the English asset when a
            // language has no page.
            context.assets.open(AppLanguage.tutorialAsset(context)).use { input ->
                file.outputStream().use { output -> input.copyTo(output) }
            }
            FileProvider.getUriForFile(context, fileProviderAuthority(context), file)
        }.getOrElse { error ->
            report(
                context.getString(
                    R.string.help_tutorial_copy_failed,
                    error.message ?: error::class.java.simpleName
                ),
                isError = true
            )
            return
        }

        try {
            context.startActivity(
                Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(uri, HTML_MIME)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
            )
            report(context.getString(R.string.help_tutorial_opening))
        } catch (notFound: ActivityNotFoundException) {
            // No browser, or one that refuses this file type. Handing it to a chooser is the
            // only way left to get the page in front of the user, and the share sheet is
            // something every device has.
            val refusal = sendFiles(
                context,
                listOf(uri),
                HTML_MIME,
                context.getString(R.string.help_send_tutorial)
            )
            report(
                refusal ?: context.getString(R.string.help_no_tutorial_viewer, tutorialPath),
                refusal != null
            )
        }
    }

    fun saveReport(context: Context) {
        report(context.getString(R.string.help_writing_report))
        scope.launch {
            val outcome = withContext(Dispatchers.IO) { runCatching { writeReport(context) } }
            outcome.onSuccess { written ->
                AppLog.info("HelpScreen", "report.saved ${written.file.name}")
                report(
                    context.getString(
                        R.string.help_report_saved,
                        written.file.absolutePath,
                        written.bytes / 1024,
                        written.filesUsed.size
                    )
                )
            }.onFailure { error ->
                AppLog.error("HelpScreen", "report.write failed: ${error.message}")
                report(
                    context.getString(
                        R.string.help_report_save_failed,
                        error.message ?: error::class.java.simpleName
                    ),
                    isError = true
                )
            }
        }
    }

    fun openFolder(context: Context, folder: File?, label: String, mimeType: String) {
        if (folder == null || !folder.exists()) {
            report(
                context.getString(
                    R.string.help_no_folder_yet,
                    label,
                    folder?.let { ": ${it.absolutePath}" } ?: ""
                )
            )
            return
        }
        val files = folder.listFiles()
            ?.sortedByDescending { it.lastModified() }
            ?.take(MAX_SHARED_FILES)
            .orEmpty()
        if (files.isEmpty()) {
            report(
                context.getString(
                    R.string.help_no_files_in_folder,
                    label,
                    folder.absolutePath
                )
            )
            return
        }
        val uris = files.map {
            FileProvider.getUriForFile(context, fileProviderAuthority(context), it)
        }
        val refusal = sendFiles(
            context,
            uris,
            mimeType,
            context.getString(R.string.help_send_folder_files, label)
        )
        report(
            refusal ?: context.getString(
                R.string.help_sharing_files,
                files.size,
                label,
                folder.absolutePath
            ),
            refusal != null
        )
    }

    /**
     * Opens a battery settings screen.
     *
     * @return true once it is up, false when this device will not show it, so the caller can
     *         fall through to the next screen rather than leaving the switch lying about what
     *         happened. A manufacturer build that has replaced the settings app can refuse the
     *         request screen with no activity at all or with a security refusal; both mean the
     *         same thing here, and both are recorded, because a device that refuses them is
     *         otherwise invisible in a report.
     */
    fun openBatteryScreen(intent: Intent): Boolean {
        return try {
            context.startActivity(intent)
            true
        } catch (absent: ActivityNotFoundException) {
            AppLog.info("HelpScreen", "battery screen absent on this device")
            false
        } catch (refused: SecurityException) {
            AppLog.warning("HelpScreen", "battery screen refused: ${refused.message}")
            false
        }
    }

    /**
     * Sends the user to a system screen that changes the exemption.
     *
     * Nothing is stored: the setting is Android's, so both answers are a trip to a system
     * screen, and the switch is corrected from the platform when the user comes back rather
     * than being moved here. Moving it here would show the answer the app hoped for instead of
     * the one Android actually gave.
     *
     * Asking has a screen of its own that names this app; undoing it does not, so clearing the
     * box opens the full list. Some manufacturer builds resolve neither, which is the case the
     * last line is for.
     */
    fun changeBatteryExemption(context: Context, wanted: Boolean) {
        if (wanted && openBatteryScreen(BatteryOptimization.requestIntent(context))) {
            report(context.getString(R.string.help_battery_asking))
            return
        }

        if (openBatteryScreen(BatteryOptimization.listIntent())) {
            report(
                if (wanted) {
                    context.getString(R.string.help_battery_pick_keep)
                } else {
                    context.getString(R.string.help_battery_pick_sleep)
                }
            )
            return
        }

        report(context.getString(R.string.help_battery_no_screen), isError = true)
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(vertical = 8.dp)
    ) {
        // The Help screen's own message wins while there is one: it is the answer to the press
        // the user has just made, and an older announcement from the streaming session would
        // bury it.
        val bannerMessage = status.ifEmpty { state.announcement }
        val bannerIsError = if (status.isEmpty()) state.announcementIsError else statusIsError
        AnnouncementBanner(message = bannerMessage, isError = bannerIsError)

        SectionHeading(stringResource(R.string.help_tutorial_heading))

        Text(
            text = stringResource(R.string.help_tutorial_body),
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.padding(horizontal = 16.dp)
        )

        // Hoisted: a modifier chain is an ordinary lambda and cannot read a resource itself.
        val tutorialButtonDescription = stringResource(R.string.help_cd_open_tutorial)

        Button(
            onClick = { openTutorial(context) },
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp)
                .heightIn(min = MinTouchTarget)
                .semantics { contentDescription = tutorialButtonDescription }
        ) {
            Text(stringResource(R.string.help_open_tutorial))
        }

        Text(
            text = stringResource(R.string.help_tutorial_stored_body),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 16.dp)
        )

        PathText(stringResource(R.string.help_tutorial_file_label), tutorialPath)

        Spacer(Modifier.height(8.dp))
        SectionHeading(stringResource(R.string.help_contents_heading))

        // Plain text with bullet characters rather than rich text: a screen reader reads the
        // list in order either way, and this cannot turn a stray character into markup.
        Text(
            text = stringResource(R.string.help_contents_body),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 16.dp)
        )

        Spacer(Modifier.height(8.dp))
        SectionHeading(stringResource(R.string.help_background_heading))

        Text(
            text = stringResource(R.string.help_background_body),
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.padding(horizontal = 16.dp)
        )

        LabelledSwitch(
            label = stringResource(R.string.help_ignore_battery),
            description = stringResource(R.string.help_ignore_battery_description),
            checked = batteryExempt,
            onCheckedChange = { wanted -> changeBatteryExemption(context, wanted) },
            stateDescription = if (batteryExempt) {
                stringResource(R.string.help_battery_exempt_state)
            } else {
                stringResource(R.string.help_battery_sleep_state)
            },
            modifier = Modifier.padding(horizontal = 16.dp)
        )

        Spacer(Modifier.height(8.dp))
        SectionHeading(stringResource(R.string.help_logs_heading))

        Text(
            text = stringResource(R.string.help_logs_body),
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.padding(horizontal = 16.dp)
        )

        Spacer(Modifier.height(8.dp))

        // The recording switch comes before anything that shapes the log: every other control
        // here decides what the log contains, and none of that matters while nothing is
        // being written.
        LabelledSwitch(
            label = stringResource(R.string.help_record_automatically),
            description = stringResource(R.string.help_record_automatically_description),
            checked = settings.recordAutomatically,
            onCheckedChange = { apply(settings.copy(recordAutomatically = it)) },
            stateDescription = if (settings.recordAutomatically) {
                stringResource(R.string.help_recording_state)
            } else {
                stringResource(R.string.help_not_recording_state)
            },
            modifier = Modifier.padding(horizontal = 16.dp)
        )

        MinimumLevelPicker(
            selected = settings.minimumLevel,
            onSelect = { apply(settings.copy(minimumLevel = it)) },
            modifier = Modifier.padding(horizontal = 16.dp)
        )

        LabelledSwitch(
            label = stringResource(R.string.help_include_milliseconds),
            description = stringResource(R.string.help_include_milliseconds_description),
            checked = settings.milliseconds,
            onCheckedChange = { apply(settings.copy(milliseconds = it)) },
            modifier = Modifier.padding(horizontal = 16.dp)
        )

        ClockFormatPicker(
            twelveHour = settings.twelveHourClock,
            onSelect = { apply(settings.copy(twelveHourClock = it)) },
            modifier = Modifier.padding(horizontal = 16.dp)
        )

        LabelledSlider(
            label = stringResource(R.string.help_keep_log_files),
            valueLabel = stringResource(R.string.help_days_value, settings.keepDays),
            value = settings.keepDays.toFloat(),
            range = MIN_KEEP_DAYS.toFloat()..MAX_KEEP_DAYS.toFloat(),
            steps = 0,
            onChange = { apply(settings.copy(keepDays = it.roundToInt())) },
            modifier = Modifier.padding(horizontal = 16.dp)
        )

        LabelledSlider(
            label = stringResource(R.string.help_max_size_per_day),
            valueLabel = stringResource(R.string.help_mib_value, settings.maxFileSizeMiB),
            value = settings.maxFileSizeMiB.toFloat(),
            range = MIN_FILE_SIZE_MIB.toFloat()..MAX_FILE_SIZE_MIB.toFloat(),
            steps = 0,
            onChange = { apply(settings.copy(maxFileSizeMiB = it.roundToInt())) },
            modifier = Modifier.padding(horizontal = 16.dp)
        )

        Spacer(Modifier.height(8.dp))

        SectionHeading(stringResource(R.string.help_language_heading))

        Text(
            text = stringResource(R.string.help_language_hint),
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.padding(horizontal = 16.dp)
        )

        LanguagePicker(
            context = context,
            onChosen = { code ->
                AppLanguage.setPreferred(context, code)
                // Rebuild the activity rather than restarting the app: a broadcast in progress
                // lives in the service and is untouched, so the picture does not blink.
                context.findActivity()?.recreate()
            }
        )

        Spacer(Modifier.height(8.dp))

        // Read here rather than inside the click handlers: the handlers are not composable, so
        // they would have to take the words from the context rather than from the resources of
        // the composition.
        val logLabel = stringResource(R.string.help_log_label)
        val reportLabel = stringResource(R.string.help_report_label)

        // Hoisted: a modifier chain is an ordinary lambda and cannot read a resource itself.
        val saveReportDescription = stringResource(R.string.help_save_report)
        val logFolderDescription = stringResource(R.string.help_open_log_folder)
        val reportsFolderDescription = stringResource(R.string.help_open_reports_folder)

        Column(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = { saveReport(context) },
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = MinTouchTarget)
                    .semantics { contentDescription = saveReportDescription }
            ) {
                Text(stringResource(R.string.help_save_report))
            }
            OutlinedButton(
                onClick = { openFolder(context, AppLog.directory(), logLabel, LOG_MIME) },
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = MinTouchTarget)
                    .semantics { contentDescription = logFolderDescription }
            ) {
                Text(stringResource(R.string.help_open_log_folder))
            }
            OutlinedButton(
                onClick = {
                    openFolder(context, reportsDirectory(context), reportLabel, TEXT_MIME)
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = MinTouchTarget)
                    .semantics { contentDescription = reportsFolderDescription }
            ) {
                Text(stringResource(R.string.help_open_reports_folder))
            }
        }

        Text(
            text = stringResource(R.string.help_report_body),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
        )

        // The file list matters as much as the path: it says which logs actually went in,
        // which is the difference between a report that describes the failure and one that
        // quietly has none.
        PathText(
            stringResource(R.string.help_log_folder_label),
            logFolder.ifEmpty { stringResource(R.string.help_no_log_folder_yet) }
        )
        PathText(stringResource(R.string.help_reports_folder_label), reportsFolder)
    }
}

/**
 * A path the user may need to type somewhere.
 *
 * No accessible name: the label's own text is the path, and a name here would be read
 * *instead* of it. "Log folder" is the kind of sentence that tells a screen-reader user
 * nothing they cannot see, and it would hide the part they need. Selectable, because the one
 * thing done with a report path is put it in a message.
 */
@Composable
private fun PathText(label: String, path: String) {
    Column(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        SelectionContainer {
            Text(
                text = path,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

/**
 * The language picker.
 *
 * Chips, one per language, with the system option first so it is the one a person gets without
 * choosing anything. Every chip carries the language's own name rather than the English name of
 * it, because somebody looking for their language looks for *Français*, not for *French*.
 *
 * The current choice is marked with `selected`, which is what a screen reader announces, and the
 * whole row is described as a group so it is read as one control rather than six loose labels.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun LanguagePicker(context: Context, onChosen: (String) -> Unit) {
    val current = AppLanguage.preferred(context)
    val systemLabel = when (val language = Locale.getDefault().language) {
        "en" -> stringResource(R.string.help_language_system, "English")
        "ar" -> stringResource(R.string.help_language_system, "العربية")
        "fr" -> stringResource(R.string.help_language_system, "Français")
        "ru" -> stringResource(R.string.help_language_system, "Русский")
        "tr" -> stringResource(R.string.help_language_system, "Türkçe")
        else -> stringResource(R.string.help_language_system, language)
    }

    FlowRow(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        FilterChip(
            selected = current == AppLanguage.SYSTEM,
            onClick = { onChosen(AppLanguage.SYSTEM) },
            label = { Text(systemLabel) },
            modifier = Modifier.heightIn(min = MinTouchTarget)
        )
        for (language in AppLanguage.available) {
            FilterChip(
                selected = current == language.code,
                onClick = { onChosen(language.code) },
                label = { Text(language.nativeName) },
                modifier = Modifier.heightIn(min = MinTouchTarget)
            )
        }
    }
}

/**
 * Which lines the log keeps.
 *
 * Chips rather than radio buttons, because the four options fit on one scrollable line and
 * the whole screen is already tall. Each chip still reports whether it is selected.
 */
@Composable
private fun MinimumLevelPicker(
    selected: AppLog.Level,
    onSelect: (AppLog.Level) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier.fillMaxWidth().padding(vertical = 8.dp)) {
        Text(
            stringResource(R.string.help_record_from_level),
            style = MaterialTheme.typography.bodyLarge
        )
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            LEVEL_OPTIONS.forEach { level ->
                val recordFromDescription =
                    stringResource(R.string.help_record_from, AppLog.levelName(level))

                FilterChip(
                    selected = level == selected,
                    onClick = { onSelect(level) },
                    label = { Text(AppLog.levelName(level)) },
                    modifier = Modifier
                        .heightIn(min = MinTouchTarget)
                        .semantics { contentDescription = recordFromDescription }
                )
            }
        }
        Text(
            text = stringResource(R.string.help_level_hint),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

/**
 * 24-hour with a time zone, or 12-hour with AM/PM.
 *
 * A choice rather than a switch, because the two options are equally likely and a switch
 * would leave the reader guessing what "on" means.
 */
@Composable
private fun ClockFormatPicker(
    twelveHour: Boolean,
    onSelect: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier.fillMaxWidth().padding(vertical = 8.dp)) {
        Text(
            stringResource(R.string.help_time_format),
            style = MaterialTheme.typography.bodyLarge
        )
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            CLOCK_OPTIONS.forEach { option ->
                // Hoisted: a modifier chain is an ordinary lambda and cannot read a resource
                // itself.
                val optionLabel = stringResource(option.labelRes)

                FilterChip(
                    selected = option.twelveHour == twelveHour,
                    onClick = { onSelect(option.twelveHour) },
                    label = { Text(optionLabel) },
                    modifier = Modifier
                        .heightIn(min = MinTouchTarget)
                        .semantics { contentDescription = optionLabel }
                )
            }
        }
        Text(
            text = stringResource(R.string.help_clock_hint),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

/** One clock option: the label as the user reads it, and the setting it stands for. */
private data class ClockOption(@StringRes val labelRes: Int, val twelveHour: Boolean)

private val CLOCK_OPTIONS = listOf(
    ClockOption(R.string.help_clock_24_hour, false),
    ClockOption(R.string.help_clock_12_hour, true)
)

private val LEVEL_OPTIONS = listOf(
    AppLog.Level.DEBUG,
    AppLog.Level.INFO,
    AppLog.Level.WARNING,
    AppLog.Level.ERROR
)

/** Where reports are written: the app's own Documents folder, as on Windows. */
private fun reportsDirectory(context: Context): File {
    val root = context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS)
        ?: context.getExternalFilesDir(null)
        ?: context.filesDir
    return File(root, REPORT_FOLDER)
}

/** Where the tutorial lands: the cache, so it is thrown away by the system when it wants to. */
private fun tutorialFile(context: Context): File = File(context.cacheDir, TUTORIAL_FILE_NAME)

/** Must match the authority declared for the provider in the manifest. */
private fun fileProviderAuthority(context: Context): String = "${context.packageName}.fileprovider"

/**
 * Hands files to whatever app the user picks.
 *
 * @return null once the chooser is up, or a sentence explaining why nothing could take them.
 */
private fun sendFiles(
    context: Context,
    uris: List<Uri>,
    mimeType: String,
    chooserTitle: String
): String? {
    return try {
        context.startActivity(
            Intent.createChooser(
                Intent(Intent.ACTION_SEND).apply {
                    this.type = mimeType
                    putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(uris))
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                },
                chooserTitle
            )
        )
        null
    } catch (notFound: ActivityNotFoundException) {
        context.getString(R.string.help_nothing_can_take_files)
    }
}

/** What a written report turned out to be, so the screen can say something true about it. */
private data class ReportWritten(
    val file: File,
    val bytes: Int,
    val filesUsed: List<File>
)

/**
 * Writes the report to the reports folder.
 *
 * Blocking file work: callers run it on [Dispatchers.IO]. The event announcing the report is
 * recorded before the log tail is read, so the report contains the line saying it was made.
 */
private fun writeReport(context: Context): ReportWritten {
    val folder = reportsDirectory(context)
    if (!folder.exists() && !folder.mkdirs()) {
        error("The reports folder could not be created: ${folder.absolutePath}")
    }

    val now = Date()
    val file = File(folder, reportFileName(now))
    AppLog.event(
        "report.started",
        mapOf("path" to file.absolutePath, "logBytes" to REPORT_LOG_BYTES.toString())
    )

    val filesUsed = mutableListOf<File>()
    val tail = AppLog.tail(REPORT_LOG_BYTES, newestFileOnly = true, filesUsed = filesUsed)

    val bytes = reportText(now, file, filesUsed, tail).toByteArray(Charsets.UTF_8)
    file.writeBytes(bytes)
    AppLog.event(
        "report.saved",
        mapOf(
            "path" to file.absolutePath,
            "bytes" to bytes.size.toString(),
            "files" to filesUsed.size.toString()
        )
    )
    return ReportWritten(file, bytes.size, filesUsed.toList())
}

/** The report's whole body. Same section order and wording as the Windows report. */
private fun reportText(
    now: Date,
    file: File,
    filesUsed: List<File>,
    tail: String
): String {
    val settings = AppLog.settings()
    val rule = "-".repeat(78)
    val lines = mutableListOf(
        "LocalStream report",
        "written at  : ${AppLog.formatTimestamp(now, settings)}",
        "session     : ${AppLog.sessionId.ifEmpty { "unknown" }}",
        "report file : ${file.absolutePath}",
        rule,
        "SYSTEM",
        systemSummary(),
        rule,
        "LOGGING SETTINGS",
        "recording   : ${if (settings.recordAutomatically) "on" else "off"}",
        "level       : ${AppLog.levelName(settings.minimumLevel)} and above",
        "clock       : " +
            (if (settings.twelveHourClock) "12-hour with AM/PM" else "24-hour with UTC offset"),
        "precision   : ${if (settings.milliseconds) "milliseconds" else "seconds"}",
        "keep        : ${settings.keepDays} day(s), " +
            "up to ${settings.maxFileSizeMiB} MiB per file",
        rule,
        "LOG LINES"
    )

    if (filesUsed.isEmpty()) {
        lines += "(no log lines: recording is off, or nothing has been recorded yet)"
    } else {
        filesUsed.forEach { used -> lines += "--- ${used.name}" }
        lines += tail.trimEnd()
    }

    lines += rule
    lines += "End of report."
    return lines.joinToString("\n") + "\n"
}

/** The device the report came from. The version is the installed build's own. */
private fun systemSummary(): String {
    val host = runCatching { InetAddress.getLocalHost().hostName.orEmpty() }
        .getOrDefault("")
        .ifEmpty { "unknown" }
    return listOf(
        "application : LocalStream",
        "version     : ${BuildConfig.VERSION_NAME}",
        "license     : GNU GPLv3",
        "device      : ${Build.MANUFACTURER} ${Build.MODEL}",
        "android     : ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})",
        "abi         : ${Build.SUPPORTED_ABIS.joinToString(", ")}",
        "host name   : $host",
        "log folder  : ${AppLog.directory()?.absolutePath ?: "unknown"}"
    ).joinToString("\n")
}

/** To the second, so two reports in one afternoon do not collide. */
private fun reportFileName(when_ : Date): String =
    "LocalStream-report-${SimpleDateFormat("yyyy-MM-dd-HHmmss", Locale.US).format(when_)}.txt"

/** The tutorial, kept once in docs/ and embedded so it works from any install location. */
private const val TUTORIAL_FILE_NAME = "Tutorial.html"

private const val REPORT_FOLDER = "LocalStream Reports"
private const val REPORT_LOG_BYTES = 256 * 1024
private const val MAX_SHARED_FILES = 5

private const val MIN_KEEP_DAYS = 1
private const val MAX_KEEP_DAYS = 90
private const val MIN_FILE_SIZE_MIB = 1
private const val MAX_FILE_SIZE_MIB = 64

private const val HTML_MIME = "text/html"
private const val TEXT_MIME = "text/plain"
private const val LOG_MIME = "*/*"