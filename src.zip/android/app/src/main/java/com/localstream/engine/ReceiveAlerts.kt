package com.localstream.engine

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat
import com.localstream.LocalStreamApp
import com.localstream.R
import com.localstream.logging.AppLog
import com.localstream.ui.MainActivity

/**
 * Says that a broadcast turned this device away.
 *
 * A refusal is the one outcome in the access handshake that happens with the viewer doing
 * nothing at all: no password mistyped, no wrong address, just a decision by someone else. Left
 * only in the app's own state it reads as the app having stopped working, so it is also said out
 * of the app, as a bubble over whatever the viewer has moved on to.
 *
 * The broadcaster's own wording is used verbatim for the body. It knows the details that matter -
 * that this was a ban rather than a single refusal, how many attempts are left - and rewriting it
 * in the receiver's words would lose exactly the part the viewer needs.
 *
 * The bubble is a shortcut bubble because that is the shape available here: the person-shaped
 * bubble metadata arrived in a later androidx.core than this app depends on, and a shortcut
 * carries the same thing to the viewer - the broadcaster's name on it, tapping it opening the
 * list it was refused from.
 *
 * Whether the system then shows it is the system's own decision, and on some it is never yes: a
 * phone whose vendor does not offer bubbles to apps outside its own shows the notification below
 * instead, which is the same words in the same place and is why this is written as one attempt
 * rather than a bubble or nothing.
 */
object ReceiveAlerts {

    /**
     * Set on the intent that opens the app from the refusal, so the viewer lands on the list they
     * were refused from rather than on the tab the app happened to be left in.
     */
    const val EXTRA_OPEN_RECEIVE = "com.localstream.extra.OPEN_RECEIVE"

    /**
     * One id for every refusal, for both the notification and the shortcut behind it, so a new
     * attempt replaces the old notice instead of stacking a second bubble next to a reason that
     * is no longer true.
     */
    private const val NOTIFICATION_ID = 1003
    private const val SHORTCUT_ID = "access-refused"

    /**
     * Posts the refusal as a bubble where the system has them, and as an ordinary
     * high-importance notification where it does not, or where the bubble cannot be built.
     *
     * @param blocked true for a ban rather than a single refusal, which changes the wording and
     *        must not read as though trying again would work.
     */
    fun showRefusal(
        context: Context,
        broadcasterName: String,
        reason: String,
        blocked: Boolean
    ) {
        val who = broadcasterName.ifBlank { context.getString(R.string.app_name) }
        // ACTION_MAIN because a shortcut's intents must carry an action, and the platform throws
        // on the spot if one does not - which it would have done here, on the main thread, at the
        // exact moment the viewer is being refused.
        val open = Intent(Intent.ACTION_MAIN, null, context, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            .putExtra(EXTRA_OPEN_RECEIVE, true)
        val openPendingIntent = PendingIntent.getActivity(
            context,
            0,
            open,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notification = NotificationCompat.Builder(
            context,
            LocalStreamApp.RECEIVER_ALERT_CHANNEL_ID
        )
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(
                context.getString(
                    if (blocked) R.string.access_blocked_title else R.string.access_refused_title
                )
            )
            .setContentText(reason)
            // The reason is a sentence or two at most, but a bubble's collapsed line holds one:
            // without this it would be cut off exactly where it stops being useful.
            .setStyle(NotificationCompat.BigTextStyle().bigText(reason))
            .setContentIntent(openPendingIntent)
            .setAutoCancel(true)
            // Messaging, because that is the category the system offers bubbles for, and this is
            // the closest honest description of what arrived: something said to this device.
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)

        val shortcut = shortcutFor(context, who, reason, open)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && shortcut != null) {
            notification.setShortcutInfo(shortcut)
            notification.setBubbleMetadata(
                NotificationCompat.BubbleMetadata.Builder(SHORTCUT_ID).build()
            )
        }

        val built = notification.build()
        try {
            try {
                NotificationManagerCompat.from(context).notify(NOTIFICATION_ID, built)
            } catch (_: SecurityException) {}
        } catch (e: RuntimeException) {
            // Notifications refused, or not granted, or refused by a channel the system will not
            // accept. The refusal is still on screen in the app and still spoken, so this is a
            // downgrade rather than a failure - but it is logged, because a viewer told nothing
            // at all has no way to know why. It is caught as broadly as it is because this runs
            // where a viewer is being turned away: nothing about a notice is worth an app crash.
            AppLog.warning("ReceiveAlerts", "Could not post the refusal notification: $e")
        }
    }

    /** Takes a standing refusal down, because the viewer has just tried again. */
    fun clear(context: Context) {
        NotificationManagerCompat.from(context).cancel(NOTIFICATION_ID)
        // The shortcut outlives its notification if left alone, and a launcher full of refusals
        // the viewer can no longer dismiss would be worse than no bubble at all.
        try {
            ShortcutManagerCompat.removeDynamicShortcuts(context, listOf(SHORTCUT_ID))
        } catch (e: IllegalArgumentException) {
            AppLog.debug("ReceiveAlerts", "Refusal shortcut already gone")
        }
    }

    /**
     * The shortcut a bubble needs before the system will show one, and the broadcaster's name on
     * it, so the refusal is visibly from them. Null where there is no bubble to be had, which
     * leaves the caller posting an ordinary notification.
     */
    private fun shortcutFor(
        context: Context,
        who: String,
        reason: String,
        open: Intent
    ): ShortcutInfoCompat? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return null
        val shortcut = ShortcutInfoCompat.Builder(context, SHORTCUT_ID)
            .setShortLabel(who)
            .setLongLabel(reason)
            .setIcon(IconCompat.createWithResource(context, R.drawable.ic_notification))
            .setIntent(open)
            // The system may evict a shortcut the app has not marked as worth keeping, and an
            // evicted shortcut takes its bubble with it - which would silence the one notice
            // this exists to give. It is removed again when the viewer retries.
            .setLongLived(true)
            .build()
        return try {
            ShortcutManagerCompat.pushDynamicShortcut(context, shortcut)
            shortcut
        } catch (e: RuntimeException) {
            // The launcher will not host the shortcut, or will not take that shortcut, so there
            // is nothing here for a bubble to hang off and the caller posts an ordinary
            // notification instead. Caught broadly for the same reason as above: this runs on the
            // main thread at the moment the viewer is being turned away.
            AppLog.warning("ReceiveAlerts", "Could not publish the refusal shortcut: $e")
            null
        }
    }
}