package com.localstream.engine

import android.content.Context
import android.util.Size
import android.view.Surface
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import com.localstream.logging.AppLog
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Camera capture via CameraX.
 *
 * CameraX's `VideoCapture` owns its own encoder, which conflicts with this app encoding
 * the stream itself. The alternative is to give CameraX a `Preview` whose surface *is* the
 * encoder's input surface: the camera renders frames into it and [VideoEncoder] encodes
 * whatever lands there. No file is written and no second encode pass happens.
 */
class CameraCaptureSource(
    private val context: Context,
    private val lifecycleOwner: LifecycleOwner
) {

    private var cameraProvider: ProcessCameraProvider? = null
    private val active = AtomicBoolean(false)

    /**
     * Opens the camera and routes it into [encoderSurface].
     *
     * Blocking on the provider future, so this must not be called from the main thread.
     *
     * @throws Exception if the camera is unavailable or permission was refused.
     */
    @Throws(Exception::class)
    fun start(
        encoderSurface: Surface,
        lensFacing: Int = CameraSelector.LENS_FACING_FRONT,
        resolution: Pair<Int, Int> = Pair(1280, 720)
    ) {
        if (!active.compareAndSet(false, true)) return

        val provider = ProcessCameraProvider.getInstance(context).get()
        cameraProvider = provider

        val preview = Preview.Builder()
            .setTargetResolution(Size(resolution.first, resolution.second))
            .build()

        // The whole trick: fulfill CameraX's request with the encoder's surface, so the
        // camera writes straight into the encoder rather than into app memory.
        preview.setSurfaceProvider { request ->
            request.provideSurface(encoderSurface, ContextCompat.getMainExecutor(context)) { result ->
                AppLog.debug("CameraCaptureSource", "Camera surface released, result code ${result.resultCode}")
            }
        }

        val selector = CameraSelector.Builder()
            .requireLensFacing(lensFacing)
            .build()

        provider.unbindAll()
        val camera = provider.bindToLifecycle(lifecycleOwner, selector, preview)
        AppLog.info("CameraCaptureSource", "Camera capture started, lens facing ${camera.cameraInfo.lensFacing}")
    }

    fun stop() {
        if (!active.compareAndSet(true, false)) return
        runCatching { cameraProvider?.unbindAll() }
        cameraProvider = null
    }
}
