package com.localstream.ui

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat

/**
 * The runtime permissions this app needs, and why each one is required.
 *
 * The set differs by mode on purpose: audio-only broadcasting needs neither the camera nor
 * screen capture, and a user who only ever presents audio should never be asked for camera
 * access they will not use.
 */
object Permissions {

    val MICROPHONE = arrayOf(Manifest.permission.RECORD_AUDIO)
    val CAMERA = arrayOf(Manifest.permission.CAMERA)
    val NOTIFICATIONS =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            arrayOf(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            emptyArray()
        }
    val NEARBY_WIFI = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        arrayOf(Manifest.permission.NEARBY_WIFI_DEVICES)
    } else {
        emptyArray()
    }

    fun granted(context: Context, permission: String): Boolean =
        ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED
}
