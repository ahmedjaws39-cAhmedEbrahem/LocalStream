package com.localstream.protocol

import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * The OpusHead identification header, RFC 7845 §5.1, and the codec-configuration block Android's
 * software Opus decoder actually requires.
 *
 * RFC 7587 keeps any header off the RTP wire, so a directly-negotiated stream carries bare Opus
 * packets. Platform decoders are nevertheless configured from a container-style media format, and
 * `c2.android.opus.decoder` (`C2SoftOpusDec`) is unusually strict about what it finds there: its
 * `process()` consumes the *first three* input buffers as codec-specific data — the OpusHead, the
 * codec delay and the seek pre-roll — and only decodes from the fourth on. Its `GetOpusHeaderBuffers`
 * reads all three from a single "unified" blob identified by `AOPUS*` marker words.
 *
 * Passing only the bare 19-byte `OpusHead` leaves the delay and pre-roll to be read from the first
 * two *audio* packets instead, so `mSamplesToDiscard` is set from a packet's opening bytes. When
 * that value is large the decoder decodes every frame and then discards all of it, and the output
 * track reports `started` while playing nothing. Building the unified blob from the negotiated
 * channel count, with zero delay and no pre-roll, keeps the decoder on the decode path from the
 * first packet.
 */
object OpusHead {

    /** 8-byte magic, then version, channels, pre-skip, rate, gain and mapping family. */
    const val SIZE = 19

    /**
     * `"AOPUSHDR"` + `uint64 19` + the 19-byte header, `"AOPUSDLY"` + `uint64 8` + the delay, and
     * `"AOPUSPRL"` + `uint64 8` + the pre-roll: each marker and length is 8 bytes.
     */
    const val CODEC_CONFIG_SIZE = (8 + 8 + SIZE) + (8 + 8 + 8) + (8 + 8 + 8)

    private val MAGIC = "OpusHead".toByteArray(Charsets.US_ASCII)
    private val HEADER_MARKER = "AOPUSHDR".toByteArray(Charsets.US_ASCII)
    private val DELAY_MARKER = "AOPUSDLY".toByteArray(Charsets.US_ASCII)
    private val PREROLL_MARKER = "AOPUSPRL".toByteArray(Charsets.US_ASCII)

    /**
     * Builds a mapping-family-0 header, which covers the mono and stereo layouts Opus in RTP
     * negotiates without an explicit stream map.
     */
    fun build(channels: Int, sampleRate: Int = LocalStream.AUDIO_CLOCK_RATE): ByteArray {
        require(channels in 1..2) { "mapping family 0 supports only mono or stereo" }
        val head = ByteBuffer.allocate(SIZE).order(ByteOrder.LITTLE_ENDIAN)
        head.put(MAGIC) // magic signature
        head.put(1) // version
        head.put(channels.toByte())
        head.putShort(0) // pre-skip; a live stream has nothing to trim
        head.putInt(sampleRate) // original input sample rate
        head.putShort(0) // output gain
        head.put(0) // channel mapping family 0
        return head.array()
    }

    /**
     * Builds the unified codec-configuration blob `C2SoftOpusDec` expects as `csd-0`.
     *
     * [codecDelayNs] and [seekPreRollNs] are in nanoseconds, matching the decoder's
     * `ns_to_samples` conversion. Both default to zero: the encoder has no container-level priming
     * for the receiver to trim, and a non-zero delay would hold back the first packets.
     */
    fun buildCodecConfig(
        channels: Int,
        sampleRate: Int = LocalStream.AUDIO_CLOCK_RATE,
        codecDelayNs: Long = 0,
        seekPreRollNs: Long = 0
    ): ByteArray {
        val head = build(channels, sampleRate)
        val config = ByteBuffer.allocate(CODEC_CONFIG_SIZE).order(ByteOrder.LITTLE_ENDIAN)
        config.put(HEADER_MARKER)
        config.putLong(head.size.toLong())
        config.put(head)
        config.put(DELAY_MARKER)
        config.putLong(8L) // the delay value is always one uint64
        config.putLong(codecDelayNs)
        config.put(PREROLL_MARKER)
        config.putLong(8L) // the pre-roll value is always one uint64
        config.putLong(seekPreRollNs)
        return config.array()
    }
}
