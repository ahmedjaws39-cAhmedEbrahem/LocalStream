package com.localstream.engine

import kotlin.math.sqrt

/**
 * Automatic gain control for the broadcast audio, matching the Windows broadcaster's.
 *
 * The level a capture path delivers depends on the source and, for device audio, on the
 * system volume, so the same broadcast can arrive quiet through one device and loud through
 * another. Each 20 ms frame is steered toward a fixed average level, so a receiver hears a
 * steady volume instead.
 *
 * The trade-off is dynamic range: quiet passages are lifted, so a quiet source's noise floor
 * comes up with them. One gain is computed per frame and applied to every channel, which keeps
 * a stereo image intact; normalising the channels separately would drift them apart.
 *
 * Not thread safe: one instance belongs to the audio capture thread.
 */
class AudioNormalizer {

    /** Smoothed RMS of the input, on the same 0..1 scale as the samples. */
    private var level = 0.0

    /** The gain currently being applied. */
    private var gain = 1.0

    /**
     * Normalises [samples] little-endian 16-bit samples in [pcm], in place.
     *
     * [pcm] must hold at least `samples * 2` bytes.
     */
    fun process(pcm: ByteArray, samples: Int) {
        if (samples <= 0) return

        var sumSquares = 0.0
        var peak = 0.0
        for (i in 0 until samples) {
            val value = readSample(pcm, i) / 32768.0
            sumSquares += value * value
            val magnitude = if (value < 0) -value else value
            if (magnitude > peak) peak = magnitude
        }
        val frameLevel = sqrt(sumSquares / samples)

        // The first frame with real audio seeds the envelope directly instead of easing up from
        // zero, which would otherwise command the maximum gain for the first third of a second.
        if (level <= 0.0) {
            level = frameLevel
        } else {
            level += (frameLevel - level) * LEVEL_RATE
        }

        // Silence holds the last gain rather than being driven to the maximum. Without the gate
        // the envelope decays toward zero, the desired gain runs to the ceiling and the device's
        // noise floor is lifted into every pause.
        if (level > GATE_RMS) {
            val desired = (TARGET_RMS / level).coerceIn(MIN_GAIN, MAX_GAIN)
            gain += (desired - gain) * GAIN_RATE
        }

        // A per-frame ceiling applied without touching the smoothed gain, so one transient does
        // not pull the long-term level down with it.
        var applied = gain
        if (peak > 0.0 && peak * applied > CEILING) {
            applied = CEILING / peak
        }

        for (i in 0 until samples) {
            val scaled = Math.round(readSample(pcm, i) * applied).toInt()
            writeSample(pcm, i, scaled.coerceIn(-32768, 32767))
        }
    }

    /** Clears the running level and gain, so a fresh broadcast starts from unity gain again. */
    fun reset() {
        level = 0.0
        gain = 1.0
    }

    private fun readSample(pcm: ByteArray, index: Int): Int {
        val low = pcm[index * 2].toInt() and 0xFF
        val high = pcm[index * 2 + 1].toInt()
        return (high shl 8) or low
    }

    private fun writeSample(pcm: ByteArray, index: Int, value: Int) {
        pcm[index * 2] = (value and 0xFF).toByte()
        pcm[index * 2 + 1] = ((value shr 8) and 0xFF).toByte()
    }

    private companion object {
        // Kept identical to the Windows encoder, so both broadcasters sound the same.
        const val TARGET_RMS = 0.10
        const val GATE_RMS = 0.0015
        const val MIN_GAIN = 0.25
        const val MAX_GAIN = 16.0
        const val LEVEL_RATE = 0.06
        const val GAIN_RATE = 0.12
        const val CEILING = 0.95
    }
}
