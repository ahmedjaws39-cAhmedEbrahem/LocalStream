package com.localstream.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.selection.toggleable
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.localstream.R
import com.localstream.protocol.LocalStream

/**
 * Minimum interactive size.
 *
 * Android's accessibility guidance requires 48dp by 48dp. Every control in this file
 * declares at least this, and decorative icons are excluded from the layout so a control's
 * whole visual area is tappable.
 */
val MinTouchTarget = 48.dp

/**
 * Audio-only / audio+video switch.
 *
 * A single [androidx.compose.material3.Switch] rather than a two-item radio group, because
 * the requirement is a mode toggle and a switch maps onto "is video on" without the user
 * having to remember which option is currently selected.
 *
 * Both ends of the switch carry a description: the label says what is *being controlled*
 * ("Include video") and the `stateDescription` says what the resulting mode *is*
 * ("Audio and video"). Without the second part a screen reader announces only "on", which
 * tells the user nothing about the consequence of the setting.
 */
@Composable
fun BroadcastModeSwitch(
    audioAndVideo: Boolean,
    onChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true
) {
    val modeDescription = stringResource(R.string.broadcast_mode_label)
    val modeStateDescription = stringResource(
        if (audioAndVideo) R.string.broadcast_mode_audio_video
        else R.string.broadcast_mode_audio_only
    )
    val consequenceDescription = stringResource(
        if (audioAndVideo) R.string.broadcast_include_video_description_on
        else R.string.broadcast_include_video_description_off
    )
    Row(
        modifier = modifier
            .fillMaxWidth()
            .heightIn(min = MinTouchTarget)
            .toggleable(
                value = audioAndVideo,
                enabled = enabled,
                role = Role.Switch,
                onValueChange = onChange
            )
            .semantics {
                // "Broadcast mode" is the group's identity; the switch state below is the
                // answer. Merging is avoided so the two are announced in sequence.
                contentDescription = modeDescription
                stateDescription = modeStateDescription
            }
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = if (audioAndVideo) Icons.Filled.Videocam else Icons.Filled.GraphicEq,
            contentDescription = null, // the row's own contentDescription covers it
            modifier = Modifier.size(32.dp)
        )
        Spacer(Modifier.width(16.dp))
        Column(Modifier.weight(1f)) {
            Text(
                text = stringResource(R.string.broadcast_include_video),
                style = MaterialTheme.typography.titleMedium
            )
            Text(
                // The visible sub-label states the consequence, which is also what
                // stateDescription announces.
                text = consequenceDescription,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Spacer(Modifier.width(16.dp))
        Switch(
            checked = audioAndVideo,
            onCheckedChange = null, // the Row owns the click target for a single large target
            enabled = enabled,
            // The Row's semantics carry the label and state, so the Switch is hidden from
            // the accessibility tree to avoid announcing the same thing twice.
            modifier = Modifier.clearAndSetSemantics { }
        )
    }
}

/**
 * A labelled on/off setting.
 *
 * A [androidx.compose.material3.Switch] with the whole row as the tap target, matching
 * [BroadcastModeSwitch]. The label names what is being controlled; [stateDescription], when
 * given, names the resulting state, so a screen reader says more than "on".
 */
@Composable
fun LabelledSwitch(
    label: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    description: String? = null,
    stateDescription: String? = null
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .heightIn(min = MinTouchTarget)
            .toggleable(
                value = checked,
                enabled = enabled,
                role = Role.Switch,
                onValueChange = onCheckedChange
            )
            .semantics {
                contentDescription = label
                if (stateDescription != null) this.stateDescription = stateDescription
            }
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(text = label, style = MaterialTheme.typography.titleMedium)
            if (description != null) {
                Text(
                    text = description,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        Spacer(Modifier.width(16.dp))
        Switch(
            checked = checked,
            onCheckedChange = null, // the Row owns the click target for a single large target
            enabled = enabled,
            // The Row's semantics carry the label and state, so the Switch is hidden from
            // the accessibility tree to avoid announcing the same thing twice.
            modifier = Modifier.clearAndSetSemantics { }
        )
    }
}

/**
 * A live status message.
 *
 * `Assertive` is used because every message here is the direct result of something the
 * user just did — starting a broadcast, a mode change — and they need it immediately.
 * Background chatter (bitrate, packet counts) uses [QuietStatus] with `Polite` instead.
 */
@Composable
fun AnnouncementBanner(
    message: String?,
    modifier: Modifier = Modifier,
    isError: Boolean = false
) {
    if (message.isNullOrBlank()) return

    val background = if (isError) {
        MaterialTheme.colorScheme.errorContainer
    } else {
        MaterialTheme.colorScheme.secondaryContainer
    }
    val foreground = if (isError) {
        MaterialTheme.colorScheme.onErrorContainer
    } else {
        MaterialTheme.colorScheme.onSecondaryContainer
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(background, MaterialTheme.shapes.medium)
            .semantics {
                // Assertive: the user initiated whatever caused this, and needs to know the
                // outcome without having to go looking for it.
                liveRegion = LiveRegionMode.Assertive
            }
            .padding(16.dp)
    ) {
        Text(
            text = message,
            style = MaterialTheme.typography.bodyLarge,
            fontWeight = FontWeight.Medium,
            color = foreground
        )
    }
}

/**
 * A status line that updates on its own, such as connection statistics.
 *
 * `Polite` so it queues behind whatever the user is currently having read, rather than
 * interrupting. A bitrate readout firing every second would be unusable if assertive.
 */
@Composable
fun QuietStatus(
    text: String,
    modifier: Modifier = Modifier
) {
    Text(
        text = text,
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = modifier
            .fillMaxWidth()
            .semantics { liveRegion = LiveRegionMode.Polite }
            .padding(horizontal = 16.dp, vertical = 4.dp)
    )
}

/** Section heading, marked so users can navigate the screen by heading. */
@Composable
fun SectionHeading(
    text: String,
    modifier: Modifier = Modifier
) {
    Text(
        text = text,
        style = MaterialTheme.typography.headlineSmall,
        modifier = modifier
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .semantics { heading() }
    )
}

/** A dot that carries a state in its colour, labelled so colour is never the only signal. */
@Composable
fun StatusDot(
    live: Boolean,
    modifier: Modifier = Modifier
) {
    val color = if (live) {
        MaterialTheme.colorScheme.primary
    } else {
        MaterialTheme.colorScheme.outline
    }
    val dotStateDescription = stringResource(if (live) R.string.state_live else R.string.state_idle)
    Box(
        modifier = modifier
            .size(12.dp)
            .background(color, MaterialTheme.shapes.extraSmall)
            .semantics {
                stateDescription = dotStateDescription
            }
    )
}

/**
 * One entry in the broadcaster list.
 *
 * The whole card is a single accessibility node: a user swiping through the list hears the
 * broadcaster's name, its state, and its mode as one utterance instead of three separate
 * stops. `mergeDescendants` is what makes that happen.
 */
@Composable
fun BroadcasterCard(
    name: String,
    live: Boolean,
    mode: String,
    resolution: String?,
    bitrateKbps: Int,
    connected: Boolean,
    enabled: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val modeText = stringResource(
        if (mode == LocalStream.MODE_AUDIO_ONLY) R.string.broadcast_mode_audio_only_lowercase
        else R.string.broadcast_mode_audio_video_lowercase
    )
    val stateText = when {
        connected -> stringResource(R.string.cd_broadcaster_state_connected)
        live -> stringResource(R.string.cd_broadcaster_state_live)
        else -> stringResource(R.string.cd_broadcaster_state_idle)
    }
    val details = buildList {
        add(modeText)
        resolution?.let { add(it) }
        add(stringResource(R.string.broadcast_bitrate_value, bitrateKbps))
    }.joinToString(", ")
    val cardDescription = stringResource(R.string.cd_broadcaster_card, name, stateText, details)

    Card(
        modifier = modifier
            .fillMaxWidth()
            .heightIn(min = MinTouchTarget)
            .semantics(mergeDescendants = true) {
                contentDescription = cardDescription
                role = Role.Button
            },
        colors = CardDefaults.cardColors(
            containerColor = if (connected) {
                MaterialTheme.colorScheme.primaryContainer
            } else {
                MaterialTheme.colorScheme.surfaceVariant
            }
        ),
        onClick = onClick,
        enabled = enabled
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            StatusDot(live = live)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(name, style = MaterialTheme.typography.titleMedium)
                Text(
                    text = details,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            if (connected) {
                Text(
                    text = stringResource(R.string.state_connected),
                    style = MaterialTheme.typography.labelLarge
                )
            }
        }
    }
}

/**
 * A slider with its value spoken.
 *
 * A bare [Slider] announces only the position, so a user cannot tell 1500 kbit/s from
 * 3000 without counting stops. The label names the control and `stateDescription` names
 * the value and its unit; both go on the slider rather than one on the visible text and
 * one on the slider, because a name and a state description read back as two utterances -
 * "Video bitrate, 1500 kilobits per second, 1500 kilobits per second" otherwise.
 *
 * @param steps stops between the ends, 0 for a continuous track. Callers round to the unit
 *        they actually want; a track with a hundred stops cannot be hit with a fingertip.
 */
@Composable
fun LabelledSlider(
    label: String,
    valueLabel: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    steps: Int,
    onChange: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
            .semantics { heading() }
    ) {
        Text(
            stringResource(R.string.label_value_pair, label, valueLabel),
            style = MaterialTheme.typography.bodyLarge
        )
        Slider(
            value = value.coerceIn(range),
            onValueChange = onChange,
            valueRange = range,
            steps = steps,
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = MinTouchTarget)
                .semantics {
                    contentDescription = label
                    stateDescription = valueLabel
                }
        )
    }
}

/** A labelled value, used for the read-outs a presenter cares about. */
@Composable
fun LabelledValue(
    label: String,
    value: String,
    modifier: Modifier = Modifier
) {
    val valueDescription = stringResource(R.string.cd_label_value, label, value)
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp)
            .semantics(mergeDescendants = true) {
                // Read as one item: "Receivers, 2", rather than two disconnected fragments.
                contentDescription = valueDescription
            },
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, style = MaterialTheme.typography.bodyLarge)
        Text(
            value,
            style = MaterialTheme.typography.bodyLarge,
            fontWeight = FontWeight.SemiBold
        )
    }
}
