package com.localstream.engine

import android.annotation.SuppressLint
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.projection.MediaProjection
import android.os.Build
import androidx.annotation.RequiresApi

/**
 * Device-audio capture, kept in its own object because it exists only on Android 10 and above.
 *
 * `AudioPlaybackCaptureConfiguration` is the only supported way for a normal app to record the
 * sound other apps are playing; the `REMOTE_SUBMIX` audio source that predates it is reserved for
 * system-signed callers. It cannot be referenced at all before API 29, so this file is loaded
 * only when the class is actually reached, which the API check in [AudioCaptureEncoder] guards.
 *
 * Capture is limited to the media, game and unknown usages: the platform refuses to hand over
 * anything a user would consider private, and a voice call or an accessibility prompt never ends
 * up in a broadcast even if the app forgets to filter it.
 */
@RequiresApi(Build.VERSION_CODES.Q)
internal object PlaybackCapture {

    /**
     * Builds the recorder.
     *
     * Suppressed rather than checked: this object holds no [android.content.Context], and the
     * contract is [AudioCaptureEncoder.start]'s - RECORD_AUDIO is granted before it is called,
     * and a refusal there already surfaces as the documented [SecurityException]. What matters
     * is that the grant is asked for, which `MainViewModel.startBroadcast` does before the
     * engine is ever started.
     */
    @SuppressLint("MissingPermission")
    fun buildRecord(
        projection: MediaProjection,
        sampleRate: Int,
        channelCount: Int,
        bufferBytes: Int
    ): AudioRecord {
        val config = AudioPlaybackCaptureConfiguration.Builder(projection)
            .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
            .addMatchingUsage(AudioAttributes.USAGE_GAME)
            .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
            .build()

        return AudioRecord.Builder()
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(sampleRate)
                    .setChannelMask(
                        if (channelCount == 2) AudioFormat.CHANNEL_IN_STEREO
                        else AudioFormat.CHANNEL_IN_MONO
                    )
                    .build()
            )
            .setBufferSizeInBytes(bufferBytes)
            .setAudioPlaybackCaptureConfig(config)
            .build()
    }
}
