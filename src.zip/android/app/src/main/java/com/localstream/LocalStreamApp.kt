package com.localstream

import android.app.Application
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import android.view.accessibility.AccessibilityManager

class LocalStreamApp : Application() {

    override fun onCreate() {
        super.onCreate()
        com.localstream.logging.AppLog.install(this)
        createNotificationChannel()
        createAccessNotificationChannel()
        createReceiverAlertChannel()
        // A screen-reader user should never be interrupted by a media notification or a
        // haptic the rest of the system decides to make; the app-level switch lets them
        // opt out entirely.
        hapticsEnabled = !isScreenReaderActive()
    }

    /** True when TalkBack or another screen reader is currently running. */
    fun isScreenReaderActive(): Boolean {
        val manager = getSystemService(ACCESSIBILITY_SERVICE) as? AccessibilityManager ?: return false
        return manager.isEnabled && manager.isTouchExplorationEnabled
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val channel = NotificationChannel(
            NOTIFICATION_CHANNEL_ID,
            getString(R.string.notification_channel_name),
            // LOW importance: a live broadcast is useful but not something the user must
            // act on, so it must not interrupt with a heads-up banner.
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = getString(R.string.notification_channel_description)
            setShowBadge(false)
            enableVibration(false)
            setSound(null, null)
        }
        val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        manager.createNotificationChannel(channel)

    }

    private fun createAccessNotificationChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        val access = NotificationChannel(
            ACCESS_NOTIFICATION_CHANNEL_ID,
            getString(R.string.notification_channel_access_name),
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = getString(R.string.notification_channel_access_description)
            setShowBadge(true)
            enableVibration(true)
            lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        }
        manager.createNotificationChannel(access)
    }

    private fun createReceiverAlertChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        val refused = NotificationChannel(
            RECEIVER_ALERT_CHANNEL_ID,
            getString(R.string.notification_channel_refused_name),
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = getString(R.string.notification_channel_refused_description)
            setShowBadge(true)
            enableVibration(true)
            lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                @Suppress("DEPRECATION")
                setAllowBubbles(true)
            }
        }
        manager.createNotificationChannel(refused)
    }

    companion object {
        const val NOTIFICATION_CHANNEL_ID = "broadcast"
        const val ACCESS_NOTIFICATION_CHANNEL_ID = "access-request"
        const val RECEIVER_ALERT_CHANNEL_ID = "access-refused"
    }
}

/**
 * Global haptics switch. Off when a screen reader is active, because TalkBack interprets
 * touch feedback as an event and the extra vibration competes with its speech.
 */
var hapticsEnabled: Boolean = true
