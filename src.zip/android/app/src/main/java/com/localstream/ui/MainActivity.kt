package com.localstream.ui

import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.lifecycle.lifecycleScope
import com.localstream.engine.ProjectionController
import com.localstream.engine.ReceiveAlerts
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    // Playback is deliberately not torn down in onDestroy: the ViewModel owns it so playback
    // survives a rotation. The ViewModel clears it in onCleared.
    private val viewModel: MainViewModel by viewModels()

    /**
     * The language is applied here rather than in onCreate because every context the activity
     * hands out afterwards - to Compose, to the theme, to the ViewModel - has to already speak
     * it. Wrapping the base context is what makes `stringResource` answer in the chosen language
     * everywhere in the app, rather than only where the code remembered to ask.
     */
    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(AppLanguage.wrap(newBase))
    }

    /**
     * Screen capture. `MediaProjection` requires a token obtained from an Activity, so this
     * is launched from here when the engine reports that video capture is needed.
     */
    private val projectionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val data = result.data
        if (result.resultCode == RESULT_OK && data != null) {
            viewModel.onProjectionToken(ProjectionController.tokenFrom(result.resultCode, data))
        } else {
            viewModel.onProjectionToken(null)
        }
    }

    /**
     * Runtime permissions. Both callers funnel through the ViewModel: the start-up set only has
     * to be reported, while the broadcast's own set decides whether the Start the user pressed
     * is resumed or refused, and only the ViewModel knows which was in flight.
     */
    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { grants ->
        viewModel.onPermissionsResult(grants)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        // From API 35 the window is edge to edge whether the app asks or not; asking makes it
        // true on every version back to 24, and makes the system draw the bars transparently.
        // The content is padded back out of the bars in MainScreen, and the scheme's colours
        // and the bar icon appearance are set by LocalStreamTheme.
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)

        // A refusal arrives as a bubble over whatever the viewer is doing, and the one thing it
        // has to answer is "why" - so opening it has to land on the list it was refused from,
        // not on whichever tab the app last happened to be left in.
        if (intent?.getBooleanExtra(ReceiveAlerts.EXTRA_OPEN_RECEIVE, false) == true) {
            viewModel.setTab(MainTab.RECEIVE)
        }

        requestEssentialPermissions()
        watchProjectionRequests()
        watchPermissionRequests()

        setContent {
            LocalStreamApp(viewModel = viewModel)
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        // CLEAR_TOP: a viewer who left the app to do something else and then taps the refusal gets
        // this same activity brought forward rather than a second copy of it, so onCreate does not
        // run again and the extra would otherwise be dropped on the way in - leaving them on the
        // tab the app was left in, with a refusal they cannot connect to anything.
        setIntent(intent)
        if (intent.getBooleanExtra(ReceiveAlerts.EXTRA_OPEN_RECEIVE, false)) {
            viewModel.setTab(MainTab.RECEIVE)
        }
    }

    /**
     * Bridges the engine's need for a capture token to the system prompt.
     *
     * The engine cannot obtain one itself: Android requires a foreground Activity and a
     * user gesture for the MediaProjection consent dialog.
     */
    private fun watchProjectionRequests() {
        lifecycleScope.launch {
            viewModel.state.collect { state ->
                if (state.needsProjectionToken) {
                    viewModel.consumeProjectionRequest()
                    val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE)
                        as MediaProjectionManager
                    projectionLauncher.launch(manager.createScreenCaptureIntent())
                }
            }
        }
    }

    /**
     * Asks for the permissions needed regardless of mode.
     *
     * The microphone is deliberately not requested here: a user who only ever *views*
     * broadcasts should not be asked to grant microphone access.
     */
    private fun requestEssentialPermissions() {
        val needed: List<String> =
            Permissions.NEARBY_WIFI.toList() + Permissions.NOTIFICATIONS.toList()
        val missing = needed.filterNot { Permissions.granted(this, it) }
        if (missing.isNotEmpty()) {
            permissionLauncher.launch(missing.toTypedArray())
        }
    }

    /**
     * Bridges the ViewModel's need for microphone or camera access to the system prompt.
     *
     * Same shape as [watchProjectionRequests] for the same reason: the ViewModel decides which
     * permissions a broadcast needs, but only an Activity can launch the dialog that grants
     * them. Consuming before launching means one prompt per request, whatever the answer.
     */
    private fun watchPermissionRequests() {
        lifecycleScope.launch {
            viewModel.state.collect { state ->
                if (state.permissionsRequest.isNotEmpty()) {
                    viewModel.consumePermissionRequest()
                    permissionLauncher.launch(state.permissionsRequest.toTypedArray())
                }
            }
        }
    }
}
