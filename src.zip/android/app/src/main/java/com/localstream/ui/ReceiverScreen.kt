﻿package com.localstream.ui

import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.ViewGroup
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.FullscreenExit
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.OutlinedTextField
import androidx.compose.runtime.getValue
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.localstream.R
import com.localstream.engine.PlaybackEngine
import com.localstream.engine.ReceiveBuffer
import com.localstream.net.DiscoveredStream
import com.localstream.ui.components.AnnouncementBanner
import com.localstream.ui.components.BroadcasterCard
import com.localstream.ui.components.LabelledValue
import com.localstream.ui.components.MinTouchTarget
import com.localstream.ui.components.QuietStatus
import com.localstream.ui.components.SectionHeading

/**
 * The receiver tab.
 *
 * A [LazyColumn] of broadcasters plus, once connected, the video surface. The video surface
 * is described but not focusable: there is nothing actionable in it, and letting a screen
 * reader focus an empty rectangle wastes one of the user's limited swipes.
 */
@Composable
fun ReceiverScreen(
    state: UiState,
    playback: PlaybackEngine,
    onEnterFullscreen: () -> Unit,
    onVideoSurfaceReady: () -> Unit,
    onConnect: (DiscoveredStream) -> Unit,
    onConnectManually: (String, Int) -> Unit,
onDisconnect: () -> Unit,
    onRescan: () -> Unit,
    onReceiveBufferChange: (Int) -> Unit,
    onCancelAccessWait: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            // The whole screen scrolls. The buffer controls and the manual-connect panel are
            // tall, and without this they leave the broadcaster list a viewport only a few
            // pixels high, so the list is effectively invisible.
            .verticalScroll(rememberScrollState())
    ) {
        AnnouncementBanner(
            message = state.announcement,
            isError = state.announcementIsError
        )

        // Both dialogs live in MainScreen rather than here: the access request belongs to the
        // Broadcast tab, where the presenter already is, and a prompt that only appears on the
        // other tab is a prompt that goes unseen. The two panels below are viewer-side and do
        // belong to this tab.
        if (state.isAwaitingApproval) {
            AccessPendingPanel(onCancel = onCancelAccessWait)
        }

        state.blockedReason?.let { reason ->
            BlockedPanel(reason = reason, onRescan = onRescan)
        }

        SectionHeading(stringResource(R.string.receive_buffer_heading))
        ReceiveBufferPicker(
            selectedMillis = state.receiveBufferMs,
            onSelect = onReceiveBufferChange
        )
        Text(
            text = stringResource(R.string.receive_buffer_hint),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
        )

        Spacer(Modifier.height(8.dp))

        if (state.connectedKey != null) {
            SectionHeading(stringResource(R.string.receive_now_playing))
            ConnectedPanel(
                state = state,
                playback = playback,
                onEnterFullscreen = onEnterFullscreen,
                onVideoSurfaceReady = onVideoSurfaceReady,
                onDisconnect = onDisconnect
            )
        }

        SectionHeading(
            if (state.broadcasters.isEmpty()) {
                stringResource(R.string.receive_broadcasters)
            } else {
                stringResource(R.string.receive_broadcasters_count, state.broadcasters.size)
            }
        )

        if (state.isScanning && state.broadcasters.isEmpty()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    // Merged, or the live region would belong to a node with no text of its own
                    // and the message would never be spoken when the scan starts.
                    .semantics(mergeDescendants = true) {
                        liveRegion = LiveRegionMode.Polite
                    },
                verticalAlignment = Alignment.CenterVertically
            ) {
                CircularProgressIndicator(modifier = Modifier.size(24.dp))
                Spacer(Modifier.width(16.dp))
                Text(
                    stringResource(R.string.receive_scanning),
                    style = MaterialTheme.typography.bodyLarge
                )
            }
        }

        if (state.broadcasters.isEmpty() && !state.isScanning) {
            Text(
                text = stringResource(R.string.receive_no_broadcasters_found),
                style = MaterialTheme.typography.bodyLarge,
                modifier = Modifier
                    .padding(16.dp)
                    // This text only ever appears as a result of a scan that just ended, which
                    // is exactly when it needs saying out loud.
                    .semantics { liveRegion = LiveRegionMode.Polite }
            )
        }

        // A plain column rather than a LazyColumn: there are only ever a handful of broadcasters,
        // and as a non-weighted child it cannot be squeezed to nothing the way the weighted lazy
        // list was when the buffer controls grew above it.
        state.broadcasters.forEach { stream ->
            BroadcasterCard(
                name = stream.description.displayName,
                live = stream.description.live,
                mode = stream.description.mode,
                resolution = if (stream.description.isAudioOnly) {
                    null
                } else {
                    stringResource(
                        R.string.receive_resolution_value,
                        stream.description.width,
                        stream.description.height
                    )
                },
                bitrateKbps = if (stream.description.isAudioOnly) {
                    stream.description.audioBitrateKbps
                } else {
                    stream.description.videoBitrateKbps
                },
                connected = state.connectedKey == stream.key,
                enabled = !state.isConnecting && state.connectedKey == null,
                onClick = { onConnect(stream) },
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
            )
        }

        // Visible whenever there is no session, not only while a scan is running: a browse that
        // has already failed or finished leaves `isScanning` false, and that is exactly when a
        // viewer needs a way to look again. Pressing it mid-scan simply restarts the browse.
        if (state.connectedKey == null) {
            // Hoisted: the modifier chain below is an ordinary lambda, not a composable one,
            // so it cannot reach for the resources itself.
            val searchAgainDescription = stringResource(R.string.cd_receive_search_again)

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.Center
            ) {
                Button(
                    onClick = onRescan,
                    modifier = Modifier
                        .heightIn(min = MinTouchTarget)
                        .semantics { contentDescription = searchAgainDescription }
                ) {
                    Icon(Icons.Filled.Refresh, contentDescription = null)
                    Spacer(Modifier.width(12.dp))
                    Text(stringResource(R.string.receive_search_again))
                }
            }
        }

        ManualConnectPanel(
            enabled = !state.isConnecting && state.connectedKey == null,
            onConnect = onConnectManually
        )
    }
}

/**
 * The receive-side buffer, as a row of compact presets.
 *
 * Filter chips rather than radio buttons: the four options fit on one scrollable line, so the
 * control does not push the broadcaster list off a short screen. Selecting one applies at once,
 * including to a running connection.
 */
/**
 * Waiting for the presenter to answer.
 *
 * A progress line rather than a dialog: there is nothing to decide here, and the wait has no
 * upper limit, so a modal with a spinner would be a barrier around a line of text. The cancel
 * button is the only way out, and it is offered rather than implied because the presenter may
 * not be coming back.
 */
@Composable
private fun AccessPendingPanel(onCancel: () -> Unit) {
    // Hoisted: a modifier chain is an ordinary lambda and cannot read a resource itself.
    val stopWaitingDescription = stringResource(R.string.cd_receive_stop_waiting)

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
            .semantics(mergeDescendants = true) { liveRegion = LiveRegionMode.Polite }
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            CircularProgressIndicator(modifier = Modifier.size(24.dp))
            Spacer(Modifier.width(16.dp))
            Text(
                stringResource(R.string.receive_waiting_permission),
                style = MaterialTheme.typography.bodyLarge
            )
        }
        Text(
            text = stringResource(R.string.receive_waiting_permission_hint),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 4.dp)
        )
        Button(
            onClick = onCancel,
            modifier = Modifier
                .padding(top = 8.dp)
                .heightIn(min = MinTouchTarget)
                .semantics { contentDescription = stopWaitingDescription }
        ) {
            Text(stringResource(R.string.receive_stop_waiting))
        }
    }
}

/**
 * Refused for the rest of this broadcast.
 *
 * Says so plainly, because the alternative - leaving the viewer to keep pressing Connect and
 * be refused again - is what "no" means. The way back is choosing something else, so the only
 * action offered is a rescan.
 */
@Composable
private fun BlockedPanel(reason: String, onRescan: () -> Unit) {
    // Hoisted: a modifier chain is an ordinary lambda and cannot read a resource itself.
    val rescanDescription = stringResource(R.string.receive_look_for_other_broadcasts)

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
            .semantics(mergeDescendants = true) { liveRegion = LiveRegionMode.Assertive }
    ) {
        Text(
            text = stringResource(R.string.receive_blocked_title),
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.error
        )
        Text(
            text = reason,
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.padding(top = 4.dp)
        )
        Text(
            text = stringResource(R.string.receive_blocked_hint),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 4.dp)
        )
        Button(
            onClick = onRescan,
            modifier = Modifier
                .padding(top = 8.dp)
                .heightIn(min = MinTouchTarget)
                .semantics { contentDescription = rescanDescription }
        ) {
            Text(stringResource(R.string.receive_look_for_other_broadcasts))
        }
    }
}

@Composable
private fun ReceiveBufferPicker(
    selectedMillis: Int,
    onSelect: (Int) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        ReceiveBuffer.entries.forEach { option ->
            val label = receiveBufferLabel(option)
            val optionDescription =
                stringResource(R.string.cd_receive_buffer_option, label, option.millis)

            FilterChip(
                selected = option.millis == selectedMillis,
                onClick = { onSelect(option.millis) },
                label = { Text(label) },
                modifier = Modifier
                    .heightIn(min = MinTouchTarget)
                    .semantics { contentDescription = optionDescription }
            )
        }
    }
}

/**
 * The localised name of a buffer preset.
 *
 * [ReceiveBuffer] lives in the engine, which has no resources of its own, so the mapping from a
 * preset to the words for it is done here where the choice of language is known.
 */
@Composable
private fun receiveBufferLabel(buffer: ReceiveBuffer): String = stringResource(
    when (buffer) {
        ReceiveBuffer.LOW_LATENCY -> R.string.receive_buffer_low_latency
        ReceiveBuffer.BALANCED -> R.string.receive_buffer_balanced
        ReceiveBuffer.SMOOTH -> R.string.receive_buffer_smooth
        ReceiveBuffer.MAXIMUM -> R.string.receive_buffer_maximum
    }
)

/**
 * Address and control port, for when discovery comes up empty.
 *
 * Deliberately not hidden behind a tap: on a locked-down network the list stays empty forever and
 * a buried "connect manually" reads as a missing feature. Nothing is sent until Connect is pressed.
 */
@Composable
private fun ManualConnectPanel(
    enabled: Boolean,
    onConnect: (String, Int) -> Unit
) {
    // Saveable: a rotation or a process death while the keyboard is open must not throw away
    // an address the user has already typed, leaving a Connect button they cannot re-enable.
    var host by rememberSaveable { mutableStateOf("") }
    var port by rememberSaveable { mutableStateOf("") }
    val portNumber = port.trim().toIntOrNull()
    val canConnect = enabled && host.isNotBlank() && portNumber != null &&
        portNumber in 1..65535

    // Hoisted: a modifier chain is an ordinary lambda and cannot read a resource itself.
    val addressDescription = stringResource(R.string.cd_receive_broadcaster_address)
    val portDescription = stringResource(R.string.receive_control_port_label)
    val connectDescription = stringResource(R.string.receive_connect_manually)

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        SectionHeading(stringResource(R.string.receive_connect_manually))
        Text(
            text = stringResource(R.string.receive_connect_manually_hint),
            style = MaterialTheme.typography.bodyMedium
        )
        OutlinedTextField(
            value = host,
            onValueChange = { host = it },
            label = { Text(stringResource(R.string.receive_address_label)) },
            singleLine = true,
            enabled = enabled,
            modifier = Modifier
                .fillMaxWidth()
                .semantics { contentDescription = addressDescription }
        )
        OutlinedTextField(
            value = port,
            onValueChange = { input -> port = input.filter(Char::isDigit) },
            label = { Text(stringResource(R.string.receive_control_port_label)) },
            singleLine = true,
            enabled = enabled,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier
                .fillMaxWidth()
                .semantics { contentDescription = portDescription }
        )
        Button(
            onClick = { host.trim().let { h -> portNumber?.let { p -> onConnect(h, p) } } },
            enabled = canConnect,
            modifier = Modifier
                .heightIn(min = MinTouchTarget)
                .semantics { contentDescription = connectDescription }
        ) {
            Text(stringResource(R.string.receive_connect))
        }
    }
}

@Composable
private fun ConnectedPanel(
    state: UiState,
    playback: PlaybackEngine,
    onEnterFullscreen: () -> Unit,
    onVideoSurfaceReady: () -> Unit,
    onDisconnect: () -> Unit
) {
    Column(Modifier.padding(horizontal = 16.dp)) {
        if (state.isReceivingVideo) {
            VideoStage(
                playback = playback,
                isFullscreen = false,
                onToggleFullscreen = onEnterFullscreen,
                onSurfaceReady = onVideoSurfaceReady,
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(16f / 9f)
            )
        } else {
            Text(
                text = stringResource(R.string.receive_audio_only_no_video),
                style = MaterialTheme.typography.bodyLarge,
                modifier = Modifier.padding(vertical = 8.dp)
            )
        }

        Spacer(Modifier.height(8.dp))

        // The broadcaster's own statistics, one polite line: useful while watching, and polite
        // so a per-second update queues behind whatever TalkBack is already reading.
        if (!state.connectionMessage.isNullOrBlank()) {
            QuietStatus(state.connectionMessage)
        }

        LabelledValue(stringResource(R.string.receive_frames_decoded), state.receivedFrames.toString())
        LabelledValue(stringResource(R.string.receive_packets_lost), state.packetLoss.toString())

        Spacer(Modifier.height(8.dp))

        // Hoisted: a modifier chain is an ordinary lambda and cannot read a resource itself.
        val disconnectDescription = stringResource(R.string.cd_receive_disconnect)

        Button(
            onClick = onDisconnect,
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 64.dp)
                .semantics { contentDescription = disconnectDescription }
        ) {
            Text(
                stringResource(R.string.receive_disconnect),
                style = MaterialTheme.typography.titleMedium
            )
        }
    }
}

/**
 * The decoder's output surface together with its fullscreen control.
 *
 * The button is always present while a video session is running; only its icon and label change
 * with [isFullscreen]. The caller decides the size, so the same stage serves the inline panel and
 * the fullscreen host.
 */
@Composable
internal fun VideoStage(
    playback: PlaybackEngine,
    isFullscreen: Boolean,
    onToggleFullscreen: () -> Unit,
    onSurfaceReady: () -> Unit,
    modifier: Modifier = Modifier
) {
    // Hoisted: a modifier chain is an ordinary lambda and cannot read a resource itself.
    val fullscreenDescription = stringResource(
        if (isFullscreen) R.string.cd_exit_fullscreen else R.string.cd_enter_fullscreen
    )

    Box(modifier.background(Color.Black)) {
        VideoSurface(
            playback = playback,
            onSurfaceReady = onSurfaceReady,
            modifier = Modifier.fillMaxSize()
        )

        // A dark disc behind the icon keeps a white glyph legible over a bright frame, so its
        // contrast does not depend on what the broadcaster happens to be showing.
        IconButton(
            onClick = onToggleFullscreen,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(8.dp)
                .size(MinTouchTarget)
                .background(Color(0x99000000), CircleShape)
                .semantics { contentDescription = fullscreenDescription }
        ) {
            Icon(
                imageVector = if (isFullscreen) {
                    Icons.Filled.FullscreenExit
                } else {
                    Icons.Filled.Fullscreen
                },
                contentDescription = null, // the button's own description covers it
                tint = Color.White
            )
        }
    }
}

/**
 * Hosts the decoder's output surface.
 *
 * A `SurfaceView` rather than a `TextureView`: the decoder renders straight into it with no
 * intermediate copy, which is both lower latency and lower power.
 *
 * [onSurfaceReady] fires on every (re)creation of the surface, not just the first, so the caller
 * can ask for a fresh keyframe after a fullscreen toggle or a rotation.
 */
@Composable
private fun VideoSurface(
    playback: PlaybackEngine,
    onSurfaceReady: () -> Unit,
    modifier: Modifier = Modifier
) {
    val holder = remember { mutableStateOf<SurfaceHolder?>(null) }
    // Identifies this surface for the engine. A new instance is minted whenever the composable is
    // recreated, which is exactly when the previous surface may still be tearing itself down.
    val token = remember { Any() }
    // Hoisted: a modifier chain is an ordinary lambda and cannot read a resource itself.
    val surfaceDescription = stringResource(R.string.cd_video_playback)

    Box(
        modifier = modifier
            .semantics {
                // Named, not live: a live region would make the screen reader announce this
                // static label every time the node is recomposed, which on a video surface
                // happens as often as the frame size changes. There is nothing to act on
                // inside, so it is not focusable either - one swipe spent on an empty
                // rectangle is one swipe too many.
                contentDescription = surfaceDescription
            }
    ) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { context ->
                SurfaceView(context).apply {
                    layoutParams = ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                    holderCallback(
                        onCreated = { surfaceHolder ->
                            holder.value = surfaceHolder
                            playback.startVideo(token, surfaceHolder.surface)
                            onSurfaceReady()
                        },
                        onDestroyed = { playback.stopVideo(token) }
                    )
                }
            }
        )

        if (holder.value == null) {
            CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))
        }
    }
}

private fun SurfaceView.holderCallback(
    onCreated: (SurfaceHolder) -> Unit,
    onDestroyed: () -> Unit
) {
    holder.addCallback(object : SurfaceHolder.Callback {
        override fun surfaceCreated(surfaceHolder: SurfaceHolder) = onCreated(surfaceHolder)
        override fun surfaceChanged(surfaceHolder: SurfaceHolder, format: Int, width: Int, height: Int) = Unit
        override fun surfaceDestroyed(surfaceHolder: SurfaceHolder) = onDestroyed()
    })
}
