package com.localstream.ui.theme

import androidx.compose.ui.graphics.Color

/**
 * Colours chosen for contrast rather than brand.
 *
 * Every foreground/background pair used for text meets at least WCAG AA (4.5:1) against
 * its own background, because a screen-reader user is very often also a low-vision user
 * and the two accommodations have to coexist.
 */
val SignalBlue = Color(0xFF0B5FA5)
val SignalBlueLight = Color(0xFF9CCBFF)

val SurfaceLight = Color(0xFFFDFCFF)
val SurfaceDark = Color(0xFF10131A)
val SurfaceVariantLight = Color(0xFFE2E2EC)
val SurfaceVariantDark = Color(0xFF2A2E38)
val OnSurfaceLight = Color(0xFF191C22)
val OnSurfaceDark = Color(0xFFE3E2E9)
val OnSurfaceVariantLight = Color(0xFF3A3F4B)
val OnSurfaceVariantDark = Color(0xFFC3C6D2)
val ErrorLight = Color(0xFF8C1D18)
val ErrorDark = Color(0xFFF2B8B5)
