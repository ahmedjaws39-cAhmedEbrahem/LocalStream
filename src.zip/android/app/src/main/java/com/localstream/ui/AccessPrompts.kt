package com.localstream.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.localstream.R
import com.localstream.protocol.ControlMessage
import com.localstream.ui.components.MinTouchTarget

/**
 * Asks for the broadcaster's password.
 *
 * The dialog is not dismissed by tapping outside: dismissing it *is* the decision to stop
 * connecting, so that is the Cancel button and nothing else. A stray tap on the dimmed
 * background must not throw away a password the user has already typed.
 *
 * @param prompt carries the refusal flag, and is the remember key: a new prompt clears the
 *        field, because the most likely reason to be looking at this again is that the last
 *        answer was wrong, and leaving it there invites submitting the same wrong answer again.
 */
@Composable
fun PasswordDialog(
    prompt: PasswordPrompt,
    onSubmit: (String) -> Unit,
    onCancel: () -> Unit
) {
    var password by remember(prompt.wrongAttempt) { mutableStateOf("") }
    val focusRequester = remember { FocusRequester() }

    // The keyboard is the whole reason this dialog exists, and a viewer who has to tap the
    // field first is a viewer who has to find it.
    LaunchedEffect(Unit) { focusRequester.requestFocus() }

    AlertDialog(
        onDismissRequest = onCancel,
        title = { Text(stringResource(R.string.access_password_required)) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = stringResource(
                        R.string.access_password_prompt_body,
                        prompt.broadcasterName
                    )
                )
                OutlinedTextField(
                    value = password,
                    onValueChange = { typed ->
                        // Capped as typed: a value the broadcaster will refuse is not worth
                        // accepting in the first place.
                        if (typed.length <= ControlMessage.PASSWORD_MAX_LENGTH) {
                            password = typed
                        }
                    },
                    label = { Text(stringResource(R.string.access_password_entry_label)) },
                    singleLine = true,
                    isError = password.isNotEmpty() && !ControlMessage.isValidPassword(password),
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Password,
                        imeAction = ImeAction.Done
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .focusRequester(focusRequester)
                )
                if (prompt.wrongAttempt) {
                    Text(
                        text = stringResource(R.string.access_password_wrong),
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodyMedium,
                        // Assertive because the dialog has just come back to the top of the
                        // stack with an empty field: without being spoken, the reason for that
                        // is gone.
                        modifier = Modifier.semantics { liveRegion = LiveRegionMode.Assertive }
                    )
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = { onSubmit(password) },
                enabled = ControlMessage.isValidPassword(password),
                modifier = Modifier.heightIn(min = MinTouchTarget)
            ) {
                Text(stringResource(R.string.receive_connect))
            }
        },
        dismissButton = {
            TextButton(
                onClick = onCancel,
                modifier = Modifier.heightIn(min = MinTouchTarget)
            ) {
                Text(stringResource(R.string.access_cancel))
            }
        }
    )
}

/**
 * Asks the presenter to let a viewer in.
 *
 * Dismissable, and dismissal means no: a prompt the presenter swipes past must not leave a
 * viewer waiting for an answer that is never coming.
 */
@Composable
fun AccessRequestDialog(
    request: AccessRequest,
    onAnswer: (allow: Boolean) -> Unit
) {
    AlertDialog(
        onDismissRequest = { onAnswer(false) },
        title = { Text(stringResource(R.string.access_request_dialog_title)) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    stringResource(
                        R.string.access_request_wants_to_watch,
                        request.viewerName
                    )
                )
                Text(
                    text = stringResource(R.string.access_request_waiting_hint),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        confirmButton = {
            TextButton(
                onClick = { onAnswer(true) },
                modifier = Modifier.heightIn(min = MinTouchTarget)
            ) {
                Text(stringResource(R.string.access_allow))
            }
        },
        dismissButton = {
            TextButton(
                onClick = { onAnswer(false) },
                modifier = Modifier.heightIn(min = MinTouchTarget)
            ) {
                Text(stringResource(R.string.access_reject))
            }
        }
    )
}