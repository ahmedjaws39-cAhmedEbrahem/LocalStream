package com.localstream.net

import org.junit.Assert.assertFalse
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import com.localstream.protocol.H264Rtp
import com.localstream.protocol.Rtp
import com.localstream.protocol.LocalStream
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress

class RtpReceiverSourceTest {

    private val peer = InetAddress.getByName("192.0.2.10")

    @Test
    fun `accepts only the negotiated address port and SSRC`() {
        assertTrue(isExpectedRtpSource(peer, 41000, 0x11223344, peer, 41000, 0x11223344))
        assertFalse(isExpectedRtpSource(peer, 41001, 0x11223344, peer, 41000, 0x11223344))
        assertFalse(
            isExpectedRtpSource(
                InetAddress.getByName("192.0.2.11"), 41000, 0x11223344, peer, 41000, 0x11223344
            )
        )
        assertFalse(isExpectedRtpSource(peer, 41000, 0x55667788, peer, 41000, 0x11223344))
    }

    @Test
    fun `receiver restores datagram capacity before each packet`() = runBlocking {
        val receiverScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
        val receiver = RtpReceiver(receiverScope)
        val sender = DatagramSocket()
        val frames = Channel<ByteArray>(capacity = 2)
        var collector: Job? = null

        try {
            val ports = receiver.open(withVideo = false)
            collector = receiverScope.launch {
                receiver.audioFramesFlow.collect { frames.send(it) }
            }
            val ssrc = 0x11223344
            assertTrue(
                receiver.setExpectedSource(
                    InetAddress.getLoopbackAddress(), sender.localPort, null, ssrc, null
                )
            )

            val smallPayload = byteArrayOf(7)
            val largePayload = ByteArray(512) { (it and 0xFF).toByte() }
            val packets = listOf(
                Rtp.build(97, false, 1, 0, ssrc, smallPayload),
                Rtp.build(97, false, 2, 960, ssrc, largePayload)
            )
            for (bytes in packets) {
                sender.send(
                    DatagramPacket(
                        bytes, bytes.size, InetAddress.getLoopbackAddress(), ports.audio
                    )
                )
            }

            val receivedSmall = withTimeout(3_000) { frames.receive() }
            val receivedLarge = withTimeout(3_000) { frames.receive() }
            assertArrayEquals(smallPayload, receivedSmall)
            assertEquals(largePayload.size, receivedLarge.size)
            assertArrayEquals(largePayload, receivedLarge)
        } finally {
            collector?.cancel()
            frames.close()
            sender.close()
            receiver.close()
            receiverScope.cancel()
        }
    }

    @Test
    fun `video packet loss drops partial access unit and receives next frame`() = runBlocking {
        val receiverScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
        val receiver = RtpReceiver(receiverScope)
        val sender = DatagramSocket()
        val frames = Channel<ByteArray>(capacity = 2)
        var collector: Job? = null

        try {
            val ports = receiver.open(withVideo = true)
            collector = receiverScope.launch {
                receiver.videoFramesFlow.collect { frames.send(it) }
            }
            val audioSsrc = 0x11223344
            val videoSsrc = 0x55667788
            assertTrue(
                receiver.setExpectedSource(
                    InetAddress.getLoopbackAddress(),
                    sender.localPort,
                    sender.localPort,
                    audioSsrc,
                    videoSsrc
                )
            )

            val fuIndicator = (0x60 or H264Rtp.TYPE_FU_A).toByte()
            val start = byteArrayOf(fuIndicator, (0x80 or H264Rtp.NAL_SLICE_IDR).toByte(), 1, 2)
            val missingEnd = byteArrayOf(fuIndicator, (0x40 or H264Rtp.NAL_SLICE_IDR).toByte(), 3, 4)
            val nextNal = byteArrayOf((0x60 or H264Rtp.NAL_SLICE_IDR).toByte(), 5, 6)
            val payloads = listOf(
                Rtp.build(LocalStream.PAYLOAD_TYPE_VIDEO, false, 1, 0, videoSsrc, start),
                Rtp.build(LocalStream.PAYLOAD_TYPE_VIDEO, true, 3, 0, videoSsrc, missingEnd),
                Rtp.build(LocalStream.PAYLOAD_TYPE_VIDEO, true, 4, 3000, videoSsrc, nextNal)
            )
            for (payload in payloads) {
                sender.send(
                    DatagramPacket(
                        payload, payload.size, InetAddress.getLoopbackAddress(), ports.video
                    )
                )
            }

            val frame = withTimeout(3_000) { frames.receive() }
            assertArrayEquals(byteArrayOf(0, 0, 0, 1) + nextNal, frame)
        } finally {
            collector?.cancel()
            frames.close()
            sender.close()
            receiver.close()
            receiverScope.cancel()
        }
    }

    @Test
    fun `reused datagram packet can be expanded after a short receive`() {
        val datagram = DatagramPacket(ByteArray(2048), 2048)
        datagram.length = 13

        datagram.length = datagram.data.size

        assertEquals(2048, datagram.length)
    }
}
