package com.localstream.net

import com.localstream.protocol.ControlMessage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.nio.charset.StandardCharsets
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * What the receiver does when the broadcaster turns it away.
 *
 * These run against a real socket on the loopback interface rather than a fake, because the
 * failure they cover is not about what the client decides but about what it never manages to do:
 * the denial has to reach the parked handshake, and the socket has to be closed from this end. A
 * mocked socket would have reported success for both.
 */
class ControlClientDenyTest {

    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private val client = ControlClient(scope)
    private var server: ServerSocket? = null

    @After
    fun tearDown() {
        client.disconnect()
        scope.cancel()
        server?.close()
    }

    /**
     * A denial while the viewer is waiting to be let in must end the attempt, not park it.
     *
     * This is the case that hung: the approval wait has no timeout, so a `deny` that never
     * reached the handshake left the viewer watching a spinner for ever, and left a connection
     * the viewer could not end either.
     */
    @Test
    fun `a refusal during the approval wait ends the attempt`() = runBlocking {
        val reason = "The presenter declined your request to watch."
        val broadcaster = serve { peer ->
            peer.readControlLine() // hello
            peer.writeLine(welcome(access = ControlMessage.ACCESS_APPROVAL))
            peer.readControlLine() // offer
            peer.writeLine(deny(ControlMessage.DENY_ACCESS, reason))
            // Deliberately still holding the socket open: a broadcaster that refuses has nothing
            // further to say, but it is not obliged to hang up, and the viewer cannot ask it to.
            peer.awaitClose()
        }

        val result = withTimeout(5_000) {
            client.connect(
                host = "127.0.0.1",
                controlPort = server!!.localPort,
                receiverName = "Viewer",
                audioPort = 0,
                videoPort = null
            )
        }

        assertTrue("the attempt should not have succeeded", result.isFailure)
        assertTrue(
            "the broadcaster should have seen the viewer's socket close",
            broadcaster.peerClosed.await(5, TimeUnit.SECONDS)
        )
        assertEquals(ConnectionState.Rejected(reason), client.state.value)
        // The reason is the whole point of the refusal, and the notice is built from it, so a
        // state that settles back to "disconnected" a moment later would lose it.
        delay(250)
        assertEquals(ConnectionState.Rejected(reason), client.state.value)
    }

    /** A ban is terminal, and the viewer has to be able to tell it from a refusal worth retrying. */
    @Test
    fun `a ban during the approval wait is kept apart from a plain refusal`() = runBlocking {
        val reason = "You have been blocked from this broadcast after 3 rejected requests."
        serve { peer ->
            peer.readControlLine()
            peer.writeLine(welcome(access = ControlMessage.ACCESS_APPROVAL))
            peer.readControlLine()
            peer.writeLine(deny(ControlMessage.DENY_BLOCKED, reason))
        }

        withTimeout(5_000) {
            client.connect(
                host = "127.0.0.1",
                controlPort = server!!.localPort,
                receiverName = "Viewer",
                audioPort = 0,
                videoPort = null
            )
        }

        assertEquals(ConnectionState.Blocked(reason), client.state.value)
    }

    /**
     * A password refusal comes back before the ports are offered, so nothing has been given away
     * yet - but the socket still has to end with the attempt rather than wait for a second one.
     */
    @Test
    fun `a refusal before the ports are offered closes the socket`() = runBlocking {
        val reason = "Wrong password. 2 attempts remaining."
        val broadcaster = serve { peer ->
            peer.readControlLine()
            peer.writeLine(welcome(access = ControlMessage.ACCESS_PASSWORD))
            peer.readControlLine() // auth
            peer.writeLine(deny(ControlMessage.DENY_AUTH, reason))
            peer.awaitClose()
        }

        withTimeout(5_000) {
            client.connect(
                host = "127.0.0.1",
                controlPort = server!!.localPort,
                receiverName = "Viewer",
                audioPort = 0,
                videoPort = null,
                passwordProvider = { "guess" }
            )
        }

        assertTrue(
            "the broadcaster should have seen the viewer's socket close",
            broadcaster.peerClosed.await(5, TimeUnit.SECONDS)
        )
        assertEquals(ConnectionState.Rejected(reason), client.state.value)
    }

    /**
     * A push message that lands between the password and its verdict must not be read as one.
     *
     * While the prompt is open the broadcaster keeps sending stats, so the first line read after
     * the `auth` is usually a stat rather than the `authResult`. Treating that as a refusal
     * re-prompted the viewer before the password had been judged, and a correct password was
     * never accepted because the verdict stayed queued behind the pushes.
     */
    @Test
    fun `a push between the password and its verdict does not force another prompt`() = runBlocking {
        val prompts = mutableListOf<Boolean>()
        serve { peer ->
            peer.readControlLine() // hello
            peer.writeLine(welcome(access = ControlMessage.ACCESS_PASSWORD))
            peer.readControlLine() // auth, first attempt
            // Sent while the viewer waits, before the broadcaster's answer.
            peer.writeLine("""{"t":"stats","fps":30,"kbps":1500,"nrt":0,"pl":0,"dropped":0}""")
            peer.writeLine("""{"t":"authResult","ok":false,"reason":"Not correct."}""")
            peer.readControlLine() // auth, second attempt
            peer.writeLine("""{"t":"authResult","ok":true}""")
            peer.readControlLine() // offer
            peer.writeLine("""{"t":"accept","ap":4002,"as":4242}""")
        }

        val result = withTimeout(5_000) {
            client.connect(
                host = "127.0.0.1",
                controlPort = server!!.localPort,
                receiverName = "Viewer",
                audioPort = 0,
                videoPort = null,
                passwordProvider = { wrongAttempt ->
                    prompts += wrongAttempt
                    if (wrongAttempt) "right" else "wrong"
                }
            )
        }

        assertEquals(4002, result.getOrThrow().audioPort)
        // Once for the wrong password, once for the retry that is told it was wrong.
        assertEquals(listOf(false, true), prompts)
    }

    /** A public broadcast still completes, so none of this closing costs a working handshake. */
    @Test
    fun `an accepted handshake is untouched`() = runBlocking {
        serve { peer ->
            peer.readControlLine()
            peer.writeLine(welcome(access = ControlMessage.ACCESS_PUBLIC))
            peer.readControlLine()
            peer.writeLine("""{"t":"accept","ap":4002,"as":4242}""")
        }

        val result = withTimeout(5_000) {
            client.connect(
                host = "127.0.0.1",
                controlPort = server!!.localPort,
                receiverName = "Viewer",
                audioPort = 0,
                videoPort = null
            )
        }

        assertEquals(4002, result.getOrThrow().audioPort)
        assertEquals(ConnectionState.Connected("Test Broadcaster", "av"), client.state.value)
    }

    /**
     * Listens on an ephemeral loopback port and runs [script] against the one connection the client
     * makes, on its own thread so the script can block.
     */
    private fun serve(script: (Peer) -> Unit): Broadcaster {
        val listening = ServerSocket(0, 1, InetAddress.getLoopbackAddress())
        server = listening
        val broadcaster = Broadcaster()
        Thread {
            try {
                listening.accept().use { socket -> script(Peer(socket, broadcaster.peerClosed)) }
            } catch (e: IOException) {
                // The test's own teardown closed the listener.
            }
        }.apply {
            isDaemon = true
            start()
        }
        return broadcaster
    }

    /** Carries what a test wants to know about the connection it is holding. */
    private class Broadcaster {
        /** Counted down once the viewer has hung up. */
        val peerClosed = CountDownLatch(1)
    }

    /** The broadcaster's end of one connection. */
    private class Peer(private val socket: Socket, private val closed: CountDownLatch) {
        private val reader = BufferedReader(
            InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8)
        )

        /** One protocol line from the viewer, or null once they have gone. */
        fun readControlLine(): String? = reader.readLine()

        fun writeLine(json: String) {
            socket.getOutputStream().apply {
                write((json + "\n").toByteArray(StandardCharsets.UTF_8))
                flush()
            }
        }

        /**
         * Waits for the viewer to hang up, which is the part that cannot be asserted from the
         * other side: a refusal the viewer has not closed the socket over is a connection the
         * broadcaster still has on its books after the viewer has been told no.
         */
        fun awaitClose() {
            try {
                while (socket.getInputStream().read() != -1) {
                    // Anything else it says is not interesting here.
                }
            } catch (e: IOException) {
                // A reset rather than a clean end, which is a close all the same.
            } finally {
                closed.countDown()
            }
        }
    }

    private fun welcome(access: String) = """
        {"t":"welcome","v":1,"id":"s-1","name":"Test Broadcaster","m":"av","sdp":"","access":"$access"}
    """.trimIndent()

    private fun deny(code: String, reason: String) =
        """{"t":"deny","code":"$code","reason":"$reason"}"""
}