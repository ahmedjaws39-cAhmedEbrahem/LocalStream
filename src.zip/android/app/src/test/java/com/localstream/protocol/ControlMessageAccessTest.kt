package com.localstream.protocol

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * The access handshake, as it looks on the wire.
 *
 * These pin the two rules that make the feature safe to roll out on two platforms at once: a
 * public broadcast stays byte-identical to what it always was, and a missing or unrecognised
 * `access` reads as public rather than as a refusal. Both matter because a receiver decides
 * whether to watch from this field alone, and the two builds of LocalStream are not upgraded
 * together.
 */
class ControlMessageAccessTest {

    private fun welcome(access: String? = null): ControlMessage.Welcome =
        ControlMessage.Welcome(
            sessionId = "s1",
            displayName = "Kitchen",
            mode = LocalStream.MODE_AUDIO_VIDEO,
            sdp = "v=0\r\n",
            access = access ?: ControlMessage.ACCESS_PUBLIC
        )

    private fun roundTrip(message: ControlMessage): ControlMessage =
        ControlMessage.parse(message.toJson().toString())!!

    @Test
    fun `public welcome leaves the access field off the wire`() {
        val json = welcome().toJson()
        assertFalse("a public broadcast must not announce itself as anything else", json.has("access"))
    }

    @Test
    fun `an older broadcaster with no access field reads as public`() {
        val parsed = ControlMessage.parse(
            JSONObject()
                .put("t", "welcome")
                .put("v", LocalStream.PROTOCOL_VERSION)
                .put("id", "s1")
                .put("name", "Kitchen")
                .put("m", LocalStream.MODE_AUDIO_VIDEO)
                .put("sdp", "v=0\r\n")
                .toString()
        ) as ControlMessage.Welcome
        // Silence must not read as "no": an older broadcaster admitted everyone, so its silence
        // is the absence of a lock rather than the presence of one.
        assertEquals(ControlMessage.ACCESS_PUBLIC, parsed.access)
    }

    @Test
    fun `an access value this build does not know reads as public`() {
        val parsed = ControlMessage.parse(
            JSONObject()
                .put("t", "welcome")
                .put("v", LocalStream.PROTOCOL_VERSION)
                .put("id", "s1")
                .put("name", "Kitchen")
                .put("m", LocalStream.MODE_AUDIO_VIDEO)
                .put("sdp", "v=0\r\n")
                .put("access", "telepathy")
                .toString()
        ) as ControlMessage.Welcome
        assertEquals(ControlMessage.ACCESS_PUBLIC, parsed.access)
    }

    @Test
    fun `a locked welcome carries its mode and survives the round trip`() {
        for (mode in listOf(ControlMessage.ACCESS_APPROVAL, ControlMessage.ACCESS_PASSWORD)) {
            val parsed = roundTrip(welcome(mode)) as ControlMessage.Welcome
            assertEquals(mode, parsed.access)
            assertEquals("s1", parsed.sessionId)
            assertEquals("v=0\r\n", parsed.sdp)
        }
    }

    @Test
    fun `an auth request carries the session and the password`() {
        val parsed = roundTrip(ControlMessage.AuthRequest("s1", "hunter2")) as ControlMessage.AuthRequest
        assertEquals("s1", parsed.sessionId)
        assertEquals("hunter2", parsed.password)
    }

    @Test
    fun `a refusal round trips with its reason`() {
        val parsed = roundTrip(ControlMessage.AuthResult(false, "Wrong password."))
            as ControlMessage.AuthResult
        assertFalse(parsed.granted)
        assertEquals("Wrong password.", parsed.reason)
    }

    @Test
    fun `the deny codes the receiver branches on are the documented strings`() {
        // These are the values a receiver matches on, and a viewer branching on a typo silently
        // retries forever, so they are spelled out rather than left to whichever way round they
        // were written.
        assertEquals("access", ControlMessage.DENY_ACCESS)
        assertEquals("auth", ControlMessage.DENY_AUTH)
        assertEquals("blocked", ControlMessage.DENY_BLOCKED)
        val parsed = roundTrip(ControlMessage.Deny(ControlMessage.DENY_BLOCKED, "No."))
            as ControlMessage.Deny
        assertEquals(ControlMessage.DENY_BLOCKED, parsed.code)
        assertEquals("No.", parsed.reason)
    }

    @Test
    fun `password length is bounded`() {
        assertFalse(ControlMessage.isValidPassword(""))
        assertFalse(ControlMessage.isValidPassword("abc"))
        assertTrue(ControlMessage.isValidPassword("abcd"))
        assertTrue(ControlMessage.isValidPassword("0123456789"))
        assertFalse(ControlMessage.isValidPassword("01234567890"))
    }

    @Test
    fun `a line that is not a control message is refused rather than guessed at`() {
        assertNull(ControlMessage.parse("not json"))
        assertNull(ControlMessage.parse("{}"))
    }
}