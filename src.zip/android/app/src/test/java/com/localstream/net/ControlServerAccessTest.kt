package com.localstream.net

import com.localstream.protocol.ControlMessage
import com.localstream.protocol.LocalStream
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.nio.charset.StandardCharsets

/**
 * What the broadcaster does when its broadcast is behind a password.
 *
 * The broadcaster's check is the authoritative one (PROTOCOL.md section 4.4): a receiver that
 * ignores `welcome.access` and offers straight away must still be turned away, and a receiver
 * that offers before its password has been judged must never be admitted. These run against a
 * real socket so the exchange is the one a Windows or Android viewer actually meets.
 */
class ControlServerAccessTest {

    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private var server: ControlServer? = null
    private var socket: Socket? = null

    @After
    fun tearDown() {
        runCatching { socket?.close() }
        socket = null
        server?.close()
        server = null
        scope.cancel()
    }

    private fun startServer(): ControlServer {
        val control = ControlServer(
            scope = scope,
            descriptionProvider = { description() },
            sdpProvider = { "v=0\r\n" },
            audioSsrcProvider = { 1111 },
            videoSsrcProvider = { 2222 },
            onOffer = { _, _, _ -> },
            onRemove = { _, _, _ -> },
            onKeyframeRequest = {},
            onBitrateRequest = { _, _ -> },
            onModeRequest = {},
            onReceiverStats = {},
            onReceiverConnected = {},
            onReceiverDisconnected = {},
            onAccessRequest = { _, _ -> },
            onAccessRequestCancelled = { _, _ -> }
        )
        control.open()
        server = control
        return control
    }

    private fun description() = LocalStream.Description(
        sessionId = "s-test",
        displayName = "Kitchen",
        mode = LocalStream.MODE_AUDIO_VIDEO,
        live = true,
        videoBitrateKbps = 1500,
        audioBitrateKbps = 48,
        width = 1280,
        height = 720,
        frameRate = 30,
        controlPort = server?.port ?: 0,
        audioPort = 45020,
        videoPort = 45040
    )

    private fun connect(): Viewer {
        val viewer = Socket()
        viewer.tcpNoDelay = true
        viewer.connect(InetSocketAddress(InetAddress.getLoopbackAddress(), server!!.port), 5_000)
        socket = viewer
        return Viewer(viewer)
    }

    /** The viewer's end of one control connection. */
    private class Viewer(socket: Socket) {
        private val socket: Socket = socket.apply { soTimeout = 5_000 }
        private val reader = BufferedReader(
            InputStreamReader(this.socket.getInputStream(), StandardCharsets.UTF_8)
        )

        fun send(message: ControlMessage) {
            this.socket.getOutputStream().apply {
                write((message.toJson().toString() + "\n").toByteArray(StandardCharsets.UTF_8))
                flush()
            }
        }

        /** One line from the broadcaster, waiting for it rather than racing it. */
        fun read(): ControlMessage {
            val line = reader.readLine() ?: throw AssertionError("The broadcaster closed the connection.")
            return ControlMessage.parse(line)
                ?: throw AssertionError("Not a control message: $line")
        }

        /** Reads until a message of the wanted type arrives, skipping pushes such as stats. */
        fun readWanted(predicate: (ControlMessage) -> Boolean): ControlMessage {
            repeat(16) {
                val message = read()
                if (predicate(message)) return message
            }
            throw AssertionError("The expected message never arrived.")
        }

        fun close() = socket.close()
    }

    private fun hello(): ControlMessage.Hello =
        ControlMessage.Hello(LocalStream.PROTOCOL_VERSION, "Viewer", "LocalStream-Test/1.0")

    @Test
    fun `a password-protected broadcast announces itself in the welcome`() {
        val control = startServer()
        control.setAccess(ControlMessage.ACCESS_PASSWORD, "abcd")

        val viewer = connect()
        viewer.send(hello())
        val welcome = viewer.readWanted { it is ControlMessage.Welcome } as ControlMessage.Welcome
        assertEquals(ControlMessage.ACCESS_PASSWORD, welcome.access)
        viewer.close()
    }

    /**
     * While the presenter is still choosing a password, a viewer is asked for one but nothing
     * gets them in: the broadcast is shut, not public, until a real password is set.
     */
    @Test
    fun `a broadcast waiting for a password admits nobody`() {
        val control = startServer()
        control.holdForPassword()

        val viewer = connect()
        viewer.send(hello())
        val welcome = viewer.readWanted { it is ControlMessage.Welcome } as ControlMessage.Welcome
        assertEquals(ControlMessage.ACCESS_PASSWORD, welcome.access)

        // Neither an empty password nor a plausible one can match a password that is not set.
        viewer.send(ControlMessage.AuthRequest("s-test", ""))
        assertFalse(
            (viewer.readWanted { it is ControlMessage.AuthResult } as ControlMessage.AuthResult)
                .granted
        )
        viewer.send(ControlMessage.AuthRequest("s-test", "abcd"))
        assertFalse(
            (viewer.readWanted { it is ControlMessage.AuthResult } as ControlMessage.AuthResult)
                .granted
        )

        viewer.send(ControlMessage.Offer("s-test", 51000, 51002))
        val deny = viewer.readWanted { it is ControlMessage.Deny } as ControlMessage.Deny
        assertEquals(ControlMessage.DENY_AUTH, deny.code)
        viewer.close()
    }

    /** A viewer that skips `auth` must not get in by omission - the missing step is named. */
    @Test
    fun `an offer without an auth is refused`() {
        val control = startServer()
        control.setAccess(ControlMessage.ACCESS_PASSWORD, "abcd")

        val viewer = connect()
        viewer.send(hello())
        viewer.readWanted { it is ControlMessage.Welcome }
        viewer.send(ControlMessage.Offer("s-test", 51000, 51002))

        val deny = viewer.readWanted { it is ControlMessage.Deny } as ControlMessage.Deny
        assertEquals(ControlMessage.DENY_AUTH, deny.code)
        viewer.close()
    }

    /** A wrong password is refused, and the offer that follows it is refused too. */
    @Test
    fun `a wrong password does not admit the viewer`() {
        val control = startServer()
        control.setAccess(ControlMessage.ACCESS_PASSWORD, "abcd")

        val viewer = connect()
        viewer.send(hello())
        viewer.readWanted { it is ControlMessage.Welcome }
        viewer.send(ControlMessage.AuthRequest("s-test", "wxyz"))

        val result = viewer.readWanted { it is ControlMessage.AuthResult }
            as ControlMessage.AuthResult
        assertFalse(result.granted)

        viewer.send(ControlMessage.Offer("s-test", 51000, 51002))
        val deny = viewer.readWanted { it is ControlMessage.Deny } as ControlMessage.Deny
        assertEquals(ControlMessage.DENY_AUTH, deny.code)
        viewer.close()
    }

    /** The password the broadcaster was set with is the one that opens it. */
    @Test
    fun `the right password admits the viewer`() {
        val control = startServer()
        control.setAccess(ControlMessage.ACCESS_PASSWORD, "abcd")

        val viewer = connect()
        viewer.send(hello())
        viewer.readWanted { it is ControlMessage.Welcome }
        viewer.send(ControlMessage.AuthRequest("s-test", "abcd"))

        val result = viewer.readWanted { it is ControlMessage.AuthResult }
            as ControlMessage.AuthResult
        assertTrue(result.granted)

        viewer.send(ControlMessage.Offer("s-test", 51000, 51002))
        val accept = viewer.readWanted { it is ControlMessage.Accept } as ControlMessage.Accept
        assertEquals(45020, accept.audioPort)
        assertEquals(45040, accept.videoPort)
        viewer.close()
    }

    /** A second connection from the same device authenticates for itself. */
    @Test
    fun `a granted password does not carry over to a second connection`() {
        val control = startServer()
        control.setAccess(ControlMessage.ACCESS_PASSWORD, "abcd")

        val first = connect()
        first.send(hello())
        first.readWanted { it is ControlMessage.Welcome }
        first.send(ControlMessage.AuthRequest("s-test", "abcd"))
        first.readWanted { it is ControlMessage.AuthResult }
        first.send(ControlMessage.Offer("s-test", 51000, 51002))
        first.readWanted { it is ControlMessage.Accept }
        first.close()

        val second = connect()
        second.send(hello())
        second.readWanted { it is ControlMessage.Welcome }
        second.send(ControlMessage.Offer("s-test", 51004, 51006))
        val deny = second.readWanted { it is ControlMessage.Deny } as ControlMessage.Deny
        assertEquals(ControlMessage.DENY_AUTH, deny.code)
        second.close()
    }
}
