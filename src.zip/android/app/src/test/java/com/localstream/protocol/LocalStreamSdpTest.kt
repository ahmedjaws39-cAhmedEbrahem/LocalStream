package com.localstream.protocol

import org.junit.Assert.assertEquals
import org.junit.Test

/**
 * The audio channel count the receiver reads out of the broadcaster's welcome SDP.
 *
 * An Opus packet carries no channel layout, so the decoder can only be configured from the
 * SDP. Not reading it made a mono broadcast decode on a stereo layout, so the exact field is
 * pinned here against the layouts the Windows client actually emits.
 */
class LocalStreamSdpTest {

    private fun description(audioChannels: Int) = LocalStream.Description(
        sessionId = "test",
        displayName = "Broadcaster",
        mode = LocalStream.MODE_AUDIO_VIDEO,
        live = true,
        videoBitrateKbps = 1500,
        audioBitrateKbps = 48,
        width = 1280,
        height = 720,
        frameRate = 30,
        controlPort = 4000,
        audioPort = 4002,
        videoPort = 4004,
        audioChannels = audioChannels
    )

    @Test
    fun `Android microphone SDP advertises mono`() {
        val sdp = LocalStream.buildSdp(description(audioChannels = 1), 4000, 1, 2)
        assertEquals(1, LocalStream.audioChannelsFromSdp(sdp))
    }

    @Test
    fun `Android device audio SDP advertises stereo`() {
        val sdp = LocalStream.buildSdp(description(audioChannels = 2), 4000, 1, 2)
        assertEquals(2, LocalStream.audioChannelsFromSdp(sdp))
    }

    @Test
    fun `mono broadcaster is read as one channel`() {
        val sdp = "v=0\r\n" +
            "m=audio 0 RTP/AVP 97\r\n" +
            "a=rtpmap:97 opus/48000/1\r\n"
        assertEquals(1, LocalStream.audioChannelsFromSdp(sdp))
    }

    @Test
    fun `stereo broadcaster is read as two channels`() {
        val sdp = "a=rtpmap:97 opus/48000/2\r\n"
        assertEquals(2, LocalStream.audioChannelsFromSdp(sdp))
    }

    @Test
    fun `video rtpmap is not mistaken for the audio one`() {
        val sdp = "m=video 0 RTP/AVP 96\r\n" +
            "a=rtpmap:96 H264/90000\r\n" +
            "m=audio 0 RTP/AVP 97\r\n" +
            "a=rtpmap:97 opus/48000/1\r\n"
        assertEquals(1, LocalStream.audioChannelsFromSdp(sdp))
    }

    @Test
    fun `missing sdp falls back to stereo`() {
        assertEquals(2, LocalStream.audioChannelsFromSdp(""))
    }

    @Test
    fun `sdp without an audio rtpmap falls back to stereo`() {
        assertEquals(2, LocalStream.audioChannelsFromSdp("a=rtpmap:96 H264/90000\r\n"))
    }

    @Test
    fun `an out of range channel count falls back to stereo`() {
        assertEquals(2, LocalStream.audioChannelsFromSdp("a=rtpmap:97 opus/48000/3\r\n"))
    }

    @Test
    fun `a malformed audio rtpmap falls back to stereo`() {
        assertEquals(2, LocalStream.audioChannelsFromSdp("a=rtpmap:97 opus\r\n"))
    }
}
