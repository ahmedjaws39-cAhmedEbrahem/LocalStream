package com.localstream.engine

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * The automatic gain control.
 *
 * A receiver must hear the broadcast at the same level whatever the source device delivers.
 * Device-audio capture carries the post-volume signal, so a quiet source is exactly what a
 * broadcaster whose system volume is turned down produces. The properties pinned here are the
 * ones that make that true: a quiet source is lifted, a loud and a quiet source converge, and
 * silence is left alone rather than amplified.
 */
class AudioNormalizerTest {

    private fun sinePcm(amplitude: Double, samples: Int, startSample: Int = 0): ByteArray {
        val pcm = ByteArray(samples * 2)
        for (i in 0 until samples) {
            val t = (startSample + i) / 48000.0
            val value = (amplitude * sin(2 * Math.PI * 440 * t)).toInt()
            pcm[i * 2] = (value and 0xFF).toByte()
            pcm[i * 2 + 1] = ((value shr 8) and 0xFF).toByte()
        }
        return pcm
    }

    private fun sampleAt(pcm: ByteArray, index: Int): Int =
        (pcm[index * 2].toInt() and 0xFF) or (pcm[index * 2 + 1].toInt() shl 8)

    private fun rms(pcm: ByteArray, samples: Int): Double {
        var sum = 0.0
        for (i in 0 until samples) sum += Math.pow(sampleAt(pcm, i) / 32768.0, 2.0)
        return sqrt(sum / samples)
    }

    /** Runs the normaliser over [frames] 20 ms frames and returns the last frame's RMS. */
    private fun settledRms(amplitude: Double, frames: Int = 80): Double {
        val normalizer = AudioNormalizer()
        var last = ByteArray(0)
        for (frame in 0 until frames) {
            val pcm = sinePcm(amplitude, 960, frame * 960)
            normalizer.process(pcm, 960)
            last = pcm
        }
        return rms(last, 960)
    }

    @Test
    fun `a quiet source is lifted toward the target`() {
        // -31 dBFS in, so a pass-through would leave it inaudible.
        val quiet = settledRms(800.0)
        assertTrue("quiet source stayed at $quiet", quiet > 0.06)
    }

    @Test
    fun `a loud source and a quiet source converge`() {
        val quiet = settledRms(800.0)
        val loud = settledRms(20000.0)
        val ratio = if (loud > quiet) loud / quiet else quiet / loud
        assertTrue("quiet=$quiet loud=$loud ratio=$ratio", ratio < 2.5)
    }

    @Test
    fun `silence is not amplified into noise`() {
        // A zero-level frame must hold the gain rather than drive it to the ceiling, which would
        // lift the device's noise floor into every pause.
        val normalizer = AudioNormalizer()
        val pcm = ByteArray(960 * 2)
        normalizer.process(pcm, 960)
        assertTrue(pcm.all { it == 0.toByte() })
    }

    @Test
    fun `one gain is applied to both channels`() {
        // A scalar gain keeps the channels' relative levels, so a stereo image survives. A
        // per-channel normaliser would pull both to the target and collapse the balance.
        val normalizer = AudioNormalizer()
        val frames = 960
        val pcm = ByteArray(frames * 4)
        for (f in 0 until frames) {
            val angle = 2 * Math.PI * 440 * f / 48000.0
            val left = (8000.0 * sin(angle)).toInt()
            val right = (2000.0 * sin(angle)).toInt()
            pcm[f * 4] = (left and 0xFF).toByte()
            pcm[f * 4 + 1] = ((left shr 8) and 0xFF).toByte()
            pcm[f * 4 + 2] = (right and 0xFF).toByte()
            pcm[f * 4 + 3] = ((right shr 8) and 0xFF).toByte()
        }
        normalizer.process(pcm, frames * 2)

        var left = 0.0
        var right = 0.0
        for (f in 0 until frames) {
            val l = ((pcm[f * 4].toInt() and 0xFF) or (pcm[f * 4 + 1].toInt() shl 8)) / 32768.0
            val r = ((pcm[f * 4 + 2].toInt() and 0xFF) or (pcm[f * 4 + 3].toInt() shl 8)) / 32768.0
            left += l * l
            right += r * r
        }
        assertEquals(0.25, sqrt(right) / sqrt(left), 0.02)
    }
}
