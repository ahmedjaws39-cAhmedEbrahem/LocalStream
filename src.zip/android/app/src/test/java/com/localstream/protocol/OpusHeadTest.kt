package com.localstream.protocol

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Test

/**
 * The decoder-configuration header.
 *
 * Two bugs made received audio silent while the AudioTrack still reported `state:started`.
 * First the Android Opus decoder needs a CSD `OpusHead` and fails its first input with err -14
 * without one. Then, with only the bare header, `C2SoftOpusDec` reads the codec delay and
 * seek pre-roll from the first two audio packets and discards every decoded frame. Both values
 * are exact byte layouts, so the tests pin them.
 */
class OpusHeadTest {

    private fun bytes(vararg values: Int) = ByteArray(values.size) { values[it].toByte() }

    private fun ascii(source: ByteArray, offset: Int, length: Int) =
        String(source, offset, length, Charsets.US_ASCII)

    private fun littleEndianLong(source: ByteArray, offset: Int): Long {
        var value = 0L
        for (i in 0 until 8) value = value or ((source[offset + i].toLong() and 0xFF) shl (8 * i))
        return value
    }

    @Test
    fun `stereo header matches the RFC 7845 layout`() {
        // "OpusHead", version 1, 2 channels, pre-skip 0, 48000 Hz LE, gain 0, mapping 0.
        val expected = bytes(
            0x4F, 0x70, 0x75, 0x73, 0x48, 0x65, 0x61, 0x64,
            0x01, 0x02, 0x00, 0x00,
            0x80, 0xBB, 0x00, 0x00,
            0x00, 0x00, 0x00
        )
        assertArrayEquals(expected, OpusHead.build(2))
    }

    @Test
    fun `the header is nineteen bytes`() {
        assertEquals(OpusHead.SIZE, OpusHead.build(2).size)
        assertEquals(19, OpusHead.SIZE)
    }

    @Test
    fun `the channel count byte reflects the request`() {
        assertEquals(1, OpusHead.build(1)[9].toInt())
        assertEquals(2, OpusHead.build(2)[9].toInt())
    }

    @Test(expected = IllegalArgumentException::class)
    fun `more than two channels requires a stream map we do not send`() {
        OpusHead.build(3)
    }

    @Test
    fun `the unified codec config is the layout C2SoftOpusDec reads`() {
        val config = OpusHead.buildCodecConfig(2)

        assertEquals(83, OpusHead.CODEC_CONFIG_SIZE)
        assertEquals(OpusHead.CODEC_CONFIG_SIZE, config.size)

        // "AOPUSHDR" | uint64 19 | OpusHead
        assertEquals("AOPUSHDR", ascii(config, 0, 8))
        assertEquals(19L, littleEndianLong(config, 8))
        assertArrayEquals(OpusHead.build(2), config.copyOfRange(16, 16 + OpusHead.SIZE))

        // "AOPUSDLY" | uint64 8 | codec delay
        assertEquals("AOPUSDLY", ascii(config, 35, 8))
        assertEquals(8L, littleEndianLong(config, 43))

        // "AOPUSPRL" | uint64 8 | seek pre-roll
        assertEquals("AOPUSPRL", ascii(config, 59, 8))
        assertEquals(8L, littleEndianLong(config, 67))
    }

    @Test
    fun `codec delay and pre-roll are little-endian nanosecond values`() {
        val config = OpusHead.buildCodecConfig(
            2,
            codecDelayNs = 0x0102030405060708L,
            seekPreRollNs = 0x1112131415161718L
        )
        assertEquals(0x0102030405060708L, littleEndianLong(config, 51))
        assertEquals(0x1112131415161718L, littleEndianLong(config, 75))
    }

    @Test
    fun `a live stream trims nothing at startup`() {
        val config = OpusHead.buildCodecConfig(2)
        assertEquals(0L, littleEndianLong(config, 51)) // codec delay
        assertEquals(0L, littleEndianLong(config, 75)) // seek pre-roll
    }
}
