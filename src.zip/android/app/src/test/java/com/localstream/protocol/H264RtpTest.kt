package com.localstream.protocol

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * NAL unit framing.
 *
 * The cases here are the ones a real device produced. `MediaCodec` on several encoders hands
 * over start-code delimited data where the AVC contract specifies length prefixes, and
 * passing that through unchanged drops every picture while still looking like a healthy
 * stream: packets arrive, nothing decodes, nothing errors. A unit test is the only place this
 * is cheap to pin down, because the device only reveals it after a full broadcast.
 */
class H264RtpTest {

    // Written as signed bytes: the payloads carry values above 0x7F, and an unsigned literal
    // does not convert to Byte without an explicit toByte().
    private fun sps(): ByteArray = byteArrayOf(0x67, 0x42, -0x40, 0x1E, -0x27)
    private fun pps(): ByteArray = byteArrayOf(0x68, -0x32, 0x3C, -0x80)
    private fun idr(): ByteArray = byteArrayOf(0x65, -0x78, -0x7C, 0x00, 0x33)

    private fun annexB(vararg units: ByteArray): ByteArray {
        val out = ArrayList<Byte>()
        for (unit in units) {
            out.addAll(listOf<Byte>(0, 0, 0, 1))
            out.addAll(unit.map { it })
        }
        return out.toByteArray()
    }

    private fun avcc(vararg units: ByteArray): ByteArray {
        val out = ArrayList<Byte>()
        for (unit in units) {
            out.addAll(
                listOf(
                    (unit.size ushr 24).toByte(),
                    (unit.size ushr 16).toByte(),
                    (unit.size ushr 8).toByte(),
                    unit.size.toByte()
                )
            )
            out.addAll(unit.map { it })
        }
        return out.toByteArray()
    }

    @Test
    fun `stripStartCode removes the four byte form`() {
        val withCode = byteArrayOf(0, 0, 0, 1) + sps()
        assertArrayEquals(sps(), H264Rtp.stripStartCode(withCode))
    }

    @Test
    fun `stripStartCode removes the three byte form`() {
        val withCode = byteArrayOf(0, 0, 1) + sps()
        assertArrayEquals(sps(), H264Rtp.stripStartCode(withCode))
    }

    @Test
    fun `stripStartCode leaves a bare NAL unit alone`() {
        assertArrayEquals(sps(), H264Rtp.stripStartCode(sps()))
    }

    @Test
    fun `a stripped parameter set reports its real NAL type`() {
        // The bug this guards: with the start code in place the type reads as 0, so a receiver
        // never treats the unit as a parameter set and no decoder is ever opened.
        assertEquals(H264Rtp.NAL_SPS, H264Rtp.nalType(H264Rtp.stripStartCode(annexB(sps()))))
        assertEquals(H264Rtp.NAL_PPS, H264Rtp.nalType(H264Rtp.stripStartCode(annexB(pps()))))
    }

    @Test
    fun `toAvcc leaves length prefixed input untouched`() {
        val input = avcc(idr())
        assertTrue("expected the same instance back", input === H264Rtp.toAvcc(input))
    }

    @Test
    fun `toAvcc converts a start code delimited access unit`() {
        val converted = H264Rtp.toAvcc(annexB(sps(), pps(), idr()))
        assertArrayEquals(avcc(sps(), pps(), idr()), converted)
    }

    @Test
    fun `toAvcc splits every unit of a multi unit access unit`() {
        val slice = ByteArray(3000) { (it and 0xFF).toByte() }
        val converted = H264Rtp.toAvcc(annexB(sps(), idr(), slice))
        val units = H264Rtp.splitAvcc(converted)
        assertEquals(3, units.size)
        assertArrayEquals(sps(), units[0])
        assertArrayEquals(idr(), units[1])
        assertArrayEquals(slice, units[2])
    }

    @Test
    fun `a converted access unit survives packetization as a decodable picture`() {
        // The end-to-end shape of the device bug: Annex B in, nothing usable out, because the
        // leading start code reads as a length of 1 and the slice is taken to be one header byte.
        val payloads = H264Rtp.packetize(H264Rtp.splitAvcc(H264Rtp.toAvcc(annexB(sps(), pps(), idr()))))
        assertTrue("expected more than one payload", payloads.size > 1)
        assertEquals(
            "the parameter sets must aggregate into a STAP-A ahead of the slice",
            H264Rtp.TYPE_STAP_A,
            H264Rtp.nalType(payloads.first())
        )
    }

    @Test
    fun `withParameterSets puts both sets ahead of the picture`() {
        val units = H264Rtp.splitAvcc(H264Rtp.withParameterSets(avcc(idr()), sps(), pps()))
        assertEquals(3, units.size)
        assertArrayEquals(sps(), units[0])
        assertArrayEquals(pps(), units[1])
        assertArrayEquals(idr(), units[2])
    }

    @Test
    fun `withParameterSets is a no-op when the sets are not known yet`() {
        val input = avcc(idr())
        assertTrue(input === H264Rtp.withParameterSets(input, null, null))
        assertTrue(input === H264Rtp.withParameterSets(input, sps(), null))
        assertTrue(input === H264Rtp.withParameterSets(input, ByteArray(0), pps()))
    }

    @Test
    fun `a keyframe packetizes with the marker on the last payload`() {
        val payloads = H264Rtp.packetize(
            H264Rtp.splitAvcc(H264Rtp.withParameterSets(avcc(idr()), sps(), pps()))
        )
        // Every payload is a whole access unit here, so the last one carries the marker bit.
        assertEquals(H264Rtp.TYPE_STAP_A, H264Rtp.nalType(payloads[0]))
    }

    @Test
    fun `discarding a lost FU-A frame keeps its fragments out of the next frame`() {
        val fragments = H264Rtp.packetize(listOf(ByteArray(2000) { (it and 0xFF).toByte() }
            .also { it[0] = H264Rtp.NAL_SLICE_IDR.toByte() }))
        assertTrue(fragments.size > 1)
        val depacketizer = H264Rtp.Depacketizer()

        assertEquals(null, depacketizer.accept(fragments.first(), marker = false))
        depacketizer.discardCurrentAccessUnit()
        assertEquals(null, depacketizer.accept(fragments.last(), marker = true))
        assertArrayEquals(annexB(idr()), depacketizer.accept(idr(), marker = true))
    }
}
