package com.localstream.protocol

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * The guard that keeps a broadcast from going live unlocked.
 *
 * These are the cases the presenter's Start path has to get right: a password that was chosen but
 * not applied must never turn into a public broadcast, whatever the password field happens to
 * hold at the moment Start is pressed.
 */
class BroadcastAccessPolicyTest {

    private fun decide(
        accessPending: Boolean,
        mode: String = ControlMessage.ACCESS_PASSWORD,
        password: String = ""
    ) = BroadcastAccessPolicy.beforeStart(accessPending, mode, password)

    @Test
    fun `nothing pending starts as the current setting`() {
        assertEquals(
            BroadcastAccessPolicy.StartDecision.Proceed,
            decide(accessPending = false)
        )
    }

    @Test
    fun `a pending public choice is already in force`() {
        assertEquals(
            BroadcastAccessPolicy.StartDecision.Proceed,
            decide(accessPending = true, mode = ControlMessage.ACCESS_PUBLIC)
        )
    }

    @Test
    fun `a pending approval choice is already in force`() {
        assertEquals(
            BroadcastAccessPolicy.StartDecision.Proceed,
            decide(accessPending = true, mode = ControlMessage.ACCESS_APPROVAL)
        )
    }

    @Test
    fun `a pending password that is long enough is applied`() {
        assertEquals(
            BroadcastAccessPolicy.StartDecision.ApplyPassword("abcd"),
            decide(accessPending = true, password = "abcd")
        )
    }

    @Test
    fun `a password at either limit is accepted`() {
        assertEquals(
            BroadcastAccessPolicy.StartDecision.ApplyPassword("1234"),
            decide(accessPending = true, password = "1234")
        )
        assertEquals(
            BroadcastAccessPolicy.StartDecision.ApplyPassword("1234567890"),
            decide(accessPending = true, password = "1234567890")
        )
    }

    /** The reported defect: a broadcast opened while the field held too few characters. */
    @Test
    fun `a short pending password refuses to start`() {
        val decision = decide(accessPending = true, password = "abc")
        assertTrue(decision is BroadcastAccessPolicy.StartDecision.Refuse)
        assertTrue((decision as BroadcastAccessPolicy.StartDecision.Refuse).message.isNotEmpty())
    }

    @Test
    fun `an empty pending password refuses to start`() {
        assertTrue(decide(accessPending = true, password = "") is BroadcastAccessPolicy.StartDecision.Refuse)
    }

    @Test
    fun `a password over the limit refuses to start`() {
        assertTrue(
            decide(accessPending = true, password = "12345678901")
                is BroadcastAccessPolicy.StartDecision.Refuse
        )
    }
}
