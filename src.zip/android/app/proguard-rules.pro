# The protocol layer is plain Kotlin with no reflection, so the default rules suffice.
# Keep model classes that are parsed from JSON intact even though they are not referenced
# by name anywhere, so R8 cannot infer they are dead.
-keepclassmembers class com.localstream.protocol.** { *; }
-keep class com.localstream.protocol.** { *; }

# Service entry points are resolved by name from the manifest.
-keep class com.localstream.engine.BroadcastService { *; }

# Kotlin coroutines internals referenced only via service loader.
-keepclassmembers class kotlinx.coroutines.** { volatile <fields>; }
-dontwarn kotlinx.coroutines.**
