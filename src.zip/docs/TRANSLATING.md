# Translating LocalStream

LocalStream ships its interface in English and, additionally, in the languages listed in the
table at the bottom of this page. This document is for whoever adds the next one: what to
translate, where the files live, and the wording already agreed on so that the Windows app, the
Android app and the tutorial all say the same thing in the same language.

## How a language is stored

Each platform uses its own native mechanism, because each one is standard there and none of them
needs a tool that is not already in the repository.

| Platform | Where the strings live | How they are applied |
| --- | --- | --- |
| Windows (Qt 6 Widgets) | `windows/translations/localstream_<code>.ts` — XML, the Qt Linguist format | `lrelease` compiles a `.ts` into a `.qm` at build time (`qt_add_translations` in `windows/CMakeLists.txt`) and the `.qm` is embedded in `LocalStream.exe` as a Qt resource under `:/i18n/`. `windows/src/ui/Language.cpp` installs the right `QTranslator` at start-up. |
| Android (Jetpack Compose) | `android/app/src/main/res/values-<code>/strings.xml` | The usual Android resource lookup. The chosen language is applied by wrapping the base context (`-` `ui/AppLanguage.kt`), so the resource system picks the right folder without the phone's own language having to change. |
| The tutorial page (`docs/Tutorial.html`) | `docs/Tutorial-<code>.html` and `android/app/src/main/assets/Tutorial-<code>.html` | The app hands the browser (Windows) or another app (Android) the file matching the language in effect, falling back to English. `Tutorial.html` itself is always the English original. |

English is the source language: there is no `en` translation file, because the strings in the code
*are* English. A missing translation falls back to English at run time rather than showing an empty
label, so a language may be added or completed a piece at a time.

## The exact commands

These are the commands that produced the shipped translations. Windows PowerShell.

### Windows

Re-extract the source strings after the interface has changed. `lupdate` treats every argument
after `-ts` as another `.ts` file, so `-ts` has to come **last**, and a directory argument is not
accepted: pass the files.

    $root = 'D:\programs\projects by AI\Brodcast'
    $lupdate = Join-Path $root 'tools\qt\6.8.3\msvc2022_64\bin\lupdate.exe'
    $files = @(Get-ChildItem -Path (Join-Path $root 'windows\src') -Recurse -Include *.cpp,*.h |
               ForEach-Object { $_.FullName })
    foreach ($code in @('ar','fr','ru','tr')) {
        $ts = Join-Path $root "windows\translations\localstream_$code.ts"
        & $lupdate -no-obsolete -locations relative -source-language en -target-language $code `
                   @files -ts $ts
    }

Then build. `windows/CMakeLists.txt` runs `lrelease` over each `.ts` and embeds the resulting `.qm`
files under `:/i18n/localstream_<code>.qm`, which is where `Language.cpp` loads them from.

### Android

`res/values/strings.xml` is the English source. Translate it into `res/values-<code>/strings.xml`,
keeping every `name` identical; a name that is missing falls back to English. An apostrophe has to
be written `\'` and `&` as `&amp;`, or `aapt` refuses the build.

### Tutorial

`docs/Tutorial.html` (Windows) and `android/app/src/main/assets/Tutorial.html` (Android) are two
different documents, not one file kept in two places: the Android page has no "closing the window"
section and no "About this build" table, because neither applies there. Translate each from its own
source, and reuse the Windows translation's wording where the sentences are identical.

## Adding a language

1. **Windows.** Add `<code>` to the table in `windows/src/ui/Language.cpp` (the display name is the
   language's own name, never the English one: a French user looking for their language looks for
   *Français*). Create the file with the `lupdate` command above.
2. **Android.** Add `android/app/src/main/res/values-<code>/strings.xml`, and add the language to
   `android/app/src/main/java/com/localstream/ui/AppLanguage.kt`.
3. **Tutorial.** Translate both `Tutorial.html` files into `Tutorial-<code>.html` beside each of
   them. Translate only the visible text: the stylesheet, the element ids and the anchors are what
   ties the two copies together and must not change.
4. Nothing else. Neither the installer nor either build script lists translation files by hand: the
   Windows files are embedded in the executable and the Android ones are in the APK's resources.

## Right-to-left languages

Arabic, Persian, Hebrew and Urdu are written right to left and the whole interface has to be
mirrored for them, not just the text. On Windows that is `Qt::RightToLeft`, set from the language
in `Language.cpp` before the first window is built, plus the handful of places that position a
widget by hand. On Android the equivalent is a `Configuration` with the locale and the layout
direction set, which `AppLanguage.kt` builds.

A page whose text reads right to left but whose layout does not is worse than an untranslated one,
so when adding one of these languages, check both applications with the screen reader before
calling it done.

## Wording

Translated languages must agree with each other. These are the words already in use, and a new
language should follow them rather than inventing a synonym; the tutorial refers to the same
controls by the same names, and a reader who meets two words for one button learns neither.

| English | العربية | Français | Русский | Türkçe |
| --- | --- | --- | --- | --- |
| LocalStream (product name) | LocalStream | LocalStream | LocalStream | LocalStream |
| broadcast (noun) | بثّ | diffusion | трансляция | yayın |
| broadcast (verb) | يبثّ | diffuser | транслировать | yayınlamak |
| broadcaster (the sender) | المُبثِّث | l'émetteur | вещатель | yayıncı |
| viewer (the watcher) | المشاهد | le spectateur | зритель | izleyici |
| receive / watch | استقبال / مشاهدة | recevoir / regarder | приём / смотреть | alma / izleme |
| screen | الشاشة | l'écran | экран | ekran |
| audio | الصوت | l'audio | звук | ses |
| camera | الكاميرا | la caméra | камера | kamera |
| device | الجهاز | l'appareil | устройство | cihaz |
| network | الشبكة | le réseau | сеть | ağ |
| password | كلمة المرور | le mot de passe | пароль | parola |
| system tray | شريط النظام | la zone de notification | системный трей | sistem tepsisi |
| background | في الخلفية | en arrière-plan | в фоне | arka planda |
| firewall | جدار الحماية | le pare-feu | брандмауэр | güvenlik duvarı |
| shortcut | الاختصار | le raccourci | ярлык | kısayol |
| installer / setup | المُثبِّت | l'installateur | установщик | kurulum |
| theme (colours) | السمة | le thème | тема | tema |
| quality | الجودة | la qualité | качество | kalite |
| frame rate | معدل الإطارات | la fréquence d'images | частота кадров | kare hızı |
| bitrate | معدل البتّات | le débit | битрейт | bit hızı |
| delay / latency | التأخير | la latence | задержка | gecikme |
| tutorial / help | الشرح | le didacticiel | руководство | kılavuz |
| report (diagnostics) | التقرير | le rapport | отчёт | rapor |
| log file | ملف السجل | le fichier journal | файл журнала | günlük dosyası |
| settings | الإعدادات | les réglages | настройки | ayarlar |
| start | ابدأ | Démarrer | Запустить | Başlat |
| stop | إيقاف | Arrêter | Остановить | Durdur |
| connect | اتصال | se connecter | подключиться | bağlan |
| battery optimisation | تحسين استهلاك البطارية | l'optimisation de la batterie | оптимизация батареи | pil optimizasyonu |

## What is deliberately not translated

- **Log lines and the diagnostic report.** They are read by whoever is diagnosing a problem, and
  a report that is in a language the developer cannot read is worth less than one that is not.
   The report's *field labels* follow the interface language only when the user chose to translate
   the interface; the log itself never does. Keeping the on-disk log in one language across
   platforms is also what makes two reports from two phones comparable.
   (The report body on the Help tab is English for the same reason.)

## The languages that ship

| Language | Code | Windows | Android | Tutorial |
| --- | --- | --- | --- | --- |
| English (source) | `en` | — | `values/` | `Tutorial.html` |
| العربية | `ar` | `localstream_ar.ts` | `values-ar/` | `Tutorial-ar.html` |
| Français | `fr` | `localstream_fr.ts` | `values-fr/` | `Tutorial-fr.html` |
| Русский | `ru` | `localstream_ru.ts` | `values-ru/` | `Tutorial-ru.html` |
| Türkçe | `tr` | `localstream_tr.ts` | `values-tr/` | `Tutorial-tr.html` |
