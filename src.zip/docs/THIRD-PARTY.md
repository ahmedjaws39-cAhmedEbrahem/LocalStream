# Third-party components

LocalStream is distributed under the GNU GPL v3 (see [../LICENSE](../LICENSE)). It uses the
components below. Nothing here is stored in this repository: the toolchain is downloaded into
`tools/` by `tools/fetch-toolchain.ps1` and is git-ignored. **A binary distribution must carry
the license text of each component it actually links.**

## Linked by the Windows build

| Component | Used for | License | Notes |
| --- | --- | --- | --- |
| Qt 6.8.3 — Core, Gui, Widgets, Network | The entire user interface and networking | LGPL v3 | Linked as DLLs, so the LGPL condition of allowing the user to replace them is met; the Qt sources are at <https://qt.io>. The license text is kept at [../licenses/LGPL-3.0.txt](../licenses/LGPL-3.0.txt) because the Qt download does not carry it. |
| FFmpeg 9.0 (BtbN shared build) — libavcodec, libavformat, libavutil, libswscale, libswresample | H.264 decoding, audio resampling | **GPL v3** (built with `--enable-gpl`) | This is what makes the whole Windows program GPL. `tools/fetch-toolchain.ps1` pins the exact build it downloads. |
| libx264 (inside the FFmpeg build) | H.264 encoding | GPL v2 or later | |
| libopus (inside the FFmpeg build) | Opus encoding and decoding | BSD 3-Clause | |
| Microsoft Visual C++ 2022 runtime (`msvcp140*.dll`, `vcruntime140*.dll`, `concrt140.dll`, `vccorlib140.dll`) | The standard library every one of the above is built against | Microsoft Visual Studio redistributable license | Copied beside the exe rather than left for the machine to supply, so the installed program needs no Visual C++ redistributable. Redistribution of these files is what the license is for; the text is installed with Visual Studio under `VC\Redist`. |
| `opengl32sw.dll`, `d3dcompiler_47.dll`, `dxcompiler.dll`, `dxil.dll` | The software OpenGL fallback and the Direct3D render backends Qt can fall back to | as published by their authors (Mesa for `opengl32sw`; Microsoft's redistributable components for the rest) | Placed beside the exe by Qt's own `windeployqt`, which decides what the binary may need. The authoritative licence texts ship with the Qt and Visual Studio installations they are copied from. |

The FFmpeg license text is `tools/ffmpeg/LICENSE.txt`, kept beside its download; the Qt LGPL
text is in [../licenses/LGPL-3.0.txt](../licenses/LGPL-3.0.txt). `tools/package-windows.ps1`
copies both into the packaged build, and with them the C++ runtime DLLs listed above.

## Linked by the Android build

| Component | License |
| --- | --- |
| AndroidX Core, Activity, Lifecycle | Apache-2.0 |
| Jetpack Compose (UI, Material 3, Material Icons) | Apache-2.0 |
| AndroidX CameraX (core, camera2, lifecycle) | Apache-2.0 |
| kotlinx.coroutines | Apache-2.0 |
| Kotlin standard library | Apache-2.0 |

The Android platform's own codecs (`MediaCodec`) are part of the operating system, not
redistributed.

## Test-only, not distributed

| Component | License |
| --- | --- |
| JUnit 4 | Eclipse Public License 1.0 |
| org.json | JSON License |

These run in the build only and are absent from the shipped APK and AAB.
