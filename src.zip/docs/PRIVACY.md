# Privacy

LocalStream is built so that there is nothing to have a privacy policy about. It collects no
data, has no account, and never contacts a server.

## What the app does with your data

- **Nothing leaves your network.** A broadcast travels directly from the broadcasting device to
  the device watching it, over your own local network. There is no relay, no cloud, and no
  analytics.
- **No internet connection is used or required.** The apps work with the internet disconnected.
- **No personal data is collected, stored on a server, or shared with anyone.** There is no
  account, no sign-in, no advertising, and no third-party analytics or crash reporting.

## Permissions, and why each one is asked for

| Permission | Why it is needed | When it is used |
| --- | --- | --- |
| Microphone | To capture the sound of a broadcast. | Only while you are broadcasting with audio. |
| Camera | To capture a camera feed. | Only while you are broadcasting the camera. |
| Screen capture | To capture the screen. | Only while you are broadcasting the screen. Android asks each time, and the grant cannot be reused. |
| Local network (Android: Nearby Wi-Fi; Windows: Firewall) | To find other devices and to send or receive the stream. | While the app is running. |
| Notifications (Android) | To show a running broadcast and offer a Stop button. | Only while broadcasting. |

A capture permission that is never used is never asked for: the app requests the microphone
only for an audio broadcast, and the camera only for a camera broadcast.

## What is written to the device

The apps write a plain-text **log** and, on request, a **diagnostics report** to their own
app-data folder on the device. These exist to help you describe a problem, and they stay on the
device until you delete them or uninstall the app. They are never uploaded automatically. You
can write a report, look at it, and choose whether to share it.

## Children

The app is a general-purpose screen-and-sound sharing tool. It is not directed at children and
collects no data from anyone.

## Changes

If this ever stops being true — if a future version were to add, say, an optional online
directory — this page would be updated before that version shipped, and the change would be
listed in the project's `CHANGELOG.md`.

## Contact

Questions or reports: open an issue in the project's repository.
