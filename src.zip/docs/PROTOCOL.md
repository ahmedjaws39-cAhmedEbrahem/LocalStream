# LocalStream Wire Protocol v1

Transport-agnostic specification shared by the Windows (Qt/C++) and Android (Kotlin) clients.

The goal is sub-300 ms end-to-end latency on a local Wi-Fi LAN with **no cloud, no
signalling server, and no third-party media server process**.

---

## 1. Design rationale

| Concern | Decision | Why |
| --- | --- | --- |
| Discovery | mDNS / DNS-SD, `_localstream._tcp.local.` | Zero configuration, no router changes, standard. |
| Media | Raw RTP over UDP (RFC 3550) | Lowest achievable latency (~40-120 ms glass-to-glass on LAN). No container, no server, no demuxer. |
| Session control | Newline-delimited JSON over TCP | Reliable, ordered, connection-oriented; trivial on both platforms (`QJsonDocument`, `org.json`). |
| Session topology | Receiver-driven offer/accept | Receiver picks its own UDP ports. Avoids multicast (often filtered on Wi-Fi APs) and avoids AP client isolation issues. |
| Keyframe latency | Explicit control-channel keyframe request | Without this, a receiver joining mid-GOP waits for the next IDR — the single largest source of join latency. |

**Explicitly rejected:** RTSP/MediaMTX (needs a server process somewhere, 300-800 ms), WebRTC
(needs signalling, heavy embed, 200-500 ms), raw length-prefixed UDP (no timestamps, no
standard tooling).

---

## 2. Service discovery

Service type: **`_localstream._tcp.local.`**

*(Valid per RFC 6335: `_localstream` is 11 characters, letters only, within the 15-char limit.)*

### 2.1 Record set published by a broadcaster

| Record | Name | Contents |
| --- | --- | --- |
| PTR | `_localstream._tcp.local.` | → instance name |
| SRV | `<instance>._localstream._tcp.local.` | priority 0, weight 0, **port = control port**, target = `<host>.local.` |
| TXT | `<instance>._localstream._tcp.local.` | key/value metadata, below |
| A/AAAA | `<host>.local.` | IP address(es) |

The instance name **must be unique per broadcasting session**, not per machine: a
broadcaster that reuses the same instance name across restarts will be served from peers'
mDNS caches, which keep the old SRV and TXT — a control port from a process that no longer
exists. The receiver would then find a broadcaster that cannot be connected to, and retrying
would not help because the cache entry survives the retry. A session-unique name makes a
restart a different record, so the stale one simply expires.

The user-visible name stays in the TXT record, so the extra uniqueness does not reach the
interface. When constructing the label, the session id belongs in its own DNS label: escaping
the `.` that joins them (`Ahmed\.a3f19c04`) produces one label containing a literal
backslash, which is a different name from the two labels it was meant to be, and the
resolver will not match it.

`live` in the TXT record must reflect whether media is actually being sent. A broadcaster
that advertises `live=0` while a session is running is listed by receivers as idle, which
is indistinguishable from "found but not started".

### 2.2 TXT key/value schema

Total serialised TXT must stay under 255 bytes so it fits comfortably in a single
mDNS packet on all stacks.

| Key | Type | Example | Meaning |
| --- | --- | --- | --- |
| `v` | int | `1` | Protocol version. Receiver refuses anything else. |
| `id` | hex8 | `a3f19c04` | Session id, regenerated every time broadcasting **starts**. |
| `n` | string | `Ada%20Laptop` | Display name, percent-escaped, max 32 bytes. |
| `m` | enum | `av` \| `a` | Mode: audio+video, or audio-only. |
| `vid` | enum | `h264` | Video codec. Omitted in audio-only mode. |
| `aud` | enum | `opus` | Audio codec. |
| `vbr` | int | `1500` | Target video bitrate, kbps. |
| `abr` | int | `48` | Target audio bitrate, kbps. |
| `dim` | WxH | `1280x720` | Video frame size. Omitted in audio-only mode. |
| `fps` | int | `30` | Video framerate. |
| `vp` | int | `45002` | Video RTP port (hint; authoritative port comes from `accept`). |
| `ap` | int | `45000` | Audio RTP port (hint; same caveat). |
| `cp` | int | `45004` | Control TCP port. **Authoritative** — SRV must agree. |
| `st` | int | `1` | Live state. `1` = streaming, `0` = registered but idle. |

Rules:

- The TXT record is republished (with `st=1`) when broadcasting starts, and with `st=0`
  plus a **goodbye** (TTL 0) when it stops.
- Receivers filter on `st=1` but keep `st=0` entries visible in the UI, marked "Idle", so
  that a screen-reader user can discover the device before the presenter presses Start.
  This is an accessibility affordance, not a protocol requirement.
- `vp`/`ap` are hints. The real ports are negotiated in §4.

---

## 3. RTP media transport

Both streams are sent to the address the receiver offered, **unicast**, from the ports
the broadcaster binds.

| Track | Payload type | Clock rate | SSRC source | Timestamps |
| --- | --- | --- | --- | --- |
| Video (H.264) | 96 (dynamic) | 90000 Hz | `vs` from `accept` | 90 kHz |
| Audio (Opus) | 97 (dynamic) | 48000 Hz | `as` from `accept` | 48 kHz |

### 3.1 Video — H.264 over RTP (RFC 6184)

Target RTP payload: **1200 bytes** by default, leaving headroom inside a 1500-byte Ethernet
MTU. A broadcaster may choose a smaller target (down to about 400 bytes) to survive a lossy
link, or a larger one (up to 1400 bytes) to cut the packet rate; the budget is the sender's
choice, not a negotiated value, so a receiver must reassemble any FU-A fragmentation whatever
the fragment size.

Colour metadata is carried in the H.264 VUI. Encoders use limited-range video and select
BT.709 for frame heights of 720 pixels or more, and BT.601/SMPTE 170M below that. Receivers
must use the decoded frame's matrix and range when converting to display RGB; if the stream
omits colour metadata, use BT.601 limited range for compatibility with older broadcasters.
Unspecified or unsupported colour metadata must not be silently treated as a reliable colour
description.

Packetisation modes, applied in this order per NAL unit:

1. **Single NAL unit packet** (types 1-23) when the NAL fits in the MTU.
2. **STAP-A** (type 24) to aggregate consecutive small NALs — used to send the parameter
   sets together, so `[AUD][SPS][PPS]` can arrive in one UDP datagram. Only the *leading*
   non-VCL NALs are aggregated: a VCL slice always ends up in the following packet. A
   receiver therefore needs the first one or two packets of a keyframe, not a single one.
   Periodic IDR (section 3) bounds how long that takes.
3. **FU-A** (type 28) when a single NAL exceeds the MTU. The FU indicator carries
   S/F/E bits and the NAL type; the FU header follows.

Rules:

- The **marker bit is set on the last packet of each access unit** when an access unit
  spans multiple packets (FU-A/STAP-A). Never set on single-NAL packets.
- `DON` (decoding order number) is not used (top two FU-A header bits are zero).
- The encoder is configured with periodic IDR (default 2 s) as a fallback if keyframe
  requests are lost.
- `sprop-parameter-sets` in the SDP (base64 of `0x67..|0x68..`) is refreshed every
  IDR so parameter-set changes propagate.

#### 3.1.1 Parameter sets must be in-band

A broadcaster **repeats the SPS and PPS in the bitstream at every IDR**, not only in the
SDP. Both reference senders do this: the Windows sender sets `AV_CODEC_FLAG_GLOBAL_HEADER`
plus x264's `repeat_headers=1` for the same reason.

The SDP is not a substitute. A receiver that joins after the broadcaster's first keyframe
has an access unit it cannot decode and no way to learn the parameters from it, and
`sprop-parameter-sets` in the `welcome` is diagnostic only — the ports and modes it carries
are authoritative, its parameter sets are not consumed. Without in-band repetition no
decoder can ever be opened and the symptom is a permanently blank picture with no error.

#### 3.1.2 NAL units are length-prefixed, never start-code delimited

On the wire, and inside every access unit handed to the packetiser, a NAL unit is its
length as a big-endian `int32` followed by the NAL bytes. Start codes (`00 00 01` /
`00 00 00 01`) never appear in an access unit.

This is worth stating because Android's `MediaCodec` does not always hand over the format
the AVC contract describes, and passing its output through unchanged fails in a way that
looks like a network fault:

- `csd-0` / `csd-1` are documented as bare NAL units, but encoders shipped on real devices
  (observed on Samsung's `OMX.qcom.video.encoder.avc`, Android 13) prefix them with
  `00 00 00 01`. Left in place, the prefix becomes the NAL header: the type reads as 0
  rather than 7, and a receiver never recognises the unit as a parameter set.
- Byte-buffer output is documented as length-prefixed, but the same encoders emit Annex B.
  Fed to a length-prefixed reader, the leading start code reads as a length of 1, so the
  slice is taken to be a single header byte, the real length is nonsense, and the picture is
  dropped before it is ever packetised. A receiver then sees video packets arriving and no
  decodable frames, which is indistinguishable from loss.

Broadcasters must therefore normalise encoder output to length-prefixed NAL units and
strip start codes from `csd-0` / `csd-1` before use. Receivers should not tolerate start
codes on the wire: a peer that sends them is not interoperable, and quietly accepting them
hides the fault.

### 3.2 Audio — Opus over RTP (RFC 7587)

- 20 ms frames = 960 samples @ 48 kHz = 160 bytes at 64 kbps.
- The RTP payload is the **raw Opus packet**. The `OpusHead` identification header is
  omitted, as required by RFC 7587 §4.2 for directly-negotiated RTP.
- Timestamps advance by exactly 960 per packet; there is no resampling drift because the
  audio capture path is driven by `AudioRecord`, which is already 48 kHz.
- No marker bit use.
- Channel count: 1 (mono) for screen-share use cases, 2 (stereo) for music. This is a
  property of the broadcaster, not of the wire format — an Opus packet carries no channel
  count of its own — so it is announced in the SDP `a=rtpmap` line (section 4.3) and a
  receiver must read it from there. A decoder opened with the wrong layout does not fail;
  it produces noise. Receivers should default to 1 when the line is missing or unparsable
  rather than guessing.
- Although the wire format omits `OpusHead`, a receiver that configures a platform decoder
  from a container-style format must supply it as codec-specific data. Android's
  `c2.android.opus.decoder` reads `csd-0`, expects at least the 19-byte `OpusHead`
  (RFC 7845 §5.1), and without it fails the first packet with err -14 while the `AudioTrack`
  still reports `started`. Receivers synthesize the header from the negotiated channel count
  at 48 kHz rather than prefix it on the wire.
- The bare 19-byte `OpusHead` is **not sufficient** for `c2.android.opus.decoder`
  (`C2SoftOpusDec`). Its `process()` consumes the first three input buffers as codec-specific
  data — the OpusHead, the codec delay and the seek pre-roll — and `GetOpusHeaderBuffers`
  reads all three from one *unified* blob marked with `AOPUSHDR`, `AOPUSDLY` and `AOPUSPRL`
  (each an 8-byte marker plus an 8-byte little-endian length). If the delay and pre-roll are
  absent, the decoder reads them from the first two audio packets and sets a garbage
  `mSamplesToDiscard`, then decodes every frame and throws it away: silence, with no error
  logged. Receivers MUST supply the unified 83-byte block as `csd-0`, with zero codec delay
  and zero seek pre-roll, so the decoder reaches its decode path on the first packet.

### 3.3 Receiver jitter handling

- **Audio:** adaptive jitter buffer, target 3 packets (60 ms). It absorbs the
  reordering that Wi-Fi causes, which is what keeps Opus from clicking.
- **Video:** no reorder buffer. Packets are depacketised and handed to the decoder
  immediately; out-of-order late frames are simply dropped. Latency beats completeness
  for a live view.

### 3.4 Media source checks

Receivers discard media until the control handshake has completed. After `accept`, they
accept a track only from the control peer's IP address, the corresponding media source port
and the SSRC carried in `accept`. These checks reject unrelated datagrams and stale or
misrouted RTP streams; they are **not cryptographic authentication**. The control channel
and RTP remain unencrypted in protocol version 1, so an on-path or LAN attacker may still
observe traffic or spoof the expected UDP tuple. Do not treat these checks as a substitute
for authenticated encryption.

---

## 4. Session control channel

TCP, port from `cp` / SRV. One connection per receiver. The broadcaster may hold several
concurrently (default cap: 4).

Framing: **UTF-8 JSON objects, one per line, `\n`-terminated.** No chunking beyond TCP
segments; a receiver must tolerate partial reads and must not assume message boundaries
align with reads.

### 4.1 Handshake

```
Receiver                                        Broadcaster
   |  TCP connect                                      |
   |-------------------------------------------------->|
   |  {"t":"hello","v":1,"role":"receiver","name":"..."} |
   |-------------------------------------------------->|
   |         {"t":"welcome","v":1,"id":"a3f19c04",       |
   |          "m":"av","name":"Ada Laptop","sdp":"..."}  |
   |<--------------------------------------------------|
   |  {"t":"offer","id":"a3f19c04","vp":51002,"ap":51000} |
   |-------------------------------------------------->|
   |  {"t":"accept","vp":45002,"ap":45000,               |
   |          "vs":305419896,"as":2271560481}            |
   |<--------------------------------------------------|
   |                    RTP starts flowing              |
```

`offer` carries the receiver's **own bound UDP ports**. `accept` returns the **broadcaster's**
source ports (`vp`/`ap`) together with its SSRCs (`vs`/`as`), so the receiver can confirm
which endpoints the media will come from and detect a misdirected stream. The receiver
starts its sockets before sending `offer` so no media is lost to a race.

  If the broadcaster is at capacity, wrong protocol version, or shutting down, it replies
  `deny` and closes, instead of `welcome`.

  The diagram is the public case. A locked broadcast inserts a step before `offer`: an `auth`
  round trip in password mode, or a hold while a presenter decides in approval mode
  (section 4.4).

  A broadcaster must not push any other message until it has sent `welcome`. The connection
  is appended to the session set at TCP accept, before the first line has been read, so a
  broadcaster that broadcasts its counters to every connected socket will put a
  `stats` message in front of the `welcome` a receiver is waiting for. A receiver that
  treats that as a protocol error drops the connection, and the symptom is a receiver that
  joins and leaves immediately and repeatedly — which reads as a network fault and is not
  one. Receivers should likewise skip unrelated push messages while reading the handshake
  rather than failing on them; a client that gives up on the first unexpected line cannot
  complete a handshake against a broadcaster that reports state while it negotiates.

### 4.2 Message catalogue

All messages carry `t`. Unknown `t` values MUST be ignored, not treated as errors — this
is the forward-compatibility rule.

**Receiver → Broadcaster**

| `t` | Fields | Purpose |
| --- | --- | --- |
| `hello` | `v`, `role`, `name`, `ua` | Announce and negotiate protocol version. |
| `auth` | `id`, `pw` | The viewer's password, in `password` mode only (section 4.4). |
| `offer` | `id`, `vp`, `ap` | Receiver's UDP ports. `vp` omitted in audio-only. |
| `keyframe` | — | Request an IDR as soon as possible. |
| `bitrate` | `vbr`, `abr` | Request a bitrate change. |
| `mode` | `m`, `r:true` | *Request* a mode change. The broadcaster may refuse. |
| `stats` | `pkt`, `lost`, `jitter`, `nack` | Telemetry, 1 Hz. |
| `bye` | `reason` | Voluntary disconnect. |

**Broadcaster → Receiver**

| `t` | Fields | Purpose |
| --- | --- | --- |
| `welcome` | `v`, `id`, `m`, `name`, `sdp`, `access` | Session accepted; `sdp` for diagnostics. `access` omitted when public (section 4.4). |
| `authResult` | `ok`, `reason` | The answer to `auth`. `ok:true` is authoritative; the viewer's own comparison of the password is irrelevant to it. |
| `accept` | `vp`, `ap`, `vs`, `as` | Negotiation complete; media follows immediately. |
| `deny` | `code`, `reason` | Rejected. `code` ∈ `version`, `capacity`, `shutdown`, `mode`, `access`, `auth`, `blocked`. |
| `mode` | `m` (no `r`) | **Authoritative** broadcast mode changed. Receiver must reconfigure. |
| `keyframe` | — | Coalesced keyframe request (aggregated from N receivers). |
| `stats` | `fps`, `kbps`, `pl`, `nrt`, `dropped` | Telemetry, 1 Hz: frame rate, total bitrate, packet loss as a fraction, receiver count (`nrt`), frames dropped. |
| `bye` | `reason` | Disconnect. `reason` ∈ `shutdown`, `mode-change`, `capacity`, `kicked`, `error`. |

### 4.3 Served SDP

The `welcome` message carries a full SDP string for logging and for third-party
debugging. It is generated from the same field set as the TXT record, so the two can
never disagree.

The SDP is *not* used for the primary media path, with one exception: the audio channel
count is read from the `a=rtpmap` line, because an Opus packet cannot describe its own
channel layout and a receiver has no other way to learn it (section 3.2). The `accept`
message carries ports and SSRCs but no channel count, so there is nothing to read there
instead.

```
m=audio 0 RTP/AVP 97
a=rtpmap:97 opus/48000/1
a=rtcp:97 IN IP4 0.0.0.0
a=ssrc:1234 cname:localstream-audio
```

The trailing field of `a=rtpmap` is the channel count. A receiver that cannot parse it
should fall back to 1 rather than refuse the session.

### 4.4 Access control

Who may join is a property of the broadcast, not of the session. The broadcaster picks one of
three modes; `public` is the default and is what a build without this feature uses.

| Mode | `welcome.access` | What the broadcaster requires |
| --- | --- | --- |
| Public | *omitted* | Nothing. `offer` is answered immediately. |
| Approval | `approval` | A presenter decision. The `offer` is held, not answered, until it comes. |
| Password | `password` | A correct `auth`, answered with `authResult`. |

**Compatibility.** The `access` field is omitted for public, and a receiver that finds it
missing — or finds a value it does not recognise — must read the broadcast as public. An older
broadcaster had no access control and admitted everyone, so its silence is the absence of a
lock, not the presence of one; refusing on a missing field would lock every viewer out of every
broadcast running an older build. The converse does not hold: a receiver that ignores the field
and sends `offer` straight away is refused by a locked broadcaster, so the broadcaster's check
is authoritative and the receiver must enforce whatever `welcome.access` says.

**Password.** Sent after `welcome`, before `offer`:

```
   {"t":"auth","id":"a3f19c04","pw":"..."}      ->   {"t":"authResult","ok":true}
                                               ->   {"t":"authResult","ok":false,"reason":"..."}
```

A `false` result does not close the session: the viewer may send `auth` again, and it is the
presenter's password being mistyped, not the viewer being unwanted. `offer` before a granted
`authResult` is `deny` with code `auth`. Passwords are 4-10 characters, are held in memory
only, and are not encrypted on the wire — this is admission control, not confidentiality.

**Approval.** The broadcaster holds the `offer` and asks the presenter, by whatever means its
user interface provides. There is no timeout: a presenter who is not looking is not a refusal.
`allow` answers the held offer with `accept`; `deny` answers it with `deny` and code `access`.
Requests that arrive while one is being answered wait their turn rather than replacing it: a
prompt that changed under the presenter's finger would be an answer given for someone else. A
viewer who gives up while waiting is not left in the queue either — their request is dropped,
because a question about nobody would stand in front of the requests that came after it and the
viewer would be waiting for an answer that is never asked.

**Live changes apply to the next viewer.** Changing mode mid-broadcast does not disturb the
viewers already admitted — cutting a stream off because the presenter changed their mind about
the password would be a worse outcome than the one being prevented. It applies to the next
`offer`. A request already waiting for a decision is re-checked against the mode in force at
the moment the answer is given, so tightening the mode cannot be walked past by a prompt that
was raised before it: allowing a viewer who has since been put behind a password grants nothing
and the viewer is refused with `auth`.

**Rejections are counted per peer address, three deep.** An explicit refusal — `deny` in answer
to a password or an approval request — counts. Going away does not: a viewer who closes the app
or loses the network while waiting has not been turned down and spends nothing. The third
refusal from one address is the last one asked about; that refusal carries `deny` with code
`blocked`, and after it every `offer` from that address is refused the same way, with no
further prompt. The tally belongs to the broadcast, not to the process: it is discarded when
the broadcaster stops, so the next broadcast starts with a clean slate.

`blocked` is the end of the road for that broadcast. A viewer that sees it must say so plainly
and must not offer a retry, because a retry against a ban is a second refusal of the same
request.

---

## 5. Mode switching

The broadcaster owns the authoritative mode. Receivers may *request* via `mode` but are
told the result via the authoritative `mode` message. The two share the type name `mode`
and are distinguished by the request-only field `r: true`; without it a receiver's request
would be indistinguishable from a command on the wire.

**Audio-only → Audio+Video** is safe at any time. Video sockets are already bound, so the
broadcaster simply starts emitting RTP on the already-negotiated video port and pushes an
authoritative `mode` message. Receivers begin depacketising.

**Audio+Video → Audio-only** must drain: the encoder flushes and stops, the broadcaster
sends `mode {m:"a"}`, then video RTP ceases. Receivers release the video decoder. Frames
already in flight are decoded and dropped normally.

In both directions the audio track is untouched, so there is no audio glitch. This is the
main reason mode switching is a control-channel operation rather than a teardown/rebuild.

### 5.1 Receiver-side channel-layout handling

A receiver that decodes audio MUST take its channel count from the broadcaster's SDP
(section 3.2, 4.3) and MUST NOT infer it from the first packet or assume its own default.
The two implementations advertise different counts — Windows mono, Android stereo — and
neither is wrong. A receiver that hardcodes stereo will decode a Windows mono broadcast to
noise, and the failure is silent: packets arrive, counters increment, and the frame counter
shows a healthy session while nothing audible comes out.

Opening the audio output device is best-effort and MUST NOT fail the session. A machine with
no sound card, or a device held by another application, should still show the picture; the
receiver reports the audio failure and carries on.

---

## 6. Accessibility contract

The protocol carries no accessibility data, but the *events* it generates are the
mechanism by which both UIs stay screen-reader current. Every implementation MUST raise a
distinct, user-visible event for each of these:

| Event | Trigger | Announced text (Windows / Android) |
| --- | --- | --- |
| `BroadcasterDiscovered` | New instance appears in browse results | "New broadcaster found: {name}" |
| `BroadcasterRemoved` | Instance leaves or TTL expires | "Broadcaster no longer available: {name}" |
| `BroadcastStarted` | Local broadcast begins | "Broadcast started" |
| `BroadcastStopped` | Local broadcast ends | "Broadcast stopped" |
| `ModeChanged` | Mode toggle flipped | "Mode: audio and video" / "Mode: audio only" |
| `ReceiverConnected` | A receiver joins | "Receiver connected: {name}" |
| `ReceiverDisconnected` | A receiver leaves | "Receiver disconnected: {name}" |
| `ModeUnavailable` | Requested mode refused | "Mode change refused" |
| `StreamError` | Fatal media/network error | "Stream error: {reason}" |

On Windows these are raised as `QAccessible::AnnouncementEvent` (NVDA and JAWS both speak
it) plus a state-change event on the owning widget. On Android they are pushed to a
`StateFlow` that the Compose tree exposes via `liveRegion = LiveRegionMode.Assertive` /
`Polite`.

---

## 7. Port allocation

All ports are ephemeral and discovered; nothing is fixed. Recommended ranges, chosen to
avoid ephemeral-port collisions, though binding to port 0 is always acceptable:

| Socket | Range |
| --- | --- |
| Control (broadcaster) | 45000-45010 |
| Audio RTP | 45020-45039 |
| Video RTP | 45040-45079 |

Every implementation MUST bind with port 0 and then publish the actually-bound port, so
that a port conflict degrades to a different port rather than a failure.
