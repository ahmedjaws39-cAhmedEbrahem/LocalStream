# LocalStream

Low-latency LAN screen and camera broadcasting. A phone broadcasts its screen or camera over
Wi-Fi; a PC on the same network watches it, or the PC can broadcast and the phone watches.

The two platforms are separate implementations of one wire protocol, so either side can be
built and used without the other. [`docs/PROTOCOL.md`](docs/PROTOCOL.md) is the contract they
both obey.

## Languages

Both apps read in English, العربية, Français, Русский and Türkçe, and so does the tutorial. The
language follows the system until it is changed, and is chosen on the **Help** tab: Windows asks
whether to restart, which is what applies the new language to every widget, and Android rebuilds
the screen on the spot. The tutorial opens in the chosen language too.

Arabic is right to left, and the whole interface is mirrored for it rather than only its text.
[`docs/TRANSLATING.md`](docs/TRANSLATING.md) has the workflow for adding another language and the
agreed wording, so the two apps and the tutorial do not drift apart.

## Layout

| Path | What it is |
| --- | --- |
| `android/` | Kotlin app. CameraX screen/camera capture, MediaCodec H.264/AAC, NSD advertisement, TCP control. |
| `windows/` | Qt 6 Widgets app. `localstream` static libs, x264 encoding, FFmpeg decoding, mDNS, TCP control. |
| `docs/PROTOCOL.md` | Wire format: control messages, RTP packetisation, DNS-SD records. |
| `tools/` | Project-local toolchains. Nothing is read from the machine's global paths. |
| `.github/workflows/` | Continuous integration: Android lint/tests/APK, Windows build/tests/installer. |

## Building

Both builds use toolchains vendored under `tools/`, so no Visual Studio, Qt, or FFmpeg install
on the machine is required or consulted. `tools\fetch-toolchain.ps1` downloads them there
(CMake, Ninja, Qt 6.8.3 msvc2022_64, an FFmpeg 9.0 shared build, vcpkg); each step is skipped
if what it produces is already present.

```powershell
# Fetch the Windows toolchain into tools\ (a few gigabytes, once)
powershell -NoProfile -ExecutionPolicy Bypass -File .\tools\fetch-toolchain.ps1 -SkipMsvc

# Android (debug APK -> android/app/build/outputs/apk/debug/app-debug.apk)
powershell -NoProfile -ExecutionPolicy Bypass -File .\tools\build-android.ps1

# Windows (-> build/windows/bin/LocalStream.exe)
powershell -NoProfile -ExecutionPolicy Bypass -File .\tools\build-windows.ps1
```

Building Windows needs Visual Studio Build Tools 2022, because `tools\build-windows.ps1` calls
`vcvars64.bat` to put `cl.exe` on `PATH`. Gradle is not on that list: the Android build uses the
wrapper committed in `android/`, so it downloads the right Gradle itself.

Pass `-Configure` to `build-windows.ps1` to re-run CMake. It is only needed after adding or
renaming a source file, because sources are collected by glob.

## Testing

```powershell
# Windows: 11 test binaries, unit and pipeline
.\tools\cmake\bin\ctest.exe --test-dir .\build\windows --output-on-failure

# Android: unit tests covering the protocol, RTP framing and the control channel
$env:ANDROID_SDK_ROOT = "$env:LOCALAPPDATA\Android\Sdk"
$env:GRADLE_USER_HOME = "$PWD\tools\gradle-home"
.\android\gradlew.bat -p android testDebugUnitTest
```

`GRADLE_USER_HOME` is required: the project keeps its dependency cache in `tools\gradle-home`, so
Gradle cannot resolve Kotlin or Compose offline without it, and there is no `local.properties`
holding an SDK path.

## Running

Start the app on both devices, then use the **Broadcast** tab on one and the **Receive** tab on
the other. The Receive tab lists broadcasters found on the network; pick one and connect.

Broadcasting on Android asks for screen-capture permission the first time. That grant cannot be
reused, so a broadcast that has to start again re-prompts, and a running screen broadcast cannot
be switched to include video without restarting. Windows has no such restriction: the **Include
video** box stays live during a broadcast, and switching back to video resumes as soon as the next
keyframe is sent. **Use a test pattern instead of the screen** captures a generated pattern and
tone rather than the desktop.

Android also sleeps an app whose screen is off, which freezes a broadcast that is still being
watched at the other end. The **Ignore battery optimisation** switch on the Android Help tab asks
Android to exempt LocalStream, on Android's own screen, and then reports what Android decided. Left
off, the app still broadcasts; it simply stops when Android puts it to sleep. One caveat for a store
release: Google restricts `REQUEST_IGNORE_BATTERY_OPTIMIZATIONS` to apps whose core function needs
it — broadcasting in the background is what this app is for — and Play judges that at submission
time, so the permission is worth revisiting if a submission is rejected.

The **Microphone** list on the Windows Broadcast tab picks what is captured. It is populated from
the recording devices DirectShow reports, and the first one is used if the list is left alone. If no
microphone is found, the broadcast will not start unless the test pattern is ticked, which replaces
the microphone with a generated tone.

### Connecting without discovery

If the Receive list is empty, both apps can be connected by hand. The broadcaster's screen shows
its control port — under the status line on Android, and in the statistics area on Windows — and
its address is its IP on the shared network. Enter the two in the address and port boxes on the
receiver and connect.

This is the route to use when discovery cannot bind UDP 5353, or when the two machines are on
different subnets where multicast does not cross. It is also the only one that works when
discovery is blocked but direct TCP is not, which is the more common half-failure.

### Interop probe

`build\windows\bin\interop_probe.exe` runs a headless receive session and prints packet counters.
It is the fastest way to check that the two implementations still agree on the wire, without
running either GUI.

```powershell
# browse the network for 25 seconds (default)
.\build\windows\bin\interop_probe.exe

# skip discovery and connect straight to a known host, for 30 seconds
.\build\windows\bin\interop_probe.exe 30 192.168.1.2:36987
```

The first argument is how long to run, the second is an optional `host:port` to connect to
directly. Direct mode is the one to reach for when discovery cannot bind, since it needs no mDNS
at all.

It prints frame, audio, and video packet counts, lost packets, and whether in-band SPS/PPS
arrived, which is what caught the Annex B/AVCC mismatch during development.

## Windows Firewall

The app sends and receives on the network, so Windows Firewall must allow it. On first launch
Windows normally prompts; if that prompt was dismissed, inbound connections stay blocked and the
Receive tab silently lists no broadcasters.

Ping still works when this is wrong, and both apps will still broadcast and receive locally, which
is what makes it confusing to diagnose. If a broadcast shows a receiver connected and no picture
arrives anywhere, or discovery lists nothing while a manual address and port also time out, check
for a rule that blocks the program — an **inbound Block** rule wins over the allow rule Windows
offered on first launch, and it is not visible from the app.

```powershell
# From an elevated prompt, to see what is actually in force
Get-NetFirewallRule -Direction Inbound -Program "*LocalStream.exe" |
  Format-Table DisplayName, Action, Enabled, Profile
```

Discovery uses UDP 5353, which is a port Windows reserves for its own DNS Client service, so the
app shares it rather than taking it exclusively. When even the shared bind fails, the broadcaster
falls back to announcing on an ephemeral port: peers will then see the announcement but cannot
resolve a port, so manual connecting is the fallback of last resort.

To allow it from an elevated prompt:

```powershell
New-NetFirewallRule -DisplayName "LocalStream" -Direction Inbound `
  -Program "$PWD\build\windows\bin\LocalStream.exe" -Action Allow `
  -Profile Private
```

## Audio

Audio is Opus over RTP in both directions, 48 kHz, 20 ms per packet. Android captures the
microphone and encodes with `MediaCodec`; Windows captures through DirectShow and encodes with
libopus. The channel count is whatever the broadcaster configured, and it is announced in the SDP
rather than being assumed, because an Opus packet carries no channel count of its own and a
decoder opened for the wrong one produces noise rather than an error.

Receiving on Windows decodes with libavcodec and plays through the default output device via
`waveOut`. Audio runs on its own thread, separate from video decoding: the device does not return
a buffer until it has played it, so the calls that fill and recycle buffers can only be made from
somewhere allowed to wait, and a blocked audio device must not be able to stall the picture.

Audio is dropped rather than queued on the way in. A packet that arrives after the next one has
already been played is worth less than none at all, so a slow device costs a few milliseconds of
sound rather than introducing a growing lag behind the video.

## Known limitations

- **`connectable=0` from the probe in direct mode is expected.** That counter only increments when
  a broadcaster is found by discovery and is usable, so it is always 0 when the probe is given a
  `host:port` and never browses.
- **Discovery cannot be verified in a dev environment with `adb` attached.** `adb` binds
  `0.0.0.0:5353` exclusively for wireless debugging, which blocks the app's browse socket.
  `adb kill-server` frees it. Incoming mDNS is also blocked by default by Windows Firewall, so
  a real end-to-end browse test needs an allow rule and an elevated shell.

## License

LocalStream is free software, released under the **GNU General Public License, version 3**
(or any later version). The full text is in [LICENSE](LICENSE).

The license is not a free choice here: the Windows build links an FFmpeg built with
`--enable-gpl` and libx264, so the combined Windows program must itself be distributed under
the GPL. The Android app links no such library, but both halves ship under the same terms so
the project stays one thing. Every third-party component and its obligations is listed in
[docs/THIRD-PARTY.md](docs/THIRD-PARTY.md).

## Privacy

LocalStream collects nothing and sends nothing to the internet. It has no account, no
analytics, no advertising, and no server: a broadcast travels directly between the two
devices on the same network. See [docs/PRIVACY.md](docs/PRIVACY.md).

## Releasing

The version lives in one place per platform — `versionName`/`versionCode` in
`android/app/build.gradle.kts` and `project(... VERSION ...)` in `windows/CMakeLists.txt` —
and the windows About box and the Android report both read it from there.

```powershell
# Android: lint, tests, signed .aab + .apk into build\android-release\
powershell -NoProfile -ExecutionPolicy Bypass -File .\tools\build-android.ps1 -Release

# Windows: one setup .exe into build\windows-dist\ (needs Inno Setup; add -Portable for a zip too)
powershell -NoProfile -ExecutionPolicy Bypass -File .\tools\package-windows.ps1
```

The Windows installer carries the whole program inside it — the exe, the Qt libraries, the Qt
plugins, the FFmpeg libraries and even the C++ runtime — so the installed copy depends on
nothing else on the machine; there is no redistributable to install first. Its Select
Additional Tasks page offers a Start menu shortcut, a desktop shortcut and a Windows Firewall
rule, and on Windows older than 10 it shows a warning page before anything is copied.

When the version changes, add a `CHANGELOG.md` entry and tag the commit. Releases are cut by
hand; see [CHANGELOG.md](CHANGELOG.md) for what has shipped.

`tools\package-source.ps1` writes `src.zip`, the source archive: the two platforms, the build
scripts, the docs and the licence texts, with the vendored toolchains and every build output
left out. It refuses to write an archive that contains the release keystore.
