# Runs the toolchain fetch for the long downloads and writes a log, so the large
# steps can be launched detached from an interactive shell and monitored later.
param(
    [Parameter(Mandatory = $true)][string] $Only,
    [string] $LogPath = "$PSScriptRoot\toolchain-fetch.log"
)

$ErrorActionPreference = 'Continue'

"=== toolchain fetch started $(Get-Date -Format o) ==="      | Out-File $LogPath -Encoding utf8
"=== requested: $Only ==="                                  | Out-File $LogPath -Append -Encoding utf8

& (Join-Path $PSScriptRoot 'fetch-toolchain.ps1') -Only $Only *>&1 |
    Tee-Object -FilePath $LogPath -Append

$code = $LASTEXITCODE
"=== toolchain fetch finished $(Get-Date -Format o) exit=$code ===" |
    Out-File $LogPath -Append -Encoding utf8
exit $code
