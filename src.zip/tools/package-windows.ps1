<#
.SYNOPSIS
    Builds the LocalStream Windows installer: one setup .exe that carries the whole program
    inside it.

.DESCRIPTION
    Runs after tools\build-windows.ps1 (and runs it if the exe is missing). Everything the app
    needs at run time already sits beside build\windows\bin\LocalStream.exe, because the build
    deploys the Qt runtime, the Qt plugins, the C++ runtime DLLs and the FFmpeg DLLs there.

    This script stages the parts worth shipping -- and nothing else: the test executables, the
    interop probe and the .ilk/.pdb build leftovers are left behind. Then it compiles
    tools\installer\LocalStream.iss with Inno Setup, which packs the whole staged folder into
    one compressed setup .exe. The installed program therefore depends on nothing outside
    itself, and neither does the installer.

    Inno Setup is required. It is free: https://jrsoftware.org/isdl.php

.EXAMPLE
    powershell -NoProfile -ExecutionPolicy Bypass -File tools\package-windows.ps1

.EXAMPLE
    powershell -NoProfile -ExecutionPolicy Bypass -File tools\package-windows.ps1 -Portable
    # also produces a zip of the staged folder, for running straight from a folder
#>

[CmdletBinding()]
param(
    [switch] $SkipBuild,
    [switch] $Portable,
    [string] $Version = ''
)

$ErrorActionPreference = 'Stop'
$ProgressPreference    = 'SilentlyContinue'

$RepoRoot = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$BinDir   = Join-Path $RepoRoot 'build\windows\bin'
$Exe      = Join-Path $BinDir 'LocalStream.exe'
$DistDir  = Join-Path $RepoRoot 'build\windows-dist'
$IssFile  = Join-Path $RepoRoot 'tools\installer\LocalStream.iss'

# windeployqt answers "the C++ runtime is missing" by copying vc_redist.x64.exe and trusting the
# user to run it, which is exactly the "needs something from outside" this package must not
# have. Find the runtime DLLs ourselves so they can be shipped beside the exe: first the
# environment vcvars set, then the newest redistributable under the Visual Studio install.
function Get-VcRuntimeDir {
    $redist = $env:VCToolsRedistDir
    if ($redist -and (Test-Path $redist)) {
        $crt = Get-ChildItem (Join-Path $redist 'x64') -Directory -Filter 'Microsoft.VC*.CRT' -EA SilentlyContinue |
            Select-Object -First 1
        if ($crt) { return $crt.FullName }
    }

    $vswhere = "${env:ProgramFiles(x86)}\Microsoft Visual Studio\Installer\vswhere.exe"
    if (Test-Path $vswhere) {
        $vs = & $vswhere -latest -products * `
            -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath
        if ($vs) {
            $base = Join-Path $vs 'VC\Redist\MSVC'
            if (Test-Path $base) {
                $crt = Get-ChildItem $base -Directory |
                    Sort-Object Name -Descending |
                    ForEach-Object {
                        Get-ChildItem (Join-Path $_.FullName 'x64') -Directory -Filter 'Microsoft.VC*.CRT' -EA SilentlyContinue
                    } | Select-Object -First 1
                if ($crt) { return $crt.FullName }
            }
        }
    }
    return $null
}

# ------------------------------------------------------------------ build if needed
if (-not (Test-Path $Exe)) {
    if ($SkipBuild) {
        throw "No build found at $Exe and -SkipBuild was given. Run tools\build-windows.ps1 first."
    }
    Write-Host 'No build found; building the Windows app first.'
    & powershell -NoProfile -ExecutionPolicy Bypass -File (Join-Path $RepoRoot 'tools\build-windows.ps1')
    if ($LASTEXITCODE -ne 0 -or -not (Test-Path $Exe)) { throw 'The Windows build failed.' }
}

# The version comes from the version resource in the exe, which the build takes from CMake's
# project() line -- so there is one number and it is the one running.
if (-not $Version) {
    $Version = (Get-Item $Exe).VersionInfo.FileVersion
    if (-not $Version) { throw "The exe carries no version resource: $Exe" }
    $Version = $Version.Trim()
}

$StageName = "LocalStream-$Version-windows-x64"
$StageDir  = Join-Path $DistDir $StageName
$SetupBase = "LocalStream-$Version-Setup"

Write-Host "Version : $Version"
Write-Host "Stage   : $StageDir"

# ------------------------------------------------------------------ stage
if (Test-Path $StageDir) { Remove-Item $StageDir -Recurse -Force }
New-Item -ItemType Directory -Force -Path $StageDir | Out-Null

# Everything beside the exe is a run-time dependency and must go in; only the test binaries,
# the interop probe (a developer tool), the VC++ runtime installer (no longer needed, the
# runtime DLLs themselves are deployed beside the exe) and the .ilk/.pdb leftovers stay out.
$skip = '(_tests\.exe$|interop_probe\.exe$|vc_redist\.x64\.exe$|\.ilk$|\.pdb$)'
Get-ChildItem $BinDir -Force |
    Where-Object { $_.Name -notmatch $skip } |
    ForEach-Object { Copy-Item $_.FullName -Destination $StageDir -Recurse -Force }

# The C++ runtime DLLs, so the installed program runs on a machine that never installed the
# VC++ redistributable.
$VcDir = Get-VcRuntimeDir
if ($VcDir) {
    Get-ChildItem $VcDir -Filter '*.dll' |
        ForEach-Object { Copy-Item $_.FullName -Destination $StageDir -Force }
    Write-Host "Runtime : $VcDir"
} else {
    Write-Warning 'The Visual C++ runtime DLLs were not found; the installed app may still ask for the VC++ redistributable.'
}

# Licence texts. Qt is LGPL-3.0 (the text is kept in the repo because the Qt download does not
# carry it); FFmpeg is GPL-3.0 (its own LICENSE.txt lives beside the download); the project's
# own GPL text and the third-party summary come from the repo.
$LicDir = Join-Path $StageDir 'licenses'
New-Item -ItemType Directory -Force -Path $LicDir | Out-Null

Copy-Item (Join-Path $RepoRoot 'LICENSE') (Join-Path $LicDir 'LocalStream-GPL-3.0.txt') -Force
Copy-Item (Join-Path $RepoRoot 'licenses\LGPL-3.0.txt') (Join-Path $LicDir 'Qt-LGPL-3.0.txt') -Force
Copy-Item (Join-Path $RepoRoot 'docs\THIRD-PARTY.md') (Join-Path $LicDir 'THIRD-PARTY.md') -Force
Copy-Item (Join-Path $RepoRoot 'docs\PRIVACY.md') (Join-Path $LicDir 'PRIVACY.md') -Force

$ffmpegLic = Join-Path $RepoRoot 'tools\ffmpeg\LICENSE.txt'
if (Test-Path $ffmpegLic) {
    Copy-Item $ffmpegLic (Join-Path $LicDir 'FFmpeg-GPL-3.0.txt') -Force
} else {
    Write-Warning 'tools\ffmpeg\LICENSE.txt is missing, so the FFmpeg licence is not staged.'
}

# A short read-me for someone who opens the install folder.
$readme = @"
LocalStream $Version
====================

LocalStream sends a screen, a camera or a microphone from one device to another over your own
local network. This folder is the Windows half, and it is complete: every library and plugin
the program uses is here, including the Visual C++ runtime, so it needs nothing installed on
the machine beyond Windows itself.

To run it: double-click LocalStream.exe. The full guide is docs/Tutorial.html (open it in a
browser). The Android app is the other half of the pair; both are needed to stream, unless you
are sending from one Windows PC to another.

This program is free software, released under the GNU General Public License version 3 or
later. See licenses/LocalStream-GPL-3.0.txt. It links Qt (LGPL-3.0) and an FFmpeg built with
--enable-gpl (GPL-3.0); see licenses/ for their texts and licenses/THIRD-PARTY.md for the full
list.

No data is collected and nothing is sent to the internet. See licenses/PRIVACY.md.
"@
Set-Content -Path (Join-Path $StageDir 'README.txt') -Value $readme -Encoding UTF8

# The docs the package should carry, beside the app.
$docStage = Join-Path $StageDir 'docs'
New-Item -ItemType Directory -Force -Path $docStage | Out-Null
Copy-Item (Join-Path $RepoRoot 'docs\Tutorial.html') $docStage -Force
Copy-Item (Join-Path $RepoRoot 'CHANGELOG.md')       $docStage -Force

# ------------------------------------------------------------------ optional portable zip
if ($Portable) {
    $ZipPath = Join-Path $DistDir "$StageName.zip"
    if (Test-Path $ZipPath) { Remove-Item $ZipPath -Force }
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    [System.IO.Compression.ZipFile]::CreateFromDirectory(
        $StageDir, $ZipPath, [System.IO.Compression.CompressionLevel]::Optimal, $true)
    Write-Host "ZIP     : $ZipPath ($([math]::Round((Get-Item $ZipPath).Length / 1MB, 1)) MiB)"
}

# ------------------------------------------------------------------ installer
# iscc.exe is on PATH when Inno Setup was installed for all users, in Program Files when it was
# not, and under the user's profile when winget installed it per-user; look in all three.
$Iscc = Get-Command iscc.exe -ErrorAction SilentlyContinue
if (-not $Iscc) {
    $candidates = @(
        (Join-Path ${env:ProgramFiles(x86)} 'Inno Setup 6\ISCC.exe'),
        (Join-Path $env:ProgramFiles      'Inno Setup 6\ISCC.exe'),
        (Join-Path $env:LOCALAPPDATA      'Programs\Inno Setup 6\ISCC.exe')
    )
    foreach ($c in $candidates) { if ($c -and (Test-Path $c)) { $Iscc = Get-Item $c; break } }
}
if (-not $Iscc) {
    throw 'Inno Setup (iscc.exe) was not found. Install it from https://jrsoftware.org/isdl.php and run this script again.'
}

$IsccPath = if ($Iscc -is [System.IO.FileInfo]) { $Iscc.FullName } else { $Iscc.Source }
Write-Host "Compiler: $IsccPath"
& $IsccPath "/DAppVersion=$Version" "/DStageDir=$StageDir" `
    "/DOutputDir=$DistDir" "/DOutputBase=$SetupBase" $IssFile
if ($LASTEXITCODE -ne 0) { throw "Inno Setup failed with exit code $LASTEXITCODE." }

$Setup = Join-Path $DistDir "$SetupBase.exe"
if (-not (Test-Path $Setup)) { throw "Inno Setup reported success but $Setup is missing." }
$setupMiB = [math]::Round((Get-Item $Setup).Length / 1MB, 1)
Write-Host ''
Write-Host "Installer: $Setup ($setupMiB MiB)"
Write-Host "Output folder: $DistDir"
