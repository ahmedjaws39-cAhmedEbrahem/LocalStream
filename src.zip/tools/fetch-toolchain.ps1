<#
.SYNOPSIS
    Fetches the Windows build toolchain INTO THE PROJECT FOLDER (tools\).

.DESCRIPTION
    Per project policy, nothing is installed system-wide. Every toolchain artefact is
    downloaded and unpacked under .\tools\ so the repository is self-contained and can be
    deleted to reclaim space.

    Each step is idempotent: it checks for an existing, valid installation first and
    skips the download if found.

    Usage:
        powershell -ExecutionPolicy Bypass -File tools\fetch-toolchain.ps1
        powershell -ExecutionPolicy Bypass -File tools\fetch-toolchain.ps1 -Only cmake,ninja,qt
        powershell -ExecutionPolicy Bypass -File tools\fetch-toolchain.ps1 -SkipMsvc
#>

[CmdletBinding()]
param(
    # Comma-separated subset of: cmake,ninja,qt,ffmpeg,msvc,vcpkg
    [string[]] $Only = @('cmake', 'ninja', 'qt', 'ffmpeg', 'msvc', 'vcpkg'),
    # Skip the Visual Studio Build Tools step (large; needs elevation).
    [switch] $SkipMsvc
)

$ErrorActionPreference = 'Stop'
$ProgressPreference    = 'SilentlyContinue'

# Callers (including run-fetch-background.ps1) read $LASTEXITCODE, and a script that ends
# without `exit` leaves them a stale or null code. End every path explicitly: 0 on success,
# 1 on any terminating error below.
trap {
    Write-Host "`n[fail] $_" -ForegroundColor Red
    exit 1
}

# `powershell -File` hands every argument over as a literal string, so `-Only cmake,ninja`
# arrives as the single value 'cmake,ninja' rather than a two-element array. Normalise.
$Only = @(($Only -join ',') -split ',' | ForEach-Object { $_.Trim() } | Where-Object { $_ })

$ToolsDir   = $PSScriptRoot
$CmakeDir   = Join-Path $ToolsDir 'cmake'
$NinjaDir   = Join-Path $ToolsDir 'ninja'
$QtDir      = Join-Path $ToolsDir 'qt'
$FfmpegDir  = Join-Path $ToolsDir 'ffmpeg'
$MsvcDir    = Join-Path $ToolsDir 'msvc'
$VcpkgDir   = Join-Path $ToolsDir 'vcpkg'
$PyLibsDir  = Join-Path $ToolsDir 'pylibs'

# Pinned versions. CMake is deliberately held at 3.31.x: CMake 4 dropped support for
# `cmake_minimum_required(VERSION <3.5)`, which several vcpkg ports still emit.
$CmakeVersion = '3.31.6'
$NinjaVersion = '1.13.2'
$QtVersion    = '6.8.3'
$VcpkgCommit  = '74c2a2175954ddf336fb3094832022093fa73df4' # vcpkg baseline

# FFmpeg: BtbN's "gpl shared" build of the 9.0 release branch - headers, import libraries and
# the DLLs, in one archive. The release tag is a dated snapshot and the asset name carries the
# build it came from, so the same download is fetched every time. This build is what makes the
# project GPL: it is configured with --enable-gpl --enable-version3 and carries libx264.
$FfmpegTag    = 'autobuild-2026-10-17-20-51'
$FfmpegAsset  = 'ffmpeg-n9.0.2-28-g669f5ab083-win64-gpl-shared-9.0.zip'

function Write-Step($msg) { Write-Host "`n==> $msg" -ForegroundColor Cyan }
function Write-Ok($msg)   { Write-Host "    [ok]   $msg" -ForegroundColor Green }
function Write-Skip($msg) { Write-Host "    [skip] $msg" -ForegroundColor DarkGray }
function Write-Need($msg) { Write-Host "    [need] $msg" -ForegroundColor Yellow }

function Get-Tool([string]$Name) {
    $wanted = if ($Only.Count) { $Only } else { @('cmake', 'ninja', 'qt', 'ffmpeg', 'msvc', 'vcpkg') }
    return ($wanted -contains $Name)
}

# --------------------------------------------------------------------------------------
# cmake
# --------------------------------------------------------------------------------------
if (Get-Tool 'cmake') {
    Write-Step "CMake $CmakeVersion"
    $exe = Get-ChildItem -Path $CmakeDir -Recurse -Filter 'cmake.exe' -ErrorAction SilentlyContinue |
           Select-Object -First 1 -ExpandProperty FullName
    if ($exe) {
        Write-Skip "already present: $exe"
    } else {
        $url  = "https://github.com/Kitware/CMake/releases/download/v$CmakeVersion/cmake-$CmakeVersion-windows-x86_64.zip"
        $zip  = Join-Path $env:TEMP "cmake-$CmakeVersion.zip"
        Write-Need "downloading $url"
        Invoke-WebRequest -Uri $url -OutFile $zip -UseBasicParsing
        Write-Need "unpacking"
        Expand-Archive -Path $zip -DestinationPath $ToolsDir -Force
        Remove-Item $zip -Force
        # Normalise the versioned folder name to tools\cmake.
        $extracted = Join-Path $ToolsDir "cmake-$CmakeVersion-windows-x86_64"
        if ((Test-Path $extracted) -and (-not (Test-Path $CmakeDir))) {
            Rename-Item $extracted $CmakeDir
        }
        Write-Ok "installed to $CmakeDir"
    }
}

# --------------------------------------------------------------------------------------
# ninja
# --------------------------------------------------------------------------------------
if (Get-Tool 'ninja') {
    Write-Step "Ninja $NinjaVersion"
    $exe = Join-Path $NinjaDir 'ninja.exe'
    if (Test-Path $exe) {
        Write-Skip "already present: $exe"
    } else {
        $url = "https://github.com/ninja-build/ninja/releases/download/v$NinjaVersion/ninja-win.zip"
        $zip = Join-Path $env:TEMP 'ninja-win.zip'
        Write-Need "downloading $url"
        Invoke-WebRequest -Uri $url -OutFile $zip -UseBasicParsing
        New-Item -ItemType Directory -Force -Path $NinjaDir | Out-Null
        Expand-Archive -Path $zip -DestinationPath $NinjaDir -Force
        Remove-Item $zip -Force
        Write-Ok "installed to $exe"
    }
}

# --------------------------------------------------------------------------------------
# qt 6 (via aqtinstall, installed into the project folder)
# --------------------------------------------------------------------------------------
if (Get-Tool 'qt') {
    Write-Step "Qt $QtVersion (msvc2022_64)"
    $marker = Join-Path $QtDir "$QtVersion\msvc2022_64\bin\qmake.exe"
    if (Test-Path $marker) {
        Write-Skip "already present: $marker"
    } else {
        # aqtinstall is installed with --target so that nothing lands in site-packages.
        if (-not (Test-Path (Join-Path $PyLibsDir 'aqt'))) {
            Write-Need "installing aqtinstall into $PyLibsDir"
            & python -m pip install --quiet --upgrade --target $PyLibsDir 'aqtinstall'
            if ($LASTEXITCODE -ne 0) { throw "pip install aqtinstall failed" }
        }
        $env:PYTHONPATH = $PyLibsDir
        Write-Need "downloading Qt (this is large, ~1.5 GB)"
        & python -m aqt install-qt windows desktop $QtVersion win64_msvc2022_64 -O $QtDir
        if ($LASTEXITCODE -ne 0) { throw "aqt install-qt failed" }
        Remove-Item Env:\PYTHONPATH -ErrorAction SilentlyContinue
        Write-Ok "installed to $QtDir"
    }
}

# --------------------------------------------------------------------------------------
# ffmpeg (headers, import libraries and DLLs; the build the app captures and encodes with)
# --------------------------------------------------------------------------------------
if (Get-Tool 'ffmpeg') {
    Write-Step "FFmpeg $FfmpegTag (win64 gpl shared)"
    $marker = Join-Path $FfmpegDir 'include\libavcodec\avcodec.h'
    if (Test-Path $marker) {
        Write-Skip "already present: $marker"
    } else {
        $url = "https://github.com/BtbN/FFmpeg-Builds/releases/download/$FfmpegTag/$FfmpegAsset"
        $zip = Join-Path $env:TEMP $FfmpegAsset
        Write-Need "downloading $url (this is large, several hundred MB)"
        Invoke-WebRequest -Uri $url -OutFile $zip -UseBasicParsing
        Write-Need "unpacking"
        $staging = Join-Path $env:TEMP 'localstream-ffmpeg'
        if (Test-Path $staging) { Remove-Item $staging -Recurse -Force }
        Expand-Archive -Path $zip -DestinationPath $staging -Force
        Remove-Item $zip -Force
        # The archive holds one folder; the app wants its contents at tools\ffmpeg.
        $inner = Get-ChildItem $staging -Directory | Select-Object -First 1
        if (-not $inner) { throw "The FFmpeg archive did not contain a folder." }
        if (Test-Path $FfmpegDir) { Remove-Item $FfmpegDir -Recurse -Force }
        New-Item -ItemType Directory -Force -Path $FfmpegDir | Out-Null
        Get-ChildItem $inner.FullName -Force | Move-Item -Destination $FfmpegDir -Force
        Remove-Item $staging -Recurse -Force
        Write-Ok "installed to $FfmpegDir"
    }
}

# --------------------------------------------------------------------------------------
# vcpkg (manifest mode; ports are built into tools\vcpkg\installed)
# --------------------------------------------------------------------------------------
if (Get-Tool 'vcpkg') {
    Write-Step "vcpkg (baseline $VcpkgCommit)"
    $exe = Join-Path $VcpkgDir 'vcpkg.exe'
    if (Test-Path $exe) {
        Write-Skip "already present: $exe"
    } else {
        $zip = Join-Path $env:TEMP 'vcpkg.zip'
        Write-Need "downloading vcpkg source"
        Invoke-WebRequest -Uri "https://github.com/microsoft/vcpkg/archive/$VcpkgCommit.zip" -OutFile $zip -UseBasicParsing
        New-Item -ItemType Directory -Force -Path $VcpkgDir | Out-Null
        Expand-Archive -Path $zip -DestinationPath (Join-Path $env:TEMP 'vcpkg-extract') -Force
        $inner = Get-ChildItem (Join-Path $env:TEMP 'vcpkg-extract') -Directory | Select-Object -First 1
        if ($inner) {
            Get-ChildItem $inner.FullName -Force | Move-Item -Destination $VcpkgDir -Force
        }
        Remove-Item $zip -Force
        Write-Need "bootstrapping vcpkg.exe (builds from source, several minutes)"
        & (Join-Path $VcpkgDir 'bootstrap-vcpkg.bat') -disableMetrics
        Write-Ok "installed to $exe"
    }
}

# --------------------------------------------------------------------------------------
# visual studio build tools (optional; large and typically needs elevation)
# --------------------------------------------------------------------------------------
if ($SkipMsvc) {
    Write-Step 'MSVC Build Tools'
    Write-Skip 'skipped via -SkipMsvc'
} elseif (Get-Tool 'msvc') {
    Write-Step 'MSVC Build Tools'
    $cl = Get-ChildItem -Path $MsvcDir -Recurse -Filter 'cl.exe' -ErrorAction SilentlyContinue |
          Select-Object -First 1 -ExpandProperty FullName
    if ($cl) {
        Write-Skip "already present: $cl"
    } else {
        $isAdmin = ([Security.Principal.WindowsPrincipal] `
                    [Security.Principal.WindowsIdentity]::GetCurrent()
                   ).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
        if (-not $isAdmin) {
            Write-Need 'NOT running elevated. The VS installer requires administrator rights.'
            Write-Need 'Re-run this script from an elevated PowerShell prompt, or install the'
            Write-Need '"Desktop development with C++" workload manually into tools\msvc.'
            Write-Need "Command: `"$PSCommandPath`""
        } else {
            $bootstrap = Join-Path $ToolsDir 'vs_BuildTools.exe'
            Write-Need 'downloading VS Build Tools bootstrapper'
            Invoke-WebRequest -Uri 'https://aka.ms/vs/17/release/vs_BuildTools.exe' `
                              -OutFile $bootstrap -UseBasicParsing
            Write-Need 'installing into project folder (this downloads several GB)'
            $proc = Start-Process -FilePath $bootstrap -ArgumentList @(
                '--quiet', '--wait', '--norestart', '--nocache',
                "--installPath", $MsvcDir,
                '--add', 'Microsoft.VisualStudio.Workload.VCTools',
                '--add', 'Microsoft.VisualStudio.Component.VC.Tools.x86.x64',
                '--add', 'Microsoft.VisualStudio.Component.Windows11SDK.22621',
                '--includeRecommended'
            ) -PassThru
            $proc | Wait-Process
            Write-Ok "installed into $MsvcDir"
        }
    }
}

Write-Step 'Done'
Write-Host "Toolchain root: $ToolsDir"
exit 0
