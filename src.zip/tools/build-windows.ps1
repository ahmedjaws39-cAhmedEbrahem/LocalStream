<#
.SYNOPSIS
    Configures and builds the Windows app (and, with -Task test, runs its tests).

.DESCRIPTION
    Everything the build needs lives inside the project folder by policy; nothing is read from
    the machine's global package paths. The script finds the Visual Studio C++ toolchain via
    vcvars64.bat, imports its environment (PATH, INCLUDE, LIB) into this process, configures
    CMake against the project-local Qt and Ninja, builds build\windows, and optionally runs
    the test suite with CTest.

    Usage:
        powershell -ExecutionPolicy Bypass -File tools\build-windows.ps1            # build
        powershell -ExecutionPolicy Bypass -File tools\build-windows.ps1 -Task test # build + tests
        powershell -ExecutionPolicy Bypass -File tools\build-windows.ps1 -Task clean # wipe + rebuild
#>

[CmdletBinding()]
param(
    [ValidateSet('build', 'test', 'clean')]
    [string] $Task = 'build'
)

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'

$Root      = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$WindowsDir = Join-Path $Root 'windows'
$BuildDir  = Join-Path $Root 'build\windows'
$QtBin     = Join-Path $Root 'tools\qt\6.8.3\msvc2022_64\bin'
$CmakeExe  = Join-Path $Root 'tools\cmake\bin\cmake.exe'
$CtestExe  = Join-Path $Root 'tools\cmake\bin\ctest.exe'
$NinjaExe  = Join-Path $Root 'tools\ninja\ninja.exe'
$QtPrefix  = Join-Path $Root 'tools\qt\6.8.3\msvc2022_64'
$FfmpegRoot = Join-Path $Root 'tools\ffmpeg'

function Fail([string]$Message) {
    Write-Host "`n[fail] $Message" -ForegroundColor Red
    exit 1
}

if (-not (Test-Path $CmakeExe))  { Fail "cmake.exe not found at $CmakeExe. Run tools\fetch-toolchain.ps1 first." }
if (-not (Test-Path $NinjaExe))  { Fail "ninja.exe not found at $NinjaExe. Run tools\fetch-toolchain.ps1 first." }
if (-not (Test-Path $QtPrefix))  { Fail "Qt install not found at $QtPrefix. Run tools\fetch-toolchain.ps1 first." }
if (-not (Test-Path $WindowsDir)) {
    # The source tree has to exist before CMake can be pointed at it. Someone who unpacked the
    # project rather than cloning it can end up one directory up or down; guard the whole source
    # directory here so a wrong working directory gives a name, not a confusing configure error.
    $src = Join-Path $Root 'windows'
    if (-not (Test-Path (Join-Path $src 'CMakeLists.txt'))) {
        Fail "windows\CMakeLists.txt was not found under $src."
    }
}

# ------------------------------------------------------------------ MSVC toolchain
#
# The Ninja generator needs the MSVC environment (cl.exe/link.exe on PATH, plus INCLUDE and
# LIB) to be inherited from a real vcvars batch file. Locate one across the VB editions, and
# fall back to the project-local install fetch-toolchain.ps1 can produce.

$vcvars = @(
    'C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvars64.bat',
    'C:\Program Files\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvars64.bat',
    "$Root\tools\msvc\VC\Auxiliary\Build\vcvars64.bat"
) | Where-Object { Test-Path $_ } | Select-Object -First 1

if (-not $vcvars) {
    # Try a broader search: Community/Professional/Enterprise for VS 2022 and 2019.
    $vsRoots = @(
        'C:\Program Files\Microsoft Visual Studio\2022',
        'C:\Program Files (x86)\Microsoft Visual Studio\2022',
        'C:\Program Files\Microsoft Visual Studio\2019'
    )
    foreach ($vs in $vsRoots) {
        if (Test-Path $vs) {
            foreach ($edition in 'Community', 'Professional', 'Enterprise', 'BuildTools') {
                $candidate = Join-Path $vs "$edition\VC\Auxiliary\Build\vcvars64.bat"
                if (Test-Path $candidate) { $vcvars = $candidate; break }
            }
        }
        if ($vcvars) { break }
    }
}

if (-not $vcvars) {
    Fail "vcvars64.bat was not found. Install the Visual Studio Build Tools 'Desktop development with C++' workload, or run tools\fetch-toolchain.ps1 -Only msvc."
}

Write-Host "MSVC env   : $vcvars" -ForegroundColor Cyan

# `cmd /c "call vcvars64.bat && set"` prints every environment variable the batch file
# establishes. Parse KEY=VALUE pairs back into this process so cl.exe, the headers and the
# import libraries are all on the exact paths the compiler expects, whatever CMake later runs.
$setOutput = cmd /c "call `"$vcvars`" >nul && set" 2>$null
if ($LASTEXITCODE -ne 0) {
    Fail "Failed to run $vcvars; it returned exit code $LASTEXITCODE."
}
foreach ($line in $setOutput) {
    if ($line -match '^(.+?)=(.*)$') {
        Set-Item -Path "Env:$($Matches[1])" -Value $Matches[2]
    }
}

# The version banner identifies which toolchain actually got imported; print it so the log
# records the compiler, not just the batch file name.
& "${env:ComSpec}" /c "call `"$vcvars`" >nul && cl 2>&1" |
    ForEach-Object { Write-Host "Compiler   : $_" -ForegroundColor Cyan }

# ------------------------------------------------------------------ configure + build

if ($Task -eq 'clean') {
    Write-Host "==> Cleaning $BuildDir" -ForegroundColor Cyan
    if (Test-Path $BuildDir) { Remove-Item -LiteralPath $BuildDir -Recurse -Force }
}

New-Item -ItemType Directory -Force -Path $BuildDir | Out-Null

Write-Host "==> Configuring CMake" -ForegroundColor Cyan
& $CmakeExe -S $WindowsDir -B $BuildDir -G Ninja `
    "-DCMAKE_MAKE_PROGRAM=$NinjaExe" `
    "-DCMAKE_PREFIX_PATH=$QtPrefix" `
    "-DLOCALSTREAM_FFMPEG_ROOT=$FfmpegRoot" `
    '-DCMAKE_BUILD_TYPE=RelWithDebInfo' `
    '-DLOCALSTREAM_BUILD_TESTS=ON' `
    '-DLOCALSTREAM_ENABLE_FFMPEG=ON' `
    '-DLOCALSTREAM_ENABLE_DISCOVERY=ON'
if ($LASTEXITCODE -ne 0) { Fail "CMake configure failed with exit code $LASTEXITCODE." }

Write-Host "==> Building" -ForegroundColor Cyan
& $CmakeExe --build $BuildDir
if ($LASTEXITCODE -ne 0) { Fail "CMake build failed with exit code $LASTEXITCODE." }

$exe = Join-Path $BuildDir 'bin\LocalStream.exe'
if (Test-Path $exe) {
    Write-Host "    [ok]   $exe" -ForegroundColor Green
} else {
    Write-Host "    [warn] LocalStream.exe was not produced; the application target may be disabled in CMakeLists.txt." -ForegroundColor Yellow
}

# ------------------------------------------------------------------ tests

if ($Task -eq 'test') {
    Write-Host "==> Running tests" -ForegroundColor Cyan
    & $CtestExe --test-dir $BuildDir --output-on-failure
    if ($LASTEXITCODE -ne 0) { Fail "Tests failed with exit code $LASTEXITCODE." }
}

Write-Host '==> Done' -ForegroundColor Cyan
exit 0