<#
.SYNOPSIS
    Packs the source tree into src.zip - the archive the project is handed over in.

.DESCRIPTION
    The archive holds the source and nothing that has to be downloaded or built: the two
    platforms, the tools that build them, the documentation, the licence texts and the
    continuous-integration workflows. The vendored toolchains under tools\ (Qt, FFmpeg, CMake,
    Ninja, vcpkg, the Gradle cache) and every build output are left out, so what is left is
    small enough to send and complete enough to build from once the toolchain is fetched again.

    The release keystore is deliberately not included, and the script fails rather than write an
    archive that contains one.

.EXAMPLE
    powershell -NoProfile -ExecutionPolicy Bypass -File tools\package-source.ps1
    # -> src.zip beside the repository root

.EXAMPLE
    powershell -NoProfile -ExecutionPolicy Bypass -File tools\package-source.ps1 -Path D:\out\source.zip
#>

[CmdletBinding()]
param(
    # Where to write the archive. Defaults to src.zip beside the repository root.
    [string] $Path = ''
)

$ErrorActionPreference = 'Stop'

$Root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
if (-not $Path) { $Path = Join-Path $Root 'src.zip' }
$Path = [System.IO.Path]::GetFullPath($Path)

# Top-level files that belong to the source.
$topFiles = @(
    '.gitattributes', '.gitignore', 'README.md', 'CHANGELOG.md', 'LICENSE', 'run-windows.bat'
)

# Directories that belong to the source.
$roots = @('.github', 'docs', 'licenses', 'android', 'windows', 'tools')

# Under tools\, these are downloads rather than project code.
$toolchainDirs = @(
    'cmake', 'ninja', 'qt', 'ffmpeg', 'vcpkg', 'msvc', 'pylibs',
    'gradle-home', 'gradle-8.9', 'android-keystore'
)

# Never packed, wherever they appear.
$excludeDirs = @('build', '.gradle', '.kotlin', '.vs', '.idea', '.vscode', '__pycache__')
$excludeFiles = @(
    'local.properties', 'keystore.properties', '*.jks', '*.keystore',
    '*.tmp', '*.log', '*.bak', '*.orig', '*.suo', '*.user', 'Thumbs.db', 'desktop.ini'
)

$files = New-Object System.Collections.Generic.List[string]
$skipped = New-Object System.Collections.Generic.List[string]

foreach ($name in $topFiles) {
    $full = Join-Path $Root $name
    if (Test-Path $full) { $files.Add($full) } else { Write-Warning "not found, skipping: $name" }
}

foreach ($rootName in $roots) {
    $dir = Join-Path $Root $rootName
    if (-not (Test-Path $dir)) { Write-Warning "not found, skipping: $rootName"; continue }

    foreach ($file in (Get-ChildItem $dir -Recurse -File -Force)) {
        $relative = $file.FullName.Substring($Root.Length + 1)
        $parts = $relative -split '[\\/]'

        $drop = $null
        foreach ($part in $parts) {
            if ($excludeDirs -contains $part) { $drop = "directory $part"; break }
            if ($rootName -eq 'tools' -and $toolchainDirs -contains $part) { $drop = "toolchain $part"; break }
        }
        if (-not $drop) {
            foreach ($pattern in $excludeFiles) {
                if ($file.Name -like $pattern) { $drop = "file $($file.Name)"; break }
            }
        }

        if ($drop) { $skipped.Add($relative) } else { $files.Add($file.FullName) }
    }
}

# A secret in a source archive is unrecoverable once it has been sent, so check before writing.
$forbidden = $files | Where-Object { $_ -match '\.(jks|keystore)$' -or $_ -match 'keystore\.properties$' }
if ($forbidden) {
    throw "Refusing to write a source archive that contains signing material: $($forbidden -join ', ')"
}

if (Test-Path $Path) { Remove-Item $Path -Force }
New-Item -ItemType Directory -Force -Path (Split-Path -Parent $Path) | Out-Null

Add-Type -AssemblyName System.IO.Compression.FileSystem
$archive = [System.IO.Compression.ZipFile]::Open($Path, 'Create')
try {
    foreach ($file in ($files | Sort-Object)) {
        $entryName = $file.Substring($Root.Length + 1).Replace('\', '/')
        [System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile(
            $archive, $file, $entryName, [System.IO.Compression.CompressionLevel]::Optimal) | Out-Null
    }
} finally {
    $archive.Dispose()
}

$info = Get-Item $Path
Write-Host ''
Write-Host "Archive : $($info.FullName)"
Write-Host ("Files   : {0}" -f $files.Count)
Write-Host ("Size    : {0:N0} bytes ({1:N2} MiB)" -f $info.Length, ($info.Length / 1MB))
Write-Host ("Skipped : {0} path(s) - toolchains, build output and local state" -f $skipped.Count)
