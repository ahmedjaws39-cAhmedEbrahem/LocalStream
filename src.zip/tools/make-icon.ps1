# Generates windows\resources\LocalStream.ico from the same mark the Android launcher icon
# uses: a monitor with two broadcast waves on a dark background.
#
# The Android icon is a vector (res/drawable/ic_launcher_foreground.xml, 108x108 viewport);
# this script redraws that geometry with System.Drawing and packs the result into a multi-size
# .ico (16/24/32/48/64/128/256), so the Windows executable carries the same mark.
#
# Run it only when the mark changes:
#   powershell -NoProfile -ExecutionPolicy Bypass -File tools\make-icon.ps1

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Drawing

$RepoRoot = Split-Path -Parent $PSScriptRoot
$OutFile  = Join-Path $RepoRoot 'windows\resources\LocalStream.ico'
$Preview  = Join-Path $RepoRoot 'build\icon-preview-256.png'

# The 108x108 viewport of the Android vector.
$background = [System.Drawing.ColorTranslator]::FromHtml('#0B1B2B')
$screenCol  = [System.Drawing.ColorTranslator]::FromHtml('#7FD4FF')
$waveCol    = [System.Drawing.ColorTranslator]::FromHtml('#4FC3F7')
$dotCol     = [System.Drawing.Color]::White

function New-MarkBitmap([int]$size) {
    $bmp = New-Object System.Drawing.Bitmap($size, $size, [System.Drawing.Imaging.PixelFormat]::Format32bppArgb)
    $g = [System.Drawing.Graphics]::FromImage($bmp)
    $g.SmoothingMode     = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
    $g.PixelOffsetMode   = [System.Drawing.Drawing2D.PixelOffsetMode]::HighQuality
    $g.Clear($background)

    # Work in the 108-unit viewport, scaled to the bitmap.
    $s = $size / 108.0
    $g.ScaleTransform($s, $s)

    function New-RoundedRect([single]$x, [single]$y, [single]$w, [single]$h, [single]$r) {
        $p = New-Object System.Drawing.Drawing2D.GraphicsPath
        $d = $r * 2
        $p.AddArc($x, $y, $d, $d, 180, 90)
        $p.AddArc($x + $w - $d, $y, $d, $d, 270, 90)
        $p.AddArc($x + $w - $d, $y + $h - $d, $d, $d, 0, 90)
        $p.AddArc($x, $y + $h - $d, $d, $d, 90, 90)
        $p.CloseFigure()
        return $p
    }

    # Display, stand, base: exactly the rectangles of the vector.
    $b = New-Object System.Drawing.SolidBrush($screenCol)
    $g.FillPath($b, (New-RoundedRect 28 36 52 32 4))
    $g.FillRectangle($b, 48, 68, 12, 4)
    $g.FillRectangle($b, 40, 72, 28, 4)
    $b.Dispose()

    # Two broadcast waves, centred at (74,52), opening away from the screen.
    $wave = New-Object System.Drawing.Pen($waveCol, 4)
    $wave.StartCap = [System.Drawing.Drawing2D.LineCap]::Round
    $wave.EndCap   = [System.Drawing.Drawing2D.LineCap]::Round
    foreach ($radius in 14, 22) {
        $box = New-Object System.Drawing.RectangleF((74 - $radius), (52 - $radius), (2 * $radius), (2 * $radius))
        $g.DrawArc($wave, $box, -52, 104)
    }
    $wave.Dispose()

    # The transmission point.
    $dot = New-Object System.Drawing.SolidBrush($dotCol)
    $g.FillEllipse($dot, 69, 45, 10, 10)
    $dot.Dispose()

    $g.Dispose()
    return $bmp
}

# Render at 256 and downscale, so the small sizes are crisp.
$master = New-MarkBitmap 1024

function Export-Png([System.Drawing.Bitmap]$src, [int]$size) {
    $out = New-Object System.Drawing.Bitmap($size, $size, [System.Drawing.Imaging.PixelFormat]::Format32bppArgb)
    $g = [System.Drawing.Graphics]::FromImage($out)
    $g.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
    $g.PixelOffsetMode   = [System.Drawing.Drawing2D.PixelOffsetMode]::HighQuality
    $g.DrawImage($src, 0, 0, $size, $size)
    $g.Dispose()
    $ms = New-Object System.IO.MemoryStream
    $out.Save($ms, [System.Drawing.Imaging.ImageFormat]::Png)
    $out.Dispose()
    return ,$ms.ToArray()
}

# BMP (not PNG) for every size: an ICO of uncompressed 32-bit images renders everywhere,
# including the 16x16 in a title bar. Format: BITMAPINFOHEADER, XOR pixels bottom-up (BGRA),
# then the 1bpp AND mask (unused because the alpha channel carries the shape, but required).
function Get-IcoBitmapBytes([System.Drawing.Bitmap]$img) {
    $w = $img.Width; $h = $img.Height
    $rect = New-Object System.Drawing.Rectangle(0, 0, $w, $h)
    $data = $img.LockBits($rect, [System.Drawing.Imaging.ImageLockMode]::ReadOnly,
                          [System.Drawing.Imaging.PixelFormat]::Format32bppArgb)
    $stride = $data.Stride
    $src = New-Object byte[] ($stride * $h)
    [System.Runtime.InteropServices.Marshal]::Copy($data.Scan0, $src, 0, $src.Length)
    $img.UnlockBits($data)

    $ms = New-Object System.IO.MemoryStream
    $bw = New-Object System.IO.BinaryWriter($ms)
    # BITMAPINFOHEADER
    $bw.Write([uint32]40); $bw.Write([int32]$w); $bw.Write([int32]($h * 2))
    $bw.Write([uint16]1);  $bw.Write([uint16]32)
    $bw.Write([uint32]0);  $bw.Write([uint32]0)
    $bw.Write([int32]0);   $bw.Write([int32]0)
    $bw.Write([uint32]0);  $bw.Write([uint32]0)
    # XOR pixels, bottom-up.
    for ($y = $h - 1; $y -ge 0; $y--) {
        $bw.Write($src, $y * $stride, $w * 4)
    }
    # AND mask: every row is 0, padded to a 4-byte boundary.
    $maskRow = [math]::Ceiling($w / 32.0) * 4
    $empty = New-Object byte[] $maskRow
    for ($y = 0; $y -lt $h; $y++) { $bw.Write($empty, 0, $maskRow) }
    $bw.Flush()
    return ,$ms.ToArray()
}

$sizes = 16, 24, 32, 48, 64, 128, 256
$images = foreach ($s in $sizes) {
    $bmp = New-Object System.Drawing.Bitmap($s, $s, [System.Drawing.Imaging.PixelFormat]::Format32bppArgb)
    $g = [System.Drawing.Graphics]::FromImage($bmp)
    $g.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
    $g.PixelOffsetMode   = [System.Drawing.Drawing2D.PixelOffsetMode]::HighQuality
    $g.DrawImage($master, 0, 0, $s, $s)
    $g.Dispose()
    $bmp
}

$payloads = $images | ForEach-Object { Get-IcoBitmapBytes $_ }

# ICONDIR + ICONDIRENTRY per image, then the payloads.
New-Item -ItemType Directory -Force -Path (Split-Path -Parent $OutFile) | Out-Null
$fs = [System.IO.File]::Create($OutFile)
$bw = New-Object System.IO.BinaryWriter($fs)
$bw.Write([uint16]0); $bw.Write([uint16]1); $bw.Write([uint16]$sizes.Count)

$offset = 6 + (16 * $sizes.Count)
for ($i = 0; $i -lt $sizes.Count; $i++) {
    $s = $sizes[$i]
    $bw.Write([byte]($(if ($s -ge 256) { 0 } else { $s })))   # width  (0 means 256)
    $bw.Write([byte]($(if ($s -ge 256) { 0 } else { $s })))   # height
    $bw.Write([byte]0); $bw.Write([byte]0)                    # palette, reserved
    $bw.Write([uint16]1); $bw.Write([uint16]32)               # planes, bpp
    $bw.Write([uint32]$payloads[$i].Length)
    $bw.Write([uint32]$offset)
    $offset += $payloads[$i].Length
}
foreach ($p in $payloads) { $bw.Write($p, 0, $p.Length) }
$bw.Flush(); $fs.Close()

# A PNG copy, so a sighted reviewer can look at the mark without an icon viewer.
New-Item -ItemType Directory -Force -Path (Split-Path -Parent $Preview) | Out-Null
[System.IO.File]::WriteAllBytes($Preview, (Export-Png $master 256))

$master.Dispose()
$images | ForEach-Object { $_.Dispose() }

Write-Host "Icon    : $OutFile ($((Get-Item $OutFile).Length) bytes, $($sizes.Count) sizes)"
Write-Host "Preview : $Preview"
