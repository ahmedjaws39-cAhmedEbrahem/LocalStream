; Inno Setup script for LocalStream.
;
; tools\package-windows.ps1 compiles this with iscc.exe, passing the version and the staged
; folder on the command line:
;
;   iscc.exe /DAppVersion=1.0.0 /DStageDir=...\LocalStream-1.0.0-windows-x64 `
;            /DOutputDir=...\windows-dist /DOutputBase=LocalStream-1.0.0-Setup LocalStream.iss
;
; The staged folder is built by the packaging script and holds everything the app needs at
; run time -- the exe, the Qt DLLs, the C++ runtime DLLs, the FFmpeg DLLs, the Qt plugins and
; the licence texts -- so the installed program depends on nothing else, and the installer
; itself carries all of it compressed inside the single setup .exe.
;
; On top of the usual pages this installer shows:
;   * a warning page (instead of silently proceeding) when Windows is older than 10, and
;   * a Select Additional Tasks page offering the Start menu shortcut, the desktop shortcut
;     and the Windows Firewall rule.

#ifndef AppVersion
  #define AppVersion "0.0.0"
#endif
#ifndef StageDir
  #define StageDir "."
#endif
#ifndef OutputDir
  #define OutputDir "."
#endif
#ifndef OutputBase
  #define OutputBase "LocalStream-Setup"
#endif

[Setup]
; A stable AppId: Inno uses it to recognise its own installations, so it must never change
; between releases or an upgrade would install alongside the old copy instead of over it.
AppId={{A7C4B9E2-3F6D-4B18-9E52-7C1D4A8F6B03}
AppName=LocalStream
AppVersion={#AppVersion}
AppVerName=LocalStream {#AppVersion}
; Shown in Settings > Apps and in the setup file's own properties, so it names the person the
; copyright line names rather than repeating the product name as if it were the publisher.
AppPublisher=Ahmed Ibrahim
AppCopyright=Copyright (C) 2026 Ahmed Ibrahim. GNU GPL v3 or later.
VersionInfoCompany=Ahmed Ibrahim
VersionInfoDescription=LocalStream Setup
VersionInfoProductName=LocalStream
VersionInfoProductVersion={#AppVersion}
VersionInfoVersion={#AppVersion}.0
VersionInfoCopyright=Copyright (C) 2026 Ahmed Ibrahim. GNU GPL v3 or later.
DefaultDirName={autopf}\LocalStream
DefaultGroupName=LocalStream
DisableProgramGroupPage=yes
OutputDir={#OutputDir}
OutputBaseFilename={#OutputBase}
Compression=lzma2/max
SolidCompression=yes
WizardStyle=modern
; The app is 64-bit; install it as such and refuse a 32-bit-only Windows. "x64compatible"
; means "runs 64-bit x64 code" -- plain "x64" was deprecated in favour of it.
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
; Writing under Program Files and adding a firewall rule both need elevation. The command-line
; override is what lets a per-user test install run without an elevation prompt.
PrivilegesRequired=admin
PrivilegesRequiredOverridesAllowed=commandline
SetupIconFile=..\..\windows\resources\LocalStream.ico
UninstallDisplayIcon={app}\LocalStream.exe
; The GPL text is shown before the files are copied.
LicenseFile={#StageDir}\licenses\LocalStream-GPL-3.0.txt

[Tasks]
Name: "startmenuicon"; Description: "Add a Start menu shortcut"; GroupDescription: "Shortcuts:"
Name: "desktopicon";   Description: "Add a desktop shortcut";   GroupDescription: "Shortcuts:"
Name: "firewallrule";  Description: "Allow LocalStream through Windows Firewall (recommended)"; GroupDescription: "Network:"

[Files]
; Everything the packaging script staged, licence folder included.
Source: "{#StageDir}\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{group}\LocalStream";     Filename: "{app}\LocalStream.exe"; Tasks: startmenuicon
Name: "{autodesktop}\LocalStream"; Filename: "{app}\LocalStream.exe"; Tasks: desktopicon

[Run]
; The firewall rule is per program, so it covers every port LocalStream uses (the TCP control
; port and the mDNS/UDP discovery socket) without opening anything else. Without it Windows
; shows its own "allow access?" dialog on first launch, which is easy to dismiss by accident.
; netsh exits non-zero when the rule cannot be added (a firewall the machine's policy has
; locked down). Setup does not read the exit code of a [Run] entry, so the cost is the missing
; rule and nothing else: the app still works and asks the first time it runs.
Filename: "{sys}\netsh.exe"; \
    Parameters: "advfirewall firewall add rule name=""LocalStream"" dir=in action=allow program=""{app}\LocalStream.exe"" enable=yes profile=domain,private"; \
    StatusMsg: "Allowing LocalStream through Windows Firewall..."; \
    Flags: runhidden; Tasks: firewallrule

Filename: "{app}\LocalStream.exe"; Description: "Launch LocalStream"; \
    Flags: nowait postinstall skipifsilent

[UninstallRun]
; Leave the machine as it was found. RunOnceId keeps the entry from running twice, and a rule
; that is not there to delete is the normal case rather than a failure: netsh reports it by
; exiting non-zero, which Setup does not treat as an error.
Filename: "{sys}\netsh.exe"; \
    Parameters: "advfirewall firewall delete rule name=""LocalStream"""; \
    Flags: runhidden; RunOnceId: "RemoveLocalStreamFirewallRule"

[Code]
var
  WindowsWarningPage: TOutputMsgWizardPage;

// Windows 10 and 11 both report a major version of 10 (11 differs only in the build number),
// so "older than 10" is exactly "major version below 10".
function WindowsIsOlderThanTen: Boolean;
var
  Info: TWindowsVersion;
begin
  GetWindowsVersionEx(Info);
  Result := Info.Major < 10;
end;

// A carriage return and a line feed. Written with Chr() rather than the usual shorthand because
// a literal "#13" in this file would be read by the Inno Setup preprocessor as a directive.
function NewLine: String;
begin
  Result := Chr(13) + Chr(10);
end;

procedure InitializeWizard;
begin
  if WindowsIsOlderThanTen then
  begin
    WindowsWarningPage := CreateOutputMsgPage(wpWelcome,
      'This version of Windows is not supported',
      'LocalStream is built and tested on Windows 10 and Windows 11.',
      'This computer reports a Windows version older than Windows 10. LocalStream has not ' +
      'been tested on it.' + NewLine + NewLine +
      'Installation is not blocked, but nothing is guaranteed: the program may not start, ' +
      'or it may fail while streaming. If you continue, you do so at your own risk.' +
      NewLine + NewLine +
      'Choose Next to continue anyway, or Cancel to close the installer.');
  end;
end;
