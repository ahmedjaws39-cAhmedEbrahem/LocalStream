# Changelog

All notable changes to LocalStream are recorded here. The format follows
[Keep a Changelog](https://keepachangelog.com/en/1.1.0/), and the project uses
[Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added

- **Windows installer.** `tools\package-windows.ps1` now builds a single setup .exe
  (Inno Setup) instead of a portable folder. Everything the program needs at run time is
  inside it — the Qt libraries, the Qt plugins, the FFmpeg libraries and the C++ runtime —
  so the installed copy depends on nothing else on the machine, and nothing has to be
  installed first.
- **Windows version check.** The installer shows a warning page before copying anything when
  the machine reports a version older than Windows 10: the program is untested there and the
  user continues at their own risk. Installation is not blocked.
- **Installer options page.** Start menu shortcut, desktop shortcut and a Windows Firewall
  rule, each chosen on the Select Additional Tasks page. The firewall rule is removed again
  on uninstall.
- **Continuous integration.** GitHub Actions build and test both halves on every push.
- **Project documentation.** `LICENSE` (GPLv3), `docs/PRIVACY.md`, `docs/THIRD-PARTY.md` and
  this changelog.

### Changed

- **Android targets API 36** (Android 16), as Google Play requires for updates since
  31 August 2026. The build moves with it: AGP 8.13.2, Gradle 8.14.6, Kotlin 2.2.21 with the
  Kotlin Compose compiler plugin, Compose BOM 2025.12.01.
- **Android draws edge to edge**, as API 35 and later require, and pads its content back out
  of the system bars.
- Android now declares its network security configuration in the manifest. The file already
  existed but nothing referenced it, so the policy it describes was not the one in force.
- The Android release build is now driven by the committed Gradle wrapper rather than a
  Gradle copy under `tools\`.

## [1.0.0] - 2026-10-17

First release. Two apps, one protocol: a phone or a PC broadcasts its screen, camera or
microphone over the local network, and the other watches.

### Added

- **Broadcasting (Windows, Android).** Screen capture, camera capture, microphone audio, and
  a generated test pattern and tone, sent as H.264 video and Opus audio over RTP.
- **Receiving (Windows, Android).** Automatic discovery of broadcasters on the network, and a
  manual address-and-port route for networks where discovery cannot cross.
- **Viewer permission (Windows broadcaster).** Watch freely, ask first, or require a password.
- **Android battery-optimisation switch.** A control on the Android Help tab that asks Android
  to exempt LocalStream from battery optimisation, on Android's own screen, and reports what
  Android decided. This keeps a broadcast alive once the phone's screen is off.
- **Diagnostics.** A rolled log file, a "write a report" action on both platforms, and the
  in-app tutorial.
- **Accessibility as a requirement, not a feature.** Every control is labelled for a screen
  reader; the Android build treats an unlabelled control as a lint error.

### Notes

- Android broadcasts cannot be restarted without asking for screen-capture permission again;
  Android does not allow that grant to be reused.
- `REQUEST_IGNORE_BATTERY_OPTIMIZATIONS` is restricted by Google Play to apps whose core
  function needs it. Broadcasting in the background qualifies, but the permission is worth
  revisiting if a submission is rejected.
