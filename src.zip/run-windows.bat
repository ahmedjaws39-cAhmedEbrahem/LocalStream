@echo off
rem LocalStream Windows launcher.
rem
rem Puts the project-local Qt and FFmpeg DLLs on PATH (nothing is read from the machine's
rem global installs) and starts the app. Double-click this file, or run it from a prompt.
rem
rem If the app has not been built yet, it is built automatically first.

setlocal
set "ROOT=%~dp0"
set "APP=%ROOT%build\windows\bin\LocalStream.exe"
set "PATH=%ROOT%tools\qt\6.8.3\msvc2022_64\bin;%ROOT%tools\ffmpeg\bin;%ROOT%build\windows\bin;%PATH%"

if not exist "%APP%" (
    echo LocalStream.exe was not found at:
    echo   %APP%
    echo.
    echo Building it now with tools\build-windows.ps1. This can take a few minutes.
    echo.
    powershell -NoProfile -ExecutionPolicy Bypass -File "%ROOT%tools\build-windows.ps1"
    if errorlevel 1 (
        echo.
        echo Build failed. Press any key to continue.
        pause
        exit /b 1
    )
)

if not exist "%APP%" (
    echo LocalStream.exe is still missing after the build:
    echo   %APP%
    echo.
    pause
    exit /b 1
)

start "" "%APP%" %*
endlocal
