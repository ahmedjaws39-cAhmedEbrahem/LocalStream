<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS []>
<TS version="2.1" language="fr" sourcelanguage="en">
<context>
    <name>BroadcastPage</name>
    <message>
        <location filename="../src/ui/BroadcastPage.cpp" line="+45" />
        <source>What to send</source>
        <translation>Ce qu'il faut envoyer</translation>
    </message>
    <message>
        <location line="+2" />
        <source>Include video</source>
        <translation>Inclure la vidéo</translation>
    </message>
    <message>
        <location line="+3" />
        <source>Turn this off to broadcast audio only. The video encoder stays warm, so turning it back on does not have to wait for a keyframe.</source>
        <translation>Désactivez ceci pour diffuser seulement l'audio. L'encodeur vidéo reste prêt, donc le réactiver n'a pas à attendre une image-clé.</translation>
    </message>
    <message>
        <location line="+5" />
        <source>Show a test pattern instead of the screen</source>
        <translation>Afficher une mire de test à la place de l'écran</translation>
    </message>
    <message>
        <location line="+2" />
        <source>Broadcast a generated pattern and tone instead of capturing this desktop. Useful on a machine with nothing worth sharing. Available before the broadcast starts.</source>
        <translation>Diffuser une mire et un son générés au lieu de capturer ce bureau. Utile sur une machine qui n'a rien d'intéressant à partager. Disponible avant le début de la diffusion.</translation>
    </message>
    <message>
        <location line="+5" />
        <source>Normalize audio level</source>
        <translation>Normaliser le niveau du son</translation>
    </message>
    <message>
        <location line="+3" />
        <source>Keep the broadcast at a steady volume even when the system volume or the capture device changes. Turn this off to send the captured level untouched. Available before the broadcast starts.</source>
        <translation>Garder la diffusion à un volume constant même si le volume du système ou la capture change. Désactivez ceci pour envoyer le niveau capturé tel quel. Disponible avant le début de la diffusion.</translation>
    </message>
    <message>
        <location line="+12" />
        <source>Which microphone to capture. The first one is used when this is left alone. Available before the broadcast starts.</source>
        <translation>Quel microphone capturer. Le premier est utilisé lorsque ce champ reste tel quel. Disponible avant le début de la diffusion.</translation>
    </message>
    <message>
        <location line="+3" />
        <source>Refresh</source>
        <translation>Actualiser</translation>
    </message>
    <message>
        <location line="+2" />
        <source>Refresh the microphone list</source>
        <translation>Actualiser la liste des microphones</translation>
    </message>
    <message>
        <location line="+2" />
        <source>Scan again for microphones plugged in since this window opened.</source>
        <translation>Relancer la recherche des microphones branchés depuis l'ouverture de cette fenêtre.</translation>
    </message>
    <message>
        <location line="+4" />
        <source>Microphone</source>
        <translation>Microphone</translation>
    </message>
    <message>
        <location line="+9" />
        <source>Quality</source>
        <translation>Qualité</translation>
    </message>
    <message>
        <location line="+4" />
        <source>1280 x 720</source>
        <translation>1280 x 720</translation>
    </message>
    <message>
        <location line="+1" />
        <source>1920 x 1080</source>
        <translation>1920 x 1080</translation>
    </message>
    <message>
        <location line="+1" />
        <source>The size sent to viewers, before they scale it to their own window.</source>
        <translation>La taille envoyée aux spectateurs, avant qu'ils ne l'adaptent à leur propre fenêtre.</translation>
    </message>
    <message>
        <location line="+6" />
        <location line="+7" />
        <source> kbps</source>
        <translation> kbit/s</translation>
    </message>
    <message>
        <location line="-6" />
        <source>How much detail to send. More looks sharper and uses more of the network.</source>
        <translation>Combien de détails envoyer. Davantage paraît plus net et consomme davantage de réseau.</translation>
    </message>
    <message>
        <location line="+7" />
        <source>How much detail to give the sound. 48 kbps is enough for speech.</source>
        <translation>Combien de détails donner au son. 48 kbit/s suffisent pour la parole.</translation>
    </message>
    <message>
        <location line="+9" />
        <source>Resolution</source>
        <translation>Résolution</translation>
    </message>
    <message>
        <location line="+3" />
        <source>Video bitrate</source>
        <translation>Débit vidéo</translation>
    </message>
    <message>
        <location line="+3" />
        <source>Audio bitrate</source>
        <translation>Débit audio</translation>
    </message>
    <message>
        <location line="+6" />
        <source>These are read when the broadcast starts, so they wait until it is stopped to take effect.</source>
        <translation>Ces réglages sont lus au démarrage de la diffusion : ils attendent donc qu'elle soit arrêtée pour prendre effet.</translation>
    </message>
    <message>
        <location line="+6" />
        <source>Packets</source>
        <translation>Paquets</translation>
    </message>
    <message>
        <location line="+7" />
        <source>1200 bytes (default)</source>
        <translation>1200 octets (par défaut)</translation>
    </message>
    <message>
        <location line="+2" />
        <source>1400 bytes</source>
        <translation>1400 octets</translation>
    </message>
    <message>
        <location line="+1" />
        <source>1000 bytes</source>
        <translation>1000 octets</translation>
    </message>
    <message>
        <location line="+1" />
        <source>800 bytes</source>
        <translation>800 octets</translation>
    </message>
    <message>
        <location line="+2" />
        <source>The largest datagram the video is split into. Smaller packets survive a weak Wi-Fi link more reliably; larger ones send fewer packets. Available before the broadcast starts.</source>
        <translation>Le plus gros datagramme dans lequel la vidéo est découpée. Les petits paquets traversent mieux une liaison Wi-Fi faible ; les plus gros en envoient moins. Disponible avant le début de la diffusion.</translation>
    </message>
    <message>
        <location line="+7" />
        <source> packets</source>
        <translation> paquets</translation>
    </message>
    <message>
        <location line="+2" />
        <source>A frame that splits into at least this many packets is spread across the frame time instead of sent in one burst, which reduces loss on a slow link. Available before the broadcast starts.</source>
        <translation>Une image qui se découpe en au moins ce nombre de paquets est répartie sur la durée de l'image au lieu d'être envoyée d'un seul coup, ce qui réduit les pertes sur une liaison lente. Disponible avant le début de la diffusion.</translation>
    </message>
    <message>
        <location line="+7" />
        <source> x frame time</source>
        <translation> x durée d'image</translation>
    </message>
    <message>
        <location line="+2" />
        <source>How slowly to spread a paced burst. Higher values add a little latency but cope with a more congested link. Available before the broadcast starts.</source>
        <translation>À quel rythme étaler une salve rythmée. Les valeurs plus élevées ajoutent un peu de latence mais supportent mieux une liaison plus encombrée. Disponible avant le début de la diffusion.</translation>
    </message>
    <message>
        <location line="+11" />
        <source>Maximum packet</source>
        <translation>Paquet maximal</translation>
    </message>
    <message>
        <location line="+2" />
        <source>Start pacing at</source>
        <translation>Commencer le rythme à</translation>
    </message>
    <message>
        <location line="+2" />
        <source>Spread over</source>
        <translation>Répartir sur</translation>
    </message>
    <message>
        <location line="+3" />
        <source>How the video is split into datagrams. These are read when the broadcast starts, so they wait until it is stopped to take effect.</source>
        <translation>Comment la vidéo est découpée en datagrammes. Ces réglages sont lus au démarrage de la diffusion : ils attendent donc qu'elle soit arrêtée pour prendre effet.</translation>
    </message>
    <message>
        <location line="+31" />
        <source>Who can watch</source>
        <translation>Qui peut regarder</translation>
    </message>
    <message>
        <location line="+4" />
        <source>Anyone on the network</source>
        <translation>Toute personne sur le réseau</translation>
    </message>
    <message>
        <location line="+2" />
        <source>Ask me first</source>
        <translation>Me demander d'abord</translation>
    </message>
    <message>
        <location line="+2" />
        <source>Only with a password</source>
        <translation>Uniquement avec un mot de passe</translation>
    </message>
    <message>
        <location line="+9" />
        <source>Between %1 and %2 characters</source>
        <translation>Entre %1 et %2 caractères</translation>
    </message>
    <message>
        <location line="+10" />
        <source>Access</source>
        <translation>Accès</translation>
    </message>
    <message>
        <location line="+4" />
        <source>Password</source>
        <translation>Mot de passe</translation>
    </message>
    <message>
        <location line="+8" />
        <source>Use this password</source>
        <translation>Utiliser ce mot de passe</translation>
    </message>
    <message>
        <location line="+3" />
        <source>Use this password for viewers who connect from now on</source>
        <translation>Utiliser ce mot de passe pour les spectateurs qui se connecteront à partir de maintenant</translation>
    </message>
    <message>
        <location line="+5" />
        <source>This takes effect straight away, so you can lock a broadcast you have already started. Viewers already watching keep their stream.</source>
        <translation>L'effet est immédiat : vous pouvez donc verrouiller une diffusion déjà commencée. Les spectateurs qui regardent déjà continuent de recevoir le flux.</translation>
    </message>
    <message>
        <location line="+11" />
        <source>Broadcast</source>
        <translation>Diffusion</translation>
    </message>
    <message>
        <location line="+18" />
        <location line="+263" />
        <source>Start broadcast</source>
        <translation>Démarrer la diffusion</translation>
    </message>
    <message>
        <location line="-259" />
        <source>Start sharing this computer on the local network.</source>
        <translation>Commencer à partager cet ordinateur sur le réseau local.</translation>
    </message>
    <message>
        <location line="+5" />
        <source>Give viewers the address and control port above if they cannot see this broadcast in their list.</source>
        <translation>Indiquez aux spectateurs l'adresse et le port de contrôle ci-dessus s'ils ne voient pas cette diffusion dans leur liste.</translation>
    </message>
    <message>
        <location line="+9" />
        <source>Ready to broadcast</source>
        <translation>Prêt à diffuser</translation>
    </message>
    <message>
        <location line="+16" />
        <source>Switched to audio and video. A keyframe follows shortly.</source>
        <translation>Passé en audio et vidéo. Une image-clé suit sous peu.</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Switched to audio only. The video encoder stays warm.</source>
        <translation>Passé en audio seul. L'encodeur vidéo reste prêt.</translation>
    </message>
    <message>
        <location line="+41" />
        <source>Broadcasting as %1. Control port %2 - viewers who cannot find this automatically can connect manually.</source>
        <translation>Diffusion sous le nom de %1. Port de contrôle %2 - les spectateurs qui ne la trouvent pas automatiquement peuvent se connecter manuellement.</translation>
    </message>
    <message>
        <location line="+9" />
        <source>Broadcast stopped.</source>
        <translation>Diffusion arrêtée.</translation>
    </message>
    <message>
        <location line="+25" />
        <source>%1 fps - %2 kbps - %3 receiver(s)</source>
        <translation>%1 im/s - %2 kbit/s - %3 spectateur(s)</translation>
    </message>
    <message>
        <location line="+7" />
        <source>
Last frame: %1 packet(s), %2 FU-A, largest %3 bytes</source>
        <translation>
Dernière image : %1 paquet(s), %2 FU-A, le plus grand %3 octets</translation>
    </message>
    <message>
        <location line="+10" />
        <source>Broadcasting. %1 joined.</source>
        <translation>Diffusion en cours. %1 a rejoint.</translation>
    </message>
    <message>
        <location line="+6" />
        <source>Broadcasting. %1 left.</source>
        <translation>Diffusion en cours. %1 est parti.</translation>
    </message>
    <message>
        <location line="+31" />
        <source>Windows PC</source>
        <translation>PC Windows</translation>
    </message>
    <message>
        <location line="+18" />
        <source>Starting the broadcast...</source>
        <translation>Démarrage de la diffusion...</translation>
    </message>
    <message>
        <location line="+36" />
        <source>That password cannot be used</source>
        <translation>Ce mot de passe ne peut pas être utilisé</translation>
    </message>
    <message>
        <location line="+1" />
        <source>The broadcast password must be between %1 and %2 characters.</source>
        <translation>Le mot de passe de la diffusion doit contenir entre %1 et %2 caractères.</translation>
    </message>
    <message>
        <location line="+4" />
        <source>Could not change who can watch</source>
        <translation>Impossible de modifier qui peut regarder</translation>
    </message>
    <message>
        <location line="+1" />
        <source>The access mode was not accepted.</source>
        <translation>Le mode d'accès n'a pas été accepté.</translation>
    </message>
    <message>
        <location line="+14" />
        <source>Access set to: %1. It applies to viewers who connect from now on.</source>
        <translation>Accès réglé sur : %1. Cela s'applique aux spectateurs qui se connecteront à partir de maintenant.</translation>
    </message>
    <message>
        <location line="+17" />
        <source>Stopping the broadcast...</source>
        <translation>Arrêt de la diffusion...</translation>
    </message>
    <message>
        <location line="+7" />
        <source>Stop broadcast</source>
        <translation>Arrêter la diffusion</translation>
    </message>
    <message>
        <location line="+22" />
        <source>A device</source>
        <translation>Un appareil</translation>
    </message>
    <message>
        <location line="+3" />
        <source>Allow %1 to watch?</source>
        <translation>Autoriser %1 à regarder ?</translation>
    </message>
    <message>
        <location line="+1" />
        <source>%1 wants to view your broadcast.</source>
        <translation>%1 souhaite regarder votre diffusion.</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Allow</source>
        <translation>Autoriser</translation>
    </message>
    <message>
        <location line="+0" />
        <source>Reject</source>
        <translation>Refuser</translation>
    </message>
    <message>
        <location line="+6" />
        <source>Broadcasting. %1 was allowed in.</source>
        <translation>Diffusion en cours. %1 a été autorisé.</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Broadcasting. %1 was rejected.</source>
        <translation>Diffusion en cours. %1 a été refusé.</translation>
    </message>
    <message>
        <location line="+8" />
        <source>The broadcast stopped.</source>
        <translation>La diffusion s'est arrêtée.</translation>
    </message>
    <message>
        <location line="+2" />
        <source>The broadcast stopped</source>
        <translation>La diffusion s'est arrêtée</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Viewers have been disconnected.

%1</source>
        <translation>Les spectateurs ont été déconnectés.
 
 %1</translation>
    </message>
    <message>
        <location line="+2" />
        <source>Could not start broadcasting.</source>
        <translation>Impossible de démarrer la diffusion.</translation>
    </message>
    <message>
        <location line="+2" />
        <source>Could not start broadcasting</source>
        <translation>Impossible de démarrer la diffusion</translation>
    </message>
    <message>
        <location line="+19" />
        <source>No microphone found</source>
        <translation>Aucun microphone trouvé</translation>
    </message>
    <message>
        <location line="+35" />
        <source>Only used when access is set to a password.</source>
        <translation>Utilisé uniquement lorsque l'accès est réglé sur un mot de passe.</translation>
    </message>
    <message>
        <location line="+26" />
        <source>No network address - is this computer on a network?</source>
        <translation>Aucune adresse réseau - cet ordinateur est-il connecté à un réseau ?</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Address %1</source>
        <translation>Adresse %1</translation>
    </message>
    <message>
        <location line="+2" />
        <source>  ·  control port %1</source>
        <translation>  ·  port de contrôle %1</translation>
    </message>
</context>
<context>
    <name>HelpPage</name>
    <message>
        <location filename="../src/ui/HelpPage.cpp" line="+40" />
        <source>LocalStream tutorial</source>
        <translation>Tutoriel LocalStream</translation>
    </message>
    <message>
        <location line="+31" />
        <source>LocalStream Tutorial</source>
        <translation>Tutoriel LocalStream</translation>
    </message>
    <message>
        <location line="+5" />
        <source>A guide that opens in your web browser: what the app is for, what each device needs, how to use it step by step, what every setting means, and what you can really do with it.</source>
        <translation>Un guide qui s'ouvre dans votre navigateur : à quoi sert l'application, ce dont chaque appareil a besoin, comment s'en servir étape par étape, ce que signifie chaque réglage, et ce qu'on peut vraiment faire avec.</translation>
    </message>
    <message>
        <location line="+5" />
        <source>Open the tutorial</source>
        <translation>Ouvrir le tutoriel</translation>
    </message>
    <message>
        <location line="+4" />
        <source>Open the tutorial in your web browser</source>
        <translation>Ouvrir le tutoriel dans votre navigateur web</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Opens the tutorial in the program you use for web pages. It works offline.</source>
        <translation>Ouvre le tutoriel dans le programme que vous utilisez pour les pages web. Il fonctionne hors ligne.</translation>
    </message>
    <message>
        <location line="+6" />
        <source>The page is stored inside this app and opens without an internet connection. Ctrl+3 brings you back to this tab.</source>
        <translation>La page est stockée dans cette application et s'ouvre sans connexion Internet. Ctrl+3 ramène à cet onglet.</translation>
    </message>
    <message>
        <location line="+8" />
        <source>What is inside</source>
        <translation>Ce qu'il contient</translation>
    </message>
    <message>
        <location line="+10" />
        <source>• What LocalStream is for: sharing a screen and a sound, following a computer from your phone, watching the same thing at the same time
• What you need on Windows, on Android, and on the network between them
• Using it step by step, as if you were doing it now
• Every setting on both tabs, explained in plain words
• Running in the background: what the switch on this tab does, and how the app stays alive beside the clock
• What this build is: version, date, creator and license
• Scenarios the apps really support, and what they do not do
• What to do when the list stays empty or the picture breaks up</source>
        <translation>• À quoi sert LocalStream : partager un écran et un son, suivre un ordinateur depuis votre téléphone, regarder la même chose en même temps
• Ce qu'il faut sur Windows, sur Android, et sur le réseau qui les relie
• Son utilisation étape par étape, comme si vous la faisiez maintenant
• Chaque réglage des deux onglets, expliqué simplement
• Le fonctionnement en arrière-plan : ce que fait l'interrupteur de cet onglet, et comment l'application reste vivante près de l'horloge
• Ce que contient cette version : numéro, date, auteur et licence
• Les scénarios réellement pris en charge, et ceux qui ne le sont pas
• Que faire quand la liste reste vide ou que l'image se coupe</translation>
    </message>
    <message>
        <location line="+16" />
        <source>Where the file is</source>
        <translation>Où se trouve le fichier</translation>
    </message>
    <message>
        <location line="+3" />
        <source>The tutorial is kept with this app's settings. If your computer has no program set up for web pages, open this file yourself:</source>
        <translation>Le tutoriel est conservé avec les réglages de l'application. Si votre ordinateur n'a aucun programme pour les pages web, ouvrez ce fichier vous-même :</translation>
    </message>
    <message>
        <location line="+16" />
        <source>Show the file in File Explorer</source>
        <translation>Afficher le fichier dans l'Explorateur</translation>
    </message>
    <message>
        <location line="+5" />
        <source>Show the tutorial file in File Explorer</source>
        <translation>Afficher le fichier du tutoriel dans l'Explorateur</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Useful when clicking Open the tutorial does nothing, because this computer has no program set up for web pages.</source>
        <translation>Utile quand cliquer sur « Ouvrir le tutoriel » ne fait rien, parce que cet ordinateur n'a aucun programme pour les pages web.</translation>
    </message>
    <message>
        <location line="+9" />
        <source>General</source>
        <translation>Général</translation>
    </message>
    <message>
        <location line="+5" />
        <source>What closing the window means. The choice is remembered, so it has to be made once.</source>
        <translation>Ce que signifie fermer la fenêtre. Le choix est mémorisé, il faut donc le faire une fois.</translation>
    </message>
    <message>
        <location line="+6" />
        <location line="+2" />
        <source>Run in background (continue when closed)</source>
        <translation>Fonctionner en arrière-plan (continuer après fermeture)</translation>
    </message>
    <message>
        <location line="+2" />
        <source>Closing the window hides LocalStream beside the clock instead of exiting it, so a broadcast keeps running while the window is gone. Double-click the tray icon, or choose Show on it, to bring the window back; Quit leaves.</source>
        <translation>Fermer la fenêtre masque LocalStream près de l'horloge au lieu de l'arrêter, si bien que la diffusion continue pendant l'absence de la fenêtre. Double-cliquez sur l'icône de la zone de notification, ou choisissez « Afficher », pour ramener la fenêtre ; « Quitter » sort.</translation>
    </message>
    <message>
        <location line="+12" />
        <source>While it is on, the app's icon sits by the clock with Show and Quit on it. Switching it on or off, and hiding or restoring the window, is written to the log, so a report can say whether the app was still running at the time.</source>
        <translation>Tant qu'il est actif, l'icône de l'application reste près de l'horloge avec Afficher et Quitter. L'activer ou le désactiver, masquer ou restaurer la fenêtre, est consigné, si bien qu'un rapport peut dire si l'application tournait encore à ce moment-là.</translation>
    </message>
    <message>
        <location line="+10" />
        <source>Report a problem</source>
        <translation>Signaler un problème</translation>
    </message>
    <message>
        <location line="+5" />
        <source>LocalStream keeps a detailed log of what it does, with the exact date and time of every event. Turn it on here, and then write a report you can attach to a message or keep for yourself.</source>
        <translation>LocalStream tient un journal détaillé de ce qu'il fait, avec la date et l'heure exactes de chaque événement. Activez-le ici, puis écrivez un rapport que vous pouvez joindre à un message ou garder pour vous.</translation>
    </message>
    <message>
        <location line="+9" />
        <location line="+1" />
        <source>Record a log automatically</source>
        <translation>Enregistrer un journal automatiquement</translation>
    </message>
    <message>
        <location line="+2" />
        <source>Writes what the app does to a log file while you use it. Turn this on before the problem happens, because a report written afterwards cannot describe it.</source>
        <translation>Écrit dans un fichier journal ce que fait l'application pendant que vous l'utilisez. Activez-le avant que le problème n'arrive : un rapport écrit après ne pourra pas le décrire.</translation>
    </message>
    <message>
        <location line="+14" />
        <source>Lines below this level are left out. Warning is the quieter choice; Debug records everything.</source>
        <translation>Les lignes sous ce niveau sont omises. Avertissement est le choix le plus discret ; Débogage enregistre tout.</translation>
    </message>
    <message>
        <location line="+3" />
        <source>Include milliseconds</source>
        <translation>Inclure les millisecondes</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Records the fraction of a second, which is often the whole explanation for a stall.</source>
        <translation>Enregistre la fraction de seconde, souvent toute l'explication d'un à-coup.</translation>
    </message>
    <message>
        <location line="+4" />
        <source>24-hour, with time zone</source>
        <translation>24 heures, avec fuseau horaire</translation>
    </message>
    <message>
        <location line="+1" />
        <source>12-hour, am/pm</source>
        <translation>12 heures, am/pm</translation>
    </message>
    <message>
        <location line="+1" />
        <source>The 24-hour form also writes the time zone offset, so a report can be lined up against other logs.</source>
        <translation>Le format 24 heures écrit aussi le décalage de fuseau horaire, pour qu'un rapport puisse être confronté aux autres journaux.</translation>
    </message>
    <message>
        <location line="+5" />
        <source> days</source>
        <translation> jours</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Log files older than this are deleted. Seven days is usually enough to notice a problem that comes and goes.</source>
        <translation>Les fichiers journaux plus vieux que cela sont supprimés. Sept jours suffisent généralement pour repérer un problème intermittent.</translation>
    </message>
    <message>
        <location line="+5" />
        <source> MiB</source>
        <translation> Mio</translation>
    </message>
    <message>
        <location line="+1" />
        <source>The ceiling for one day's log. Past it the file rolls over, so a long session cannot fill the disk.</source>
        <translation>Le plafond pour une journée de journal. Au-delà, le fichier change : une longue session ne peut donc pas remplir le disque.</translation>
    </message>
    <message>
        <location line="+16" />
        <source>Record from level</source>
        <translation>Enregistrer à partir du niveau</translation>
    </message>
    <message>
        <location line="+4" />
        <source>Time format</source>
        <translation>Format de l'heure</translation>
    </message>
    <message>
        <location line="+3" />
        <source>Keep log files</source>
        <translation>Conserver les fichiers journaux</translation>
    </message>
    <message>
        <location line="+3" />
        <source>Maximum size a day</source>
        <translation>Taille maximale par jour</translation>
    </message>
    <message>
        <location line="+8" />
        <source>Include this computer's details</source>
        <translation>Inclure les détails de cet ordinateur</translation>
    </message>
    <message>
        <location line="+2" />
        <source>The Windows version, the app version, the display and the free space on disk.</source>
        <translation>La version de Windows, la version de l'application, l'affichage et l'espace libre sur le disque.</translation>
    </message>
    <message>
        <location line="+3" />
        <source>Include the log itself</source>
        <translation>Inclure le journal lui-même</translation>
    </message>
    <message>
        <location line="+1" />
        <source>The most recent lines of the log, which is where the answer usually is.</source>
        <translation>Les lignes les plus récentes du journal, là où se trouve d'habitude la réponse.</translation>
    </message>
    <message>
        <location line="+6" />
        <source> KiB</source>
        <translation> Kio</translation>
    </message>
    <message>
        <location line="+1" />
        <source>How much of the log to include. 256 KiB is a few minutes of a normal session.</source>
        <translation>Combien du journal inclure. 256 Kio représentent quelques minutes d'une session normale.</translation>
    </message>
    <message>
        <location line="+3" />
        <source>Include the days before today</source>
        <translation>Inclure les jours précédents</translation>
    </message>
    <message>
        <location line="+2" />
        <source>For a problem that started yesterday and was only noticed this morning.</source>
        <translation>Pour un problème commencé hier et remarqué seulement ce matin.</translation>
    </message>
    <message>
        <location line="+3" />
        <source>Include these settings</source>
        <translation>Inclure ces réglages</translation>
    </message>
    <message>
        <location line="+1" />
        <source>The settings above, which decide what the log contains in the first place.</source>
        <translation>Les réglages ci-dessus, qui déterminent d'abord le contenu du journal.</translation>
    </message>
    <message>
        <location line="+22" />
        <source>Log lines to include</source>
        <translation>Lignes de journal à inclure</translation>
    </message>
    <message>
        <location line="+29" />
        <location line="+4" />
        <source>Save a report now</source>
        <translation>Enregistrer un rapport maintenant</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Writes a report you can attach to a message. Nothing is sent anywhere.</source>
        <translation>Écrit un rapport que vous pouvez joindre à un message. Rien n'est envoyé nulle part.</translation>
    </message>
    <message>
        <location line="+5" />
        <location line="+3" />
        <source>Open the log folder</source>
        <translation>Ouvrir le dossier des journaux</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Where the log files are kept.</source>
        <translation>Où sont conservés les fichiers journaux.</translation>
    </message>
    <message>
        <location line="+2" />
        <source>log</source>
        <translation>journal</translation>
    </message>
    <message>
        <location line="+4" />
        <location line="+3" />
        <source>Open the reports folder</source>
        <translation>Ouvrir le dossier des rapports</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Where reports are saved.</source>
        <translation>Où sont enregistrés les rapports.</translation>
    </message>
    <message>
        <location line="+2" />
        <source>report</source>
        <translation>rapport</translation>
    </message>
    <message>
        <location line="+18" />
        <source>About</source>
        <translation>À propos</translation>
    </message>
    <message>
        <location line="+18" />
        <source>Project</source>
        <translation>Projet</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Version</source>
        <translation>Version</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Date</source>
        <translation>Date</translation>
    </message>
    <message>
        <location line="+0" />
        <source>October 2026</source>
        <translation>Octobre 2026</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Creator</source>
        <translation>Auteur</translation>
    </message>
    <message>
        <location line="+0" />
        <source>Ahmed Ibrahim</source>
        <translation>Ahmed Ibrahim</translation>
    </message>
    <message>
        <location line="+1" />
        <source>License</source>
        <translation>Licence</translation>
    </message>
    <message>
        <location line="+0" />
        <source>GNU GPLv3</source>
        <translation>GNU GPLv3</translation>
    </message>
    <message>
        <location line="+5" />
        <source>Everything this app sends stays on your own network: no account, no upload, and no internet connection needed.</source>
        <translation>Tout ce que cette application envoie reste sur votre propre réseau : aucun compte, aucun envoi vers un serveur, aucune connexion Internet nécessaire.</translation>
    </message>
    <message>
        <location line="+19" />
        <location line="+12" />
        <location line="+16" />
        <location line="+14" />
        <source>Tutorial</source>
        <translation>Tutoriel</translation>
    </message>
    <message>
        <location line="-41" />
        <source>The tutorial could not be saved to this computer's settings folder, so it cannot be opened right now.</source>
        <translation>Le tutoriel n'a pas pu être enregistré dans le dossier de réglages de cet ordinateur : il ne peut pas être ouvert pour l'instant.</translation>
    </message>
    <message>
        <location line="+12" />
        <source>This computer has no program set up to open web pages.

Open this file yourself:
%1</source>
        <translation>Cet ordinateur n'a aucun programme pour ouvrir les pages web. Ouvrez ce fichier vous-même :
 %1</translation>
    </message>
    <message>
        <location line="+7" />
        <source>The tutorial is opening in your web browser.</source>
        <translation>Le tutoriel s'ouvre dans votre navigateur web.</translation>
    </message>
    <message>
        <location line="+9" />
        <source>The tutorial could not be saved to this computer's settings folder, so it cannot be shown right now.</source>
        <translation>Le tutoriel n'a pas pu être enregistré dans le dossier de réglages de cet ordinateur : il ne peut pas être affiché pour l'instant.</translation>
    </message>
    <message>
        <location line="+14" />
        <source>File Explorer could not be opened.

The tutorial is here:
%1</source>
        <translation>L'Explorateur n'a pas pu être ouvert. Le tutoriel est ici :
 %1</translation>
    </message>
    <message>
        <location line="+4" />
        <source>The tutorial's folder is open in File Explorer.</source>
        <translation>Le dossier du tutoriel est ouvert dans l'Explorateur.</translation>
    </message>
    <message>
        <location line="+44" />
        <source>The report could not be saved: %1</source>
        <translation>Le rapport n'a pas pu être enregistré : %1</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Report</source>
        <translation>Rapport</translation>
    </message>
    <message>
        <location line="+1" />
        <source>The report could not be saved.

%1</source>
        <translation>Le rapport n'a pas pu être enregistré.
 
 %1</translation>
    </message>
    <message>
        <location line="+9" />
        <source>Saved: %1
%2 KiB, from %3 log file(s).</source>
        <translation>Enregistré : %1
 %2 Kio, à partir de %3 fichier(s) journal.</translation>
    </message>
    <message>
        <location line="+6" />
        <source>Report saved as %1.</source>
        <translation>Rapport enregistré sous %1.</translation>
    </message>
    <message>
        <location line="+6" />
        <location line="+5" />
        <source>Folders</source>
        <translation>Dossiers</translation>
    </message>
    <message>
        <location line="-4" />
        <source>This computer has no folder available for the %1 files.</source>
        <translation>Aucun dossier n'est disponible sur cet ordinateur pour les fichiers %1.</translation>
    </message>
    <message>
        <location line="+5" />
        <source>The folder could not be opened.

%1</source>
        <translation>Le dossier n'a pas pu être ouvert.
 
 %1</translation>
    </message>
    <message>
        <location line="+60" />
        <source>No settings folder is available on this computer.</source>
        <translation>Aucun dossier de réglages n'est disponible sur cet ordinateur.</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/ui/MainWindow.cpp" line="+62" />
        <source>Share this computer on the network, or watch someone who is.</source>
        <translation>Partagez cet ordinateur sur le réseau, ou regardez quelqu'un qui le fait.</translation>
    </message>
    <message>
        <location line="+24" />
        <source>Broadcast</source>
        <translation>Diffusion</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Receive</source>
        <translation>Réception</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Help</source>
        <translation>Aide</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Share this computer's screen or audio.</source>
        <translation>Partager l'écran ou le son de cet ordinateur.</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Watch a broadcast from another computer.</source>
        <translation>Regarder une diffusion depuis un autre ordinateur.</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Open the tutorial in your web browser.</source>
        <translation>Ouvrir le tutoriel dans votre navigateur web.</translation>
    </message>
    <message>
        <location line="+48" />
        <source>a broadcast is running</source>
        <translation>une diffusion est en cours</translation>
    </message>
    <message>
        <location line="+5" />
        <source>you are watching a broadcast</source>
        <translation>vous regardez une diffusion</translation>
    </message>
    <message>
        <location line="+11" />
        <location line="+40" />
        <source>Close LocalStream</source>
        <translation>Fermer LocalStream</translation>
    </message>
    <message>
        <location line="-39" />
        <location line="+40" />
        <source>LocalStream is still busy: %1.</source>
        <translation>LocalStream est encore occupé : %1.</translation>
    </message>
    <message>
        <location line="-39" />
        <location line="+40" />
        <source> and </source>
        <translation> et </translation>
    </message>
    <message>
        <location line="-39" />
        <source>Close the app and stop?</source>
        <translation>Fermer l'application et arrêter ?</translation>
    </message>
    <message>
        <location line="+41" />
        <source>Hide it in the system tray and keep it running, or exit and stop?</source>
        <translation>La masquer dans la zone de notification et la laisser tourner, ou quitter et arrêter ?</translation>
    </message>
    <message>
        <location line="+4" />
        <source>Hide in the system tray</source>
        <translation>Masquer dans la zone de notification</translation>
    </message>
    <message>
        <location line="+2" />
        <source>Exit and stop</source>
        <translation>Quitter et arrêter</translation>
    </message>
    <message>
        <location line="+2" />
        <source>Cancel</source>
        <translation>Annuler</translation>
    </message>
    <message>
        <location line="+37" />
        <source>LocalStream is running in the background. Double-click to open it.</source>
        <translation>LocalStream fonctionne en arrière-plan. Double-cliquez pour l'ouvrir.</translation>
    </message>
    <message>
        <location line="+4" />
        <source>Show LocalStream</source>
        <translation>Afficher LocalStream</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Quit</source>
        <translation>Quitter</translation>
    </message>
    <message>
        <location line="+89" />
        <source>Theme: follow system</source>
        <translation>Thème : suivre le système</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Theme: light</source>
        <translation>Thème : clair</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Theme: dark</source>
        <translation>Thème : sombre</translation>
    </message>
    <message>
        <location line="+3" />
        <source> (Windows decides)</source>
        <translation> (Windows décide)</translation>
    </message>
    <message>
        <location line="+5" />
        <source>Windows High Contrast is on, so it decides the colours. Click to keep the preference for when it switches off.</source>
        <translation>Le contraste élevé de Windows est actif : c'est lui qui décide des couleurs. Cliquez pour conserver le préférence pour quand il sera désactivé.</translation>
    </message>
    <message>
        <location line="+2" />
        <source>Switch to the next colour theme. Ctrl+1 and Ctrl+2 switch tabs.</source>
        <translation>Passer au thème de couleurs suivant. Ctrl+1 et Ctrl+2 changent d'onglet.</translation>
    </message>
</context>
<context>
    <name>PasswordDialog</name>
    <message>
        <location filename="../src/ui/ReceivePage.cpp" line="+156" />
        <source>Watch</source>
        <translation>Regarder</translation>
    </message>
    <message>
        <location line="+4" />
        <source>Password required</source>
        <translation>Mot de passe requis</translation>
    </message>
    <message>
        <location line="+7" />
        <source>%1 is broadcasting privately.</source>
        <translation>%1 diffuse en privé.</translation>
    </message>
    <message>
        <location line="+1" />
        <location line="+42" />
        <source>The broadcaster</source>
        <translation>Le diffuseur</translation>
    </message>
    <message>
        <location line="-24" />
        <source>Password</source>
        <translation>Mot de passe</translation>
    </message>
    <message>
        <location line="+23" />
        <source>%1 requires a password.</source>
        <translation>%1 demande un mot de passe.</translation>
    </message>
    <message>
        <location line="+24" />
        <source>The password must be between %1 and %2 characters.</source>
        <translation>Le mot de passe doit contenir entre %1 et %2 caractères.</translation>
    </message>
</context>
<context>
    <name>ReceivePage</name>
    <message>
        <location line="-192" />
        <source>%1 - audio only</source>
        <translation>%1 - audio seulement</translation>
    </message>
    <message>
        <location line="+2" />
        <source>%1 - %2x%3</source>
        <translation>%1 - %2x%3</translation>
    </message>
    <message>
        <location line="+10" />
        <source>Windows PC</source>
        <translation>PC Windows</translation>
    </message>
    <message>
        <location line="+207" />
        <source>Available broadcasters</source>
        <translation>Diffuseurs disponibles</translation>
    </message>
    <message>
        <location line="+2" />
        <source>Broadcasters found on this network. Select one, then choose Connect.</source>
        <translation>Diffuseurs trouvés sur ce réseau. Choisissez-en un, puis cliquez sur Se connecter.</translation>
    </message>
    <message>
        <location line="+3" />
        <location line="+544" />
        <source>Connect</source>
        <translation>Se connecter</translation>
    </message>
    <message>
        <location line="-538" />
        <source>Search again</source>
        <translation>Rechercher à nouveau</translation>
    </message>
    <message>
        <location line="+2" />
        <source>Search for broadcasters again</source>
        <translation>Chercher à nouveau les diffuseurs</translation>
    </message>
    <message>
        <location line="+2" />
        <source>Ask the network again. Useful when a broadcaster has just come online, or when nothing has appeared for a while.</source>
        <translation>Redemander au réseau. Utile quand un diffuseur vient d'arriver en ligne, ou quand rien n'apparaît depuis un moment.</translation>
    </message>
    <message>
        <location line="+7" />
        <location line="+133" />
        <source>Receive buffer</source>
        <translation>Tampon de réception</translation>
    </message>
    <message>
        <location line="-132" />
        <source>Low latency (200 ms)</source>
        <translation>Faible latence (200 ms)</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Balanced (500 ms)</source>
        <translation>Équilibré (500 ms)</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Smooth (1 second)</source>
        <translation>Fluide (1 seconde)</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Maximum (2 seconds)</source>
        <translation>Maximum (2 secondes)</translation>
    </message>
    <message>
        <location line="+23" />
        <source>Video from the broadcaster</source>
        <translation>Vidéo du diffuseur</translation>
    </message>
    <message>
        <location line="+5" />
        <source>Fullscreen</source>
        <translation>Plein écran</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Enter fullscreen</source>
        <translation>Passer en plein écran</translation>
    </message>
    <message>
        <location line="+4" />
        <source>Connect to a broadcaster to see the picture here.</source>
        <translation>Connectez-vous à un diffuseur pour voir l'image ici.</translation>
    </message>
    <message>
        <location line="+25" />
        <source>If the list is empty, enter the broadcaster's address and the control port shown on its Broadcast screen.</source>
        <translation>Si la liste est vide, saisissez l'adresse du diffuseur et le port de contrôle affiché sur son écran « Diffusion ».</translation>
    </message>
    <message>
        <location line="+4" />
        <location line="+1" />
        <source>Broadcaster address</source>
        <translation>Adresse du diffuseur</translation>
    </message>
    <message>
        <location line="+2" />
        <location line="+1" />
        <source>Control port</source>
        <translation>Port de contrôle</translation>
    </message>
    <message>
        <location line="+8" />
        <source>Connect manually</source>
        <translation>Connexion manuelle</translation>
    </message>
    <message>
        <location line="+21" />
        <source>Broadcasters</source>
        <translation>Diffuseurs</translation>
    </message>
    <message>
        <location line="+12" />
        <source>Select a broadcaster, then choose Connect. Enter connects to the one highlighted.</source>
        <translation>Choisissez un diffuseur, puis cliquez sur Se connecter. Entrée se connecte à celui qui est sélectionné.</translation>
    </message>
    <message>
        <location line="+4" />
        <source>Connect by address</source>
        <translation>Se connecter par adresse</translation>
    </message>
    <message>
        <location line="+10" />
        <source>Picture</source>
        <translation>Image</translation>
    </message>
    <message>
        <location line="+14" />
        <source>Session</source>
        <translation>Session</translation>
    </message>
    <message>
        <location line="+12" />
        <source>Scanning for broadcasters on this network.</source>
        <translation>Recherche de diffuseurs sur ce réseau.</translation>
    </message>
    <message>
        <location line="+26" />
        <source>Searching for broadcasters...</source>
        <translation>Recherche de diffuseurs...</translation>
    </message>
    <message>
        <location line="+41" />
        <source>%1 Windows Firewall may also be blocking incoming connections to LocalStream.</source>
        <translation>%1 Le pare-feu Windows bloque peut-être aussi les connexions entrantes vers LocalStream.</translation>
    </message>
    <message>
        <location line="+20" />
        <source>Connected.</source>
        <translation>Connecté.</translation>
    </message>
    <message>
        <location line="+8" />
        <location line="+337" />
        <source>Disconnected.</source>
        <translation>Déconnecté.</translation>
    </message>
    <message>
        <location line="-309" />
        <source>Asking %1 for permission to watch...</source>
        <translation>Demande à %1 l'autorisation de regarder...</translation>
    </message>
    <message>
        <location line="+24" />
        <source>Blocked by the broadcaster</source>
        <translation>Bloqué par le diffuseur</translation>
    </message>
    <message>
        <location line="+8" />
        <source>%1 fps - %2 kbps</source>
        <translation>%1 im/s - %2 kbit/s</translation>
    </message>
    <message>
        <location line="+15" />
        <source>%1/%2 audio played</source>
        <translation>%1/%2 audio lu</translation>
    </message>
    <message>
        <location line="+2" />
        <source>no audio: %1</source>
        <translation>pas d'audio : %1</translation>
    </message>
    <message>
        <location line="+2" />
        <source>audio device not open</source>
        <translation>périphérique audio non ouvert</translation>
    </message>
    <message>
        <location line="+2" />
        <source>audio not decoding (%1 sent, %2 rejected)</source>
        <translation>audio non décodé (%1 envoyés, %2 rejetés)</translation>
    </message>
    <message>
        <location line="+5" />
        <source>Received: %1 audio, %2 video, %3 lost%4 - decoded: %5 video, %6</source>
        <translation>Reçu : %1 audio, %2 vidéo, %3 perdus%4 - décodé : %5 vidéo, %6</translation>
    </message>
    <message>
        <location line="+5" />
        <source> - waiting for keyframe header</source>
        <translation> - en attente de l'en-tête d'image-clé</translation>
    </message>
    <message>
        <location line="+72" />
        <source>Found a broadcaster. Choose Connect to watch.</source>
        <translation>Un diffuseur a été trouvé. Choisissez Se connecter pour regarder.</translation>
    </message>
    <message>
        <location line="+16" />
        <source>No broadcasters found. Check that both devices are on the same Wi-Fi network, and that Windows Firewall is letting LocalStream receive network traffic.</source>
        <translation>Aucun diffuseur trouvé. Vérifiez que les deux appareils sont sur le même réseau Wi-Fi et que le pare-feu Windows autorise LocalStream à recevoir du trafic réseau.</translation>
    </message>
    <message>
        <location line="+29" />
        <source>That broadcaster is no longer on the network.</source>
        <translation>Ce diffuseur n'est plus sur le réseau.</translation>
    </message>
    <message>
        <location line="+14" />
        <source>That broadcaster did not advertise a control port.</source>
        <translation>Ce diffuseur n'a pas indiqué de port de contrôle.</translation>
    </message>
    <message>
        <location line="+4" />
        <location line="+34" />
        <source>Connecting...</source>
        <translation>Connexion...</translation>
    </message>
    <message>
        <location line="-18" />
        <source>Enter the broadcaster's address first.</source>
        <translation>Saisissez d'abord l'adresse du diffuseur.</translation>
    </message>
    <message>
        <location line="+10" />
        <source>Enter the control port shown on the broadcaster's screen.</source>
        <translation>Saisissez le port de contrôle affiché sur l'écran du diffuseur.</translation>
    </message>
    <message>
        <location line="+21" />
        <source>Disconnecting...</source>
        <translation>Déconnexion...</translation>
    </message>
    <message>
        <location line="+7" />
        <source>Disconnect</source>
        <translation>Se déconnecter</translation>
    </message>
    <message>
        <location line="+47" />
        <source>Checking the password...</source>
        <translation>Vérification du mot de passe...</translation>
    </message>
    <message>
        <location line="+20" />
        <source>Could not connect.</source>
        <translation>Impossible de se connecter.</translation>
    </message>
    <message>
        <location line="+2" />
        <source>Could not connect</source>
        <translation>Impossible de se connecter</translation>
    </message>
</context>
<context>
    <name>VideoWindow</name>
    <message>
        <location line="-801" />
        <source>Exit fullscreen</source>
        <translation>Quitter le plein écran</translation>
    </message>
</context>
</TS>
