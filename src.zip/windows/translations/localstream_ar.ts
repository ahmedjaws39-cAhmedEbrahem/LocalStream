<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS []>
<TS version="2.1" language="ar" sourcelanguage="en">
<context>
    <name>BroadcastPage</name>
    <message>
        <location filename="../src/ui/BroadcastPage.cpp" line="+45" />
        <source>What to send</source>
        <translation>ماذا تريد أن ترسل</translation>
    </message>
    <message>
        <location line="+2" />
        <source>Include video</source>
        <translation>تضمين الفيديو</translation>
    </message>
    <message>
        <location line="+3" />
        <source>Turn this off to broadcast audio only. The video encoder stays warm, so turning it back on does not have to wait for a keyframe.</source>
        <translation>أوقف هذا لبث الصوت فقط. يبقى مرمّز الفيديو جاهزًا، فإن إعادة تشغيله لا تنتظر إطار مفتاح.</translation>
    </message>
    <message>
        <location line="+5" />
        <source>Show a test pattern instead of the screen</source>
        <translation>عرض نمط اختبار بدل الشاشة</translation>
    </message>
    <message>
        <location line="+2" />
        <source>Broadcast a generated pattern and tone instead of capturing this desktop. Useful on a machine with nothing worth sharing. Available before the broadcast starts.</source>
        <translation>بث نمطًا ونغمة مولَّدين بدل التقاط سطح المكتب هذا. مفيد على جهاز لا شيء يستحق مشاركته. متاح قبل بدء البث.</translation>
    </message>
    <message>
        <location line="+5" />
        <source>Normalize audio level</source>
        <translation>توحيد مستوى الصوت</translation>
    </message>
    <message>
        <location line="+3" />
        <source>Keep the broadcast at a steady volume even when the system volume or the capture device changes. Turn this off to send the captured level untouched. Available before the broadcast starts.</source>
        <translation>أبقِ البث بمستوى صوت ثابت حتى يتغير مستوى النظام أو جهاز الالتقاط. أوقف هذا لإرسال المستوى الملتقَط دون تغيير. متاح قبل بدء البث.</translation>
    </message>
    <message>
        <location line="+12" />
        <source>Which microphone to capture. The first one is used when this is left alone. Available before the broadcast starts.</source>
        <translation>أي ميكروفون يُلتقط. يُستخدم الأول عند ترك هذا كما هو. متاح قبل بدء البث.</translation>
    </message>
    <message>
        <location line="+3" />
        <source>Refresh</source>
        <translation>تحديث</translation>
    </message>
    <message>
        <location line="+2" />
        <source>Refresh the microphone list</source>
        <translation>تحديث قائمة الميكروفونات</translation>
    </message>
    <message>
        <location line="+2" />
        <source>Scan again for microphones plugged in since this window opened.</source>
        <translation>أعد الفحص عن الميكروفونات الموصولة منذ فتح هذه النافذة.</translation>
    </message>
    <message>
        <location line="+4" />
        <source>Microphone</source>
        <translation>الميكروفون</translation>
    </message>
    <message>
        <location line="+9" />
        <source>Quality</source>
        <translation>الجودة</translation>
    </message>
    <message>
        <location line="+4" />
        <source>1280 x 720</source>
        <translation>1280 x 720</translation>
    </message>
    <message>
        <location line="+1" />
        <source>1920 x 1080</source>
        <translation>1920 x 1080</translation>
    </message>
    <message>
        <location line="+1" />
        <source>The size sent to viewers, before they scale it to their own window.</source>
        <translation>الحجم المُرسَل إلى المشاهدين، قبل أن يكيّفونه مع نافذتهم.</translation>
    </message>
    <message>
        <location line="+6" />
        <location line="+7" />
        <source> kbps</source>
        <translation> كيلوبت/ث</translation>
    </message>
    <message>
        <location line="-6" />
        <source>How much detail to send. More looks sharper and uses more of the network.</source>
        <translation>كم مقدار التفاصيل المُرسلة. المزيد يبدو أوضح ويستهلك من الشبكة أكثر.</translation>
    </message>
    <message>
        <location line="+7" />
        <source>How much detail to give the sound. 48 kbps is enough for speech.</source>
        <translation>كم مقدار التفاصيل الممنوحة للصوت. 48 كيلوبت/ث تكفي للكلام.</translation>
    </message>
    <message>
        <location line="+9" />
        <source>Resolution</source>
        <translation>الدقة</translation>
    </message>
    <message>
        <location line="+3" />
        <source>Video bitrate</source>
        <translation>معدل بتات الفيديو</translation>
    </message>
    <message>
        <location line="+3" />
        <source>Audio bitrate</source>
        <translation>معدل بتات الصوت</translation>
    </message>
    <message>
        <location line="+6" />
        <source>These are read when the broadcast starts, so they wait until it is stopped to take effect.</source>
        <translation>تُقرأ هذه الإعدادات عند بدء البث، لذلك تنتظر حتى يتوقف قبل أن تسري.</translation>
    </message>
    <message>
        <location line="+6" />
        <source>Packets</source>
        <translation>الحزم</translation>
    </message>
    <message>
        <location line="+7" />
        <source>1200 bytes (default)</source>
        <translation>1200 بايت (افتراضي)</translation>
    </message>
    <message>
        <location line="+2" />
        <source>1400 bytes</source>
        <translation>1400 بايت</translation>
    </message>
    <message>
        <location line="+1" />
        <source>1000 bytes</source>
        <translation>1000 بايت</translation>
    </message>
    <message>
        <location line="+1" />
        <source>800 bytes</source>
        <translation>800 بايت</translation>
    </message>
    <message>
        <location line="+2" />
        <source>The largest datagram the video is split into. Smaller packets survive a weak Wi-Fi link more reliably; larger ones send fewer packets. Available before the broadcast starts.</source>
        <translation>أكبر مخطط بيانات يُقسَّم إليه الفيديو. الحزم الصغيرة تنجو من اتصال واي فاي الضعيف بثبات أكبر؛ والكبيرة ترسل حزمًا أقل. متاح قبل بدء البث.</translation>
    </message>
    <message>
        <location line="+7" />
        <source> packets</source>
        <translation> حزمة</translation>
    </message>
    <message>
        <location line="+2" />
        <source>A frame that splits into at least this many packets is spread across the frame time instead of sent in one burst, which reduces loss on a slow link. Available before the broadcast starts.</source>
        <translation>إطار ينقسم إلى هذا العدد من الحزم على الأقل يُوزَّع على مدة الإطار بدل إرساله في دفعة واحدة، مما يقلل الفقد على الاتصال البطيء. متاح قبل بدء البث.</translation>
    </message>
    <message>
        <location line="+7" />
        <source> x frame time</source>
        <translation> x مدة الإطار</translation>
    </message>
    <message>
        <location line="+2" />
        <source>How slowly to spread a paced burst. Higher values add a little latency but cope with a more congested link. Available before the broadcast starts.</source>
        <translation>مدى بطء توزيع الدفعة المنظَّمة. القيم الأعلى تضيف قدرًا بسيطًا من التأخير لكنها تتحمل اتصالًا أكثر ازدحامًا. متاح قبل بدء البث.</translation>
    </message>
    <message>
        <location line="+11" />
        <source>Maximum packet</source>
        <translation>أكبر حزمة</translation>
    </message>
    <message>
        <location line="+2" />
        <source>Start pacing at</source>
        <translation>ابدأ التنظيم عند</translation>
    </message>
    <message>
        <location line="+2" />
        <source>Spread over</source>
        <translation>وزَّع على</translation>
    </message>
    <message>
        <location line="+3" />
        <source>How the video is split into datagrams. These are read when the broadcast starts, so they wait until it is stopped to take effect.</source>
        <translation>كيف يُقسَّم الفيديو إلى مخططات بيانات. تُقرأ هذه الإعدادات عند بدء البث، لذلك تنتظر حتى يتوقف قبل أن تسري.</translation>
    </message>
    <message>
        <location line="+31" />
        <source>Who can watch</source>
        <translation>من يمكنه المشاهدة</translation>
    </message>
    <message>
        <location line="+4" />
        <source>Anyone on the network</source>
        <translation>أي شخص على الشبكة</translation>
    </message>
    <message>
        <location line="+2" />
        <source>Ask me first</source>
        <translation>اسألني أولًا</translation>
    </message>
    <message>
        <location line="+2" />
        <source>Only with a password</source>
        <translation>بكلمة مرور فقط</translation>
    </message>
    <message>
        <location line="+9" />
        <source>Between %1 and %2 characters</source>
        <translation>بين %1 و%2 حرفًا</translation>
    </message>
    <message>
        <location line="+10" />
        <source>Access</source>
        <translation>الوصول</translation>
    </message>
    <message>
        <location line="+4" />
        <source>Password</source>
        <translation>كلمة المرور</translation>
    </message>
    <message>
        <location line="+8" />
        <source>Use this password</source>
        <translation>استخدم كلمة المرور هذه</translation>
    </message>
    <message>
        <location line="+3" />
        <source>Use this password for viewers who connect from now on</source>
        <translation>استخدم كلمة المرور هذه للمشاهدين الذين يتصلون من الآن فصاعدًا</translation>
    </message>
    <message>
        <location line="+5" />
        <source>This takes effect straight away, so you can lock a broadcast you have already started. Viewers already watching keep their stream.</source>
        <translation>يسري هذا فورًا، فبإمكانك قفل بثٍ بدأته بالفعل. المشاهدون الذين يشاهدون الآن يبقون على بثهم.</translation>
    </message>
    <message>
        <location line="+11" />
        <source>Broadcast</source>
        <translation>البث</translation>
    </message>
    <message>
        <location line="+18" />
        <location line="+263" />
        <source>Start broadcast</source>
        <translation>ابدأ البث</translation>
    </message>
    <message>
        <location line="-259" />
        <source>Start sharing this computer on the local network.</source>
        <translation>ابدأ مشاركة هذا الحاسوب على الشبكة المحلية.</translation>
    </message>
    <message>
        <location line="+5" />
        <source>Give viewers the address and control port above if they cannot see this broadcast in their list.</source>
        <translation>امنح المشاهدين العنوان ومنفذ التحكم أعلاه إن لم يروا هذا البث في قائمتهم.</translation>
    </message>
    <message>
        <location line="+9" />
        <source>Ready to broadcast</source>
        <translation>جاهز للبث</translation>
    </message>
    <message>
        <location line="+16" />
        <source>Switched to audio and video. A keyframe follows shortly.</source>
        <translation>تم التبديل إلى الصوت والفيديو. يتبع ذلك إطار مفتاح بعد قليل.</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Switched to audio only. The video encoder stays warm.</source>
        <translation>تم التبديل إلى الصوت فقط. يبقى مرمّز الفيديو جاهزًا.</translation>
    </message>
    <message>
        <location line="+41" />
        <source>Broadcasting as %1. Control port %2 - viewers who cannot find this automatically can connect manually.</source>
        <translation>يبث باسم %1. منفذ التحكم %2 - المشاهدون الذين لا يجدونه تلقائيًا يمكنهم الاتصال يدويًا.</translation>
    </message>
    <message>
        <location line="+9" />
        <source>Broadcast stopped.</source>
        <translation>توقف البث.</translation>
    </message>
    <message>
        <location line="+25" />
        <source>%1 fps - %2 kbps - %3 receiver(s)</source>
        <translation>%1 إطار/ث - %2 كيلوبت/ث - %3 مشاهد</translation>
    </message>
    <message>
        <location line="+7" />
        <source>
Last frame: %1 packet(s), %2 FU-A, largest %3 bytes</source>
        <translation>
آخر إطار: %1 حزمة، %2 FU-A، الأكبر %3 بايت</translation>
    </message>
    <message>
        <location line="+10" />
        <source>Broadcasting. %1 joined.</source>
        <translation>يبث. انضم %1.</translation>
    </message>
    <message>
        <location line="+6" />
        <source>Broadcasting. %1 left.</source>
        <translation>يبث. غادر %1.</translation>
    </message>
    <message>
        <location line="+31" />
        <source>Windows PC</source>
        <translation>حاسوب Windows</translation>
    </message>
    <message>
        <location line="+18" />
        <source>Starting the broadcast...</source>
        <translation>بدء البث...</translation>
    </message>
    <message>
        <location line="+36" />
        <source>That password cannot be used</source>
        <translation>لا يمكن استخدام كلمة المرور هذه</translation>
    </message>
    <message>
        <location line="+1" />
        <source>The broadcast password must be between %1 and %2 characters.</source>
        <translation>يجب أن تكون كلمة مرور البث بين %1 و%2 حرفًا.</translation>
    </message>
    <message>
        <location line="+4" />
        <source>Could not change who can watch</source>
        <translation>تعذّر تغيير من يمكنه المشاهدة</translation>
    </message>
    <message>
        <location line="+1" />
        <source>The access mode was not accepted.</source>
        <translation>لم يتم قبول وضع الوصول.</translation>
    </message>
    <message>
        <location line="+14" />
        <source>Access set to: %1. It applies to viewers who connect from now on.</source>
        <translation>تم ضبط الوصول على: %1. يسري على المشاهدين الذين يتصلون من الآن فصاعدًا.</translation>
    </message>
    <message>
        <location line="+17" />
        <source>Stopping the broadcast...</source>
        <translation>جارٍ إيقاف البث...</translation>
    </message>
    <message>
        <location line="+7" />
        <source>Stop broadcast</source>
        <translation>أوقف البث</translation>
    </message>
    <message>
        <location line="+22" />
        <source>A device</source>
        <translation>جهاز</translation>
    </message>
    <message>
        <location line="+3" />
        <source>Allow %1 to watch?</source>
        <translation>هل تسمح لـ %1 بالمشاهدة؟</translation>
    </message>
    <message>
        <location line="+1" />
        <source>%1 wants to view your broadcast.</source>
        <translation>يريد %1 مشاهدة بثك.</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Allow</source>
        <translation>السماح</translation>
    </message>
    <message>
        <location line="+0" />
        <source>Reject</source>
        <translation>الرفض</translation>
    </message>
    <message>
        <location line="+6" />
        <source>Broadcasting. %1 was allowed in.</source>
        <translation>يبث. السماح لـ %1 بالدخول.</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Broadcasting. %1 was rejected.</source>
        <translation>يبث. رفض طلب %1.</translation>
    </message>
    <message>
        <location line="+8" />
        <source>The broadcast stopped.</source>
        <translation>توقف البث.</translation>
    </message>
    <message>
        <location line="+2" />
        <source>The broadcast stopped</source>
        <translation>توقف البث</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Viewers have been disconnected.
 
 %1</source>
        <translation>تم فصل المشاهدين.
 
 %1</translation>
    </message>
    <message>
        <location line="+2" />
        <source>Could not start broadcasting.</source>
        <translation>تعذّر بدء البث.</translation>
    </message>
    <message>
        <location line="+2" />
        <source>Could not start broadcasting</source>
        <translation>تعذّر بدء البث</translation>
    </message>
    <message>
        <location line="+19" />
        <source>No microphone found</source>
        <translation>لم يُعثر على ميكروفون</translation>
    </message>
    <message>
        <location line="+35" />
        <source>Only used when access is set to a password.</source>
        <translation>يُستخدم فقط عندما يكون الوصول مضبوطًا على كلمة مرور.</translation>
    </message>
    <message>
        <location line="+26" />
        <source>No network address - is this computer on a network?</source>
        <translation>لا يوجد عنوان شبكي - هل هذا الحاسوب على شبكة؟</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Address %1</source>
        <translation>العنوان %1</translation>
    </message>
    <message>
        <location line="+2" />
        <source>  ·  control port %1</source>
        <translation>  ·  منفذ التحكم %1</translation>
    </message>
</context>
<context>
    <name>HelpPage</name>
    <message>
        <location filename="../src/ui/HelpPage.cpp" line="+40" />
        <source>LocalStream tutorial</source>
        <translation>دليل LocalStream</translation>
    </message>
    <message>
        <location line="+31" />
        <source>LocalStream Tutorial</source>
        <translation>دليل LocalStream</translation>
    </message>
    <message>
        <location line="+5" />
        <source>A guide that opens in your web browser: what the app is for, what each device needs, how to use it step by step, what every setting means, and what you can really do with it.</source>
        <translation>دليل يُفتح في متصفح الويب: ما الغرض من التطبيق، وما يحتاجه كل جهاز، وكيف تستخدمه خطوة بخطوة، ومعنى كل إعداد، وما يمكنك فعله به حقًا.</translation>
    </message>
    <message>
        <location line="+5" />
        <source>Open the tutorial</source>
        <translation>افتح الدليل</translation>
    </message>
    <message>
        <location line="+4" />
        <source>Open the tutorial in your web browser</source>
        <translation>افتح الدليل في متصفح الويب</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Opens the tutorial in the program you use for web pages. It works offline.</source>
        <translation>يفتح الدليل في البرنامج الذي تستخدمه لصفحات الويب. يعمل دون اتصال.</translation>
    </message>
    <message>
        <location line="+6" />
        <source>The page is stored inside this app and opens without an internet connection. Ctrl+3 brings you back to this tab.</source>
        <translation>الصفحة مخزنة داخل هذا التطبيق وتُفتح دون اتصال بالإنترنت. يُعيدك Ctrl+3 إلى هذا التبويب.</translation>
    </message>
    <message>
        <location line="+8" />
        <source>What is inside</source>
        <translation>ما في الدليل</translation>
    </message>
    <message>
        <location line="+10" />
        <source>• What LocalStream is for: sharing a screen and a sound, following a computer from your phone, watching the same thing at the same time
• What you need on Windows, on Android, and on the network between them
• Using it step by step, as if you were doing it now
• Every setting on both tabs, explained in plain words
• Running in the background: what the switch on this tab does, and how the app stays alive beside the clock
• What this build is: version, date, creator and license
• Scenarios the apps really support, and what they do not do
• What to do when the list stays empty or the picture breaks up</source>
        <translation>• ما الغرض من LocalStream: مشاركة شاشة وصوت، ومتابعة حاسوب من هاتفك، ومشاهدة الشيء نفسه في الوقت نفسه
• ما تحتاجه على Windows وعلى Android وعلى الشبكة بينهما
• استخدامه خطوة بخطوة، كما لو كنت تفعله الآن
• كل إعداد في التبويبين، مشروحًا بكلمات واضحة
• التشغيل في الخلفية: ما يفعله المفتاح في هذا التبويب، وكيف يبقى التطبيق حيًا بجوار الساعة
• ما هي هذه النسخة: رقم النسخة، والتاريخ، وصاحبها، والرخصة
• السيناريوهات التي يدعمها التطبيق فعلًا، وما لا يدعمه
• ما العمل حين تبقى القائمة فارغة أو تتقطع الصورة</translation>
    </message>
    <message>
        <location line="+16" />
        <source>Where the file is</source>
        <translation>أين يوجد الملف</translation>
    </message>
    <message>
        <location line="+3" />
        <source>The tutorial is kept with this app's settings. If your computer has no program set up for web pages, open this file yourself:</source>
        <translation>يُحفظ الدليل مع إعدادات هذا التطبيق. إن لم يكن على حاسوبك برنامج مضبوط لصفحات الويب، فافتح هذا الملف بنفسك:</translation>
    </message>
    <message>
        <location line="+16" />
        <source>Show the file in File Explorer</source>
        <translation>أظهر الملف في مستكشف الملفات</translation>
    </message>
    <message>
        <location line="+5" />
        <source>Show the tutorial file in File Explorer</source>
        <translation>أظهر ملف الدليل في مستكشف الملفات</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Useful when clicking Open the tutorial does nothing, because this computer has no program set up for web pages.</source>
        <translation>مفيد عندما لا يفعل النقر على "افتح الدليل" شيئًا، لأن هذا الحاسوب لا يملك برنامجًا مضبوطًا لصفحات الويب.</translation>
    </message>
    <message>
        <location line="+9" />
        <source>General</source>
        <translation>عام</translation>
    </message>
    <message>
        <location line="+5" />
        <source>What closing the window means. The choice is remembered, so it has to be made once.</source>
        <translation>ماذا يعني إغلاق النافذة. يُحفظ الاختيار، لذا يجب اتخاذه مرة واحدة.</translation>
    </message>
    <message>
        <location line="+6" />
        <location line="+2" />
        <source>Run in background (continue when closed)</source>
        <translation>تشغيل في الخلفية (يكمل عند الإغلاق)</translation>
    </message>
    <message>
        <location line="+2" />
        <source>Closing the window hides LocalStream beside the clock instead of exiting it, so a broadcast keeps running while the window is gone. Double-click the tray icon, or choose Show on it, to bring the window back; Quit leaves.</source>
        <translation>إغلاق النافذة يخفي LocalStream بجوار الساعة بدل إنهائه، فيستمر البث أثناء غياب النافذة. انقر نقرًا مزدوجًا على أيقونة شريط النظام، أو اختر "إظهار" منها، لإرجاع النافذة؛ و"إنهاء" يغادر.</translation>
    </message>
    <message>
        <location line="+12" />
        <source>While it is on, the app's icon sits by the clock with Show and Quit on it. Switching it on or off, and hiding or restoring the window, is written to the log, so a report can say whether the app was still running at the time.</source>
        <translation>أثناء تشغيله، توجد أيقونة التطبيق بجوار الساعة وفيها "إظهار" و"إنهاء". تشغيله أو إيقافه، وإخفاء النافذة أو إعادتها، يُسجَّل في السجل، حتى يستطيع التقرير أن يقول إن كان التطبيق ما زال يعمل حينها.</translation>
    </message>
    <message>
        <location line="+10" />
        <source>Report a problem</source>
        <translation>الإبلاغ عن مشكلة</translation>
    </message>
    <message>
        <location line="+5" />
        <source>LocalStream keeps a detailed log of what it does, with the exact date and time of every event. Turn it on here, and then write a report you can attach to a message or keep for yourself.</source>
        <translation>يحتفظ LocalStream بسجل تفصيلي لما يفعله، مع التاريخ والوقت الدقيقين لكل حدث. شغّله من هنا، ثم اكتب تقريرًا يمكنك إرفاقه برسالة أو الاحتفاظ به لنفسك.</translation>
    </message>
    <message>
        <location line="+9" />
        <location line="+1" />
        <source>Record a log automatically</source>
        <translation>سجّل السجل تلقائيًا</translation>
    </message>
    <message>
        <location line="+2" />
        <source>Writes what the app does to a log file while you use it. Turn this on before the problem happens, because a report written afterwards cannot describe it.</source>
        <translation>يكتب ما يفعله التطبيق في ملف سجل أثناء استخدامه. شغّل هذا قبل حدوث المشكلة، فالتقرير المكتوب بعدها لا يستطيع وصفها.</translation>
    </message>
    <message>
        <location line="+14" />
        <source>Lines below this level are left out. Warning is the quieter choice; Debug records everything.</source>
        <translation>تُترك الأسطر التي دون هذا المستوى. "تحذير" هو الخيار الأكثر هدوءًا؛ و"تصحيح" يسجّل كل شيء.</translation>
    </message>
    <message>
        <location line="+3" />
        <source>Include milliseconds</source>
        <translation>تضمين المللي ثانية</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Records the fraction of a second, which is often the whole explanation for a stall.</source>
        <translation>يسجّل جزء الثانية، وهو غالبًا الشرح كله للتعثر.</translation>
    </message>
    <message>
        <location line="+4" />
        <source>24-hour, with time zone</source>
        <translation>24 ساعة، مع المنطقة الزمنية</translation>
    </message>
    <message>
        <location line="+1" />
        <source>12-hour, am/pm</source>
        <translation>12 ساعة، ص/م</translation>
    </message>
    <message>
        <location line="+1" />
        <source>The 24-hour form also writes the time zone offset, so a report can be lined up against other logs.</source>
        <translation>صيغة 24 ساعة تكتب أيضًا إزاحة المنطقة الزمنية، حتى يمكن مطابقة التقرير مع سجلات أخرى.</translation>
    </message>
    <message>
        <location line="+5" />
        <source> days</source>
        <translation> يومًا</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Log files older than this are deleted. Seven days is usually enough to notice a problem that comes and goes.</source>
        <translation>تُحذف ملفات السجل الأقدم من هذا. سبعة أيام تكفي عادةً لملاحظة مشكلة تأتي وتذهب.</translation>
    </message>
    <message>
        <location line="+5" />
        <source> MiB</source>
        <translation> م.با</translation>
    </message>
    <message>
        <location line="+1" />
        <source>The ceiling for one day's log. Past it the file rolls over, so a long session cannot fill the disk.</source>
        <translation>السقف الأقصى لسجل يوم واحد. بعده تنتقل الملفات إلى ملف جديد، فلا تستطيع جلسة طويلة ملء القرص.</translation>
    </message>
    <message>
        <location line="+16" />
        <source>Record from level</source>
        <translation>سجّل ابتداءً من المستوى</translation>
    </message>
    <message>
        <location line="+4" />
        <source>Time format</source>
        <translation>تنسيق الوقت</translation>
    </message>
    <message>
        <location line="+3" />
        <source>Keep log files</source>
        <translation>الاحتفاظ بملفات السجل</translation>
    </message>
    <message>
        <location line="+3" />
        <source>Maximum size a day</source>
        <translation>الحجم الأقصى لليوم</translation>
    </message>
    <message>
        <location line="+8" />
        <source>Include this computer's details</source>
        <translation>تضمين تفاصيل هذا الحاسوب</translation>
    </message>
    <message>
        <location line="+2" />
        <source>The Windows version, the app version, the display and the free space on disk.</source>
        <translation>نسخة Windows، ونسخة التطبيق، والشاشة، والمساحة الحرة على القرص.</translation>
    </message>
    <message>
        <location line="+3" />
        <source>Include the log itself</source>
        <translation>تضمين السجل نفسه</translation>
    </message>
    <message>
        <location line="+1" />
        <source>The most recent lines of the log, which is where the answer usually is.</source>
        <translation>أحدث أسطر السجل، وهو ما توجد فيه الإجابة عادةً.</translation>
    </message>
    <message>
        <location line="+6" />
        <source> KiB</source>
        <translation> ك.با</translation>
    </message>
    <message>
        <location line="+1" />
        <source>How much of the log to include. 256 KiB is a few minutes of a normal session.</source>
        <translation>كم من السجل يُضمَّن. 256 ك.با تعني بضع دقائق من جلسة عادية.</translation>
    </message>
    <message>
        <location line="+3" />
        <source>Include the days before today</source>
        <translation>تضمين الأيام التي سبقت اليوم</translation>
    </message>
    <message>
        <location line="+2" />
        <source>For a problem that started yesterday and was only noticed this morning.</source>
        <translation>لمشكلة بدأت أمس ولم يلاحظها إلا هذا الصباح.</translation>
    </message>
    <message>
        <location line="+3" />
        <source>Include these settings</source>
        <translation>تضمين هذه الإعدادات</translation>
    </message>
    <message>
        <location line="+1" />
        <source>The settings above, which decide what the log contains in the first place.</source>
        <translation>الإعدادات أعلاه، التي تحدد ما في السجل أصلًا.</translation>
    </message>
    <message>
        <location line="+22" />
        <source>Log lines to include</source>
        <translation>عدد أسطر السجل المُضمَّنة</translation>
    </message>
    <message>
        <location line="+29" />
        <location line="+4" />
        <source>Save a report now</source>
        <translation>احفظ تقريرًا الآن</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Writes a report you can attach to a message. Nothing is sent anywhere.</source>
        <translation>يكتب تقريرًا يمكنك إرفاقه برسالة. لا يُرسَل شيء إلى أي مكان.</translation>
    </message>
    <message>
        <location line="+5" />
        <location line="+3" />
        <source>Open the log folder</source>
        <translation>افتح مجلد السجل</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Where the log files are kept.</source>
        <translation>حيث تُحفظ ملفات السجل.</translation>
    </message>
    <message>
        <location line="+2" />
        <source>log</source>
        <translation>السجل</translation>
    </message>
    <message>
        <location line="+4" />
        <location line="+3" />
        <source>Open the reports folder</source>
        <translation>افتح مجلد التقارير</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Where reports are saved.</source>
        <translation>حيث تُحفظ التقارير.</translation>
    </message>
    <message>
        <location line="+2" />
        <source>report</source>
        <translation>التقرير</translation>
    </message>
    <message>
        <location line="+18" />
        <source>About</source>
        <translation>حول</translation>
    </message>
    <message>
        <location line="+18" />
        <source>Project</source>
        <translation>المشروع</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Version</source>
        <translation>النسخة</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Date</source>
        <translation>التاريخ</translation>
    </message>
    <message>
        <location line="+0" />
        <source>October 2026</source>
        <translation>أكتوبر 2026</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Creator</source>
        <translation>المؤلف</translation>
    </message>
    <message>
        <location line="+0" />
        <source>Ahmed Ibrahim</source>
        <translation>Ahmed Ibrahim</translation>
    </message>
    <message>
        <location line="+1" />
        <source>License</source>
        <translation>الرخصة</translation>
    </message>
    <message>
        <location line="+0" />
        <source>GNU GPLv3</source>
        <translation>GNU GPLv3</translation>
    </message>
    <message>
        <location line="+5" />
        <source>Everything this app sends stays on your own network: no account, no upload, and no internet connection needed.</source>
        <translation>كل ما يرسله هذا التطبيق يبقى على شبكتك أنت: بلا حساب، وبلا رفع، وبلا حاجة إلى اتصال بالإنترنت.</translation>
    </message>
    <message>
        <location line="+19" />
        <location line="+12" />
        <location line="+16" />
        <location line="+14" />
        <source>Tutorial</source>
        <translation>الدليل</translation>
    </message>
    <message>
        <location line="-41" />
        <source>The tutorial could not be saved to this computer's settings folder, so it cannot be opened right now.</source>
        <translation>تعذّر حفظ الدليل في مجلد إعدادات هذا الحاسوب، لذلك لا يمكن فتحه الآن.</translation>
    </message>
    <message>
        <location line="+12" />
        <source>This computer has no program set up to open web pages.
 
 Open this file yourself:
 %1</source>
        <translation>لا يوجد على هذا الحاسوب برنامج مضبوط لفتح صفحات الويب. افتح هذا الملف بنفسك:
 %1</translation>
    </message>
    <message>
        <location line="+7" />
        <source>The tutorial is opening in your web browser.</source>
        <translation>يجري فتح الدليل في متصفح الويب.</translation>
    </message>
    <message>
        <location line="+9" />
        <source>The tutorial could not be saved to this computer's settings folder, so it cannot be shown right now.</source>
        <translation>تعذّر حفظ الدليل في مجلد إعدادات هذا الحاسوب، لذلك لا يمكن عرضه الآن.</translation>
    </message>
    <message>
        <location line="+14" />
        <source>File Explorer could not be opened.
 
 The tutorial is here:
 %1</source>
        <translation>تعذّر فتح مستكشف الملفات. الدليل هنا:
 %1</translation>
    </message>
    <message>
        <location line="+4" />
        <source>The tutorial's folder is open in File Explorer.</source>
        <translation>مجلد الدليل مفتوح في مستكشف الملفات.</translation>
    </message>
    <message>
        <location line="+44" />
        <source>The report could not be saved: %1</source>
        <translation>تعذّر حفظ التقرير: %1</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Report</source>
        <translation>التقرير</translation>
    </message>
    <message>
        <location line="+1" />
        <source>The report could not be saved.
 
 %1</source>
        <translation>تعذّر حفظ التقرير.
 
 %1</translation>
    </message>
    <message>
        <location line="+9" />
        <source>Saved: %1
 %2 KiB, from %3 log file(s).</source>
        <translation>تم الحفظ: %1
 %2 ك.با، من %3 ملف سجل.</translation>
    </message>
    <message>
        <location line="+6" />
        <source>Report saved as %1.</source>
        <translation>تم حفظ التقرير باسم %1.</translation>
    </message>
    <message>
        <location line="+6" />
        <location line="+5" />
        <source>Folders</source>
        <translation>المجلدات</translation>
    </message>
    <message>
        <location line="-4" />
        <source>This computer has no folder available for the %1 files.</source>
        <translation>لا يوجد على هذا الحاسوب مجلد متاح لملفات %1.</translation>
    </message>
    <message>
        <location line="+5" />
        <source>The folder could not be opened.
 
 %1</source>
        <translation>تعذّر فتح المجلد.
 
 %1</translation>
    </message>
    <message>
        <location line="+60" />
        <source>No settings folder is available on this computer.</source>
        <translation>لا يوجد مجلد إعدادات متاح على هذا الحاسوب.</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/ui/MainWindow.cpp" line="+62" />
        <source>Share this computer on the network, or watch someone who is.</source>
        <translation>شارك هذا الحاسوب على الشبكة، أو شاهد من يفعل ذلك.</translation>
    </message>
    <message>
        <location line="+24" />
        <source>Broadcast</source>
        <translation>البث</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Receive</source>
        <translation>الاستقبال</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Help</source>
        <translation>المساعدة</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Share this computer's screen or audio.</source>
        <translation>شارك شاشة أو صوت هذا الحاسوب.</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Watch a broadcast from another computer.</source>
        <translation>شاهد بثًا من حاسوب آخر.</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Open the tutorial in your web browser.</source>
        <translation>افتح الدليل في متصفح الويب.</translation>
    </message>
    <message>
        <location line="+48" />
        <source>a broadcast is running</source>
        <translation>هناك بث قيد التشغيل</translation>
    </message>
    <message>
        <location line="+5" />
        <source>you are watching a broadcast</source>
        <translation>أنت تشاهد بثًا</translation>
    </message>
    <message>
        <location line="+11" />
        <location line="+40" />
        <source>Close LocalStream</source>
        <translation>إغلاق LocalStream</translation>
    </message>
    <message>
        <location line="-39" />
        <location line="+40" />
        <source>LocalStream is still busy: %1.</source>
        <translation>لا يزال LocalStream مشغولًا: %1.</translation>
    </message>
    <message>
        <location line="-39" />
        <location line="+40" />
        <source> and </source>
        <translation> و </translation>
    </message>
    <message>
        <location line="-39" />
        <source>Close the app and stop?</source>
        <translation>هل تريد إغلاق التطبيق وإيقافه؟</translation>
    </message>
    <message>
        <location line="+41" />
        <source>Hide it in the system tray and keep it running, or exit and stop?</source>
        <translation>هل تريد إخفاءه في منطقة الإشعارات مع بقائه يعمل، أم الإنهاء والإيقاف؟</translation>
    </message>
    <message>
        <location line="+4" />
        <source>Hide in the system tray</source>
        <translation>إخفاؤه في شريط النظام</translation>
    </message>
    <message>
        <location line="+2" />
        <source>Exit and stop</source>
        <translation>إنهاء وإيقاف</translation>
    </message>
    <message>
        <location line="+2" />
        <source>Cancel</source>
        <translation>إلغاء</translation>
    </message>
    <message>
        <location line="+37" />
        <source>LocalStream is running in the background. Double-click to open it.</source>
        <translation>يعمل LocalStream في الخلفية. انقر نقرًا مزدوجًا لفتحه.</translation>
    </message>
    <message>
        <location line="+4" />
        <source>Show LocalStream</source>
        <translation>إظهار LocalStream</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Quit</source>
        <translation>إنهاء</translation>
    </message>
    <message>
        <location line="+89" />
        <source>Theme: follow system</source>
        <translation>السمة: تتبع النظام</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Theme: light</source>
        <translation>السمة: فاتحة</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Theme: dark</source>
        <translation>السمة: داكنة</translation>
    </message>
    <message>
        <location line="+3" />
        <source> (Windows decides)</source>
        <translation> (يقرر Windows)</translation>
    </message>
    <message>
        <location line="+5" />
        <source>Windows High Contrast is on, so it decides the colours. Click to keep the preference for when it switches off.</source>
        <translation>التباين العالي في Windows مُفعّل، فهو يقرر الألوان. انقر للاحتفاظ بالتفضيل لحين إيقافه.</translation>
    </message>
    <message>
        <location line="+2" />
        <source>Switch to the next colour theme. Ctrl+1 and Ctrl+2 switch tabs.</source>
        <translation>التبديل إلى سمة الألوان التالية. مفتاحا Ctrl+1 وCtrl+2 يبدّلان التبويبات.</translation>
    </message>
</context>
<context>
    <name>PasswordDialog</name>
    <message>
        <location filename="../src/ui/ReceivePage.cpp" line="+156" />
        <source>Watch</source>
        <translation>شاهد</translation>
    </message>
    <message>
        <location line="+4" />
        <source>Password required</source>
        <translation>كلمة المرور مطلوبة</translation>
    </message>
    <message>
        <location line="+7" />
        <source>%1 is broadcasting privately.</source>
        <translation>%1 يبث بشكل خاص.</translation>
    </message>
    <message>
        <location line="+1" />
        <location line="+42" />
        <source>The broadcaster</source>
        <translation>المُذيع</translation>
    </message>
    <message>
        <location line="-24" />
        <source>Password</source>
        <translation>كلمة المرور</translation>
    </message>
    <message>
        <location line="+23" />
        <source>%1 requires a password.</source>
        <translation>%1 يتطلب كلمة مرور.</translation>
    </message>
    <message>
        <location line="+24" />
        <source>The password must be between %1 and %2 characters.</source>
        <translation>يجب أن تكون كلمة المرور بين %1 و%2 حرفًا.</translation>
    </message>
</context>
<context>
    <name>ReceivePage</name>
    <message>
        <location line="-192" />
        <source>%1 - audio only</source>
        <translation>%1 - صوت فقط</translation>
    </message>
    <message>
        <location line="+2" />
        <source>%1 - %2x%3</source>
        <translation>%1 - %2x%3</translation>
    </message>
    <message>
        <location line="+10" />
        <source>Windows PC</source>
        <translation>حاسوب Windows</translation>
    </message>
    <message>
        <location line="+207" />
        <source>Available broadcasters</source>
        <translation>المذيعون المتاحون</translation>
    </message>
    <message>
        <location line="+2" />
        <source>Broadcasters found on this network. Select one, then choose Connect.</source>
        <translation>مذيعون وُجدوا على هذه الشبكة. اختر واحدًا، ثم اختر "اتصال".</translation>
    </message>
    <message>
        <location line="+3" />
        <location line="+544" />
        <source>Connect</source>
        <translation>اتصال</translation>
    </message>
    <message>
        <location line="-538" />
        <source>Search again</source>
        <translation>ابحث مرة أخرى</translation>
    </message>
    <message>
        <location line="+2" />
        <source>Search for broadcasters again</source>
        <translation>ابحث عن المذيعين مرة أخرى</translation>
    </message>
    <message>
        <location line="+2" />
        <source>Ask the network again. Useful when a broadcaster has just come online, or when nothing has appeared for a while.</source>
        <translation>اسأل الشبكة مجددًا. مفيد عندما يكون هناك مذيع قد ظهر للتو، أو عندما لا يظهر شيء مدة طويلة.</translation>
    </message>
    <message>
        <location line="+7" />
        <location line="+133" />
        <source>Receive buffer</source>
        <translation>مخزن الاستقبال</translation>
    </message>
    <message>
        <location line="-132" />
        <source>Low latency (200 ms)</source>
        <translation>زمن استجابة منخفض (200 مللي ثانية)</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Balanced (500 ms)</source>
        <translation>متوازن (500 مللي ثانية)</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Smooth (1 second)</source>
        <translation>سلس (ثانية واحدة)</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Maximum (2 seconds)</source>
        <translation>الأقصى (ثانيتان)</translation>
    </message>
    <message>
        <location line="+23" />
        <source>Video from the broadcaster</source>
        <translation>فيديو من المذيع</translation>
    </message>
    <message>
        <location line="+5" />
        <source>Fullscreen</source>
        <translation>ملء الشاشة</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Enter fullscreen</source>
        <translation>الدخول إلى ملء الشاشة</translation>
    </message>
    <message>
        <location line="+4" />
        <source>Connect to a broadcaster to see the picture here.</source>
        <translation>اتصل بمذيع لتظهر الصورة هنا.</translation>
    </message>
    <message>
        <location line="+25" />
        <source>If the list is empty, enter the broadcaster's address and the control port shown on its Broadcast screen.</source>
        <translation>إذا كانت القائمة فارغة، أدخل عنوان المذيع ومنفذ التحكم الظاهر في شاشة "البث" لديه.</translation>
    </message>
    <message>
        <location line="+4" />
        <location line="+1" />
        <source>Broadcaster address</source>
        <translation>عنوان المذيع</translation>
    </message>
    <message>
        <location line="+2" />
        <location line="+1" />
        <source>Control port</source>
        <translation>منفذ التحكم</translation>
    </message>
    <message>
        <location line="+8" />
        <source>Connect manually</source>
        <translation>اتصال يدوي</translation>
    </message>
    <message>
        <location line="+21" />
        <source>Broadcasters</source>
        <translation>المذيعون</translation>
    </message>
    <message>
        <location line="+12" />
        <source>Select a broadcaster, then choose Connect. Enter connects to the one highlighted.</source>
        <translation>اختر مذيعًا، ثم اختر "اتصال". Enter يتصل بالمحدد.</translation>
    </message>
    <message>
        <location line="+4" />
        <source>Connect by address</source>
        <translation>الاتصال بالعنوان</translation>
    </message>
    <message>
        <location line="+10" />
        <source>Picture</source>
        <translation>الصورة</translation>
    </message>
    <message>
        <location line="+14" />
        <source>Session</source>
        <translation>الجلسة</translation>
    </message>
    <message>
        <location line="+12" />
        <source>Scanning for broadcasters on this network.</source>
        <translation>جارٍ البحث عن مذيعين على هذه الشبكة.</translation>
    </message>
    <message>
        <location line="+26" />
        <source>Searching for broadcasters...</source>
        <translation>جارٍ البحث عن مذيعين...</translation>
    </message>
    <message>
        <location line="+41" />
        <source>%1 Windows Firewall may also be blocking incoming connections to LocalStream.</source>
        <translation>قد يحجب جدار حماية Windows أيضًا الاتصالات الواردة إلى LocalStream.</translation>
    </message>
    <message>
        <location line="+20" />
        <source>Connected.</source>
        <translation>تم الاتصال.</translation>
    </message>
    <message>
        <location line="+8" />
        <location line="+337" />
        <source>Disconnected.</source>
        <translation>تمقطع الاتصال.</translation>
    </message>
    <message>
        <location line="-309" />
        <source>Asking %1 for permission to watch...</source>
        <translation>جارٍ طلب إذن المشاهدة من %1...</translation>
    </message>
    <message>
        <location line="+24" />
        <source>Blocked by the broadcaster</source>
        <translation>حظر المذيع المشاهدة</translation>
    </message>
    <message>
        <location line="+8" />
        <source>%1 fps - %2 kbps</source>
        <translation>%1 إطار/ث - %2 كيلوبت/ث</translation>
    </message>
    <message>
        <location line="+15" />
        <source>%1/%2 audio played</source>
        <translation>تمت معالجة %1/%2 من الصوت</translation>
    </message>
    <message>
        <location line="+2" />
        <source>no audio: %1</source>
        <translation>لا صوت: %1</translation>
    </message>
    <message>
        <location line="+2" />
        <source>audio device not open</source>
        <translation>جهاز الصوت غير مفتوح</translation>
    </message>
    <message>
        <location line="+2" />
        <source>audio not decoding (%1 sent, %2 rejected)</source>
        <translation>الصوت لا يُفك ترميزه (%1 مُرسَل، %2 مرفوض)</translation>
    </message>
    <message>
        <location line="+5" />
        <source>Received: %1 audio, %2 video, %3 lost%4 - decoded: %5 video, %6</source>
        <translation>المستلَم: %1 صوت، %2 فيديو، %3 مفقود%4 - المُفَكّ: %5 فيديو، %6</translation>
    </message>
    <message>
        <location line="+5" />
        <source> - waiting for keyframe header</source>
        <translation> - في انتظار رأس إطار المفتاح</translation>
    </message>
    <message>
        <location line="+72" />
        <source>Found a broadcaster. Choose Connect to watch.</source>
        <translation>وُجد مذيع. اختر "اتصال" للمشاهدة.</translation>
    </message>
    <message>
        <location line="+16" />
        <source>No broadcasters found. Check that both devices are on the same Wi-Fi network, and that Windows Firewall is letting LocalStream receive network traffic.</source>
        <translation>لم يُعثر على مذيعين. تحقق من أن الجهازين على شبكة واي فاي نفسها، وأن جدار حماية Windows يسمح لـ LocalStream باستقبال حركة الشبكة.</translation>
    </message>
    <message>
        <location line="+29" />
        <source>That broadcaster is no longer on the network.</source>
        <translation>لم يعد ذلك المذيع موجودًا على الشبكة.</translation>
    </message>
    <message>
        <location line="+14" />
        <source>That broadcaster did not advertise a control port.</source>
        <translation>لم يعلن ذلك المذيع عن منفذ تحكم.</translation>
    </message>
    <message>
        <location line="+4" />
        <location line="+34" />
        <source>Connecting...</source>
        <translation>جارٍ الاتصال...</translation>
    </message>
    <message>
        <location line="-18" />
        <source>Enter the broadcaster's address first.</source>
        <translation>أدخل عنوان المذيع أولًا.</translation>
    </message>
    <message>
        <location line="+10" />
        <source>Enter the control port shown on the broadcaster's screen.</source>
        <translation>أدخل منفذ التحكم الظاهر على شاشة المذيع.</translation>
    </message>
    <message>
        <location line="+21" />
        <source>Disconnecting...</source>
        <translation>جارٍ قطع الاتصال...</translation>
    </message>
    <message>
        <location line="+7" />
        <source>Disconnect</source>
        <translation>قطع الاتصال</translation>
    </message>
    <message>
        <location line="+47" />
        <source>Checking the password...</source>
        <translation>جارٍ التحقق من كلمة المرور...</translation>
    </message>
    <message>
        <location line="+20" />
        <source>Could not connect.</source>
        <translation>تعذّر الاتصال.</translation>
    </message>
    <message>
        <location line="+2" />
        <source>Could not connect</source>
        <translation>تعذّر الاتصال</translation>
    </message>
</context>
<context>
    <name>VideoWindow</name>
    <message>
        <location line="-801" />
        <source>Exit fullscreen</source>
        <translation>الخروج من ملء الشاشة</translation>
    </message>
</context>
</TS>
