<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS []>
<TS version="2.1" language="tr" sourcelanguage="en">
<context>
    <name>BroadcastPage</name>
    <message>
        <location filename="../src/ui/BroadcastPage.cpp" line="+45" />
        <source>What to send</source>
        <translation>Ne gönderilecek</translation>
    </message>
    <message>
        <location line="+2" />
        <source>Include video</source>
        <translation>Videoyu dahil et</translation>
    </message>
    <message>
        <location line="+3" />
        <source>Turn this off to broadcast audio only. The video encoder stays warm, so turning it back on does not have to wait for a keyframe.</source>
        <translation>Yalnızca ses yayınlamak için kapatın. Video kodlayıcı sıcak kalır, bu yüzden yeniden açmak ana kareyi beklemez.</translation>
    </message>
    <message>
        <location line="+5" />
        <source>Show a test pattern instead of the screen</source>
        <translation>Ekran yerine test deseni göster</translation>
    </message>
    <message>
        <location line="+2" />
        <source>Broadcast a generated pattern and tone instead of capturing this desktop. Useful on a machine with nothing worth sharing. Available before the broadcast starts.</source>
        <translation>Bu masaüstünü yakalamak yerine üretilmiş bir desen ve ton yayınla. Paylaşacak bir şeyi olmayan bir makinede işe yarar. Yayın başlamadan önce kullanılabilir.</translation>
    </message>
    <message>
        <location line="+5" />
        <source>Normalize audio level</source>
        <translation>Ses düzeyini normalleştir</translation>
    </message>
    <message>
        <location line="+3" />
        <source>Keep the broadcast at a steady volume even when the system volume or the capture device changes. Turn this off to send the captured level untouched. Available before the broadcast starts.</source>
        <translation>Sistem ses düzeyi veya yakalama aygıtı değişse bile yayını sabit bir ses düzeyinde tut. Yakalanan düzeyi olduğu gibi göndermek için kapatın. Yayın başlamadan önce kullanılabilir.</translation>
    </message>
    <message>
        <location line="+12" />
        <source>Which microphone to capture. The first one is used when this is left alone. Available before the broadcast starts.</source>
        <translation>Hangi mikrofon yakalansın. Bu ayara dokunulmadığında birincisi kullanılır. Yayın başlamadan önce kullanılabilir.</translation>
    </message>
    <message>
        <location line="+3" />
        <source>Refresh</source>
        <translation>Yenile</translation>
    </message>
    <message>
        <location line="+2" />
        <source>Refresh the microphone list</source>
        <translation>Mikrofon listesini yenile</translation>
    </message>
    <message>
        <location line="+2" />
        <source>Scan again for microphones plugged in since this window opened.</source>
        <translation>Bu pencere açıldıktan sonra takılan mikrofonlar için yeniden tara.</translation>
    </message>
    <message>
        <location line="+4" />
        <source>Microphone</source>
        <translation>Mikrofon</translation>
    </message>
    <message>
        <location line="+9" />
        <source>Quality</source>
        <translation>Kalite</translation>
    </message>
    <message>
        <location line="+4" />
        <source>1280 x 720</source>
        <translation>1280 x 720</translation>
    </message>
    <message>
        <location line="+1" />
        <source>1920 x 1080</source>
        <translation>1920 x 1080</translation>
    </message>
    <message>
        <location line="+1" />
        <source>The size sent to viewers, before they scale it to their own window.</source>
        <translation>İzleyicilere, kendi pencerelerine uyarlamadan önce gönderilen boyut.</translation>
    </message>
    <message>
        <location line="+6" />
        <location line="+7" />
        <source> kbps</source>
        <translation> kbps</translation>
    </message>
    <message>
        <location line="-6" />
        <source>How much detail to send. More looks sharper and uses more of the network.</source>
        <translation>Ne kadar ayrıntı gönderileceği. Daha fazlası daha keskin görünür ve ağı daha çok kullanır.</translation>
    </message>
    <message>
        <location line="+7" />
        <source>How much detail to give the sound. 48 kbps is enough for speech.</source>
        <translation>Sese ne kadar ayrıntı verileceği. Konuşma için 48 kbps yeterlidir.</translation>
    </message>
    <message>
        <location line="+9" />
        <source>Resolution</source>
        <translation>Çözünürlük</translation>
    </message>
    <message>
        <location line="+3" />
        <source>Video bitrate</source>
        <translation>Video bit hızı</translation>
    </message>
    <message>
        <location line="+3" />
        <source>Audio bitrate</source>
        <translation>Ses bit hızı</translation>
    </message>
    <message>
        <location line="+6" />
        <source>These are read when the broadcast starts, so they wait until it is stopped to take effect.</source>
        <translation>Bu ayarlar yayın başlarken okunur, bu yüzden etkili olmaları için yayının durması beklenir.</translation>
    </message>
    <message>
        <location line="+6" />
        <source>Packets</source>
        <translation>Paketler</translation>
    </message>
    <message>
        <location line="+7" />
        <source>1200 bytes (default)</source>
        <translation>1200 bayt (varsayılan)</translation>
    </message>
    <message>
        <location line="+2" />
        <source>1400 bytes</source>
        <translation>1400 bayt</translation>
    </message>
    <message>
        <location line="+1" />
        <source>1000 bytes</source>
        <translation>1000 bayt</translation>
    </message>
    <message>
        <location line="+1" />
        <source>800 bytes</source>
        <translation>800 bayt</translation>
    </message>
    <message>
        <location line="+2" />
        <source>The largest datagram the video is split into. Smaller packets survive a weak Wi-Fi link more reliably; larger ones send fewer packets. Available before the broadcast starts.</source>
        <translation>Videonun bölündüğü en büyük veri paketi. Küçük paketler zayıf bir Wi-Fi bağlantısında daha güvenilir biçimde geçer; büyükleri daha az paket gönderir. Yayın başlamadan önce kullanılabilir.</translation>
    </message>
    <message>
        <location line="+7" />
        <source> packets</source>
        <translation> paket</translation>
    </message>
    <message>
        <location line="+2" />
        <source>A frame that splits into at least this many packets is spread across the frame time instead of sent in one burst, which reduces loss on a slow link. Available before the broadcast starts.</source>
        <translation>En az bu kadar pakete bölünen bir kare, tek seferde gönderilmek yerine kare süresine yayılır; bu, yavaş bir bağlantıda kaybı azaltır. Yayın başlamadan önce kullanılabilir.</translation>
    </message>
    <message>
        <location line="+7" />
        <source> x frame time</source>
        <translation> x kare süresi</translation>
    </message>
    <message>
        <location line="+2" />
        <source>How slowly to spread a paced burst. Higher values add a little latency but cope with a more congested link. Available before the broadcast starts.</source>
        <translation>Hızlandırılmış bir gönderi ne kadar yavaş yayılacak. Daha yüksek değerler biraz gecikme ekler ama daha yoğun bir bağlantıyla başa çıkar. Yayın başlamadan önce kullanılabilir.</translation>
    </message>
    <message>
        <location line="+11" />
        <source>Maximum packet</source>
        <translation>En büyük paket</translation>
    </message>
    <message>
        <location line="+2" />
        <source>Start pacing at</source>
        <translation>Hızlandırmayı başlat</translation>
    </message>
    <message>
        <location line="+2" />
        <source>Spread over</source>
        <translation>Şunun üzerine yay</translation>
    </message>
    <message>
        <location line="+3" />
        <source>How the video is split into datagrams. These are read when the broadcast starts, so they wait until it is stopped to take effect.</source>
        <translation>Videonun veri paketlerine nasıl bölündüğü. Bu ayarlar yayın başlarken okunur, bu yüzden etkili olmaları için yayının durması beklenir.</translation>
    </message>
    <message>
        <location line="+31" />
        <source>Who can watch</source>
        <translation>Kim izleyebilir</translation>
    </message>
    <message>
        <location line="+4" />
        <source>Anyone on the network</source>
        <translation>Ağdaki herkes</translation>
    </message>
    <message>
        <location line="+2" />
        <source>Ask me first</source>
        <translation>Önce bana sor</translation>
    </message>
    <message>
        <location line="+2" />
        <source>Only with a password</source>
        <translation>Yalnızca parolayla</translation>
    </message>
    <message>
        <location line="+9" />
        <source>Between %1 and %2 characters</source>
        <translation>%1 ile %2 karakter arasında</translation>
    </message>
    <message>
        <location line="+10" />
        <source>Access</source>
        <translation>Erişim</translation>
    </message>
    <message>
        <location line="+4" />
        <source>Password</source>
        <translation>Parola</translation>
    </message>
    <message>
        <location line="+8" />
        <source>Use this password</source>
        <translation>Bu parolayı kullan</translation>
    </message>
    <message>
        <location line="+3" />
        <source>Use this password for viewers who connect from now on</source>
        <translation>Bu parolayı bundan sonra bağlanan izleyiciler için kullan</translation>
    </message>
    <message>
        <location line="+5" />
        <source>This takes effect straight away, so you can lock a broadcast you have already started. Viewers already watching keep their stream.</source>
        <translation>Bu etkisi hemen olur, böylece zaten başlamış bir yayını kapatabilirsiniz. İzleyenler yayını almaya devam eder.</translation>
    </message>
    <message>
        <location line="+11" />
        <source>Broadcast</source>
        <translation>Yayın</translation>
    </message>
    <message>
        <location line="+18" />
        <location line="+263" />
        <source>Start broadcast</source>
        <translation>Yayını başlat</translation>
    </message>
    <message>
        <location line="-259" />
        <source>Start sharing this computer on the local network.</source>
        <translation>Bu bilgisayarı yerel ağda paylaşmaya başla.</translation>
    </message>
    <message>
        <location line="+5" />
        <source>Give viewers the address and control port above if they cannot see this broadcast in their list.</source>
        <translation>İzleyiciler bu yayını kendi listelerinde göremiyorsa yukarıdaki adresi ve kontrol bağlantı noktasını verin.</translation>
    </message>
    <message>
        <location line="+9" />
        <source>Ready to broadcast</source>
        <translation>Yayına hazır</translation>
    </message>
    <message>
        <location line="+16" />
        <source>Switched to audio and video. A keyframe follows shortly.</source>
        <translation>Ses ve videoya geçildi. Kısa süre sonra bir ana kare geliyor.</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Switched to audio only. The video encoder stays warm.</source>
        <translation>Yalnızca sese geçildi. Video kodlayıcı sıcak kalıyor.</translation>
    </message>
    <message>
        <location line="+41" />
        <source>Broadcasting as %1. Control port %2 - viewers who cannot find this automatically can connect manually.</source>
        <translation>%1 olarak yayın yapılıyor. Kontrol bağlantı noktası %2 - otomatik olarak bulamayan izleyiciler elle bağlanabilir.</translation>
    </message>
    <message>
        <location line="+9" />
        <source>Broadcast stopped.</source>
        <translation>Yayın durdu.</translation>
    </message>
    <message>
        <location line="+25" />
        <source>%1 fps - %2 kbps - %3 receiver(s)</source>
        <translation>%1 fps - %2 kbps - %3 izleyici</translation>
    </message>
    <message>
        <location line="+7" />
        <source>
Last frame: %1 packet(s), %2 FU-A, largest %3 bytes</source>
        <translation>
Son kare: %1 paket, %2 FU-A, en büyüğü %3 bayt</translation>
    </message>
    <message>
        <location line="+10" />
        <source>Broadcasting. %1 joined.</source>
        <translation>Yayın yapılıyor. %1 katıldı.</translation>
    </message>
    <message>
        <location line="+6" />
        <source>Broadcasting. %1 left.</source>
        <translation>Yayın yapılıyor. %1 ayrıldı.</translation>
    </message>
    <message>
        <location line="+31" />
        <source>Windows PC</source>
        <translation>Windows bilgisayarı</translation>
    </message>
    <message>
        <location line="+18" />
        <source>Starting the broadcast...</source>
        <translation>Yayın başlatılıyor...</translation>
    </message>
    <message>
        <location line="+36" />
        <source>That password cannot be used</source>
        <translation>Bu parola kullanılamaz</translation>
    </message>
    <message>
        <location line="+1" />
        <source>The broadcast password must be between %1 and %2 characters.</source>
        <translation>Yayın parolası %1 ile %2 karakter arasında olmalı.</translation>
    </message>
    <message>
        <location line="+4" />
        <source>Could not change who can watch</source>
        <translation>Kim izleyebilir değiştirilemedi</translation>
    </message>
    <message>
        <location line="+1" />
        <source>The access mode was not accepted.</source>
        <translation>Erişim kipi kabul edilmedi.</translation>
    </message>
    <message>
        <location line="+14" />
        <source>Access set to: %1. It applies to viewers who connect from now on.</source>
        <translation>Erişim şu şekilde ayarlandı: %1. Bu, bundan sonra bağlanan izleyiciler için geçerlidir.</translation>
    </message>
    <message>
        <location line="+17" />
        <source>Stopping the broadcast...</source>
        <translation>Yayın durduruluyor...</translation>
    </message>
    <message>
        <location line="+7" />
        <source>Stop broadcast</source>
        <translation>Yayını durdur</translation>
    </message>
    <message>
        <location line="+22" />
        <source>A device</source>
        <translation>Bir aygıt</translation>
    </message>
    <message>
        <location line="+3" />
        <source>Allow %1 to watch?</source>
        <translation>%1 izleyebilsin mi?</translation>
    </message>
    <message>
        <location line="+1" />
        <source>%1 wants to view your broadcast.</source>
        <translation>%1 yayınınızı izlemek istiyor.</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Allow</source>
        <translation>İzin ver</translation>
    </message>
    <message>
        <location line="+0" />
        <source>Reject</source>
        <translation>Reddet</translation>
    </message>
    <message>
        <location line="+6" />
        <source>Broadcasting. %1 was allowed in.</source>
        <translation>Yayın yapılıyor. %1 içeri alındı.</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Broadcasting. %1 was rejected.</source>
        <translation>Yayın yapılıyor. %1 reddedildi.</translation>
    </message>
    <message>
        <location line="+8" />
        <source>The broadcast stopped.</source>
        <translation>Yayın durdu.</translation>
    </message>
    <message>
        <location line="+2" />
        <source>The broadcast stopped</source>
        <translation>Yayın durdu</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Viewers have been disconnected.

%1</source>
        <translation>İzleyiciler bağlantısı kesildi.
 
 %1</translation>
    </message>
    <message>
        <location line="+2" />
        <source>Could not start broadcasting.</source>
        <translation>Yayın başlatılamadı.</translation>
    </message>
    <message>
        <location line="+2" />
        <source>Could not start broadcasting</source>
        <translation>Yayın başlatılamadı</translation>
    </message>
    <message>
        <location line="+19" />
        <source>No microphone found</source>
        <translation>Mikrofon bulunamadı</translation>
    </message>
    <message>
        <location line="+35" />
        <source>Only used when access is set to a password.</source>
        <translation>Yalnızca erişim parolaya ayarlıyken kullanılır.</translation>
    </message>
    <message>
        <location line="+26" />
        <source>No network address - is this computer on a network?</source>
        <translation>Ağ adresi yok - bu bilgisayar bir ağda mı?</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Address %1</source>
        <translation>Adres %1</translation>
    </message>
    <message>
        <location line="+2" />
        <source>  ·  control port %1</source>
        <translation>  ·  kontrol bağlantı noktası %1</translation>
    </message>
</context>
<context>
    <name>HelpPage</name>
    <message>
        <location filename="../src/ui/HelpPage.cpp" line="+40" />
        <source>LocalStream tutorial</source>
        <translation>LocalStream eğitimi</translation>
    </message>
    <message>
        <location line="+31" />
        <source>LocalStream Tutorial</source>
        <translation>LocalStream Eğitimi</translation>
    </message>
    <message>
        <location line="+5" />
        <source>A guide that opens in your web browser: what the app is for, what each device needs, how to use it step by step, what every setting means, and what you can really do with it.</source>
        <translation>Web tarayıcınızda açılan bir kılavuz: uygulamanın ne işe yaradığı, her aygıtın neye ihtiyaç duyduğu, adım adım nasıl kullanılacağı, her ayarın ne anlama geldiği ve gerçekte neler yapılabileceği.</translation>
    </message>
    <message>
        <location line="+5" />
        <source>Open the tutorial</source>
        <translation>Eğitimi aç</translation>
    </message>
    <message>
        <location line="+4" />
        <source>Open the tutorial in your web browser</source>
        <translation>Eğitimi web tarayıcınızda aç</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Opens the tutorial in the program you use for web pages. It works offline.</source>
        <translation>Eğitimi web sayfaları için kullandığınız programda açar. Çevrimdışı çalışır.</translation>
    </message>
    <message>
        <location line="+6" />
        <source>The page is stored inside this app and opens without an internet connection. Ctrl+3 brings you back to this tab.</source>
        <translation>Sayfa bu uygulamanın içinde saklanır ve internet bağlantisi olmadan açılır. Ctrl+3 sizi bu sekmeye geri getirir.</translation>
    </message>
    <message>
        <location line="+8" />
        <source>What is inside</source>
        <translation>İçindekiler</translation>
    </message>
    <message>
        <location line="+10" />
        <source>• What LocalStream is for: sharing a screen and a sound, following a computer from your phone, watching the same thing at the same time
• What you need on Windows, on Android, and on the network between them
• Using it step by step, as if you were doing it now
• Every setting on both tabs, explained in plain words
• Running in the background: what the switch on this tab does, and how the app stays alive beside the clock
• What this build is: version, date, creator and license
• Scenarios the apps really support, and what they do not do
• What to do when the list stays empty or the picture breaks up</source>
        <translation>• LocalStream ne işe yarar: bir ekranı ve sesi paylaşmak, bilgisayarı telefonunuzdan izlemek, aynı şeyi aynı anda görmek
• Windows'ta, Android'de ve aralarındaki ağda neye ihtiyacınız var
• Şu anda yapıyormuş gibi adım adım kullanmak
• İki sekmedeki her ayarın sade bir dille açıklaması
• Arka planda çalışma: bu sekmedeki anahtar ne yapıyor ve uygulama saatin yanında nasıl yaşıyor
• Bu sürüm nedir: sürüm numarası, tarih, yapımcı ve lisans
• Uygulamaların gerçekten desteklediği senaryolar ve desteklemediği şeyler
• Liste boş kalırsa veya görüntü bozulursa ne yapılır</translation>
    </message>
    <message>
        <location line="+16" />
        <source>Where the file is</source>
        <translation>Dosyanın yeri</translation>
    </message>
    <message>
        <location line="+3" />
        <source>The tutorial is kept with this app's settings. If your computer has no program set up for web pages, open this file yourself:</source>
        <translation>Eğitim, uygulamanın ayarlarıyla birlikte saklanır. Bilgisayarınızda web sayfaları için ayarlanmış bir program yoksa bu dosyayı kendiniz açın:</translation>
    </message>
    <message>
        <location line="+16" />
        <source>Show the file in File Explorer</source>
        <translation>Dosyayı Dosya Gezgini'nde göster</translation>
    </message>
    <message>
        <location line="+5" />
        <source>Show the tutorial file in File Explorer</source>
        <translation>Eğitim dosyasını Dosya Gezgini'nde göster</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Useful when clicking Open the tutorial does nothing, because this computer has no program set up for web pages.</source>
        <translation>Eğitimi aç'a tıklamak hiçbir şey yapmadığında işe yarar, çünkü bu bilgisayarda web sayfaları için ayarlanmış bir program yok.</translation>
    </message>
    <message>
        <location line="+9" />
        <source>General</source>
        <translation>Genel</translation>
    </message>
    <message>
        <location line="+5" />
        <source>What closing the window means. The choice is remembered, so it has to be made once.</source>
        <translation>Pencereyi kapatmanın ne anlama geldiği. Seçim hatırlanır, bu yüzden bir kez yapılmalıdır.</translation>
    </message>
    <message>
        <location line="+6" />
        <location line="+2" />
        <source>Run in background (continue when closed)</source>
        <translation>Arka planda çalış (kapandıktan sonra devam et)</translation>
    </message>
    <message>
        <location line="+2" />
        <source>Closing the window hides LocalStream beside the clock instead of exiting it, so a broadcast keeps running while the window is gone. Double-click the tray icon, or choose Show on it, to bring the window back; Quit leaves.</source>
        <translation>Pencereyi kapatmak, LocalStream'i saatin yanına gizler ve programdan çıkarmaz; böylece pencere yokken yayın sürmeye devam eder. Pencereyi geri getirmek için bildirim alanındaki simgeye çift tıklayın ya da menüden Göster'i seçin; Çıkış ise programı kapatır.</translation>
    </message>
    <message>
        <location line="+12" />
        <source>While it is on, the app's icon sits by the clock with Show and Quit on it. Switching it on or off, and hiding or restoring the window, is written to the log, so a report can say whether the app was still running at the time.</source>
        <translation>Açık olduğu sürece uygulamanın simgesi saatin yanında, Göster ve Çıkış seçenekleriyle durur. Açmak ve kapatmak, pencereyi gizlemek ve geri getirmek günlüğe yazılır; böylece bir rapor o sırada uygulamanın çalışıp çalışmadığını söyleyebilir.</translation>
    </message>
    <message>
        <location line="+10" />
        <source>Report a problem</source>
        <translation>Sorun bildir</translation>
    </message>
    <message>
        <location line="+5" />
        <source>LocalStream keeps a detailed log of what it does, with the exact date and time of every event. Turn it on here, and then write a report you can attach to a message or keep for yourself.</source>
        <translation>LocalStream, yaptığı her şeyin ayrıntılı günlüğünü, her olayın kesin tarihi ve saatiyle tutar. Buradan açın ve sonra bir mesaja ekleyebileceğiniz ya da kendiniz için saklayabileceğiniz bir rapor yazın.</translation>
    </message>
    <message>
        <location line="+9" />
        <location line="+1" />
        <source>Record a log automatically</source>
        <translation>Günlüğü otomatik kaydet</translation>
    </message>
    <message>
        <location line="+2" />
        <source>Writes what the app does to a log file while you use it. Turn this on before the problem happens, because a report written afterwards cannot describe it.</source>
        <translation>Uygulamanın yaptıklarını, siz kullanırken bir günlük dosyasına yazar. Bunu sorun olmadan önce açın, çünkü sonradan yazılan bir rapor onu tarif edemez.</translation>
    </message>
    <message>
        <location line="+14" />
        <source>Lines below this level are left out. Warning is the quieter choice; Debug records everything.</source>
        <translation>Bu seviyenin altındaki satırlar yazılmaz. Uyarı daha sessiz seçimdir; Hata ayıklama her şeyi kaydeder.</translation>
    </message>
    <message>
        <location line="+3" />
        <source>Include milliseconds</source>
        <translation>Milisaniyeleri dahil et</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Records the fraction of a second, which is often the whole explanation for a stall.</source>
        <translation>Saniyenin kesirini kaydeder; bu çoğu zaman takılmanın bütün açıklamasıdır.</translation>
    </message>
    <message>
        <location line="+4" />
        <source>24-hour, with time zone</source>
        <translation>24 saat, saat dilimiyle</translation>
    </message>
    <message>
        <location line="+1" />
        <source>12-hour, am/pm</source>
        <translation>12 saat, öğleden önce/sonra</translation>
    </message>
    <message>
        <location line="+1" />
        <source>The 24-hour form also writes the time zone offset, so a report can be lined up against other logs.</source>
        <translation>24 saat biçimi saat dilimi farkını da yazar; böylece bir rapor diğer günlüklerle yan yana konabilir.</translation>
    </message>
    <message>
        <location line="+5" />
        <source> days</source>
        <translation> gün</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Log files older than this are deleted. Seven days is usually enough to notice a problem that comes and goes.</source>
        <translation>Bu tarihten eski günlük dosyaları silinir. Gelip giden bir sorunu fark etmek için genellikle yedi gün yeterlidir.</translation>
    </message>
    <message>
        <location line="+5" />
        <source> MiB</source>
        <translation> MiB</translation>
    </message>
    <message>
        <location line="+1" />
        <source>The ceiling for one day's log. Past it the file rolls over, so a long session cannot fill the disk.</source>
        <translation>Bir günlük için üst sınır. Bu aşılınca dosya yenisine döner, böylece uzun bir oturum diski dolduramaz.</translation>
    </message>
    <message>
        <location line="+16" />
        <source>Record from level</source>
        <translation>Şu seviyeden kaydet</translation>
    </message>
    <message>
        <location line="+4" />
        <source>Time format</source>
        <translation>Zaman biçimi</translation>
    </message>
    <message>
        <location line="+3" />
        <source>Keep log files</source>
        <translation>Günlük dosyalarını sakla</translation>
    </message>
    <message>
        <location line="+3" />
        <source>Maximum size a day</source>
        <translation>Günlük en fazla boyut</translation>
    </message>
    <message>
        <location line="+8" />
        <source>Include this computer's details</source>
        <translation>Bu bilgisayarın ayrıntılarını dahil et</translation>
    </message>
    <message>
        <location line="+2" />
        <source>The Windows version, the app version, the display and the free space on disk.</source>
        <translation>Windows sürümü, uygulama sürümü, ekran ve diskteki boş yer.</translation>
    </message>
    <message>
        <location line="+3" />
        <source>Include the log itself</source>
        <translation>Günlüğün kendisini dahil et</translation>
    </message>
    <message>
        <location line="+1" />
        <source>The most recent lines of the log, which is where the answer usually is.</source>
        <translation>Günlüğün en son satırları, cevabın genellikle bulunduğu yer.</translation>
    </message>
    <message>
        <location line="+6" />
        <source> KiB</source>
        <translation> KiB</translation>
    </message>
    <message>
        <location line="+1" />
        <source>How much of the log to include. 256 KiB is a few minutes of a normal session.</source>
        <translation>Günlüğün ne kadarı dahil edilecek. 256 KiB, olağan bir oturumun birkaç dakikasıdır.</translation>
    </message>
    <message>
        <location line="+3" />
        <source>Include the days before today</source>
        <translation>Bugünden önceki günleri dahil et</translation>
    </message>
    <message>
        <location line="+2" />
        <source>For a problem that started yesterday and was only noticed this morning.</source>
        <translation>Dün başlayıp sadece bu sabah fark edilen bir sorun için.</translation>
    </message>
    <message>
        <location line="+3" />
        <source>Include these settings</source>
        <translation>Bu ayarları dahil et</translation>
    </message>
    <message>
        <location line="+1" />
        <source>The settings above, which decide what the log contains in the first place.</source>
        <translation>Baştan günlüğün içeriğini belirleyen, yukarıdaki ayarlar.</translation>
    </message>
    <message>
        <location line="+22" />
        <source>Log lines to include</source>
        <translation>Dahil edilecek günlük satırı</translation>
    </message>
    <message>
        <location line="+29" />
        <location line="+4" />
        <source>Save a report now</source>
        <translation>Şimdi bir rapor kaydet</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Writes a report you can attach to a message. Nothing is sent anywhere.</source>
        <translation>Bir mesaja ekleyebileceğiniz bir rapor yazar. Hiçbir şey hiçbir yere gönderilmez.</translation>
    </message>
    <message>
        <location line="+5" />
        <location line="+3" />
        <source>Open the log folder</source>
        <translation>Günlük klasörünü aç</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Where the log files are kept.</source>
        <translation>Günlük dosyalarının saklandığı yer.</translation>
    </message>
    <message>
        <location line="+2" />
        <source>log</source>
        <translation>günlük</translation>
    </message>
    <message>
        <location line="+4" />
        <location line="+3" />
        <source>Open the reports folder</source>
        <translation>Rapor klasörünü aç</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Where reports are saved.</source>
        <translation>Raporların kaydedildiği yer.</translation>
    </message>
    <message>
        <location line="+2" />
        <source>report</source>
        <translation>rapor</translation>
    </message>
    <message>
        <location line="+18" />
        <source>About</source>
        <translation>Hakkında</translation>
    </message>
    <message>
        <location line="+18" />
        <source>Project</source>
        <translation>Proje</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Version</source>
        <translation>Sürüm</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Date</source>
        <translation>Tarih</translation>
    </message>
    <message>
        <location line="+0" />
        <source>October 2026</source>
        <translation>Ekim 2026</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Creator</source>
        <translation>Yapımcı</translation>
    </message>
    <message>
        <location line="+0" />
        <source>Ahmed Ibrahim</source>
        <translation>Ahmed Ibrahim</translation>
    </message>
    <message>
        <location line="+1" />
        <source>License</source>
        <translation>Lisans</translation>
    </message>
    <message>
        <location line="+0" />
        <source>GNU GPLv3</source>
        <translation>GNU GPLv3</translation>
    </message>
    <message>
        <location line="+5" />
        <source>Everything this app sends stays on your own network: no account, no upload, and no internet connection needed.</source>
        <translation>Bu uygulamanın gönderdiği her şey kendi ağınızda kalır: hesap yok, yükleme yok ve internet bağlantısı gerekmez.</translation>
    </message>
    <message>
        <location line="+19" />
        <location line="+12" />
        <location line="+16" />
        <location line="+14" />
        <source>Tutorial</source>
        <translation>Eğitim</translation>
    </message>
    <message>
        <location line="-41" />
        <source>The tutorial could not be saved to this computer's settings folder, so it cannot be opened right now.</source>
        <translation>Eğitim bu bilgisayarın ayarlar klasörüne kaydedilemediği için şu anda açılamıyor.</translation>
    </message>
    <message>
        <location line="+12" />
        <source>This computer has no program set up to open web pages.

Open this file yourself:
%1</source>
        <translation>Bu bilgisayarda web sayfalarını açacak bir program ayarlı değil. Bu dosyayı kendiniz açın:
 %1</translation>
    </message>
    <message>
        <location line="+7" />
        <source>The tutorial is opening in your web browser.</source>
        <translation>Eğitim web tarayıcınızda açılıyor.</translation>
    </message>
    <message>
        <location line="+9" />
        <source>The tutorial could not be saved to this computer's settings folder, so it cannot be shown right now.</source>
        <translation>Eğitim bu bilgisayarın ayarlar klasörüne kaydedilemediği için şu anda gösterilemiyor.</translation>
    </message>
    <message>
        <location line="+14" />
        <source>File Explorer could not be opened.

The tutorial is here:
%1</source>
        <translation>Dosya Gezgini açılamadı. Eğitim şurada:
 %1</translation>
    </message>
    <message>
        <location line="+4" />
        <source>The tutorial's folder is open in File Explorer.</source>
        <translation>Eğitimin klasörü Dosya Gezgini'nde açık.</translation>
    </message>
    <message>
        <location line="+44" />
        <source>The report could not be saved: %1</source>
        <translation>Rapor kaydedilemedi: %1</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Report</source>
        <translation>Rapor</translation>
    </message>
    <message>
        <location line="+1" />
        <source>The report could not be saved.

%1</source>
        <translation>Rapor kaydedilemedi.
 
 %1</translation>
    </message>
    <message>
        <location line="+9" />
        <source>Saved: %1
%2 KiB, from %3 log file(s).</source>
        <translation>Kaydedildi: %1
 %2 KiB, %3 günlük dosyasından.</translation>
    </message>
    <message>
        <location line="+6" />
        <source>Report saved as %1.</source>
        <translation>Rapor %1 olarak kaydedildi.</translation>
    </message>
    <message>
        <location line="+6" />
        <location line="+5" />
        <source>Folders</source>
        <translation>Klasörler</translation>
    </message>
    <message>
        <location line="-4" />
        <source>This computer has no folder available for the %1 files.</source>
        <translation>Bu bilgisayarda %1 dosyaları için kullanılabilir bir klasör yok.</translation>
    </message>
    <message>
        <location line="+5" />
        <source>The folder could not be opened.

%1</source>
        <translation>Klasör açılamadı.
 
 %1</translation>
    </message>
    <message>
        <location line="+60" />
        <source>No settings folder is available on this computer.</source>
        <translation>Bu bilgisayarda kullanılabilir bir ayarlar klasörü yok.</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/ui/MainWindow.cpp" line="+62" />
        <source>Share this computer on the network, or watch someone who is.</source>
        <translation>Bu bilgisayarı ağda paylaşın ya da paylaşan birini izleyin.</translation>
    </message>
    <message>
        <location line="+24" />
        <source>Broadcast</source>
        <translation>Yayın</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Receive</source>
        <translation>Al</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Help</source>
        <translation>Yardım</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Share this computer's screen or audio.</source>
        <translation>Bu bilgisayarın ekranını veya sesini paylaşın.</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Watch a broadcast from another computer.</source>
        <translation>Başka bir bilgisayardan yapılan yayını izleyin.</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Open the tutorial in your web browser.</source>
        <translation>Eğitimi web tarayıcınızda açın.</translation>
    </message>
    <message>
        <location line="+48" />
        <source>a broadcast is running</source>
        <translation>bir yayın çalışıyor</translation>
    </message>
    <message>
        <location line="+5" />
        <source>you are watching a broadcast</source>
        <translation>bir yayın izliyorsunuz</translation>
    </message>
    <message>
        <location line="+11" />
        <location line="+40" />
        <source>Close LocalStream</source>
        <translation>LocalStream'i kapat</translation>
    </message>
    <message>
        <location line="-39" />
        <location line="+40" />
        <source>LocalStream is still busy: %1.</source>
        <translation>LocalStream hâlâ meşgul: %1.</translation>
    </message>
    <message>
        <location line="-39" />
        <location line="+40" />
        <source> and </source>
        <translation> ve </translation>
    </message>
    <message>
        <location line="-39" />
        <source>Close the app and stop?</source>
        <translation>Uygulamayı kapatıp durdurulsun mu?</translation>
    </message>
    <message>
        <location line="+41" />
        <source>Hide it in the system tray and keep it running, or exit and stop?</source>
        <translation>Bildirim alanına gizleyip çalışır durumda bırakılsın mı, yoksa çıkıp durdurulsun mu?</translation>
    </message>
    <message>
        <location line="+4" />
        <source>Hide in the system tray</source>
        <translation>Bildirim alanına gizle</translation>
    </message>
    <message>
        <location line="+2" />
        <source>Exit and stop</source>
        <translation>Çık ve durdur</translation>
    </message>
    <message>
        <location line="+2" />
        <source>Cancel</source>
        <translation>Vazgeç</translation>
    </message>
    <message>
        <location line="+37" />
        <source>LocalStream is running in the background. Double-click to open it.</source>
        <translation>LocalStream arka planda çalışıyor. Açmak için çift tıklayın.</translation>
    </message>
    <message>
        <location line="+4" />
        <source>Show LocalStream</source>
        <translation>LocalStream'i göster</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Quit</source>
        <translation>Çık</translation>
    </message>
    <message>
        <location line="+89" />
        <source>Theme: follow system</source>
        <translation>Tema: sistemi izle</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Theme: light</source>
        <translation>Tema: açık</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Theme: dark</source>
        <translation>Tema: koyu</translation>
    </message>
    <message>
        <location line="+3" />
        <source> (Windows decides)</source>
        <translation> (Windows karar verir)</translation>
    </message>
    <message>
        <location line="+5" />
        <source>Windows High Contrast is on, so it decides the colours. Click to keep the preference for when it switches off.</source>
        <translation>Windows Yüksek Karşıtlık açık, bu yüzden renkleri o belirliyor. Kapandığında tercihin geçerli olması için tıklayın.</translation>
    </message>
    <message>
        <location line="+2" />
        <source>Switch to the next colour theme. Ctrl+1 and Ctrl+2 switch tabs.</source>
        <translation>Sonraki renk temasına geç. Ctrl+1 ve Ctrl+2 sekmeleri değiştirir.</translation>
    </message>
</context>
<context>
    <name>PasswordDialog</name>
    <message>
        <location filename="../src/ui/ReceivePage.cpp" line="+156" />
        <source>Watch</source>
        <translation>İzle</translation>
    </message>
    <message>
        <location line="+4" />
        <source>Password required</source>
        <translation>Parola gerekli</translation>
    </message>
    <message>
        <location line="+7" />
        <source>%1 is broadcasting privately.</source>
        <translation>%1 gizli yayın yapıyor.</translation>
    </message>
    <message>
        <location line="+1" />
        <location line="+42" />
        <source>The broadcaster</source>
        <translation>Yayıncı</translation>
    </message>
    <message>
        <location line="-24" />
        <source>Password</source>
        <translation>Parola</translation>
    </message>
    <message>
        <location line="+23" />
        <source>%1 requires a password.</source>
        <translation>%1 parola istiyor.</translation>
    </message>
    <message>
        <location line="+24" />
        <source>The password must be between %1 and %2 characters.</source>
        <translation>Parola %1 ile %2 karakter arasında olmalı.</translation>
    </message>
</context>
<context>
    <name>ReceivePage</name>
    <message>
        <location line="-192" />
        <source>%1 - audio only</source>
        <translation>%1 - yalnızca ses</translation>
    </message>
    <message>
        <location line="+2" />
        <source>%1 - %2x%3</source>
        <translation>%1 - %2x%3</translation>
    </message>
    <message>
        <location line="+10" />
        <source>Windows PC</source>
        <translation>Windows bilgisayarı</translation>
    </message>
    <message>
        <location line="+207" />
        <source>Available broadcasters</source>
        <translation>Kullanılabilir yayıncılar</translation>
    </message>
    <message>
        <location line="+2" />
        <source>Broadcasters found on this network. Select one, then choose Connect.</source>
        <translation>Bu ağda bulunan yayıncılar. Birini seçin, sonra Bağlan'ı seçin.</translation>
    </message>
    <message>
        <location line="+3" />
        <location line="+544" />
        <source>Connect</source>
        <translation>Bağlan</translation>
    </message>
    <message>
        <location line="-538" />
        <source>Search again</source>
        <translation>Yeniden ara</translation>
    </message>
    <message>
        <location line="+2" />
        <source>Search for broadcasters again</source>
        <translation>Yayıncıları yeniden ara</translation>
    </message>
    <message>
        <location line="+2" />
        <source>Ask the network again. Useful when a broadcaster has just come online, or when nothing has appeared for a while.</source>
        <translation>Ağa yeniden sor. Bir yayıncı yeni çevrimiçi olduğunda ya da bir süredir hiçbir şey görünmediğinde işe yarar.</translation>
    </message>
    <message>
        <location line="+7" />
        <location line="+133" />
        <source>Receive buffer</source>
        <translation>Alımla arabelleği</translation>
    </message>
    <message>
        <location line="-132" />
        <source>Low latency (200 ms)</source>
        <translation>Düşük gecikme (200 ms)</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Balanced (500 ms)</source>
        <translation>Dengeli (500 ms)</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Smooth (1 second)</source>
        <translation>Akıcı (1 saniye)</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Maximum (2 seconds)</source>
        <translation>En yüksek (2 saniye)</translation>
    </message>
    <message>
        <location line="+23" />
        <source>Video from the broadcaster</source>
        <translation>Yayıncıdan video</translation>
    </message>
    <message>
        <location line="+5" />
        <source>Fullscreen</source>
        <translation>Tam ekran</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Enter fullscreen</source>
        <translation>Tam ekrana geç</translation>
    </message>
    <message>
        <location line="+4" />
        <source>Connect to a broadcaster to see the picture here.</source>
        <translation>Yayıncıya bağlanın, görüntü burada görünsün.</translation>
    </message>
    <message>
        <location line="+25" />
        <source>If the list is empty, enter the broadcaster's address and the control port shown on its Broadcast screen.</source>
        <translation>Liste boşsa yayıncının adresini ve Yayın ekranında görünen kontrol bağlantı noktasını girin.</translation>
    </message>
    <message>
        <location line="+4" />
        <location line="+1" />
        <source>Broadcaster address</source>
        <translation>Yayıncı adresi</translation>
    </message>
    <message>
        <location line="+2" />
        <location line="+1" />
        <source>Control port</source>
        <translation>Kontrol bağlantı noktası</translation>
    </message>
    <message>
        <location line="+8" />
        <source>Connect manually</source>
        <translation>Elle bağlan</translation>
    </message>
    <message>
        <location line="+21" />
        <source>Broadcasters</source>
        <translation>Yayıncılar</translation>
    </message>
    <message>
        <location line="+12" />
        <source>Select a broadcaster, then choose Connect. Enter connects to the one highlighted.</source>
        <translation>Bir yayıncı seçin, sonra Bağlan'ı seçin. Enter, vurgulanan yayıncıya bağlanır.</translation>
    </message>
    <message>
        <location line="+4" />
        <source>Connect by address</source>
        <translation>Adresle bağlan</translation>
    </message>
    <message>
        <location line="+10" />
        <source>Picture</source>
        <translation>Görüntü</translation>
    </message>
    <message>
        <location line="+14" />
        <source>Session</source>
        <translation>Oturum</translation>
    </message>
    <message>
        <location line="+12" />
        <source>Scanning for broadcasters on this network.</source>
        <translation>Bu ağda yayıncılar aranıyor.</translation>
    </message>
    <message>
        <location line="+26" />
        <source>Searching for broadcasters...</source>
        <translation>Yayıncılar aranıyor...</translation>
    </message>
    <message>
        <location line="+41" />
        <source>%1 Windows Firewall may also be blocking incoming connections to LocalStream.</source>
        <translation>%1 Windows Güvenlik Duvarı da LocalStream'e gelen bağlantıları engelliyor olabilir.</translation>
    </message>
    <message>
        <location line="+20" />
        <source>Connected.</source>
        <translation>Bağlandı.</translation>
    </message>
    <message>
        <location line="+8" />
        <location line="+337" />
        <source>Disconnected.</source>
        <translation>Bağlantı kesildi.</translation>
    </message>
    <message>
        <location line="-309" />
        <source>Asking %1 for permission to watch...</source>
        <translation>%1 izleme izni isteniyor...</translation>
    </message>
    <message>
        <location line="+24" />
        <source>Blocked by the broadcaster</source>
        <translation>Yayıncı tarafından engellendi</translation>
    </message>
    <message>
        <location line="+8" />
        <source>%1 fps - %2 kbps</source>
        <translation>%1 fps - %2 kbps</translation>
    </message>
    <message>
        <location line="+15" />
        <source>%1/%2 audio played</source>
        <translation>%1/%2 ses çalındı</translation>
    </message>
    <message>
        <location line="+2" />
        <source>no audio: %1</source>
        <translation>ses yok: %1</translation>
    </message>
    <message>
        <location line="+2" />
        <source>audio device not open</source>
        <translation>ses aygıtı açık değil</translation>
    </message>
    <message>
        <location line="+2" />
        <source>audio not decoding (%1 sent, %2 rejected)</source>
        <translation>ses çözülmüyor (%1 gönderildi, %2 reddedildi)</translation>
    </message>
    <message>
        <location line="+5" />
        <source>Received: %1 audio, %2 video, %3 lost%4 - decoded: %5 video, %6</source>
        <translation>Alınan: %1 ses, %2 video, %3 kayıp%4 - çözülen: %5 video, %6</translation>
    </message>
    <message>
        <location line="+5" />
        <source> - waiting for keyframe header</source>
        <translation> - ana kare başlığı bekleniyor</translation>
    </message>
    <message>
        <location line="+72" />
        <source>Found a broadcaster. Choose Connect to watch.</source>
        <translation>Bir yayıncı bulundu. İzlemek için Bağlan'ı seçin.</translation>
    </message>
    <message>
        <location line="+16" />
        <source>No broadcasters found. Check that both devices are on the same Wi-Fi network, and that Windows Firewall is letting LocalStream receive network traffic.</source>
        <translation>Yayıncı bulunamadı. İki aygıtın da aynı Wi-Fi ağında olduğundan ve Windows Güvenlik Duvarı'nın LocalStream'in ağ trafiği almasına izin verdiğinden emin olun.</translation>
    </message>
    <message>
        <location line="+29" />
        <source>That broadcaster is no longer on the network.</source>
        <translation>Bu yayıncı artık ağda değil.</translation>
    </message>
    <message>
        <location line="+14" />
        <source>That broadcaster did not advertise a control port.</source>
        <translation>Bu yayıncı kontrol bağlantı noktası bildirmedi.</translation>
    </message>
    <message>
        <location line="+4" />
        <location line="+34" />
        <source>Connecting...</source>
        <translation>Bağlanılıyor...</translation>
    </message>
    <message>
        <location line="-18" />
        <source>Enter the broadcaster's address first.</source>
        <translation>Önce yayıncının adresini girin.</translation>
    </message>
    <message>
        <location line="+10" />
        <source>Enter the control port shown on the broadcaster's screen.</source>
        <translation>Yayıncının ekranında görünen kontrol bağlantı noktasını girin.</translation>
    </message>
    <message>
        <location line="+21" />
        <source>Disconnecting...</source>
        <translation>Bağlantı kesiliyor...</translation>
    </message>
    <message>
        <location line="+7" />
        <source>Disconnect</source>
        <translation>Bağlantıyı kes</translation>
    </message>
    <message>
        <location line="+47" />
        <source>Checking the password...</source>
        <translation>Parola denetleniyor...</translation>
    </message>
    <message>
        <location line="+20" />
        <source>Could not connect.</source>
        <translation>Bağlanılamadı.</translation>
    </message>
    <message>
        <location line="+2" />
        <source>Could not connect</source>
        <translation>Bağlanılamadı</translation>
    </message>
</context>
<context>
    <name>VideoWindow</name>
    <message>
        <location line="-801" />
        <source>Exit fullscreen</source>
        <translation>Tam ekrandan çık</translation>
    </message>
</context>
</TS>
