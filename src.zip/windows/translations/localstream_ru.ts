<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS []>
<TS version="2.1" language="ru" sourcelanguage="en">
<context>
    <name>BroadcastPage</name>
    <message>
        <location filename="../src/ui/BroadcastPage.cpp" line="+45" />
        <source>What to send</source>
        <translation>Что передавать</translation>
    </message>
    <message>
        <location line="+2" />
        <source>Include video</source>
        <translation>Передавать видео</translation>
    </message>
    <message>
        <location line="+3" />
        <source>Turn this off to broadcast audio only. The video encoder stays warm, so turning it back on does not have to wait for a keyframe.</source>
        <translation>Отключите, чтобы передавать только звук. Видеокодек остаётся готовым, поэтому включение обратно не ждёт опорного кадра.</translation>
    </message>
    <message>
        <location line="+5" />
        <source>Show a test pattern instead of the screen</source>
        <translation>Показывать тестовый сигнал вместо экрана</translation>
    </message>
    <message>
        <location line="+2" />
        <source>Broadcast a generated pattern and tone instead of capturing this desktop. Useful on a machine with nothing worth sharing. Available before the broadcast starts.</source>
        <translation>Передавать сгенерированный сигнал и тон вместо захвата этого рабочего стола. Полезно на машине, где нечего показывать. Доступно до начала трансляции.</translation>
    </message>
    <message>
        <location line="+5" />
        <source>Normalize audio level</source>
        <translation>Выравнивать уровень звука</translation>
    </message>
    <message>
        <location line="+3" />
        <source>Keep the broadcast at a steady volume even when the system volume or the capture device changes. Turn this off to send the captured level untouched. Available before the broadcast starts.</source>
        <translation>Поддерживать постоянную громкость трансляции, даже если меняется системная громкость или устройство захвата. Отключите, чтобы передавать захваченный уровень без изменений. Доступно до начала трансляции.</translation>
    </message>
    <message>
        <location line="+12" />
        <source>Which microphone to capture. The first one is used when this is left alone. Available before the broadcast starts.</source>
        <translation>Какой микрофон захватывать. Если это поле не менять, используется первый. Доступно до начала трансляции.</translation>
    </message>
    <message>
        <location line="+3" />
        <source>Refresh</source>
        <translation>Обновить</translation>
    </message>
    <message>
        <location line="+2" />
        <source>Refresh the microphone list</source>
        <translation>Обновить список микрофонов</translation>
    </message>
    <message>
        <location line="+2" />
        <source>Scan again for microphones plugged in since this window opened.</source>
        <translation>Снова найти микрофоны, подключённые после открытия этого окна.</translation>
    </message>
    <message>
        <location line="+4" />
        <source>Microphone</source>
        <translation>Микрофон</translation>
    </message>
    <message>
        <location line="+9" />
        <source>Quality</source>
        <translation>Качество</translation>
    </message>
    <message>
        <location line="+4" />
        <source>1280 x 720</source>
        <translation>1280 x 720</translation>
    </message>
    <message>
        <location line="+1" />
        <source>1920 x 1080</source>
        <translation>1920 x 1080</translation>
    </message>
    <message>
        <location line="+1" />
        <source>The size sent to viewers, before they scale it to their own window.</source>
        <translation>Размер, который отправляется зрителям, до того как они подгонят его под своё окно.</translation>
    </message>
    <message>
        <location line="+6" />
        <location line="+7" />
        <source> kbps</source>
        <translation> кбит/с</translation>
    </message>
    <message>
        <location line="-6" />
        <source>How much detail to send. More looks sharper and uses more of the network.</source>
        <translation>Сколько деталей передавать. Больше выглядит резче и расходует больше сети.</translation>
    </message>
    <message>
        <location line="+7" />
        <source>How much detail to give the sound. 48 kbps is enough for speech.</source>
        <translation>Сколько деталей отдавать звуку. Для речи хватает 48 кбит/с.</translation>
    </message>
    <message>
        <location line="+9" />
        <source>Resolution</source>
        <translation>Разрешение</translation>
    </message>
    <message>
        <location line="+3" />
        <source>Video bitrate</source>
        <translation>Битрейт видео</translation>
    </message>
    <message>
        <location line="+3" />
        <source>Audio bitrate</source>
        <translation>Битрейт звука</translation>
    </message>
    <message>
        <location line="+6" />
        <source>These are read when the broadcast starts, so they wait until it is stopped to take effect.</source>
        <translation>Эти настройки читаются при запуске трансляции, поэтому они вступят в силу только после её остановки.</translation>
    </message>
    <message>
        <location line="+6" />
        <source>Packets</source>
        <translation>Пакеты</translation>
    </message>
    <message>
        <location line="+7" />
        <source>1200 bytes (default)</source>
        <translation>1200 байт (по умолчанию)</translation>
    </message>
    <message>
        <location line="+2" />
        <source>1400 bytes</source>
        <translation>1400 байт</translation>
    </message>
    <message>
        <location line="+1" />
        <source>1000 bytes</source>
        <translation>1000 байт</translation>
    </message>
    <message>
        <location line="+1" />
        <source>800 bytes</source>
        <translation>800 байт</translation>
    </message>
    <message>
        <location line="+2" />
        <source>The largest datagram the video is split into. Smaller packets survive a weak Wi-Fi link more reliably; larger ones send fewer packets. Available before the broadcast starts.</source>
        <translation>Наибольший датаграмм, на которые делится видео. Мелкие пакеты надёжнее переживают слабую связь Wi-Fi; крупные отправляют меньше пакетов. Доступно до начала трансляции.</translation>
    </message>
    <message>
        <location line="+7" />
        <source> packets</source>
        <translation> пакетов</translation>
    </message>
    <message>
        <location line="+2" />
        <source>A frame that splits into at least this many packets is spread across the frame time instead of sent in one burst, which reduces loss on a slow link. Available before the broadcast starts.</source>
        <translation>Кадр, который делится хотя бы на столько пакетов, распределяется по времени кадра вместо отправки одним залпом, что снижает потери на медленной связи. Доступно до начала трансляции.</translation>
    </message>
    <message>
        <location line="+7" />
        <source> x frame time</source>
        <translation> x длительности кадра</translation>
    </message>
    <message>
        <location line="+2" />
        <source>How slowly to spread a paced burst. Higher values add a little latency but cope with a more congested link. Available before the broadcast starts.</source>
        <translation>Насколько медленно растягивать выровненный залп. Большие значения добавляют немного задержки, зато лучше переносят более загруженную связь. Доступно до начала трансляции.</translation>
    </message>
    <message>
        <location line="+11" />
        <source>Maximum packet</source>
        <translation>Наибольший пакет</translation>
    </message>
    <message>
        <location line="+2" />
        <source>Start pacing at</source>
        <translation>Начинать выравнивание с</translation>
    </message>
    <message>
        <location line="+2" />
        <source>Spread over</source>
        <translation>Растянуть на</translation>
    </message>
    <message>
        <location line="+3" />
        <source>How the video is split into datagrams. These are read when the broadcast starts, so they wait until it is stopped to take effect.</source>
        <translation>Как видео делится на датаграммы. Эти настройки читаются при запуске трансляции, поэтому они вступят в силу только после её остановки.</translation>
    </message>
    <message>
        <location line="+31" />
        <source>Who can watch</source>
        <translation>Кто может смотреть</translation>
    </message>
    <message>
        <location line="+4" />
        <source>Anyone on the network</source>
        <translation>Любой в сети</translation>
    </message>
    <message>
        <location line="+2" />
        <source>Ask me first</source>
        <translation>Сначала спросить меня</translation>
    </message>
    <message>
        <location line="+2" />
        <source>Only with a password</source>
        <translation>Только по паролю</translation>
    </message>
    <message>
        <location line="+9" />
        <source>Between %1 and %2 characters</source>
        <translation>От %1 до %2 символов</translation>
    </message>
    <message>
        <location line="+10" />
        <source>Access</source>
        <translation>Доступ</translation>
    </message>
    <message>
        <location line="+4" />
        <source>Password</source>
        <translation>Пароль</translation>
    </message>
    <message>
        <location line="+8" />
        <source>Use this password</source>
        <translation>Использовать этот пароль</translation>
    </message>
    <message>
        <location line="+3" />
        <source>Use this password for viewers who connect from now on</source>
        <translation>Использовать этот пароль для зрителей, которые подключаются с этого момента</translation>
    </message>
    <message>
        <location line="+5" />
        <source>This takes effect straight away, so you can lock a broadcast you have already started. Viewers already watching keep their stream.</source>
        <translation>Действует сразу, поэтому уже начатую трансляцию можно закрыть. Те, кто смотрит сейчас, продолжают получать поток.</translation>
    </message>
    <message>
        <location line="+11" />
        <source>Broadcast</source>
        <translation>Трансляция</translation>
    </message>
    <message>
        <location line="+18" />
        <location line="+263" />
        <source>Start broadcast</source>
        <translation>Начать трансляцию</translation>
    </message>
    <message>
        <location line="-259" />
        <source>Start sharing this computer on the local network.</source>
        <translation>Начать показывать этот компьютер в локальной сети.</translation>
    </message>
    <message>
        <location line="+5" />
        <source>Give viewers the address and control port above if they cannot see this broadcast in their list.</source>
        <translation>Покажите зрителям адрес и порт управления выше, если они не видят эту трансляцию в своём списке.</translation>
    </message>
    <message>
        <location line="+9" />
        <source>Ready to broadcast</source>
        <translation>Готово к трансляции</translation>
    </message>
    <message>
        <location line="+16" />
        <source>Switched to audio and video. A keyframe follows shortly.</source>
        <translation>Переключено на звук и видео. Опорный кадр последует вскоре.</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Switched to audio only. The video encoder stays warm.</source>
        <translation>Переключено на один звук. Видеокодек остаётся готовым.</translation>
    </message>
    <message>
        <location line="+41" />
        <source>Broadcasting as %1. Control port %2 - viewers who cannot find this automatically can connect manually.</source>
        <translation>Трансляция под именем %1. Порт управления %2 - зрители, которые не находят её автоматически, могут подключиться вручную.</translation>
    </message>
    <message>
        <location line="+9" />
        <source>Broadcast stopped.</source>
        <translation>Трансляция остановлена.</translation>
    </message>
    <message>
        <location line="+25" />
        <source>%1 fps - %2 kbps - %3 receiver(s)</source>
        <translation>%1 к/с - %2 кбит/с - %3 зрител(ей)</translation>
    </message>
    <message>
        <location line="+7" />
        <source>
Last frame: %1 packet(s), %2 FU-A, largest %3 bytes</source>
        <translation>
Последний кадр: %1 пакет(ов), %2 FU-A, наибольший %3 байт</translation>
    </message>
    <message>
        <location line="+10" />
        <source>Broadcasting. %1 joined.</source>
        <translation>Идёт трансляция. %1 присоединился.</translation>
    </message>
    <message>
        <location line="+6" />
        <source>Broadcasting. %1 left.</source>
        <translation>Идёт трансляция. %1 вышел.</translation>
    </message>
    <message>
        <location line="+31" />
        <source>Windows PC</source>
        <translation>Компьютер с Windows</translation>
    </message>
    <message>
        <location line="+18" />
        <source>Starting the broadcast...</source>
        <translation>Запуск трансляции...</translation>
    </message>
    <message>
        <location line="+36" />
        <source>That password cannot be used</source>
        <translation>Этот пароль использовать нельзя</translation>
    </message>
    <message>
        <location line="+1" />
        <source>The broadcast password must be between %1 and %2 characters.</source>
        <translation>Пароль трансляции должен содержать от %1 до %2 символов.</translation>
    </message>
    <message>
        <location line="+4" />
        <source>Could not change who can watch</source>
        <translation>Не удалось изменить, кто может смотреть</translation>
    </message>
    <message>
        <location line="+1" />
        <source>The access mode was not accepted.</source>
        <translation>Режим доступа не принят.</translation>
    </message>
    <message>
        <location line="+14" />
        <source>Access set to: %1. It applies to viewers who connect from now on.</source>
        <translation>Доступ изменён на: %1. Это действует для зрителей, которые подключаются с этого момента.</translation>
    </message>
    <message>
        <location line="+17" />
        <source>Stopping the broadcast...</source>
        <translation>Остановка трансляции...</translation>
    </message>
    <message>
        <location line="+7" />
        <source>Stop broadcast</source>
        <translation>Остановить трансляцию</translation>
    </message>
    <message>
        <location line="+22" />
        <source>A device</source>
        <translation>Устройство</translation>
    </message>
    <message>
        <location line="+3" />
        <source>Allow %1 to watch?</source>
        <translation>Разрешить %1 смотреть?</translation>
    </message>
    <message>
        <location line="+1" />
        <source>%1 wants to view your broadcast.</source>
        <translation>%1 хочет смотреть вашу трансляцию.</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Allow</source>
        <translation>Разрешить</translation>
    </message>
    <message>
        <location line="+0" />
        <source>Reject</source>
        <translation>Отклонить</translation>
    </message>
    <message>
        <location line="+6" />
        <source>Broadcasting. %1 was allowed in.</source>
        <translation>Идёт трансляция. %1 допущен.</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Broadcasting. %1 was rejected.</source>
        <translation>Идёт трансляция. %1 отклонён.</translation>
    </message>
    <message>
        <location line="+8" />
        <source>The broadcast stopped.</source>
        <translation>Трансляция остановлена.</translation>
    </message>
    <message>
        <location line="+2" />
        <source>The broadcast stopped</source>
        <translation>Трансляция остановлена</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Viewers have been disconnected.

%1</source>
        <translation>Зрители отключены.
 
 %1</translation>
    </message>
    <message>
        <location line="+2" />
        <source>Could not start broadcasting.</source>
        <translation>Не удалось начать трансляцию.</translation>
    </message>
    <message>
        <location line="+2" />
        <source>Could not start broadcasting</source>
        <translation>Не удалось начать трансляцию</translation>
    </message>
    <message>
        <location line="+19" />
        <source>No microphone found</source>
        <translation>Микрофон не найден</translation>
    </message>
    <message>
        <location line="+35" />
        <source>Only used when access is set to a password.</source>
        <translation>Используется только когда доступ закрыт паролем.</translation>
    </message>
    <message>
        <location line="+26" />
        <source>No network address - is this computer on a network?</source>
        <translation>Нет сетевого адреса - этот компьютер в сети?</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Address %1</source>
        <translation>Адрес %1</translation>
    </message>
    <message>
        <location line="+2" />
        <source>  ·  control port %1</source>
        <translation>  ·  порт управления %1</translation>
    </message>
</context>
<context>
    <name>HelpPage</name>
    <message>
        <location filename="../src/ui/HelpPage.cpp" line="+40" />
        <source>LocalStream tutorial</source>
        <translation>Учебник LocalStream</translation>
    </message>
    <message>
        <location line="+31" />
        <source>LocalStream Tutorial</source>
        <translation>Учебник LocalStream</translation>
    </message>
    <message>
        <location line="+5" />
        <source>A guide that opens in your web browser: what the app is for, what each device needs, how to use it step by step, what every setting means, and what you can really do with it.</source>
        <translation>Руководство, которое открывается в вашем браузере: для чего нужна программа, что нужно каждому устройству, как пользоваться по шагам, что означает каждая настройка и что на самом деле можно делать.</translation>
    </message>
    <message>
        <location line="+5" />
        <source>Open the tutorial</source>
        <translation>Открыть учебник</translation>
    </message>
    <message>
        <location line="+4" />
        <source>Open the tutorial in your web browser</source>
        <translation>Открыть учебник в браузере</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Opens the tutorial in the program you use for web pages. It works offline.</source>
        <translation>Открывает учебник в программе, которой вы пользуетесь для веб-страниц. Работает без интернета.</translation>
    </message>
    <message>
        <location line="+6" />
        <source>The page is stored inside this app and opens without an internet connection. Ctrl+3 brings you back to this tab.</source>
        <translation>Страница хранится внутри программы и открывается без подключения к интернету. Ctrl+3 возвращает на эту вкладку.</translation>
    </message>
    <message>
        <location line="+8" />
        <source>What is inside</source>
        <translation>Что внутри</translation>
    </message>
    <message>
        <location line="+10" />
        <source>• What LocalStream is for: sharing a screen and a sound, following a computer from your phone, watching the same thing at the same time
• What you need on Windows, on Android, and on the network between them
• Using it step by step, as if you were doing it now
• Every setting on both tabs, explained in plain words
• Running in the background: what the switch on this tab does, and how the app stays alive beside the clock
• What this build is: version, date, creator and license
• Scenarios the apps really support, and what they do not do
• What to do when the list stays empty or the picture breaks up</source>
        <translation>• Для чего нужен LocalStream: показать экран и звук, следить за компьютером с телефона, смотреть одно и то же одновременно
• Что нужно на Windows, на Android и в сети между ними
• Как пользоваться по шагам, как будто вы делаете это сейчас
• Все настройки обеих вкладок, объяснённые простыми словами
• Работа в фоне: что делает переключатель на этой вкладке и как программа остаётся живой рядом с часами
• Что это за сборка: версия, дата, автор и лицензия
• Сценарии, которые программы действительно поддерживают, и то, чего они не делают
• Что делать, если список остаётся пустым или картинка рассыпается</translation>
    </message>
    <message>
        <location line="+16" />
        <source>Where the file is</source>
        <translation>Где находится файл</translation>
    </message>
    <message>
        <location line="+3" />
        <source>The tutorial is kept with this app's settings. If your computer has no program set up for web pages, open this file yourself:</source>
        <translation>Учебник хранится вместе с настройками программы. Если на компьютере нет программы для веб-страниц, откройте этот файл сами:</translation>
    </message>
    <message>
        <location line="+16" />
        <source>Show the file in File Explorer</source>
        <translation>Показать файл в Проводнике</translation>
    </message>
    <message>
        <location line="+5" />
        <source>Show the tutorial file in File Explorer</source>
        <translation>Показать файл учебника в Проводнике</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Useful when clicking Open the tutorial does nothing, because this computer has no program set up for web pages.</source>
        <translation>Полезно, когда щелчок по «Открыть учебник» ничего не делает, потому что на этом компьютере нет программы для веб-страниц.</translation>
    </message>
    <message>
        <location line="+9" />
        <source>General</source>
        <translation>Общие</translation>
    </message>
    <message>
        <location line="+5" />
        <source>What closing the window means. The choice is remembered, so it has to be made once.</source>
        <translation>Что означает закрытие окна. Выбор запоминается, поэтому его нужно сделать один раз.</translation>
    </message>
    <message>
        <location line="+6" />
        <location line="+2" />
        <source>Run in background (continue when closed)</source>
        <translation>Работать в фоне (продолжать после закрытия)</translation>
    </message>
    <message>
        <location line="+2" />
        <source>Closing the window hides LocalStream beside the clock instead of exiting it, so a broadcast keeps running while the window is gone. Double-click the tray icon, or choose Show on it, to bring the window back; Quit leaves.</source>
        <translation>Закрытие окна прячет LocalStream рядом с часами вместо выхода из программы, поэтому трансляция продолжается, пока окна нет. Дважды щёлкните значок в области уведомлений или выберите «Показать», чтобы вернуть окно; «Выход» завершает работу.</translation>
    </message>
    <message>
        <location line="+12" />
        <source>While it is on, the app's icon sits by the clock with Show and Quit on it. Switching it on or off, and hiding or restoring the window, is written to the log, so a report can say whether the app was still running at the time.</source>
        <translation>Пока это включено, значок программы лежит рядом с часами с пунктами «Показать» и «Выход». Включение и выключение, скрытие и восстановление окна записываются в журнал, чтобы отчёт мог сказать, работала ли программа в этот момент.</translation>
    </message>
    <message>
        <location line="+10" />
        <source>Report a problem</source>
        <translation>Сообщить о проблеме</translation>
    </message>
    <message>
        <location line="+5" />
        <source>LocalStream keeps a detailed log of what it does, with the exact date and time of every event. Turn it on here, and then write a report you can attach to a message or keep for yourself.</source>
        <translation>LocalStream ведёт подробный журнал своих действий с точной датой и временем каждого события. Включите его здесь, затем напишите отчёт, который можно приложить к письму или оставить себе.</translation>
    </message>
    <message>
        <location line="+9" />
        <location line="+1" />
        <source>Record a log automatically</source>
        <translation>Записывать журнал автоматически</translation>
    </message>
    <message>
        <location line="+2" />
        <source>Writes what the app does to a log file while you use it. Turn this on before the problem happens, because a report written afterwards cannot describe it.</source>
        <translation>Пишет в файл журнала то, что делает программа, пока вы ей пользуетесь. Включите это до того, как случится проблема: отчёт, написанный позже, не сможет её описать.</translation>
    </message>
    <message>
        <location line="+14" />
        <source>Lines below this level are left out. Warning is the quieter choice; Debug records everything.</source>
        <translation>Строки ниже этого уровня не записываются. «Предупреждение» - более тихий выбор; «Отладка» записывает всё.</translation>
    </message>
    <message>
        <location line="+3" />
        <source>Include milliseconds</source>
        <translation>Включать миллисекунды</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Records the fraction of a second, which is often the whole explanation for a stall.</source>
        <translation>Записывает долю секунды, которая часто и есть всё объяснение задержки.</translation>
    </message>
    <message>
        <location line="+4" />
        <source>24-hour, with time zone</source>
        <translation>24 часа, с часовым поясом</translation>
    </message>
    <message>
        <location line="+1" />
        <source>12-hour, am/pm</source>
        <translation>12 часов, am/pm</translation>
    </message>
    <message>
        <location line="+1" />
        <source>The 24-hour form also writes the time zone offset, so a report can be lined up against other logs.</source>
        <translation>Формат 24 часа также записывает смещение часового пояса, чтобы отчёт можно было сопоставить с другими журналами.</translation>
    </message>
    <message>
        <location line="+5" />
        <source> days</source>
        <translation> дней</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Log files older than this are deleted. Seven days is usually enough to notice a problem that comes and goes.</source>
        <translation>Файлы журнала старше этого удаляются. Семи дней обычно хватает, чтобы заметить то проблему, то нет.</translation>
    </message>
    <message>
        <location line="+5" />
        <source> MiB</source>
        <translation> МиБ</translation>
    </message>
    <message>
        <location line="+1" />
        <source>The ceiling for one day's log. Past it the file rolls over, so a long session cannot fill the disk.</source>
        <translation>Предел за один день журнала. После него файл переходит на новый, поэтому долгая сессия не заполнит диск.</translation>
    </message>
    <message>
        <location line="+16" />
        <source>Record from level</source>
        <translation>Записывать с уровня</translation>
    </message>
    <message>
        <location line="+4" />
        <source>Time format</source>
        <translation>Формат времени</translation>
    </message>
    <message>
        <location line="+3" />
        <source>Keep log files</source>
        <translation>Хранить файлы журнала</translation>
    </message>
    <message>
        <location line="+3" />
        <source>Maximum size a day</source>
        <translation>Максимальный размер за день</translation>
    </message>
    <message>
        <location line="+8" />
        <source>Include this computer's details</source>
        <translation>Включать сведения об этом компьютере</translation>
    </message>
    <message>
        <location line="+2" />
        <source>The Windows version, the app version, the display and the free space on disk.</source>
        <translation>Версия Windows, версия программы, экран и свободное место на диске.</translation>
    </message>
    <message>
        <location line="+3" />
        <source>Include the log itself</source>
        <translation>Включать сам журнал</translation>
    </message>
    <message>
        <location line="+1" />
        <source>The most recent lines of the log, which is where the answer usually is.</source>
        <translation>Последние строки журнала, где обычно и находится ответ.</translation>
    </message>
    <message>
        <location line="+6" />
        <source> KiB</source>
        <translation> КиБ</translation>
    </message>
    <message>
        <location line="+1" />
        <source>How much of the log to include. 256 KiB is a few minutes of a normal session.</source>
        <translation>Сколько журнала включить. 256 КиБ - это несколько минут обычной сессии.</translation>
    </message>
    <message>
        <location line="+3" />
        <source>Include the days before today</source>
        <translation>Включать дни до сегодняшнего</translation>
    </message>
    <message>
        <location line="+2" />
        <source>For a problem that started yesterday and was only noticed this morning.</source>
        <translation>Для проблемы, начавшейся вчера и замеченной только сегодня утром.</translation>
    </message>
    <message>
        <location line="+3" />
        <source>Include these settings</source>
        <translation>Включать эти настройки</translation>
    </message>
    <message>
        <location line="+1" />
        <source>The settings above, which decide what the log contains in the first place.</source>
        <translation>Настройки выше, которые и определяют содержимое журнала.</translation>
    </message>
    <message>
        <location line="+22" />
        <source>Log lines to include</source>
        <translation>Строк журнала включить</translation>
    </message>
    <message>
        <location line="+29" />
        <location line="+4" />
        <source>Save a report now</source>
        <translation>Сохранить отчёт сейчас</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Writes a report you can attach to a message. Nothing is sent anywhere.</source>
        <translation>Пишет отчёт, который можно приложить к письму. Ничего никуда не отправляется.</translation>
    </message>
    <message>
        <location line="+5" />
        <location line="+3" />
        <source>Open the log folder</source>
        <translation>Открыть папку журнала</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Where the log files are kept.</source>
        <translation>Где хранятся файлы журнала.</translation>
    </message>
    <message>
        <location line="+2" />
        <source>log</source>
        <translation>журнал</translation>
    </message>
    <message>
        <location line="+4" />
        <location line="+3" />
        <source>Open the reports folder</source>
        <translation>Открыть папку отчётов</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Where reports are saved.</source>
        <translation>Где сохраняются отчёты.</translation>
    </message>
    <message>
        <location line="+2" />
        <source>report</source>
        <translation>отчёт</translation>
    </message>
    <message>
        <location line="+18" />
        <source>About</source>
        <translation>О программе</translation>
    </message>
    <message>
        <location line="+18" />
        <source>Project</source>
        <translation>Проект</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Version</source>
        <translation>Версия</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Date</source>
        <translation>Дата</translation>
    </message>
    <message>
        <location line="+0" />
        <source>October 2026</source>
        <translation>Октябрь 2026</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Creator</source>
        <translation>Автор</translation>
    </message>
    <message>
        <location line="+0" />
        <source>Ahmed Ibrahim</source>
        <translation>Ahmed Ibrahim</translation>
    </message>
    <message>
        <location line="+1" />
        <source>License</source>
        <translation>Лицензия</translation>
    </message>
    <message>
        <location line="+0" />
        <source>GNU GPLv3</source>
        <translation>GNU GPLv3</translation>
    </message>
    <message>
        <location line="+5" />
        <source>Everything this app sends stays on your own network: no account, no upload, and no internet connection needed.</source>
        <translation>Всё, что эта программа отправляет, остаётся в вашей собственной сети: без учётной записи, без отправки наружу и без интернета.</translation>
    </message>
    <message>
        <location line="+19" />
        <location line="+12" />
        <location line="+16" />
        <location line="+14" />
        <source>Tutorial</source>
        <translation>Учебник</translation>
    </message>
    <message>
        <location line="-41" />
        <source>The tutorial could not be saved to this computer's settings folder, so it cannot be opened right now.</source>
        <translation>Учебник не удалось сохранить в папке настроек этого компьютера, поэтому сейчас его нельзя открыть.</translation>
    </message>
    <message>
        <location line="+12" />
        <source>This computer has no program set up to open web pages.

Open this file yourself:
%1</source>
        <translation>На этом компьютере нет программы для открытия веб-страниц. Откройте этот файл сами:
 %1</translation>
    </message>
    <message>
        <location line="+7" />
        <source>The tutorial is opening in your web browser.</source>
        <translation>Учебник открывается в вашем браузере.</translation>
    </message>
    <message>
        <location line="+9" />
        <source>The tutorial could not be saved to this computer's settings folder, so it cannot be shown right now.</source>
        <translation>Учебник не удалось сохранить в папке настроек этого компьютера, поэтому сейчас его нельзя показать.</translation>
    </message>
    <message>
        <location line="+14" />
        <source>File Explorer could not be opened.

The tutorial is here:
%1</source>
        <translation>Не удалось открыть Проводник. Учебник здесь:
 %1</translation>
    </message>
    <message>
        <location line="+4" />
        <source>The tutorial's folder is open in File Explorer.</source>
        <translation>Папка учебника открыта в Проводнике.</translation>
    </message>
    <message>
        <location line="+44" />
        <source>The report could not be saved: %1</source>
        <translation>Не удалось сохранить отчёт: %1</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Report</source>
        <translation>Отчёт</translation>
    </message>
    <message>
        <location line="+1" />
        <source>The report could not be saved.

%1</source>
        <translation>Не удалось сохранить отчёт.
 
 %1</translation>
    </message>
    <message>
        <location line="+9" />
        <source>Saved: %1
%2 KiB, from %3 log file(s).</source>
        <translation>Сохранено: %1
 %2 КиБ, из %3 файлов журнала.</translation>
    </message>
    <message>
        <location line="+6" />
        <source>Report saved as %1.</source>
        <translation>Отчёт сохранён как %1.</translation>
    </message>
    <message>
        <location line="+6" />
        <location line="+5" />
        <source>Folders</source>
        <translation>Папки</translation>
    </message>
    <message>
        <location line="-4" />
        <source>This computer has no folder available for the %1 files.</source>
        <translation>На этом компьютере нет папки для файлов %1.</translation>
    </message>
    <message>
        <location line="+5" />
        <source>The folder could not be opened.

%1</source>
        <translation>Не удалось открыть папку.
 
 %1</translation>
    </message>
    <message>
        <location line="+60" />
        <source>No settings folder is available on this computer.</source>
        <translation>На этом компьютере нет папки настроек.</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/ui/MainWindow.cpp" line="+62" />
        <source>Share this computer on the network, or watch someone who is.</source>
        <translation>Показывайте этот компьютер в сети или смотрите того, кто это делает.</translation>
    </message>
    <message>
        <location line="+24" />
        <source>Broadcast</source>
        <translation>Трансляция</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Receive</source>
        <translation>Приём</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Help</source>
        <translation>Справка</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Share this computer's screen or audio.</source>
        <translation>Показывать экран или звук этого компьютера.</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Watch a broadcast from another computer.</source>
        <translation>Смотреть трансляцию с другого компьютера.</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Open the tutorial in your web browser.</source>
        <translation>Открыть учебник в браузере.</translation>
    </message>
    <message>
        <location line="+48" />
        <source>a broadcast is running</source>
        <translation>идёт трансляция</translation>
    </message>
    <message>
        <location line="+5" />
        <source>you are watching a broadcast</source>
        <translation>вы смотрите трансляцию</translation>
    </message>
    <message>
        <location line="+11" />
        <location line="+40" />
        <source>Close LocalStream</source>
        <translation>Закрыть LocalStream</translation>
    </message>
    <message>
        <location line="-39" />
        <location line="+40" />
        <source>LocalStream is still busy: %1.</source>
        <translation>LocalStream ещё занят: %1.</translation>
    </message>
    <message>
        <location line="-39" />
        <location line="+40" />
        <source> and </source>
        <translation> и </translation>
    </message>
    <message>
        <location line="-39" />
        <source>Close the app and stop?</source>
        <translation>Закрыть программу и остановить?</translation>
    </message>
    <message>
        <location line="+41" />
        <source>Hide it in the system tray and keep it running, or exit and stop?</source>
        <translation>Спрятать её в области уведомлений и оставить работать или выйти и остановить?</translation>
    </message>
    <message>
        <location line="+4" />
        <source>Hide in the system tray</source>
        <translation>Спрятать в области уведомлений</translation>
    </message>
    <message>
        <location line="+2" />
        <source>Exit and stop</source>
        <translation>Выйти и остановить</translation>
    </message>
    <message>
        <location line="+2" />
        <source>Cancel</source>
        <translation>Отмена</translation>
    </message>
    <message>
        <location line="+37" />
        <source>LocalStream is running in the background. Double-click to open it.</source>
        <translation>LocalStream работает в фоне. Дважды щёлкните, чтобы открыть.</translation>
    </message>
    <message>
        <location line="+4" />
        <source>Show LocalStream</source>
        <translation>Показать LocalStream</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Quit</source>
        <translation>Выход</translation>
    </message>
    <message>
        <location line="+89" />
        <source>Theme: follow system</source>
        <translation>Тема: как в системе</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Theme: light</source>
        <translation>Тема: светлая</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Theme: dark</source>
        <translation>Тема: тёмная</translation>
    </message>
    <message>
        <location line="+3" />
        <source> (Windows decides)</source>
        <translation> (решает Windows)</translation>
    </message>
    <message>
        <location line="+5" />
        <source>Windows High Contrast is on, so it decides the colours. Click to keep the preference for when it switches off.</source>
        <translation>Включён режим высокой контрастности Windows, поэтому цвета задаёт он. Щёлкните, чтобы сохранить выбор на случай, когда режим выключат.</translation>
    </message>
    <message>
        <location line="+2" />
        <source>Switch to the next colour theme. Ctrl+1 and Ctrl+2 switch tabs.</source>
        <translation>Переключиться на следующую тему оформления. Ctrl+1 и Ctrl+2 переключают вкладки.</translation>
    </message>
</context>
<context>
    <name>PasswordDialog</name>
    <message>
        <location filename="../src/ui/ReceivePage.cpp" line="+156" />
        <source>Watch</source>
        <translation>Смотреть</translation>
    </message>
    <message>
        <location line="+4" />
        <source>Password required</source>
        <translation>Требуется пароль</translation>
    </message>
    <message>
        <location line="+7" />
        <source>%1 is broadcasting privately.</source>
        <translation>%1 ведёт приватную трансляцию.</translation>
    </message>
    <message>
        <location line="+1" />
        <location line="+42" />
        <source>The broadcaster</source>
        <translation>Вещающий</translation>
    </message>
    <message>
        <location line="-24" />
        <source>Password</source>
        <translation>Пароль</translation>
    </message>
    <message>
        <location line="+23" />
        <source>%1 requires a password.</source>
        <translation>%1 требует пароль.</translation>
    </message>
    <message>
        <location line="+24" />
        <source>The password must be between %1 and %2 characters.</source>
        <translation>Пароль должен содержать от %1 до %2 символов.</translation>
    </message>
</context>
<context>
    <name>ReceivePage</name>
    <message>
        <location line="-192" />
        <source>%1 - audio only</source>
        <translation>%1 - только звук</translation>
    </message>
    <message>
        <location line="+2" />
        <source>%1 - %2x%3</source>
        <translation>%1 - %2x%3</translation>
    </message>
    <message>
        <location line="+10" />
        <source>Windows PC</source>
        <translation>Компьютер с Windows</translation>
    </message>
    <message>
        <location line="+207" />
        <source>Available broadcasters</source>
        <translation>Доступные вещающие</translation>
    </message>
    <message>
        <location line="+2" />
        <source>Broadcasters found on this network. Select one, then choose Connect.</source>
        <translation>Вещающие, найденные в этой сети. Выберите одного, затем нажмите «Подключиться».</translation>
    </message>
    <message>
        <location line="+3" />
        <location line="+544" />
        <source>Connect</source>
        <translation>Подключиться</translation>
    </message>
    <message>
        <location line="-538" />
        <source>Search again</source>
        <translation>Искать снова</translation>
    </message>
    <message>
        <location line="+2" />
        <source>Search for broadcasters again</source>
        <translation>Искать вещающих снова</translation>
    </message>
    <message>
        <location line="+2" />
        <source>Ask the network again. Useful when a broadcaster has just come online, or when nothing has appeared for a while.</source>
        <translation>Спросить сеть ещё раз. Полезно, когда вещающий только что появился в сети или когда ничего не показывалось долгое время.</translation>
    </message>
    <message>
        <location line="+7" />
        <location line="+133" />
        <source>Receive buffer</source>
        <translation>Буфер приёма</translation>
    </message>
    <message>
        <location line="-132" />
        <source>Low latency (200 ms)</source>
        <translation>Малая задержка (200 мс)</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Balanced (500 ms)</source>
        <translation>Сбалансированный (500 мс)</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Smooth (1 second)</source>
        <translation>Плавный (1 секунда)</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Maximum (2 seconds)</source>
        <translation>Максимальный (2 секунды)</translation>
    </message>
    <message>
        <location line="+23" />
        <source>Video from the broadcaster</source>
        <translation>Видео от вещающего</translation>
    </message>
    <message>
        <location line="+5" />
        <source>Fullscreen</source>
        <translation>Во весь экран</translation>
    </message>
    <message>
        <location line="+1" />
        <source>Enter fullscreen</source>
        <translation>Войти в полноэкранный режим</translation>
    </message>
    <message>
        <location line="+4" />
        <source>Connect to a broadcaster to see the picture here.</source>
        <translation>Подключитесь к вещающему, чтобы увидеть картинку здесь.</translation>
    </message>
    <message>
        <location line="+25" />
        <source>If the list is empty, enter the broadcaster's address and the control port shown on its Broadcast screen.</source>
        <translation>Если список пуст, введите адрес вещающего и порт управления, показанный на его вкладке «Трансляция».</translation>
    </message>
    <message>
        <location line="+4" />
        <location line="+1" />
        <source>Broadcaster address</source>
        <translation>Адрес вещающего</translation>
    </message>
    <message>
        <location line="+2" />
        <location line="+1" />
        <source>Control port</source>
        <translation>Порт управления</translation>
    </message>
    <message>
        <location line="+8" />
        <source>Connect manually</source>
        <translation>Подключение вручную</translation>
    </message>
    <message>
        <location line="+21" />
        <source>Broadcasters</source>
        <translation>Вещающие</translation>
    </message>
    <message>
        <location line="+12" />
        <source>Select a broadcaster, then choose Connect. Enter connects to the one highlighted.</source>
        <translation>Выберите вещающего, затем нажмите «Подключиться». Enter подключает к выделенному.</translation>
    </message>
    <message>
        <location line="+4" />
        <source>Connect by address</source>
        <translation>Подключиться по адресу</translation>
    </message>
    <message>
        <location line="+10" />
        <source>Picture</source>
        <translation>Картинка</translation>
    </message>
    <message>
        <location line="+14" />
        <source>Session</source>
        <translation>Сеанс</translation>
    </message>
    <message>
        <location line="+12" />
        <source>Scanning for broadcasters on this network.</source>
        <translation>Идёт поиск вещающих в этой сети.</translation>
    </message>
    <message>
        <location line="+26" />
        <source>Searching for broadcasters...</source>
        <translation>Поиск вещающих...</translation>
    </message>
    <message>
        <location line="+41" />
        <source>%1 Windows Firewall may also be blocking incoming connections to LocalStream.</source>
        <translation>Брандмауэр Windows (%1) тоже может блокировать входящие подключения к LocalStream.</translation>
    </message>
    <message>
        <location line="+20" />
        <source>Connected.</source>
        <translation>Подключено.</translation>
    </message>
    <message>
        <location line="+8" />
        <location line="+337" />
        <source>Disconnected.</source>
        <translation>Отключено.</translation>
    </message>
    <message>
        <location line="-309" />
        <source>Asking %1 for permission to watch...</source>
        <translation>Запрашивается разрешение у %1...</translation>
    </message>
    <message>
        <location line="+24" />
        <source>Blocked by the broadcaster</source>
        <translation>Заблокировано вещающим</translation>
    </message>
    <message>
        <location line="+8" />
        <source>%1 fps - %2 kbps</source>
        <translation>%1 к/с - %2 кбит/с</translation>
    </message>
    <message>
        <location line="+15" />
        <source>%1/%2 audio played</source>
        <translation>Звука воспроизведено %1/%2</translation>
    </message>
    <message>
        <location line="+2" />
        <source>no audio: %1</source>
        <translation>звука нет: %1</translation>
    </message>
    <message>
        <location line="+2" />
        <source>audio device not open</source>
        <translation>звуковое устройство не открыто</translation>
    </message>
    <message>
        <location line="+2" />
        <source>audio not decoding (%1 sent, %2 rejected)</source>
        <translation>звук не декодируется (отправлено %1, отклонено %2)</translation>
    </message>
    <message>
        <location line="+5" />
        <source>Received: %1 audio, %2 video, %3 lost%4 - decoded: %5 video, %6</source>
        <translation>Принято: %1 звука, %2 видео, %3 потеряно%4 - декодировано: %5 видео, %6</translation>
    </message>
    <message>
        <location line="+5" />
        <source> - waiting for keyframe header</source>
        <translation> - ожидание заголовка опорного кадра</translation>
    </message>
    <message>
        <location line="+72" />
        <source>Found a broadcaster. Choose Connect to watch.</source>
        <translation>Найден вещающий. Нажмите «Подключиться», чтобы смотреть.</translation>
    </message>
    <message>
        <location line="+16" />
        <source>No broadcasters found. Check that both devices are on the same Wi-Fi network, and that Windows Firewall is letting LocalStream receive network traffic.</source>
        <translation>Вещающие не найдены. Проверьте, что оба устройства в одной сети Wi-Fi и что брандмауэр Windows разрешает LocalStream принимать сетевой трафик.</translation>
    </message>
    <message>
        <location line="+29" />
        <source>That broadcaster is no longer on the network.</source>
        <translation>Этого вещающего больше нет в сети.</translation>
    </message>
    <message>
        <location line="+14" />
        <source>That broadcaster did not advertise a control port.</source>
        <translation>Этот вещающий не объявил порт управления.</translation>
    </message>
    <message>
        <location line="+4" />
        <location line="+34" />
        <source>Connecting...</source>
        <translation>Подключение...</translation>
    </message>
    <message>
        <location line="-18" />
        <source>Enter the broadcaster's address first.</source>
        <translation>Сначала введите адрес вещающего.</translation>
    </message>
    <message>
        <location line="+10" />
        <source>Enter the control port shown on the broadcaster's screen.</source>
        <translation>Введите порт управления, показанный на экране вещающего.</translation>
    </message>
    <message>
        <location line="+21" />
        <source>Disconnecting...</source>
        <translation>Отключение...</translation>
    </message>
    <message>
        <location line="+7" />
        <source>Disconnect</source>
        <translation>Отключиться</translation>
    </message>
    <message>
        <location line="+47" />
        <source>Checking the password...</source>
        <translation>Проверка пароля...</translation>
    </message>
    <message>
        <location line="+20" />
        <source>Could not connect.</source>
        <translation>Не удалось подключиться.</translation>
    </message>
    <message>
        <location line="+2" />
        <source>Could not connect</source>
        <translation>Не удалось подключиться</translation>
    </message>
</context>
<context>
    <name>VideoWindow</name>
    <message>
        <location line="-801" />
        <source>Exit fullscreen</source>
        <translation>Выйти из полноэкранного режима</translation>
    </message>
</context>
</TS>
