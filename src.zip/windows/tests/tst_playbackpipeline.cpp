#include <QtTest>

#include <QImage>
#include <QList>
#include <QMutex>

#include <libavutil/pixfmt.h>

#include <cmath>

#include "capture/Encoders.h"
#include "engine/AudioPlayer.h"
#include "engine/PlaybackEngine.h"
#include "net/ControlServer.h"
#include "net/RtpReceiver.h"
#include "net/RtpSender.h"

using namespace localstream;
using localstream::engine::PlaybackEngine;

/**
 * End-to-end over loopback: encode, packetize, send through real UDP, receive, depacketize.
 *
 * Every layer is the production one, so a mismatch between the sender's AVCC output and the
 * receiver's Annex B input surfaces here instead of as a black screen on a second machine. The
 * RtpSender fans out to targets and the RtpReceiver owns its own event loop, so the two are
 * pointed at each other on 127.0.0.1 and nothing else is mocked out.
 */
class PlaybackPipeline : public QObject
{
    Q_OBJECT

private slots:
    void videoReachesReceiverAsAnnexB();
    void spsAndPpsSurviveTheRoundTrip();
    void garbagePayloadIsRejectedNotCrashed();
    void audioReachesTheHandler();
    void audioPlayerDecodesSubmittedPackets();
    void keyframeRequestReachesTheHook();
    void playBackEngineDecodesABroadcast();
};

namespace {

/// A moving gradient rather than a flat colour: a flat field compresses to almost nothing and
/// would let a broken depacketiser still hand the decoder something plausible.
///
/// Built as raw BGRA rather than a QImage, because this file needs no `QImage` include.
QByteArray testPattern(int width, int height)
{
    QByteArray buffer(static_cast<qsizetype>(width) * height * 4, Qt::Uninitialized);
    auto* out = reinterpret_cast<uchar*>(buffer.data());
    for (int y = 0; y < height; ++y) {
        auto* line = reinterpret_cast<quint32*>(out + static_cast<qsizetype>(y) * width * 4);
        for (int x = 0; x < width; ++x) {
            const int r = (x * 255) / qMax(1, width - 1);
            const int g = (y * 255) / qMax(1, height - 1);
            const int b = ((x * y) * 255) / qMax(1, width * height - 1);
            // True BGRA memory order: byte 0 is blue, byte 2 is red.
            line[x] = (static_cast<quint32>(0xFF) << 24) | (static_cast<quint32>(r) << 16)
                | (static_cast<quint32>(g) << 8) | static_cast<quint32>(b);
        }
    }
    return buffer;
}

/// BGRA is what a Windows capture device delivers, and the sample states the format rather than
/// leaving the encoder to assume it, exactly as FrameSource does.
capture::VideoSample makeSample(const QByteArray& bgra, int width, int height, qint64 index)
{
    capture::VideoSample sample;
    sample.width = width;
    sample.height = height;
    sample.format = AV_PIX_FMT_BGRA;
    sample.ptsMicros = index * (1000000 / 30);
    sample.linesize = width * 4;
    sample.data = bgra;
    return sample;
}

} // namespace

void PlaybackPipeline::videoReachesReceiverAsAnnexB()
{
    constexpr int Width = 320;
    constexpr int Height = 240;

    capture::VideoEncoder encoder(Width, Height, 30, 500);
    QVERIFY2(encoder.isOpen(), "the H.264 encoder did not open");

    net::RtpSender sender;
    QString error;
    QVERIFY2(sender.open(true, &error), qPrintable(error));
    QVERIFY(sender.videoPort() > 0);

    net::RtpReceiver receiver;
    QVERIFY2(receiver.open(true, &error), qPrintable(error));

    net::RtpSender::Target target;
    target.address = QHostAddress(QHostAddress::LocalHost);
    target.audioPort = receiver.ports().audio;
    target.videoPort = receiver.ports().video;
    sender.addTarget(target);
    QVERIFY(receiver.setExpectedSource(target.address, sender.audioPort(), sender.audioSsrc(),
        sender.videoPort(), sender.videoSsrc()));

    std::atomic<int> units {0};
    std::atomic<int> keyframes {0};
    receiver.setVideoHandler([&](const QByteArray& accessUnit, const QByteArray&, const QByteArray&) {
        if (accessUnit.isEmpty()) {
            return;
        }
        // Annex B, because that is what the depacketiser is documented to produce and what the
        // decoder is handed. Checking the start code here is what makes a regression to AVCC
        // output a test failure rather than a decoder that quietly never produces a frame.
        const bool hasStartCode = accessUnit.startsWith("\x00\x00\x00\x01")
            || accessUnit.startsWith("\x00\x00\x01");
        QVERIFY2(hasStartCode, "access unit did not begin with an Annex B start code");
        units.fetch_add(1);
    });

    // The encoder buffers for lookahead, so frames come out later than they go in; the loop
    // sends more than that so the depacketiser has something to close a unit with.
    for (int i = 0; i < 30; ++i) {
        encoder.encode(makeSample(testPattern(Width, Height), Width, Height, i),
            [&](const capture::EncodedVideo& encoded) {
                if (encoded.keyframe) {
                    keyframes.fetch_add(1);
                }
                sender.sendVideo(encoded.accessUnit);
            });
    }
    encoder.flush([&](const capture::EncodedVideo& encoded) { sender.sendVideo(encoded.accessUnit); });

    QTest::qWait(400);

    QVERIFY2(units.load() > 0,
        qPrintable(QStringLiteral("no access unit arrived: sender vport %1, receiver vport %2")
                       .arg(sender.videoPort())
                       .arg(receiver.ports().video)));
    QVERIFY2(keyframes.load() > 0, "no keyframe was produced, so nothing was decodable");

    receiver.close();
    sender.close();
}

void PlaybackPipeline::spsAndPpsSurviveTheRoundTrip()
{
    capture::VideoEncoder encoder(320, 240, 30, 500);
    QVERIFY(encoder.isOpen());

    // Empty until the first keyframe. libav writes an H.264 encoder's extradata lazily, when the
    // first packet comes out, so with repeat_headers on the parameter sets arrive inside that
    // keyframe instead. VideoEncoder captures them there, and a receiver that wants them has to
    // have asked for a keyframe -- which is what PlaybackEngine does for every receiver it
    // accepts.
    QVERIFY2(encoder.sps().isEmpty(), "SPS appeared before the encoder produced any packet");

    std::atomic<bool> sawKeyframe {false};
    for (int i = 0; i < 30 && !sawKeyframe.load(); ++i) {
        encoder.encode(makeSample(testPattern(320, 240), 320, 240, i),
            [&](const capture::EncodedVideo& encoded) {
                if (encoded.keyframe) {
                    sawKeyframe.store(true);
                }
            });
    }
    QVERIFY2(sawKeyframe.load(), "no keyframe was produced, so no parameter sets were captured");

    const QByteArray sps = encoder.sps();
    const QByteArray pps = encoder.pps();
    QVERIFY2(!sps.isEmpty(), "no SPS was captured from the first keyframe");
    QVERIFY2(!pps.isEmpty(), "no PPS was captured from the first keyframe");

    // Bare NAL units, with no length prefix and no Annex B start code. That is the single
    // contract across protocol::h264::splitAvcc, Depacketizer::sps() and VideoEncoder::sps(), and
    // a receiver that rebuilds decoder extradata has to be able to rely on it. Asserting the
    // leading byte here is what catches a regression to one-byte SPS: a lone 0x67 is a
    // well-formed-looking header with no payload, and it fails at the decoder rather than here.
    QVERIFY2(!encoder.sps().startsWith('\0'), "SPS carried a length prefix or start code");
    QCOMPARE(static_cast<quint8>(encoder.sps().at(0)) & 0x1F, 7);
    QCOMPARE(static_cast<quint8>(encoder.pps().at(0)) & 0x1F, 8);

    // A real parameter set is more than its header: the earlier bug produced a 1-byte SPS that
    // passed every type check and only failed at the decoder.
    QVERIFY2(encoder.sps().size() > 8, "SPS is too short to be a real parameter set");
    QVERIFY2(encoder.pps().size() >= 4, "PPS is too short to be a real parameter set");

    // Stable for the encoder's lifetime, because a receiver caches them once and must not have
    // them change under it.
    QCOMPARE(encoder.sps(), sps);
    QCOMPARE(encoder.pps(), pps);
}

void PlaybackPipeline::garbagePayloadIsRejectedNotCrashed()
{
    net::RtpReceiver receiver;
    QString error;
    QVERIFY2(receiver.open(true, &error), qPrintable(error));

    std::atomic<int> nonEmptyUnits {0};
    receiver.setVideoHandler(
        [&](const QByteArray& accessUnit, const QByteArray&, const QByteArray&) {
            if (!accessUnit.isEmpty()) {
                nonEmptyUnits.fetch_add(1);
            }
        });

    // Sent to the receiver's own video port, so it goes through the same depacketiser as real
    // traffic. The payload is not a valid RTP header for the sequence the receiver is tracking,
    // which is the point: rejecting it must not read past the end of the buffer.
    QUdpSocket senderSocket;
    QVERIFY(senderSocket.bind(QHostAddress(QHostAddress::LocalHost), 0));

    for (int i = 0; i < 50; ++i) {
        QByteArray payload(64, Qt::Uninitialized);
        for (int b = 0; b < payload.size(); ++b) {
            payload[b] = static_cast<char>((b * 7 + i) & 0xFF);
        }
        senderSocket.writeDatagram(payload, QHostAddress(QHostAddress::LocalHost),
            static_cast<quint16>(receiver.ports().video));
    }

    QTest::qWait(200);

    // The assertion is that we got here: the depacketiser either rejects the garbage or emits
    // nothing usable, and either way the receiver is still alive and answering.
    const net::RtpReceiver::Stats stats = receiver.stats();
    QVERIFY(stats.videoPackets >= 0);
    QVERIFY(receiver.isOpen());

    receiver.close();
    QVERIFY(!receiver.isOpen());
}

// The audio path goes through a reorder buffer before it reaches the handler, and that buffer is
// the one place production never exercised until now: its callback was named `emit`, which Qt
// defines as an empty macro, so every audio frame was buffered, acknowledged by the sequence
// counter and then silently discarded. The packets-arrived counter stayed healthy while no audio
// ever played, which is exactly the symptom this test exists to make impossible to reintroduce.
void PlaybackPipeline::audioReachesTheHandler()
{
    net::RtpSender sender;
    QString error;
    QVERIFY2(sender.open(true, &error), qPrintable(error));
    QVERIFY(sender.audioPort() > 0);

    net::RtpReceiver receiver;
    QVERIFY2(receiver.open(true, &error), qPrintable(error));

    net::RtpSender::Target target;
    target.address = QHostAddress(QHostAddress::LocalHost);
    target.audioPort = receiver.ports().audio;
    target.videoPort = receiver.ports().video;
    sender.addTarget(target);
    QVERIFY(receiver.setExpectedSource(target.address, sender.audioPort(), sender.audioSsrc(),
        sender.videoPort(), sender.videoSsrc()));

    std::atomic<int> audioFrames {0};
    QMutex receivedMutex;
    QList<QByteArray> received;
    receiver.setAudioHandler([&](const QByteArray& frame) {
        {
            QMutexLocker locker(&receivedMutex);
            received.append(frame);
        }
        audioFrames.fetch_add(1);
    });

    // Valid Opus is not required: the receiver's contract is to hand the RTP payload straight to
    // its handler. The distinct leading byte makes a reordered, duplicated or dropped frame
    // detectable rather than merely a wrong count.
    constexpr int FrameCount = 20;
    for (int i = 0; i < FrameCount; ++i) {
        QByteArray frame(40, static_cast<char>(0x40 + i));
        frame[0] = static_cast<char>(i);
        sender.sendAudio(frame);
    }

    QTRY_VERIFY_WITH_TIMEOUT(audioFrames.load() >= FrameCount, 3000);

    QMutexLocker locker(&receivedMutex);
    QCOMPARE(received.size(), FrameCount);
    for (int i = 0; i < FrameCount; ++i) {
        QCOMPARE(received.at(i).size(), 40);
        QCOMPARE(static_cast<quint8>(received.at(i).at(0)), static_cast<quint8>(i));
    }
    QVERIFY(receiver.stats().audioPackets >= static_cast<quint64>(FrameCount));

    receiver.close();
    sender.close();
}

// The one path no test drove: AudioPlayer's own thread, fed real Opus packets. The pipeline test
// opens the player but never submits a packet, so a broken decode wiring (a lost queued call, a
// device that never opens, a malformed packet handed to libav) reads as "the broadcaster sent no
// audio" and nothing here would notice.
void PlaybackPipeline::audioPlayerDecodesSubmittedPackets()
{
    // Real Opus, produced by the same encoder the Windows broadcaster uses. Mono, because that is
    // what Android captures, while its SDP advertises stereo.
    capture::AudioEncoder encoder(48000, 1, 48);
    QVERIFY(encoder.isOpen());

    QList<capture::EncodedAudio> packets;
    constexpr int inRate = 48000;
    constexpr int chunkFrames = 960;
    constexpr double kPi = 3.14159265358979323846;
    for (int start = 0; start < inRate; start += chunkFrames) {
        QByteArray data(chunkFrames * static_cast<int>(sizeof(qint16)), Qt::Uninitialized);
        auto* samples = reinterpret_cast<qint16*>(data.data());
        for (int i = 0; i < chunkFrames; ++i) {
            const double t = static_cast<double>(start + i) / inRate;
            samples[i] = static_cast<qint16>(16000 * std::sin(2 * kPi * 440 * t));
        }
        capture::AudioSample sample;
        sample.data = data;
        sample.samples = chunkFrames;
        sample.sampleRate = inRate;
        sample.channels = 1;
        sample.format = AV_SAMPLE_FMT_S16;
        encoder.encode(sample, [&packets](const capture::EncodedAudio& audio) {
            packets.append(audio);
        });
    }
    QVERIFY(!packets.isEmpty());

    engine::AudioPlayer player;
    QString failure;
    // Two channels: exactly what the handshake selects from Android's `opus/48000/2` SDP.
    QVERIFY2(player.start(2, [&failure](const QString& reason) { failure = reason; }),
        qPrintable(failure.isEmpty() ? QStringLiteral("AudioPlayer::start returned false") : failure));

    // A burst is the shape the receiver actually sees, and the shape the old one-packet-at-a-time
    // path mangled: every packet but the first of a burst was dropped. Five is well inside the
    // queue, so all of them have to survive the queue, the decoder and the device-open path.
    const int burst = qMin(packets.size(), 5);
    for (int i = 0; i < burst; ++i) {
        player.submit(packets.at(i).packet);
    }

    QTRY_COMPARE_WITH_TIMEOUT(player.stats().decoded, static_cast<quint64>(burst), 5000);
    QTRY_COMPARE_WITH_TIMEOUT(player.stats().queued, static_cast<quint64>(burst), 5000);
    QCOMPARE(player.stats().dropped, static_cast<quint64>(0));
    QVERIFY2(player.stats().peak > 0, qPrintable(QStringLiteral("decoded peak=%1").arg(player.stats().peak)));

    player.stop();
}

void PlaybackPipeline::keyframeRequestReachesTheHook()
{
    net::RtpSender sender;
    QString error;
    QVERIFY2(sender.open(true, &error), qPrintable(error));

    std::atomic<int> hookCalls {0};
    sender.setKeyframeRequestHook([&] { hookCalls.fetch_add(1); });

    sender.requestKeyframe();
    QCOMPARE(hookCalls.load(), 1);

    sender.close();
}

// The whole stack over loopback, including the control handshake: a real ControlServer offering
// to a real PlaybackEngine through a real ControlClient. This is the only test that reaches the
// decoder, so it is the one that would catch a bad extradata, a mismatched SPS/PPS format or a
// keyframe that never arrives -- the failures that otherwise present as a black window.
void PlaybackPipeline::playBackEngineDecodesABroadcast()
{
    constexpr int Width = 320;
    constexpr int Height = 240;

    capture::VideoEncoder encoder(Width, Height, 30, 500);
    QVERIFY(encoder.isOpen());

    net::RtpSender sender;
    QString error;
    QVERIFY2(sender.open(true, &error), qPrintable(error));

    net::ControlServer control;
    control.setCallbacks([&] {
        net::ControlServer::Callbacks callbacks;
        callbacks.description = [&] {
            protocol::LocalStream::Description description;
            description.sessionId = QStringLiteral("test-session");
            description.displayName = QStringLiteral("Test Broadcaster");
            description.mode = QString::fromLatin1(protocol::LocalStream::ModeAudioVideo);
            description.width = 320;
            description.height = 240;
            description.frameRate = 30;
            // The accept message carries these, and a receiver treats a zero video port as an
            // audio-only broadcast: it then never hands a single access unit to its decoder. They
            // are the sender's actually-bound ports, not something invented for the test, because
            // ControlServer forwards exactly this description to the receiver.
            description.audioPort = sender.audioPort();
            description.videoPort = sender.videoPort();
            description.controlPort = control.port();
            return description;
        };
        callbacks.sdp = [] { return QByteArray(); };
        callbacks.audioSsrc = [&] { return sender.audioSsrc(); };
        callbacks.videoSsrc = [&] { return sender.videoSsrc(); };
        callbacks.onOffer = [&](const QHostAddress& address, int audioPort, int videoPort) {
            net::RtpSender::Target target;
            target.address = address;
            target.audioPort = audioPort;
            target.videoPort = videoPort;
            sender.addTarget(target);
            // What BroadcastEngine does: a receiver that joins mid-GOP has no parameter sets
            // until the next keyframe, so one is forced on the offer.
            encoder.requestKeyframe();
        };
        return callbacks;
    }());
    QVERIFY2(control.listen(&error), qPrintable(error));
    QVERIFY(control.port() > 0);

    // The client asks for a keyframe on connect; the encoder honours it, so the parameter sets
    // and the first IDR both reach the decoder.
    sender.setKeyframeRequestHook([&] { encoder.requestKeyframe(); });

    PlaybackEngine playback;
    std::atomic<int> framesSeen {0};
    int lastWidth = 0;
    int lastHeight = 0;
    connect(&playback, &PlaybackEngine::videoFrameReady, this,
        [&](const QImage& frame) {
            if (frame.isNull()) {
                return;
            }
            lastWidth = frame.width();
            lastHeight = frame.height();
            framesSeen.fetch_add(1);
        });

    PlaybackEngine::Settings settings;
    settings.receiverName = QStringLiteral("Pipeline Test");
    QVERIFY2(playback.start(QStringLiteral("127.0.0.1"), control.port(), settings, &error),
        qPrintable(error));

    // Wait for the handshake and the first picture before pumping, so the encoder's first
    // keyframe is not missed by a receiver that is not listening yet.
    QTRY_VERIFY_WITH_TIMEOUT(control.receiverCount() > 0, 5000);

    for (int i = 0; i < 60 && framesSeen.load() < 3; ++i) {
        encoder.encode(makeSample(testPattern(Width, Height), Width, Height, i),
            [&](const capture::EncodedVideo& encoded) {
                sender.sendVideo(encoded.accessUnit);
            });
        QTest::qWait(20);
    }

    QTRY_VERIFY_WITH_TIMEOUT(framesSeen.load() > 0, 5000);

    QCOMPARE(lastWidth, Width);
    QCOMPARE(lastHeight, Height);

    playback.stop();
    control.close();
    sender.close();
}

// QTEST_MAIN, not QTEST_APPLESS_MAIN: RtpReceiver's media thread runs a QEventLoop, which
// cannot be used without a QCoreApplication instance.
QTEST_MAIN(PlaybackPipeline)
#include "tst_playbackpipeline.moc"
