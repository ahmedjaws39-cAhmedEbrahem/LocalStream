#include "logging/Diagnostics.h"
#include "logging/Log.h"

#include <QDateTime>
#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QTemporaryDir>
#include <QtTest>

using namespace localstream;

/**
 * The log format and the report.
 *
 * These are the parts of the logging feature a user never sees working and always depends on: a
 * timestamp that quietly loses its timezone, a level column that stops lining up, a report that
 * claims to quote a log file it left out. None of that shows up as a crash or a wrong picture,
 * so it is written here instead of being left to whoever reads the first real report.
 */
class TestLogging : public QObject
{
    Q_OBJECT

private slots:
    void aLineCarriesTheTimeTheZoneAndWhereItCameFrom();
    void millisecondsCanBeTurnedOffAndTheClockCanBecomeTwelveHour();
    void everyLevelStartsInTheSameColumn();
    void levelsSurviveTheRoundTripThroughTheirNames();
    void anEventIsGreppableAndItsFieldsStayReadable();
    void recordingOffWritesNothingAtAll();
    void turningRecordingBackOnDoesNotClaimTheAppStartedAgain();
    void quietLinesAreDroppedBelowTheChosenLevel();
    void aFullFileIsRolledOverInsteadOfGrowingForever();
    void oldFilesArePrunedWhenTheWindowNarrows();
    void aReportQuotesTheLogAndSaysWhichFileItRead();
    void aReportSaysSoWhenThereIsNothingToQuote();
};

namespace {

logging::Settings defaults()
{
    logging::Settings options;
    options.recordAutomatically = true;
    options.minimumLevel = logging::Level::Debug;
    options.milliseconds = true;
    options.twelveHourClock = false;
    return options;
}

QString readAll(const QString& path)
{
    QFile file(path);
    if (!file.open(QIODevice::ReadOnly)) {
        return {};
    }
    return QString::fromUtf8(file.readAll());
}

} // namespace

void TestLogging::aLineCarriesTheTimeTheZoneAndWhereItCameFrom()
{
    const QDateTime when(QDate(2026, 10, 5), QTime(9, 14, 2, 481),
        QTimeZone::fromSecondsAheadOfUtc(2 * 3600));
    const QString line = logging::formatLine(
        logging::Level::Info, QStringLiteral("BroadcastEngine"), QStringLiteral("started"), 7,
        when, defaults());

    QVERIFY(line.startsWith(QStringLiteral("2026-10-05 09:14:02.481 +02:00")));
    QVERIFY(line.contains(QStringLiteral("[INFO ]")));
    QVERIFY(line.contains(QStringLiteral("[BroadcastEngine]")));
    QVERIFY(line.contains(QStringLiteral("[T7]")));
    QVERIFY(line.endsWith(QStringLiteral("started")));
}

void TestLogging::millisecondsCanBeTurnedOffAndTheClockCanBecomeTwelveHour()
{
    const QDateTime when(QDate(2026, 10, 5), QTime(21, 14, 2, 481),
        QTimeZone::fromSecondsAheadOfUtc(-5 * 3600));

    logging::Settings secondsOnly = defaults();
    secondsOnly.milliseconds = false;
    QVERIFY(logging::formatTimestamp(when, secondsOnly)
        .startsWith(QStringLiteral("2026-10-05 21:14:02 -05:00")));
    QVERIFY(!logging::formatTimestamp(when, secondsOnly).contains(QLatin1Char('.')));

    logging::Settings twelveHour = defaults();
    twelveHour.twelveHourClock = true;
    const QString morning = logging::formatTimestamp(
        QDateTime(QDate(2026, 10, 5), QTime(9, 4, 0), QTimeZone::fromSecondsAheadOfUtc(0)),
        twelveHour);
    QVERIFY2(morning.contains(QStringLiteral("AM")),
        qPrintable(QStringLiteral("expected an AM marker in %1").arg(morning)));
    QVERIFY(morning.startsWith(QStringLiteral("2026-10-05 09:04:00.000")));
    QCOMPARE(morning,
        QStringLiteral("2026-10-05 09:04:00.000 AM +00:00"));

    const QString evening = logging::formatTimestamp(
        QDateTime(QDate(2026, 10, 5), QTime(21, 4, 0), QTimeZone::fromSecondsAheadOfUtc(0)),
        twelveHour);
    QVERIFY2(evening.contains(QStringLiteral("PM")),
        qPrintable(QStringLiteral("expected a PM marker in %1").arg(evening)));

    // The offset stays even on a twelve-hour clock: it is what makes the time comparable to
    // another machine's log, which is the whole reason for writing it out.
    QVERIFY(morning.endsWith(QStringLiteral("+00:00")));
}

void TestLogging::everyLevelStartsInTheSameColumn()
{
    const QDateTime when(QDate(2026, 10, 5), QTime(9, 14, 2), QTimeZone::fromSecondsAheadOfUtc(0));
    int column = -1;
    for (const logging::Level level : {logging::Level::Debug, logging::Level::Info,
             logging::Level::Warning, logging::Level::Error}) {
        const QString line =
            logging::formatLine(level, QStringLiteral("c"), QStringLiteral("m"), 1, when, defaults());
        QVERIFY2(logging::levelTag(level).size() == 5,
            qPrintable(QStringLiteral("level tag %1 is not five characters")
                           .arg(logging::levelTag(level))));
        const int found = line.indexOf(QLatin1Char('['), 25);
        QVERIFY(found > 0);
        if (column < 0) {
            column = found;
        }
        QCOMPARE(found, column);
    }
}

void TestLogging::levelsSurviveTheRoundTripThroughTheirNames()
{
    for (const logging::Level level : {logging::Level::Debug, logging::Level::Info,
             logging::Level::Warning, logging::Level::Error}) {
        logging::Level parsed = logging::Level::Error;
        QVERIFY(logging::parseLevel(logging::levelName(level), &parsed));
        QCOMPARE(parsed, level);
    }
    logging::Level untouched = logging::Level::Debug;
    QVERIFY(!logging::parseLevel(QStringLiteral("shouting"), &untouched));
    QCOMPARE(untouched, logging::Level::Debug);
}

void TestLogging::anEventIsGreppableAndItsFieldsStayReadable()
{
    QTemporaryDir home;
    QVERIFY(home.isValid());
    const QString folder = home.filePath(QStringLiteral("logs"));

    logging::install(folder);
    logging::event(QStringLiteral("broadcast.started"),
        {{QStringLiteral("port"), QStringLiteral("53525")},
            {QStringLiteral("reason"), QStringLiteral("no room for the last one")}});
    logging::shutdown();

    const QStringList files = logging::filesNewestFirst();
    QCOMPARE(files.size(), 1);
    const QString body = readAll(files.first());

    // The name alone has to be findable, and the value has to stay one value: a space inside a
    // field would otherwise split into two and make the line ambiguous to read and to parse.
    QVERIFY2(body.contains(QStringLiteral("[broadcast.started]")),
        qPrintable(QStringLiteral("no event line in:\n%1").arg(body)));
    QVERIFY(body.contains(QStringLiteral("port=53525")));
    QVERIFY(body.contains(QStringLiteral("reason=\"no room for the last one\"")));
}

void TestLogging::recordingOffWritesNothingAtAll()
{
    QTemporaryDir home;
    QVERIFY(home.isValid());
    const QString folder = home.filePath(QStringLiteral("logs"));

    logging::install(folder);
    logging::Settings off = logging::settings();
    QVERIFY(off.recordAutomatically);
    off.recordAutomatically = false;
    logging::setSettings(off);

    logging::error(QStringLiteral("Test"), QStringLiteral("this must not be written"));
    logging::shutdown();

    // A file from the install's own header is acceptable; a line about the error is not.
    const QDir dir(folder);
    for (const QString& name : dir.entryList(QDir::Files)) {
        QVERIFY2(!readAll(dir.filePath(name)).contains(QStringLiteral("this must not be written")),
            "a line reached the disk with recording switched off");
    }
}

void TestLogging::turningRecordingBackOnDoesNotClaimTheAppStartedAgain()
{
    QTemporaryDir home;
    QVERIFY(home.isValid());
    const QString folder = home.filePath(QStringLiteral("logs"));

    logging::install(folder);
    logging::info(QStringLiteral("Test"), QStringLiteral("before the switch"));
    logging::shutdown();

    // A second run in the same process is what the Help tab's switch produces, and it has to be
    // findable again by whatever reopened the file.
    logging::install(folder);
    // Counted on the field rather than the application name, which under this harness is the
    // test binary's. Each run writes one, so this is the number the switch must not change.
    const int headersBefore = readAll(logging::currentFilePath())
                                  .count(QStringLiteral("started    :"));

    logging::Settings off = logging::settings();
    off.recordAutomatically = false;
    logging::setSettings(off);
    logging::error(QStringLiteral("Test"), QStringLiteral("while off"));

    logging::Settings on = off;
    on.recordAutomatically = true;
    logging::setSettings(on);
    logging::info(QStringLiteral("Test"), QStringLiteral("after the switch"));
    logging::shutdown();

    const QStringList files = logging::filesNewestFirst();
    QCOMPARE(files.size(), 1);
    const QString body = readAll(files.first());

    // No new header: the switch is a pause in one run, not a new one, and a report quoting this
    // file must not carry two false start times for the same session.
    QCOMPARE(body.count(QStringLiteral("started    :")), headersBefore);
    QVERIFY2(body.contains(QStringLiteral("[logging.resumed]")),
        qPrintable(QStringLiteral("no resume line in:\n%1").arg(body)));
    QVERIFY(body.contains(QStringLiteral("after the switch")));
    QVERIFY2(!body.contains(QStringLiteral("while off")),
        "a line written while recording was off reached the file");
}

void TestLogging::quietLinesAreDroppedBelowTheChosenLevel()
{
    QTemporaryDir home;
    QVERIFY(home.isValid());
    const QString folder = home.filePath(QStringLiteral("logs"));

    logging::install(folder);
    logging::Settings warningsOnly = logging::settings();
    warningsOnly.minimumLevel = logging::Level::Warning;
    logging::setSettings(warningsOnly);

    logging::debug(QStringLiteral("Test"), QStringLiteral("chatter"));
    logging::info(QStringLiteral("Test"), QStringLiteral("also chatter"));
    logging::warning(QStringLiteral("Test"), QStringLiteral("a real problem"));
    logging::error(QStringLiteral("Test"), QStringLiteral("a worse problem"));
    logging::shutdown();

    const QString body = readAll(logging::currentFilePath());
    QVERIFY(!body.contains(QStringLiteral("chatter")));
    QVERIFY(body.contains(QStringLiteral("a real problem")));
    QVERIFY(body.contains(QStringLiteral("a worse problem")));
}

void TestLogging::aFullFileIsRolledOverInsteadOfGrowingForever()
{
    QTemporaryDir home;
    QVERIFY(home.isValid());
    const QString folder = home.filePath(QStringLiteral("logs"));

    logging::install(folder);
    logging::event(QStringLiteral("test.started"));
    logging::Settings smallest = logging::settings();
    smallest.maxFileSizeMiB = 1; // the floor the settings allow
    logging::setSettings(smallest);

    // Few lines, each large, rather than thousands of realistic ones: every line is also handed
    // on to the console handler, which inside a test run is the test's own output. A rollover is
    // about bytes against a ceiling, not about how many lines got there.
    const QString body(300 * 1024, QLatin1Char('x'));
    for (int line = 0; line < 5; ++line) {
        logging::info(QStringLiteral("Filler"), body);
    }
    logging::shutdown();

    const QDir dir(folder);
    const QStringList rolled = dir.entryList({QStringLiteral("*.log.1")}, QDir::Files);
    const QStringList live = dir.entryList({QStringLiteral("*.log")}, QDir::Files);
    QCOMPARE(rolled.size(), 1);
    QCOMPARE(live.size(), 1);
    QVERIFY2(QFileInfo(dir.filePath(rolled.first())).size() <= 1024 * 1024,
        "a rolled-over file kept growing past the ceiling");
    QVERIFY2(QFileInfo(dir.filePath(live.first())).size() <= 1024 * 1024,
        "the live file went past the ceiling without rolling");
}

void TestLogging::oldFilesArePrunedWhenTheWindowNarrows()
{
    QTemporaryDir home;
    QVERIFY(home.isValid());
    const QString folder = home.filePath(QStringLiteral("logs"));
    QVERIFY(QDir().mkpath(folder));

    const QDate today = QDate::currentDate();
    const QString recent = QDir(folder).filePath(
        QStringLiteral("LocalStream-%1.log").arg(today.addDays(-1).toString(
            QStringLiteral("yyyy-MM-dd"))));
    const QString ancient = QDir(folder).filePath(
        QStringLiteral("LocalStream-%1.log").arg(today.addDays(-40).toString(
            QStringLiteral("yyyy-MM-dd"))));
    for (const QString& path : {recent, ancient}) {
        QFile file(path);
        QVERIFY(file.open(QIODevice::WriteOnly));
        file.write("old\n");
        file.close();
    }

    logging::install(folder);
    logging::Settings week = logging::settings();
    week.keepDays = 7;
    logging::setSettings(week);
    logging::shutdown();

    QVERIFY2(QFileInfo::exists(recent), "a file inside the window was deleted");
    QVERIFY2(!QFileInfo::exists(ancient), "a file outside the window was kept");
}

void TestLogging::aReportQuotesTheLogAndSaysWhichFileItRead()
{
    QTemporaryDir home;
    QVERIFY(home.isValid());
    const QString folder = home.filePath(QStringLiteral("logs"));
    const QString reports = home.filePath(QStringLiteral("reports"));

    logging::install(folder);
    logging::event(QStringLiteral("receiver.connected"),
        {{QStringLiteral("from"), QStringLiteral("192.168.1.40")}});
    logging::shutdown();

    logging::ReportOptions options;
    options.logTailKib = 64;
    const logging::ReportResult result = logging::writeReport(options, reports);

    QVERIFY2(result.ok, qPrintable(result.error));
    QVERIFY(QFileInfo::exists(result.path));
    QCOMPARE(result.includedFiles.size(), 1);

    const QString body = readAll(result.path);
    QVERIFY(body.contains(QStringLiteral("LocalStream report")));
    QVERIFY(body.contains(QStringLiteral("SYSTEM")));
    QVERIFY(body.contains(QStringLiteral("LOGGING SETTINGS")));
    QVERIFY2(body.contains(QStringLiteral("receiver.connected")),
        "the report does not quote the log it was asked for");
    QVERIFY2(body.contains(QStringLiteral("End of report.")),
        "a truncated report would be read as the whole story");
    QCOMPARE(body.toUtf8().size(), result.bytes);
}

void TestLogging::aReportSaysSoWhenThereIsNothingToQuote()
{
    QTemporaryDir home;
    QVERIFY(home.isValid());
    const QString reports = home.filePath(QStringLiteral("reports"));

    // Nothing installed, so there is no session and no log. The report still has to come out,
    // saying so, rather than coming out empty or not at all.
    const logging::ReportResult result = logging::writeReport({}, reports);
    QVERIFY2(result.ok, qPrintable(result.error));
    const QString body = readAll(result.path);
    QVERIFY2(body.contains(QStringLiteral("no log lines")),
        qPrintable(QStringLiteral("a report with nothing to quote did not say so:\n%1").arg(body)));
}

QTEST_GUILESS_MAIN(TestLogging)
#include "tst_logging.moc"
