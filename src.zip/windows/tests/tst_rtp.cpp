#include <QtTest>

#include "protocol/Rtp.h"

using namespace localstream::protocol;

/**
 * RTP header codec.
 *
 * Byte-level rather than round-trip only: the payload of a packet is what the video decoder
 * and the Opus decoder will see, and a header that parses but places the payload one byte off
 * corrupts every frame while every other test still passes.
 */
class TestRtp : public QObject
{
    Q_OBJECT

private slots:
    void buildProducesTwelveByteHeader()
    {
        const QByteArray packet = Rtp::build(96, true, 0x1234, 0x0000ABCD, 0x11223344,
            QByteArray::fromHex("deadbeef"));

        QCOMPARE(packet.size(), Rtp::HeaderBytes + 4);
        QCOMPARE(static_cast<quint8>(packet.at(0)), quint8(0x80)); // V=2, no padding or CSRCs
        QCOMPARE(static_cast<quint8>(packet.at(1)) & 0x80, quint8(0x80)); // marker
        QCOMPARE(static_cast<quint8>(packet.at(1)) & 0x7F, quint8(96)); // payload type
        QCOMPARE(static_cast<quint8>(packet.at(2)), quint8(0x12));
        QCOMPARE(static_cast<quint8>(packet.at(3)), quint8(0x34));
    }

    void buildWritesBigEndianFields()
    {
        // Every multi-byte RTP field is big-endian; a stray memcpy of a host integer puts a
        // little-endian sequence number on the wire and the peer's reorder buffer stalls.
        const QByteArray packet = Rtp::build(97, false, 0x0102, 0x0A0B0C0D, 0x11223344,
            QByteArray("x"));
        QCOMPARE(static_cast<quint8>(packet.at(2)), quint8(0x01));
        QCOMPARE(static_cast<quint8>(packet.at(3)), quint8(0x02));
        QCOMPARE(static_cast<quint8>(packet.at(4)), quint8(0x0A));
        QCOMPARE(static_cast<quint8>(packet.at(5)), quint8(0x0B));
        QCOMPARE(static_cast<quint8>(packet.at(6)), quint8(0x0C));
        QCOMPARE(static_cast<quint8>(packet.at(7)), quint8(0x0D));
        QCOMPARE(static_cast<quint8>(packet.at(8)), quint8(0x11));
        QCOMPARE(static_cast<quint8>(packet.at(9)), quint8(0x22));
        QCOMPARE(static_cast<quint8>(packet.at(10)), quint8(0x33));
        QCOMPARE(static_cast<quint8>(packet.at(11)), quint8(0x44));
    }

    void roundTrip()
    {
        const QByteArray payload = QByteArray::fromHex("0102030405060708");
        const QByteArray packet = Rtp::build(96, true, 0xBEEF, 0x11223344, 0xCAFEBABE, payload);

        Rtp::Packet parsed;
        QVERIFY(Rtp::parse(packet, 0, packet.size(), parsed));
        QCOMPARE(parsed.payloadType, 96);
        QCOMPARE(parsed.marker, true);
        QCOMPARE(parsed.sequenceNumber, quint16(0xBEEF));
        QCOMPARE(parsed.timestamp, quint32(0x11223344));
        QCOMPARE(parsed.ssrc, quint32(0xCAFEBABE));
        QCOMPARE(parsed.payloadOffset, Rtp::HeaderBytes);
        QCOMPARE(parsed.payloadLength, payload.size());
        QCOMPARE(packet.mid(parsed.payloadOffset, parsed.payloadLength), payload);
    }

    void emptyPayloadIsValid()
    {
        // A zero-length payload is legal and must not be rejected: rejecting it would drop
        // keep-alive-ish packets and desynchronise the loss counter.
        const QByteArray packet = Rtp::build(96, false, 1, 0, 1, QByteArray());
        Rtp::Packet parsed;
        QVERIFY(Rtp::parse(packet, 0, packet.size(), parsed));
        QCOMPARE(parsed.payloadLength, 0);
    }

    void rejectsShortDatagram()
    {
        Rtp::Packet parsed;
        for (int length = 0; length < Rtp::HeaderBytes; ++length) {
            QVERIFY2(!Rtp::parse(QByteArray(length, '\0'), 0, length, parsed),
                qPrintable(QStringLiteral("accepted a %1-byte datagram").arg(length)));
        }
    }

    void rejectsBadVersion()
    {
        QByteArray packet = Rtp::build(96, false, 1, 0, 1, QByteArray("payload"));
        packet[0] = 0x40; // V=1
        Rtp::Packet parsed;
        QVERIFY(!Rtp::parse(packet, 0, packet.size(), parsed));
    }

    void honoursOffsetAndLength()
    {
        // The receive path hands a reused buffer to the parser, so a nonzero offset must work.
        const QByteArray inner = Rtp::build(97, false, 5, 0, 0, QByteArray("abcd"));
        QByteArray framed = QByteArray(7, '\xAA');
        framed.append(inner);
        framed.append(QByteArray(3, '\xBB'));

        Rtp::Packet parsed;
        QVERIFY(Rtp::parse(framed, 7, inner.size(), parsed));
        QCOMPARE(parsed.payloadType, 97);
        QCOMPARE(parsed.payloadLength, 4);
    }

    void sequenceDeltaWrapsAtSixteenBits()
    {
        // The reorder buffer depends on this: 65535 -> 0 is a forward step of one, not a
        // jump of 65535 backwards.
        QCOMPARE(Rtp::sequenceDelta(0, 65535), 1);
        QCOMPARE(Rtp::sequenceDelta(5, 3), 2);
        QCOMPARE(Rtp::sequenceDelta(3, 5), 65534);
    }
};

QTEST_GUILESS_MAIN(TestRtp)
#include "tst_rtp.moc"
