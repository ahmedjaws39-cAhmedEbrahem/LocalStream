#include <QCoreApplication>
#include <QElapsedTimer>
#include <QEventLoop>
#include <QHostAddress>
#include <QSignalSpy>
#include <QThread>
#include <QtTest>
#include <QTcpSocket>

#include <memory>

#include "net/ControlClient.h"
#include "net/ControlServer.h"
#include "protocol/ControlMessage.h"
#include "protocol/LocalStream.h"
#include "testvectors.h"

using namespace localstream::net;
using namespace localstream::protocol;

/**
 * Control channel, end to end over loopback TCP.
 *
 * The server and the client here are the two halves of the same protocol but they were
 * written separately, so a real socket is the only way to catch the failure that matters
 * most: a handshake that appears to succeed while nothing is actually usable afterwards.
 */
class TestControlChannel : public QObject
{
    Q_OBJECT

private:
    static ControlServer::Callbacks defaultCallbacks()
    {
        LocalStream::Description description;
        description.sessionId = QStringLiteral("abcd1234");
        description.displayName = QStringLiteral("Test Broadcaster");
        description.mode = QString::fromLatin1(LocalStream::ModeAudioVideo);
        description.audioPort = 41000;
        description.videoPort = 41001;

        ControlServer::Callbacks callbacks;
        callbacks.description = [description] { return description; };
        callbacks.sdp = [] { return QByteArray("v=0\r\n"); };
        callbacks.audioSsrc = [] { return localstream::testvectors::kAudioSsrc; };
        callbacks.videoSsrc = [] { return localstream::testvectors::kVideoSsrc; };
        return callbacks;
    }

    /// Drives the event loop until @p predicate holds or the budget runs out.
    template<typename Predicate>
    static bool waitFor(Predicate&& predicate, int timeoutMs = 5000)
    {
        QElapsedTimer timer;
        timer.start();
        while (!predicate()) {
            if (timer.elapsed() > timeoutMs) {
                return false;
            }
            QCoreApplication::processEvents(QEventLoop::AllEvents, 20);
            QThread::msleep(1);
        }
        return true;
    }

    /// Reads one newline-terminated line from a raw socket, for the negative tests.
    static QByteArray readLine(QTcpSocket& socket, int timeoutMs = 5000)
    {
        QByteArray buffer;
        QElapsedTimer timer;
        timer.start();
        while (timer.elapsed() < timeoutMs) {
            buffer.append(socket.readAll());
            const int newline = buffer.indexOf('\n');
            if (newline >= 0) {
                return buffer.left(newline);
            }
            QCoreApplication::processEvents(QEventLoop::AllEvents, 20);
            QThread::msleep(1);
        }
        return {};
    }

    static bool writeLine(QTcpSocket& socket, const QByteArray& line)
    {
        if (socket.state() != QAbstractSocket::ConnectedState) {
            return false;
        }
        const QByteArray payload = line + '\n';
        if (socket.write(payload) != payload.size()) {
            return false;
        }
        socket.flush();
        // `waitForBytesWritten` is only a wait, not an assertion: when `write` already handed
        // the data to the OS there is nothing left pending and it returns false for what is
        // actually a success. Loop on `bytesToWrite` so the check means "drained", which is
        // what this helper is for.
        while (socket.bytesToWrite() > 0) {
            if (!socket.waitForBytesWritten(3000)) {
                return false;
            }
        }
        return true;
    }

private slots:
    void serverReportsItsPort()
    {
        ControlServer server;
        server.setCallbacks(defaultCallbacks());
        QString error;
        QVERIFY2(server.listen(&error), qPrintable(error));
        QVERIFY(server.port() > 0);
        server.close();
    }

    void helloAndOfferProduceWelcomeThenAccept()
    {
        ControlServer server;
        auto callbacks = defaultCallbacks();
        QList<QHostAddress> offered;
        callbacks.onOffer = [&offered](const QHostAddress& address, int, int) {
            offered.append(address);
        };
        server.setCallbacks(callbacks);
        QString error;
        QVERIFY2(server.listen(&error), qPrintable(error));

        ControlClient client;
        QSignalSpy handshake(&client, &ControlClient::handshakeSucceeded);
        QSignalSpy failure(&client, &ControlClient::handshakeFailed);

        client.connectToBroadcaster(QStringLiteral("127.0.0.1"), server.port(),
            QStringLiteral("Test Receiver"), 42000, 42001);

        QVERIFY2(waitFor([&] { return handshake.size() == 1 || failure.size() == 1; }),
            "handshake did not complete");
        QCOMPARE(failure.size(), 0);
        QCOMPARE(handshake.size(), 1);

        const auto result = handshake.takeFirst().at(0).value<ControlClient::Handshake>();
        // The accept must carry the broadcaster's ports, not an echo of the offer.
        QCOMPARE(result.audioPort, 41000);
        QCOMPARE(result.videoPort, 41001);
        QCOMPARE(result.audioSsrc, quint32(0x11223344));
        QCOMPARE(result.videoSsrc, quint32(0xAABBCCDD));

        QVERIFY(waitFor([&] { return offered.size() == 1; }));
        QCOMPARE(offered.first(), QHostAddress(QHostAddress::LocalHost));

        client.disconnectFromBroadcaster();
        server.close();
    }

    void welcomeCarriesTheDescription()
    {
        ControlServer server;
        server.setCallbacks(defaultCallbacks());
        QString error;
        QVERIFY(server.listen(&error));

        QTcpSocket socket;
        socket.connectToHost(QStringLiteral("127.0.0.1"), static_cast<quint16>(server.port()));
        QVERIFY(socket.waitForConnected(3000));
        QVERIFY(writeLine(socket, toJsonLine(Hello {LocalStream::ProtocolVersion,
                                  QStringLiteral("receiver"), QStringLiteral("Raw"),
                                  QStringLiteral("test")})));

        const QByteArray welcome = readLine(socket);
        const auto parsed = parse(welcome);
        const auto* message = std::get_if<Welcome>(&parsed);
        QVERIFY2(message, qPrintable(QStringLiteral("expected a welcome, got: %1")
                                         .arg(QString::fromUtf8(welcome))));
        QCOMPARE(message->sessionId, QStringLiteral("abcd1234"));
        QCOMPARE(message->displayName, QStringLiteral("Test Broadcaster"));
        QCOMPARE(message->mode, QString::fromLatin1(LocalStream::ModeAudioVideo));

        socket.abort();
        server.close();
    }

    void versionMismatchIsDeniedWithAnExplanation()
    {
        // A silent disconnect here would be the worst outcome: the user would see a failed
        // connection with no way to tell a version problem from a firewall.
        ControlServer server;
        server.setCallbacks(defaultCallbacks());
        QString error;
        QVERIFY(server.listen(&error));

        QTcpSocket socket;
        socket.connectToHost(QStringLiteral("127.0.0.1"), static_cast<quint16>(server.port()));
        QVERIFY(socket.waitForConnected(3000));
        QVERIFY(writeLine(socket, toJsonLine(Hello {LocalStream::ProtocolVersion + 99,
                                  QStringLiteral("receiver"), QStringLiteral("Future"),
                                  QStringLiteral("test")})));

        const QByteArray denyLine = readLine(socket);
        const auto parsed = parse(denyLine);
        const auto* deny = std::get_if<Deny>(&parsed);
        QVERIFY2(deny, qPrintable(QStringLiteral("expected a deny, got: %1")
                                      .arg(QString::fromUtf8(denyLine))));
        QCOMPARE(deny->code, QString::fromLatin1(deny::Version));
        QVERIFY(!deny->reason.isEmpty());
        QVERIFY(deny->reason.contains(QString::number(LocalStream::ProtocolVersion + 99)));

        socket.abort();
        server.close();
    }

    void capacityIsEnforced()
    {
        ControlServer server;
        server.setCallbacks(defaultCallbacks());
        server.setMaxReceivers(0);
        QString error;
        QVERIFY(server.listen(&error));

        QTcpSocket socket;
        socket.connectToHost(QStringLiteral("127.0.0.1"), static_cast<quint16>(server.port()));
        QVERIFY(socket.waitForConnected(3000));
        QVERIFY(writeLine(socket, toJsonLine(Hello {LocalStream::ProtocolVersion,
                                  QStringLiteral("receiver"), QStringLiteral("One"),
                                  QStringLiteral("test")})));

        const QByteArray denyLine = readLine(socket);
        const ControlMessage deny_msg = parse(denyLine);
            const auto* deny = std::get_if<Deny>(&deny_msg);
        QVERIFY2(deny, qPrintable(QStringLiteral("expected a deny, got: %1")
                                      .arg(QString::fromUtf8(denyLine))));
        QCOMPARE(deny->code, QString::fromLatin1(deny::Capacity));

        socket.abort();
        server.close();
    }

    // A socket is accepted before its `hello` is read, so a bare TCP connect -- a port scan, or
    // a client that stalls mid-handshake -- must not be reported as a receiver or consume a
    // capacity slot. Counting the session list instead did both.
    void ungreetedConnectionIsNotAReceiver()
    {
        ControlServer server;
        server.setCallbacks(defaultCallbacks());
        server.setMaxReceivers(1);
        QString error;
        QVERIFY(server.listen(&error));

        QTcpSocket idle;
        idle.connectToHost(QStringLiteral("127.0.0.1"), static_cast<quint16>(server.port()));
        QVERIFY(idle.waitForConnected(3000));
        QTest::qWait(100);
        QCOMPARE(server.receiverCount(), 0);

        // With the idle socket still connected, a real receiver must fit in the single slot,
        // which it only can if the idle one is not counted.
        QTcpSocket socket;
        socket.connectToHost(QStringLiteral("127.0.0.1"), static_cast<quint16>(server.port()));
        QVERIFY(socket.waitForConnected(3000));
        QVERIFY(writeLine(socket, toJsonLine(Hello {LocalStream::ProtocolVersion,
                                  QStringLiteral("receiver"), QStringLiteral("One"),
                                  QStringLiteral("test")})));
        QVERIFY(!readLine(socket).isEmpty()); // welcome, so the greeting was accepted
        QTRY_COMPARE(server.receiverCount(), 1);

        idle.abort();
        socket.abort();
        server.close();
    }

    void offerIsAnsweredWithTheBroadcastersPorts()
    {
        ControlServer server;
        server.setCallbacks(defaultCallbacks());
        QString error;
        QVERIFY(server.listen(&error));

        QTcpSocket socket;
        socket.connectToHost(QStringLiteral("127.0.0.1"), static_cast<quint16>(server.port()));
        QVERIFY(socket.waitForConnected(3000));
        QVERIFY(writeLine(socket, toJsonLine(Hello {LocalStream::ProtocolVersion,
                                  QStringLiteral("receiver"), QStringLiteral("Raw"),
                                  QStringLiteral("test")})));
        QVERIFY(!readLine(socket).isEmpty()); // welcome

        // The receiver offers its own ports; the accept must not echo them back.
        QVERIFY(writeLine(socket, toJsonLine(Offer {QStringLiteral("abcd1234"), 42000, 42001})));

        const QByteArray acceptLine = readLine(socket);
        const ControlMessage accept_msg = parse(acceptLine);
            const auto* accept = std::get_if<Accept>(&accept_msg);
        QVERIFY2(accept, qPrintable(QStringLiteral("expected an accept, got: %1")
                                        .arg(QString::fromUtf8(acceptLine))));
        QCOMPARE(accept->audioPort, 41000);
        QCOMPARE(accept->videoPort, 41001);
        QCOMPARE(accept->audioSsrc, quint32(0x11223344));
        QCOMPARE(accept->videoSsrc, quint32(0xAABBCCDD));

        socket.abort();
        server.close();
    }

    void modeRequestIsAnsweredWithTheAuthoritativeMode()
    {
        ControlServer server;
        auto callbacks = defaultCallbacks();
        QString requested;
        callbacks.onModeRequest = [&requested](const QString& mode) { requested = mode; };
        server.setCallbacks(callbacks);
        QString error;
        QVERIFY(server.listen(&error));

        QTcpSocket socket;
        socket.connectToHost(QStringLiteral("127.0.0.1"), static_cast<quint16>(server.port()));
        QVERIFY(socket.waitForConnected(3000));
        QVERIFY(writeLine(socket, toJsonLine(Hello {LocalStream::ProtocolVersion,
                                  QStringLiteral("receiver"), QStringLiteral("Raw"),
                                  QStringLiteral("test")})));
        QVERIFY(!readLine(socket).isEmpty());

        QVERIFY(writeLine(socket, toJsonLine(ModeRequest {QStringLiteral("a")})));

        // The request is relayed to the engine...
        QVERIFY(waitFor([&] { return !requested.isEmpty(); }));
        QCOMPARE(requested, QStringLiteral("a"));
        // ...and answered, so a refused request is never silent.
        const QByteArray answer = readLine(socket);
        const ControlMessage changed_msg = parse(answer);
            const auto* changed = std::get_if<ModeChanged>(&changed_msg);
        QVERIFY2(changed, qPrintable(QStringLiteral("expected a mode answer, got: %1")
                                         .arg(QString::fromUtf8(answer))));
        // The server's own mode has not changed, so the answer is still "av".
        QCOMPARE(changed->mode, QString::fromLatin1(LocalStream::ModeAudioVideo));

        socket.abort();
        server.close();
    }

    void clientAppliesAnAuthoritativeModeChange()
    {
        // The regression this guards: post-handshake messages must reach the UI layer. When
        // they were left unread the buffer filled, the reader blocked, and the receiver never
        // learned the broadcast had switched to audio only.
        ControlServer server;
        server.setCallbacks(defaultCallbacks());
        QString error;
        QVERIFY(server.listen(&error));

        ControlClient client;
        QSignalSpy handshake(&client, &ControlClient::handshakeSucceeded);
        QSignalSpy modeSpy(&client, &ControlClient::modeChanged);
        client.connectToBroadcaster(QStringLiteral("127.0.0.1"), server.port(),
            QStringLiteral("Test Receiver"), 42000, 42001);

        QVERIFY(waitFor([&] { return handshake.size() == 1; }));
        QCOMPARE(client.mode(), QString::fromLatin1(LocalStream::ModeAudioVideo));

        server.sendModeChanged(QString::fromLatin1(LocalStream::ModeAudioOnly));

        QVERIFY2(waitFor([&] { return modeSpy.size() == 1; }),
            "the client ignored the broadcaster's mode change");
        QCOMPARE(modeSpy.takeFirst().at(0).toString(),
            QString::fromLatin1(LocalStream::ModeAudioOnly));
        QCOMPARE(client.mode(), QString::fromLatin1(LocalStream::ModeAudioOnly));

        client.disconnectFromBroadcaster();
        server.close();
    }

    void clientReceivesBroadcasterStats()
    {
        ControlServer server;
        server.setCallbacks(defaultCallbacks());
        QString error;
        QVERIFY(server.listen(&error));

        ControlClient client;
        QSignalSpy handshake(&client, &ControlClient::handshakeSucceeded);
        QSignalSpy statsSpy(&client, &ControlClient::broadcasterStatsReceived);
        client.connectToBroadcaster(QStringLiteral("127.0.0.1"), server.port(),
            QStringLiteral("Test Receiver"), 42000, 42001);
        QVERIFY(waitFor([&] { return handshake.size() == 1; }));

        server.sendStats(BroadcasterStats {30, 1500, 0.5, 2, 7});

        QVERIFY(waitFor([&] { return statsSpy.size() == 1; }));
        const auto stats = statsSpy.takeFirst().at(0).value<BroadcasterStats>();
        QCOMPARE(stats.framesPerSecond, 30);
        QCOMPARE(stats.kilobitsPerSecond, 1500);
        QCOMPARE(stats.receiverCount, 2);

        client.disconnectFromBroadcaster();
        server.close();
    }

    void clientSendsKeyframeAndStatsRequests()
    {
        ControlServer server;
        auto callbacks = defaultCallbacks();
        int keyframes = 0;
        QList<ReceiverStats> received;
        callbacks.onKeyframeRequest = [&keyframes] { ++keyframes; };
        callbacks.onReceiverStats = [&received](const ReceiverStats& s) { received.append(s); };
        server.setCallbacks(callbacks);
        QString error;
        QVERIFY(server.listen(&error));

        ControlClient client;
        QSignalSpy handshake(&client, &ControlClient::handshakeSucceeded);
        client.connectToBroadcaster(QStringLiteral("127.0.0.1"), server.port(),
            QStringLiteral("Test Receiver"), 42000, 42001);
        QVERIFY(waitFor([&] { return handshake.size() == 1; }));

        client.requestKeyframe();
        QVERIFY2(waitFor([&] { return keyframes == 1; }), "no keyframe request reached the server");

        client.sendStats(ReceiverStats {120, 2, 3.5, 1});
        QVERIFY(waitFor([&] { return received.size() == 1; }));
        QCOMPARE(received.first().packets, quint64(120));
        QCOMPARE(received.first().lost, quint64(2));

        client.disconnectFromBroadcaster();
        server.close();
    }

    void byeIsDeliveredBeforeTheSocketCloses()
    {
        // The whole reason the write path is buffered: a `bye` written and immediately closed
        // is truncated, and the receiver reports a bare disconnect instead of a reason.
        ControlServer server;
        server.setCallbacks(defaultCallbacks());
        QString error;
        QVERIFY(server.listen(&error));

        QTcpSocket socket;
        socket.connectToHost(QStringLiteral("127.0.0.1"), static_cast<quint16>(server.port()));
        QVERIFY(socket.waitForConnected(3000));
        QVERIFY(writeLine(socket, toJsonLine(Hello {LocalStream::ProtocolVersion,
                                  QStringLiteral("receiver"), QStringLiteral("Raw"),
                                  QStringLiteral("test")})));
        QVERIFY(!readLine(socket).isEmpty());

        server.closeAll(QString::fromLatin1(bye::Shutdown));

        const QByteArray byeLine = readLine(socket);
        const ControlMessage bye_msg = parse(byeLine);
            const auto* bye = std::get_if<Bye>(&bye_msg);
        QVERIFY2(bye, qPrintable(QStringLiteral("expected a bye, got: %1")
                                     .arg(QString::fromUtf8(byeLine))));
        QCOMPARE(bye->reason, QString::fromLatin1(bye::Shutdown));

        socket.abort();
        server.close();
    }

    void serverWithdrawsTheTargetWhenAReceiverLeaves()
    {
        ControlServer server;
        auto callbacks = defaultCallbacks();
        int offers = 0;
        int removes = 0;
        callbacks.onOffer = [&offers](const QHostAddress&, int, int) { ++offers; };
        callbacks.onRemove = [&removes](const QHostAddress&, int, int) { ++removes; };
        server.setCallbacks(callbacks);
        QString error;
        QVERIFY(server.listen(&error));

        QTcpSocket socket;
        socket.connectToHost(QStringLiteral("127.0.0.1"), static_cast<quint16>(server.port()));
        QVERIFY(socket.waitForConnected(3000));
        QVERIFY(writeLine(socket, toJsonLine(Hello {LocalStream::ProtocolVersion,
                                  QStringLiteral("receiver"), QStringLiteral("Leaver"),
                                  QStringLiteral("test")})));
        QVERIFY(!readLine(socket).isEmpty());
        QVERIFY(writeLine(socket, toJsonLine(Offer {QStringLiteral("abcd1234"), 42000, 42001})));
        QVERIFY(!readLine(socket).isEmpty());
        QVERIFY(waitFor([&] { return offers == 1; }));
        QCOMPARE(server.receiverCount(), 1);

        // Drop the connection without a `bye`, the way a phone leaving Wi-Fi does.
        socket.abort();
        QVERIFY2(waitFor([&] { return removes == 1; }),
            "an abruptly dropped receiver must still have its RTP target withdrawn");
        QCOMPARE(server.receiverCount(), 0);

        server.close();
    }

    void clientReportsARejection()
    {
        ControlServer server;
        server.setCallbacks(defaultCallbacks());
        server.setMaxReceivers(0);
        QString error;
        QVERIFY(server.listen(&error));

        ControlClient client;
        QSignalSpy failure(&client, &ControlClient::handshakeFailed);
        client.connectToBroadcaster(QStringLiteral("127.0.0.1"), server.port(),
            QStringLiteral("Test Receiver"), 42000, 42001);

        QVERIFY2(waitFor([&] { return failure.size() >= 1; }), "the client never reported a refusal");
        QVERIFY(!failure.takeFirst().at(0).toString().isEmpty());

        client.disconnectFromBroadcaster();
        server.close();
    }

    void clientReportsAnUnreachableHost()
    {
        ControlClient client;
        QSignalSpy failure(&client, &ControlClient::handshakeFailed);
        // Port 1 on loopback: reliably refused, unlike a timeout which would be slow.
        client.connectToBroadcaster(QStringLiteral("127.0.0.1"), 1,
            QStringLiteral("Test Receiver"), 42000, 42001);

        QVERIFY2(waitFor([&] { return failure.size() >= 1; }, 8000),
            "connecting to a closed port must fail rather than hang");
        client.disconnectFromBroadcaster();
    }

    // ------------------------------------------------------------------ access

    /// Sends `hello` and returns the session id from the `welcome`, for the raw-socket tests.
    static QString greet(QTcpSocket& socket)
    {
        if (!socket.waitForConnected(3000)) {
            return {};
        }
        writeLine(socket, toJsonLine(Hello {LocalStream::ProtocolVersion,
            QStringLiteral("receiver"), QStringLiteral("Raw"), QStringLiteral("test")}));
        const auto parsed = parse(readLine(socket));
        const auto* welcome = std::get_if<Welcome>(&parsed);
        return welcome ? welcome->sessionId : QString{};
    }

    void welcomeAdvertisesTheAccessMode()
    {
        ControlServer server;
        server.setCallbacks(defaultCallbacks());
        server.setAccessMode(QString::fromLatin1(access::Approval));
        QString error;
        QVERIFY(server.listen(&error));

        QTcpSocket socket;
        socket.connectToHost(QStringLiteral("127.0.0.1"), static_cast<quint16>(server.port()));
        QVERIFY(socket.waitForConnected(3000));
        QVERIFY(writeLine(socket, toJsonLine(Hello {LocalStream::ProtocolVersion,
            QStringLiteral("receiver"), QStringLiteral("Raw"), QStringLiteral("test")})));

        const auto parsed = parse(readLine(socket));
        const auto* welcome = std::get_if<Welcome>(&parsed);
        QVERIFY(welcome);
        QCOMPARE(welcome->access, QString::fromLatin1(access::Approval));

        socket.abort();
        server.close();
    }

    void publicBroadcastOmitsTheAccessField()
    {
        // The field is absent for the default mode on purpose, and an absent field has to parse
        // as public: that is the whole compatibility story for a viewer talking to a broadcaster
        // that has never heard of access control.
        const QByteArray line = toJsonLine(Welcome {LocalStream::ProtocolVersion,
            QStringLiteral("abcd1234"), QString::fromLatin1(LocalStream::ModeAudioVideo),
            QStringLiteral("Test"), QByteArray("v=0\r\n")});
        QVERIFY(!line.contains("access"));
        QCOMPARE(std::get<Welcome>(parse(line)).access, QString::fromLatin1(access::Public));
    }

    void passwordBroadcastRefusesAnOfferWithoutAuthentication()
    {
        ControlServer server;
        server.setCallbacks(defaultCallbacks());
        server.setAccessMode(QString::fromLatin1(access::Password));
        server.setAccessPassword(QStringLiteral("hunter2"));
        QString error;
        QVERIFY(server.listen(&error));

        QTcpSocket socket;
        socket.connectToHost(QStringLiteral("127.0.0.1"), static_cast<quint16>(server.port()));
        const QString session = greet(socket);
        QVERIFY(!session.isEmpty());

        QVERIFY(writeLine(socket, toJsonLine(Offer {session, 42000, 42001})));
        const auto parsed = parse(readLine(socket));
        const auto* deny = std::get_if<Deny>(&parsed);
        QVERIFY2(deny, "a skipped password must not be admitted by omission");
        QCOMPARE(deny->code, QString::fromLatin1(deny::Auth));

        socket.abort();
        server.close();
    }

    void theRightPasswordIsAcceptedAndAWrongOneIsNot()
    {
        // The offered list is shared with the callback rather than re-registered after listen():
        // the core copies its callbacks when it is built, so a later setCallbacks() would look
        // like it worked and change nothing.
        auto offered = std::make_shared<QList<QHostAddress>>();
        auto callbacks = defaultCallbacks();
        callbacks.onOffer = [offered](const QHostAddress& address, int, int) {
            offered->append(address);
        };

        ControlServer server;
        server.setCallbacks(callbacks);
        server.setAccessMode(QString::fromLatin1(access::Password));
        server.setAccessPassword(QStringLiteral("hunter2"));
        QString error;
        QVERIFY(server.listen(&error));

        // Wrong first: the session must survive so the viewer can retype, which is the whole
        // reason the socket is not closed here.
        QTcpSocket socket;
        socket.connectToHost(QStringLiteral("127.0.0.1"), static_cast<quint16>(server.port()));
        const QString session = greet(socket);
        QVERIFY(!session.isEmpty());
        QVERIFY(writeLine(socket, toJsonLine(AuthRequest {session, QStringLiteral("wrong")})));
        auto parsed = parse(readLine(socket));
        const auto* refused = std::get_if<AuthResult>(&parsed);
        QVERIFY(refused);
        QVERIFY(!refused->granted);
        QCOMPARE(socket.state(), QAbstractSocket::ConnectedState);

        QVERIFY(writeLine(socket, toJsonLine(AuthRequest {session, QStringLiteral("hunter2")})));
        parsed = parse(readLine(socket));
        const auto* granted = std::get_if<AuthResult>(&parsed);
        QVERIFY(granted);
        QVERIFY(granted->granted);

        // Only now does the offer work.
        QVERIFY(writeLine(socket, toJsonLine(Offer {session, 42000, 42001})));
        QVERIFY2(waitFor([&] { return offered->size() == 1; }),
            "a correct password did not admit the viewer");

        socket.abort();
        server.close();
    }

    void approvalHoldsTheOfferUntilTheAnswer()
    {
        auto offered = std::make_shared<QList<QHostAddress>>();
        auto requests = std::make_shared<QList<QPair<quint64, QString>>>();
        auto callbacks = defaultCallbacks();
        callbacks.onOffer = [offered](const QHostAddress& address, int, int) {
            offered->append(address);
        };
        callbacks.onAccessRequest = [requests](quint64 key, const QString& name) {
            requests->append({key, name});
        };

        ControlServer server;
        server.setCallbacks(callbacks);
        server.setAccessMode(QString::fromLatin1(access::Approval));
        QString error;
        QVERIFY(server.listen(&error));

        QTcpSocket socket;
        socket.connectToHost(QStringLiteral("127.0.0.1"), static_cast<quint16>(server.port()));
        const QString session = greet(socket);
        QVERIFY(!session.isEmpty());
        QVERIFY(writeLine(socket, toJsonLine(Offer {session, 42000, 42001})));

        // Nothing is admitted while the prompt is open. The absence of an `accept` is the point:
        // a broadcast that published the ports before the answer would already be streaming.
        QVERIFY2(waitFor([&] { return requests->size() == 1; }), "no prompt was raised");
        QCOMPARE(requests->first().first, quint64(1));
        QCOMPARE(requests->first().second, QStringLiteral("Raw"));
        QVERIFY2(waitFor([&] { return offered->isEmpty(); }, 400),
            "the offer was admitted before anyone answered");

        server.resolveAccessRequest(requests->first().first, true);
        QVERIFY2(waitFor([&] { return offered->size() == 1; }), "an allowed viewer was not admitted");

        socket.abort();
        server.close();
    }

    void approvalIsRecheckedWhenTheModeChangesWhileThePromptIsOpen()
    {
        // The case that makes a live mode change worth having: a password is set while a viewer
        // is waiting for approval, and then the presenter presses Allow. Allowing must not walk
        // past the password - the viewer has not entered one.
        auto requests = std::make_shared<QList<quint64>>();
        auto callbacks = defaultCallbacks();
        callbacks.onAccessRequest = [requests](quint64 key, const QString&) {
            requests->append(key);
        };

        ControlServer server;
        server.setCallbacks(callbacks);
        server.setAccessMode(QString::fromLatin1(access::Approval));
        QString error;
        QVERIFY(server.listen(&error));

        QTcpSocket socket;
        socket.connectToHost(QStringLiteral("127.0.0.1"), static_cast<quint16>(server.port()));
        const QString session = greet(socket);
        QVERIFY(writeLine(socket, toJsonLine(Offer {session, 42000, 42001})));
        QVERIFY(waitFor([&] { return requests->size() == 1; }));

        server.setAccessMode(QString::fromLatin1(access::Password));
        server.setAccessPassword(QStringLiteral("hunter2"));
        server.resolveAccessRequest(requests->first(), true);

        const auto parsed = parse(readLine(socket));
        const auto* deny = std::get_if<Deny>(&parsed);
        QVERIFY2(deny, "the viewer was admitted without the password that was just set");
        QCOMPARE(deny->code, QString::fromLatin1(deny::Auth));

        socket.abort();
        server.close();
    }

    /// One request-and-reject cycle from loopback. Returns the request key, or 0 if the broadcaster
/// never asked. Reads the refusal so each cycle proves it was counted.
    quint64 requestAndReject(ControlServer& server, std::shared_ptr<QList<quint64>>& requests)
    {
        requests->clear();
        QTcpSocket socket;
        socket.connectToHost(QStringLiteral("127.0.0.1"), static_cast<quint16>(server.port()));
        const QString session = greet(socket);
        if (session.isEmpty() || !writeLine(socket, toJsonLine(Offer {session, 42000, 42001}))) {
            return 0;
        }
        if (!waitFor([&] { return requests->size() == 1; })) {
            return 0;
        }
        const quint64 key = requests->first();
        server.resolveAccessRequest(key, false);
        const auto parsed = parse(readLine(socket));
        const auto* deny = std::get_if<Deny>(&parsed);
        Q_ASSERT(deny);
        socket.abort();
        QTest::qWait(150);
        return key;
    }

    void threeRejectionsBanTheViewer()
    {
        auto requests = std::make_shared<QList<quint64>>();
        auto callbacks = defaultCallbacks();
        callbacks.onAccessRequest = [requests](quint64 key, const QString&) {
            requests->append(key);
        };

        ControlServer server;
        server.setCallbacks(callbacks);
        server.setAccessMode(QString::fromLatin1(access::Approval));
        QString error;
        QVERIFY(server.listen(&error));

        // Loopback is one address, which is exactly the point: the tally is per peer, and three
        // rejections from one peer have to end in a ban rather than a fourth prompt.
        for (int attempt = 0; attempt < 3; ++attempt) {
            QVERIFY2(requestAndReject(server, requests) != 0,
                qPrintable(QStringLiteral("rejection %1 was never asked about").arg(attempt + 1)));
        }

        // The fourth is refused outright, with no prompt at all.
        requests->clear();
        QTcpSocket socket;
        socket.connectToHost(QStringLiteral("127.0.0.1"), static_cast<quint16>(server.port()));
        const QString session = greet(socket);
        QVERIFY(!session.isEmpty());
        QVERIFY(writeLine(socket, toJsonLine(Offer {session, 42000, 42001})));
        const QByteArray raw = readLine(socket);
        const auto parsed = parse(raw);
        const auto* deny = std::get_if<Deny>(&parsed);
        QVERIFY2(deny, qPrintable(QStringLiteral("a barred viewer was not refused; got: %1")
                                      .arg(QString::fromUtf8(raw))));
        QCOMPARE(deny->code, QString::fromLatin1(deny::Blocked));
        QVERIFY2(waitFor([&] { return requests->isEmpty(); }, 400),
            "a barred viewer still raised a prompt");

        socket.abort();
        server.close();
    }

    void clearingTheHistoryUnbansTheViewer()
    {
        auto requests = std::make_shared<QList<quint64>>();
        auto callbacks = defaultCallbacks();
        callbacks.onAccessRequest = [requests](quint64 key, const QString&) {
            requests->append(key);
        };

        ControlServer server;
        server.setCallbacks(callbacks);
        server.setAccessMode(QString::fromLatin1(access::Approval));
        QString error;
        QVERIFY(server.listen(&error));

        for (int attempt = 0; attempt < 3; ++attempt) {
            QVERIFY(requestAndReject(server, requests) != 0);
        }

        // Banned now.
        requests->clear();
        QTcpSocket banned;
        banned.connectToHost(QStringLiteral("127.0.0.1"), static_cast<quint16>(server.port()));
        const QString bannedSession = greet(banned);
        QVERIFY(writeLine(banned, toJsonLine(Offer {bannedSession, 42000, 42001})));
        const auto blocked = parse(readLine(banned));
        const auto* blockedDeny = std::get_if<Deny>(&blocked);
        QVERIFY(blockedDeny);
        QCOMPARE(blockedDeny->code, QString::fromLatin1(deny::Blocked));
        banned.abort();

        // A rejection belongs to the broadcast, not to the app: stopping and starting again
        // must not carry the tally over.
        server.clearAccessHistory();
        server.close();
        QVERIFY(server.listen(&error));

        QTcpSocket fresh;
        fresh.connectToHost(QStringLiteral("127.0.0.1"), static_cast<quint16>(server.port()));
        const QString freshSession = greet(fresh);
        QVERIFY(writeLine(fresh, toJsonLine(Offer {freshSession, 42000, 42001})));
        QVERIFY2(waitFor([&] { return requests->size() == 1; }),
            "a cleared history should have prompted again");

        fresh.abort();
        server.close();
    }

    void aViewerWhoHangsUpWhileWaitingIsNotCountedAsARejection()
    {
        // A rejection is a decision. A viewer who closes the app, or loses the network, has not
        // been turned down and must not spend one of three tries.
        auto requests = std::make_shared<QList<quint64>>();
        auto callbacks = defaultCallbacks();
        callbacks.onAccessRequest = [requests](quint64 key, const QString&) {
            requests->append(key);
        };

        ControlServer server;
        server.setCallbacks(callbacks);
        server.setAccessMode(QString::fromLatin1(access::Approval));
        QString error;
        QVERIFY(server.listen(&error));

        for (int attempt = 0; attempt < 4; ++attempt) {
            requests->clear();
            QTcpSocket socket;
            socket.connectToHost(QStringLiteral("127.0.0.1"), static_cast<quint16>(server.port()));
            const QString session = greet(socket);
            QVERIFY(writeLine(socket, toJsonLine(Offer {session, 42000, 42001})));
            QVERIFY2(waitFor([&] { return requests->size() == 1; }),
                "hanging up spent a rejection, so the prompt stopped coming");
            socket.abort();
            QTest::qWait(150);
        }

        server.close();
    }

    void aViewerBlockedByTheClientSeesOneMessageAndNoRetryOffer()
    {
        // The client must not raise both a handshake failure and a ban for one refusal: the
        // second dialog would sit on top of the answer to the question the viewer asked.
        auto requests = std::make_shared<QList<quint64>>();
        auto callbacks = defaultCallbacks();
        callbacks.onAccessRequest = [requests](quint64 key, const QString&) {
            requests->append(key);
        };

        ControlServer server;
        server.setCallbacks(callbacks);
        server.setAccessMode(QString::fromLatin1(access::Approval));
        QString error;
        QVERIFY(server.listen(&error));

        for (int attempt = 0; attempt < 3; ++attempt) {
            QVERIFY(requestAndReject(server, requests) != 0);
        }

        ControlClient client;
        QSignalSpy failure(&client, &ControlClient::handshakeFailed);
        QSignalSpy states(&client, &ControlClient::stateChanged);
        client.connectToBroadcaster(QStringLiteral("127.0.0.1"), server.port(),
            QStringLiteral("Test Receiver"), 42000, 42001);

        QVERIFY2(waitFor([&] {
            for (const QList<QVariant>& call : states) {
                if (call.at(0).value<ControlClient::State>() == ControlClient::State::Blocked) {
                    return true;
                }
            }
            return false;
        }, 8000), "the client never reached the blocked state");
        QCOMPARE(failure.size(), 0);
        QVERIFY(!ControlClient::blockedMessage().isEmpty());

        client.disconnectFromBroadcaster();
        server.close();
    }

    void partialLinesAreBufferedUntilComplete()
    {
        // Newline framing: a message split across TCP segments must still parse. Treating the
        // first fragment as a whole line would drop the `hello` whenever it did not arrive in
        // one segment, which on a busy Wi-Fi is most of the time.
        ControlServer server;
        server.setCallbacks(defaultCallbacks());
        QString error;
        QVERIFY(server.listen(&error));

        QTcpSocket socket;
        socket.connectToHost(QStringLiteral("127.0.0.1"), static_cast<quint16>(server.port()));
        QVERIFY(socket.waitForConnected(3000));

        const QByteArray hello = toJsonLine(Hello {LocalStream::ProtocolVersion,
            QStringLiteral("receiver"), QStringLiteral("Split"), QStringLiteral("test")});
        socket.write(hello.left(5));
        socket.flush();
        QCoreApplication::processEvents(QEventLoop::AllEvents, 50);

        socket.write(hello.mid(5) + "\n");
        socket.flush();

        const QByteArray welcome = readLine(socket);
        QVERIFY2(!welcome.isEmpty(), "a split hello was not reassembled");
        QVERIFY(std::holds_alternative<Welcome>(parse(welcome)));

        socket.abort();
        server.close();
    }

    void unknownMessagesDoNotDisturbTheSession()
    {
        ControlServer server;
        server.setCallbacks(defaultCallbacks());
        QString error;
        QVERIFY(server.listen(&error));

        QTcpSocket socket;
        socket.connectToHost(QStringLiteral("127.0.0.1"), static_cast<quint16>(server.port()));
        QVERIFY(socket.waitForConnected(3000));
        QVERIFY(writeLine(socket, toJsonLine(Hello {LocalStream::ProtocolVersion,
                                  QStringLiteral("receiver"), QStringLiteral("Chatty"),
                                  QStringLiteral("test")})));
        QVERIFY(!readLine(socket).isEmpty());

        // Forward compatibility: a message type this build has never heard of must be ignored,
        // not treated as a protocol violation.
        QVERIFY(writeLine(socket, R"({"t":"teleport","where":"elsewhere"})"));
        QVERIFY(writeLine(socket, "not even json"));

        // The session must still work afterwards.
        QVERIFY(writeLine(socket, toJsonLine(Offer {QStringLiteral("abcd1234"), 42000, 42001})));
        const QByteArray accept = readLine(socket);
        QVERIFY2(std::holds_alternative<Accept>(parse(accept)),
            "an unknown message type broke the session");

        socket.abort();
        server.close();
    }
};

QTEST_GUILESS_MAIN(TestControlChannel)
#include "tst_controlchannel.moc"
