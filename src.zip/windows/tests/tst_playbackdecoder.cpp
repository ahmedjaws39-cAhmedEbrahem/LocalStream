#include <QtTest>

#include <QMutex>
#include <QSemaphore>
#include <QThread>

#include <atomic>

#include "capture/Encoders.h"
#include "engine/PlaybackDecoder.h"
#include "protocol/H264Rtp.h"

using localstream::capture::EncodedVideo;
using localstream::capture::VideoEncoder;
using localstream::engine::PlaybackDecoder;

/**
 * Tests for the decode thread itself, rather than for the picture that comes out of it.
 *
 * The pipeline test already proves a real broadcast decodes end to end. What it cannot prove is
 * the property that is easy to lose in a refactor and impossible to notice from the outside: that
 * decoding happens on its own thread, and that stopping and restarting leaves nothing latched.
 * Both fail silently -- the first as a UI that stutters under load, the second as a picture that
 * freezes after a reconnect -- so they are asserted here directly.
 */
class PlaybackDecoderTest : public QObject
{
    Q_OBJECT

private slots:
    void decodesAKeyframeOnItsOwnThread();
    void ignoresAccessUnitsBeforeParameterSets();
    void survivesStopMidStream();
    void restartsAfterStop();
    void keepsOnlyTheNewestFrameWhileBusy();
    void decodesColoursInsteadOfSwappingOrDroppingThem();
};

namespace {

constexpr int Width = 320;
constexpr int Height = 240;

/// A moving gradient rather than a flat colour: a flat field compresses to almost nothing and
/// would let a broken path still hand the decoder something plausible.
QByteArray testPattern()
{
    QByteArray buffer(static_cast<qsizetype>(Width) * Height * 4, Qt::Uninitialized);
    auto* out = reinterpret_cast<uchar*>(buffer.data());
    for (int y = 0; y < Height; ++y) {
        auto* line = reinterpret_cast<quint32*>(out + static_cast<qsizetype>(y) * Width * 4);
        for (int x = 0; x < Width; ++x) {
            const int r = (x * 255) / qMax(1, Width - 1);
            const int g = (y * 255) / qMax(1, Height - 1);
            const int b = ((x * y) * 255) / qMax(1, Width * Height - 1);
            // True BGRA memory order: byte 0 is blue, byte 2 is red.
            line[x] = (static_cast<quint32>(0xFF) << 24) | (static_cast<quint32>(r) << 16)
                | (static_cast<quint32>(g) << 8) | static_cast<quint32>(b);
        }
    }
    return buffer;
}

/// A flat field of one colour, in the BGRA byte order a Windows capture device delivers.
///
/// Unlike testPattern() this is deliberately written with the true BGRA memory layout
/// (byte 0 = blue, byte 1 = green, byte 2 = red), so a channel swap anywhere in the
/// encode/decode path shows up as a wrong pixel rather than cancelling out.
QByteArray solidBgra(int width, int height, int r, int g, int b)
{
    QByteArray buffer(static_cast<qsizetype>(width) * height * 4, Qt::Uninitialized);
    auto* out = reinterpret_cast<quint32*>(buffer.data());
    const quint32 pixel = (static_cast<quint32>(0xFF) << 24) | (static_cast<quint32>(r) << 16)
        | (static_cast<quint32>(g) << 8) | static_cast<quint32>(b);
    for (qsizetype i = 0; i < static_cast<qsizetype>(width) * height; ++i) {
        out[i] = pixel;
    }
    return buffer;
}

localstream::capture::VideoSample makeSample(
    const QByteArray& bgra, qint64 index, int width = Width, int height = Height)
{
    localstream::capture::VideoSample sample;
    sample.width = width;
    sample.height = height;
    sample.format = AV_PIX_FMT_BGRA;
    sample.ptsMicros = index * (1000000 / 30);
    sample.linesize = width * 4;
    sample.data = bgra;
    return sample;
}

/**
 * Turns an encoder access unit into what the decoder is handed.
 *
 * The encoder emits AVCC; the receiver's depacketiser emits Annex B, and PlaybackDecoder's
 * contract is Annex B. Going through the NAL list rather than prefixing the whole unit keeps the
 * length prefixes out, which is the mistake that produces a decoder that never emits a frame.
 */
QByteArray toAnnexB(const QByteArray& avcc)
{
    static constexpr char StartCode[4] = { '\0', '\0', '\0', '\1' };
    QByteArray annexB;
    const QList<QByteArray> nals = localstream::protocol::h264::splitAvcc(avcc);
    for (const QByteArray& nal : nals) {
        annexB.append(StartCode, 4);
        annexB.append(nal);
    }
    return annexB;
}

/// Drives an encoder and submits everything it produces, the way the receiver would.
///
/// Asks for a keyframe first, so every batch is self-contained. Without it a batch that follows a
/// flush contains no IDR at all, and a decoder handed only P-frames correctly produces nothing --
/// which would make these tests fail for a reason that has nothing to do with the decoder.
void pumpEncoder(VideoEncoder& encoder, PlaybackDecoder& decoder, int frames)
{
    const QByteArray pattern = testPattern();
    encoder.requestKeyframe();
    for (int i = 0; i < frames; ++i) {
        encoder.encode(makeSample(pattern, i), [&](const EncodedVideo& encoded) {
            decoder.submit(toAnnexB(encoded.accessUnit), encoder.sps(), encoder.pps());
        });
    }
    encoder.flush([&](const EncodedVideo& encoded) {
        decoder.submit(toAnnexB(encoded.accessUnit), encoder.sps(), encoder.pps());
    });
}

} // namespace

void PlaybackDecoderTest::decodesAKeyframeOnItsOwnThread()
{
    VideoEncoder encoder(Width, Height, 30, 500);
    QVERIFY(encoder.isOpen());

    PlaybackDecoder decoder;
    std::atomic<int> frames {0};
    std::atomic<bool> offCallerThread {false};
    // Recorded from the decode thread and read here, so it has to be atomic: a plain bool read
    // across threads is exactly the kind of thing that makes this test lie on one run and pass on
    // the next.
    const QThread* callerThread = QThread::currentThread();

    QVERIFY(decoder.start(
        [&](const QImage& image) {
            if (!image.isNull()) {
                frames.fetch_add(1);
            }
            if (QThread::currentThread() != callerThread) {
                offCallerThread.store(true);
            }
        },
        [](const QString&) {}));

    pumpEncoder(encoder, decoder, 20);
    QTRY_VERIFY_WITH_TIMEOUT(frames.load() > 0, 5000);

    QVERIFY2(offCallerThread.load(),
        "decoding ran on the caller's thread, so a slow frame would stall whatever called submit()");

    // The whole point of moving libav off the caller: submit() returns while the decoder is still
    // working, rather than decoding inline.
    decoder.stop();
}

void PlaybackDecoderTest::ignoresAccessUnitsBeforeParameterSets()
{
    // One encoder per phase, and not out of tidiness: VideoEncoder::flush() signals end of stream
    // with a null frame, so the context is at EOF afterwards and encodes into it yield nothing.
    // Sharing one encoder across the two phases would test the encoder, not the decoder.
    VideoEncoder head(Width, Height, 30, 500);
    QVERIFY(head.isOpen());

    const QByteArray pattern = testPattern();
    QByteArray firstUnit;
    head.encode(makeSample(pattern, 0), [&](const EncodedVideo& encoded) {
        firstUnit = toAnnexB(encoded.accessUnit);
    });
    head.flush([&](const EncodedVideo& encoded) { firstUnit = toAnnexB(encoded.accessUnit); });
    QVERIFY(!firstUnit.isEmpty());

    PlaybackDecoder decoder;
    std::atomic<int> frames {0};
    QVERIFY(decoder.start([&](const QImage&) { frames.fetch_add(1); }, [](const QString&) {}));

    // A receiver that joins mid-broadcast sends its first packets before the keyframe carrying the
    // parameter sets arrives. Those units are undecodable and must be dropped quietly rather than
    // opening a decoder that can never decode, or being reported as a failure.
    for (int i = 0; i < 5; ++i) {
        decoder.submit(firstUnit, QByteArray(), QByteArray());
    }
    QTest::qWait(300);

    QVERIFY2(frames.load() == 0, "a decoder was opened without parameter sets");
    QVERIFY(!decoder.isOpen());

    // Once the sets arrive, the very next unit decodes: nothing was latched shut by the earlier
    // units, which is the failure this guards -- a decoder that rejects everything forever after
    // its first unit arrived too early.
    VideoEncoder tail(Width, Height, 30, 500);
    QVERIFY(tail.isOpen());
    pumpEncoder(tail, decoder, 20);
    QTRY_VERIFY_WITH_TIMEOUT(frames.load() > 0, 5000);

    decoder.stop();
}

void PlaybackDecoderTest::survivesStopMidStream()
{
    VideoEncoder encoder(Width, Height, 30, 500);
    QVERIFY(encoder.isOpen());

    PlaybackDecoder decoder;
    std::atomic<int> frames {0};
    std::atomic<bool> stopped {false};
    QVERIFY(decoder.start([&](const QImage&) { frames.fetch_add(1); }, [](const QString&) {}));

    const QByteArray pattern = testPattern();
    for (int i = 0; i < 40; ++i) {
        encoder.encode(makeSample(pattern, i), [&](const EncodedVideo& encoded) {
            decoder.submit(toAnnexB(encoded.accessUnit), encoder.sps(), encoder.pps());
        });
        // Stopped with work still queued, which is the case that used to be able to destroy the
        // decoder on the wrong thread or leave the pending slot latched.
        if (i == 10) {
            decoder.stop();
            stopped.store(true);
        }
    }
    QVERIFY(stopped.load());

    // The thread is joined and the decoder gone; nothing may arrive afterwards.
    const int atStop = frames.load();
    QTest::qWait(200);
    QCOMPARE(frames.load(), atStop);
    QVERIFY(!decoder.isRunning());
    QVERIFY(!decoder.isOpen());

    // Submitting after stop is a no-op rather than a crash: the media thread can still be mid
    // datagram when the UI closes the window.
    decoder.submit(toAnnexB(QByteArray("dummy")), encoder.sps(), encoder.pps());
}

void PlaybackDecoderTest::restartsAfterStop()
{
    // A second encoder for the second session, because VideoEncoder::flush() is end of stream and
    // the context cannot be encoded into afterwards.
    VideoEncoder first(Width, Height, 30, 500);
    QVERIFY(first.isOpen());

    PlaybackDecoder decoder;
    std::atomic<int> frames {0};
    QVERIFY(decoder.start([&](const QImage&) { frames.fetch_add(1); }, [](const QString&) {}));

    pumpEncoder(first, decoder, 20);
    QTRY_VERIFY_WITH_TIMEOUT(frames.load() > 0, 5000);

    decoder.stop();
    const int before = frames.load();

    // A second session must decode from scratch, with no decoder or parameter set left over from
    // the first. Reconnecting is the normal path after a broadcaster restarts.
    std::atomic<int> second {0};
    QVERIFY(decoder.start([&](const QImage&) { second.fetch_add(1); }, [](const QString&) {}));
    QVERIFY(!decoder.isOpen());

    VideoEncoder again(Width, Height, 30, 500);
    QVERIFY(again.isOpen());
    pumpEncoder(again, decoder, 20);
    QTRY_VERIFY_WITH_TIMEOUT(second.load() > 0, 5000);

    // The first session's handler is gone: start() replaced it, rather than both counting.
    QCOMPARE(frames.load(), before);
    decoder.stop();
}

void PlaybackDecoderTest::keepsOnlyTheNewestFrameWhileBusy()
{
    VideoEncoder encoder(Width, Height, 30, 500);
    QVERIFY(encoder.isOpen());

    PlaybackDecoder decoder;
    std::atomic<int> frames {0};

    // Starts with no tokens, so the first handler to run blocks the decode thread inside it. That
    // is what makes the timing below deterministic instead of a race against the decoder.
    QSemaphore release(0);

    QVERIFY(decoder.start(
        [&](const QImage&) {
            frames.fetch_add(1);
            release.acquire();
        },
        [](const QString&) {}));

    const QByteArray pattern = testPattern();
    int submitted = 0;
    for (int i = 0; i < 60; ++i) {
        encoder.encode(makeSample(pattern, i), [&](const EncodedVideo& encoded) {
            ++submitted;
            decoder.submit(toAnnexB(encoded.accessUnit), encoder.sps(), encoder.pps());
        });
    }
    QVERIFY(submitted > 20);

    // Every submit() after the first lands while the decode thread is stuck, so they all collapse
    // into one pending slot. If submit() queued instead, the decoder would owe `submitted` frames
    // of latency by the time it caught up, and the picture would fall further behind the stream
    // with every frame rather than staying current.
    QTest::qWait(200);
    QCOMPARE(frames.load(), 1);

    // Enough tokens for every handler that will ever run, so nothing blocks from here on.
    for (int i = 0; i < submitted + 8; ++i) {
        release.release();
    }

    // The one pending unit decodes, and then the decoder is caught up with the stream -- not
    // working through a backlog of sixty.
    QTRY_VERIFY_WITH_TIMEOUT(frames.load() >= 2, 5000);
    QTest::qWait(200);
    QVERIFY2(frames.load() < submitted / 2,
        qPrintable(QStringLiteral("submit() queued rather than dropping: %1 frames out of %2 units")
                       .arg(frames.load())
                       .arg(submitted)));

    // And it is still decoding afterwards: a decoder that dropped its way into a permanently stuck
    // state would have satisfied every assertion above just as happily.
    const int caughtUp = frames.load();
    pumpEncoder(encoder, decoder, 20);
    QTRY_VERIFY_WITH_TIMEOUT(frames.load() > caughtUp, 5000);

    decoder.stop();
}

// The decoder's job is not merely to emit a frame, it is to emit the right pixels. The other
// tests here only count frames, so a channel swap or a chroma path that collapses to grey would
// pass every one of them and only show up as "the colours are wrong" on a second machine.
void PlaybackDecoderTest::decodesColoursInsteadOfSwappingOrDroppingThem()
{
    struct Colour
    {
        int r;
        int g;
        int b;
        const char* name;
    };
    const Colour colours[] = {
        {255, 0, 0, "red"},
        {0, 255, 0, "green"},
        {0, 0, 255, "blue"},
    };

    const QSize sizes[] = {QSize(Width, Height), QSize(1280, 720)};
    for (const QSize& size : sizes) {
        for (const Colour& colour : colours) {
            VideoEncoder encoder(size.width(), size.height(), 30, 4000);
            QVERIFY2(encoder.isOpen(), "the H.264 encoder did not open");

            PlaybackDecoder decoder;
            QImage captured;
            QMutex mutex;
            QVERIFY(decoder.start(
                [&](const QImage& image) {
                    if (!image.isNull()) {
                        QMutexLocker locker(&mutex);
                        captured = image;
                    }
                },
                [](const QString&) {}));

            const QByteArray frame
                = solidBgra(size.width(), size.height(), colour.r, colour.g, colour.b);
            encoder.requestKeyframe();
            for (int i = 0; i < 20; ++i) {
                encoder.encode(makeSample(frame, i, size.width(), size.height()),
                    [&](const EncodedVideo& encoded) {
                        decoder.submit(toAnnexB(encoded.accessUnit), encoder.sps(), encoder.pps());
                    });
            }
            encoder.flush([&](const EncodedVideo& encoded) {
                decoder.submit(toAnnexB(encoded.accessUnit), encoder.sps(), encoder.pps());
            });

            QTRY_VERIFY_WITH_TIMEOUT(([&] {
                QMutexLocker locker(&mutex);
                return !captured.isNull();
            })(), 5000);

            QImage image;
            {
                QMutexLocker locker(&mutex);
                image = captured;
            }
            const QRgb pixel = image.pixel(image.width() / 2, image.height() / 2);
            const QString detail
                = QStringLiteral("%1: decoded rgb(%2,%3,%4), expected rgb(%5,%6,%7)")
                      .arg(QString::fromLatin1(colour.name))
                      .arg(qRed(pixel))
                      .arg(qGreen(pixel))
                      .arg(qBlue(pixel))
                      .arg(colour.r)
                      .arg(colour.g)
                      .arg(colour.b);
            // A tolerance of 24 covers the lossy YUV420 round trip; a channel swap, a grey
            // collapse, or a BT.601/BT.709 mismatch is outside it.
            QVERIFY2(qAbs(qRed(pixel) - colour.r) <= 24, qPrintable(detail));
            QVERIFY2(qAbs(qGreen(pixel) - colour.g) <= 24, qPrintable(detail));
            QVERIFY2(qAbs(qBlue(pixel) - colour.b) <= 24, qPrintable(detail));

            decoder.stop();
        }
    }
}

QTEST_MAIN(PlaybackDecoderTest)
#include "tst_playbackdecoder.moc"
