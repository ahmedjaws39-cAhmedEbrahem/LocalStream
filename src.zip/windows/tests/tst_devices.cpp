#include <QtTest>

#include <QString>

#include "capture/FrameSource.h"

using namespace localstream::capture;

/**
 * The microphone and camera lists come from one DirectShow enumeration call.
 *
 * `avdevice_list_input_sources` returns every capture device whatever class is asked for, so the
 * application has to separate them itself, and the only signal is the alternative device name.
 * Getting it wrong is silent: the microphone picker starts offering a camera, and the mistake
 * only surfaces when the user presses Start and FFmpeg refuses to open a video device as audio.
 */
class DeviceListTest : public QObject
{
    Q_OBJECT

private slots:
    void recognisesAudioAlternativeNames();
    void doesNotMistakeAVideoDeviceForAudio();
};

void DeviceListTest::recognisesAudioAlternativeNames()
{
    // The shape Windows uses for the audio capture class: a class-manager moniker whose category
    // is the audio input GUID, followed by the `wave` subkey. Two real devices and a differently
    // cased variant, because the spelling is the driver's and case is not guaranteed.
    QVERIFY(isAudioDeviceName(QStringLiteral(
        "@device_cm_{33D9A762-90C8-11D0-BD43-00A0C911CE86}\\wave_{B045B70E-5B7E-4C0F-9C0A-...}")));
    QVERIFY(isAudioDeviceName(QStringLiteral(
        "@device_cm_{33D9A762-90C8-11D0-BD43-00A0C911CE86}\\wave_{A1F2C3D4-...}")));
    QVERIFY(isAudioDeviceName(QStringLiteral(
        "@device_cm_{33D9A762-90C8-11D0-BD43-00A0C911CE86}\\WAVE_{0}")));
}

void DeviceListTest::doesNotMistakeAVideoDeviceForAudio()
{
    // A USB webcam (PnP moniker) and a software capture filter (the video input category). Both
    // were offered as microphones by the broken build, because the class filter was ignored.
    QVERIFY(!isAudioDeviceName(QStringLiteral(
        "@device_pnp_\\\\?\\usb#vid_1bcf&pid_2b8d&mi_00#7&12838094&0&0000"
        "#{65e8773d-8f56-11d0-a3b9-00a0c9223196}\\global")));
    QVERIFY(!isAudioDeviceName(QStringLiteral(
        "@device_sw_{860BB310-5D01-11D0-BD3B-00A0C911CE86}\\{B62F0906-7E6F-4B9A-9C5A-...}")));
    QVERIFY(!isAudioDeviceName(QString()));
}

QTEST_APPLESS_MAIN(DeviceListTest)
#include "tst_devices.moc"
