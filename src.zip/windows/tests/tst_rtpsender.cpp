#include <QtTest>
#include <QHostAddress>
#include <QUdpSocket>

#include "net/RtpSender.h"
#include "protocol/LocalStream.h"
#include "protocol/Rtp.h"

using namespace localstream::net;
using namespace localstream::protocol;

/**
 * RTP fan-out over loopback.
 *
 * Uses real sockets on 127.0.0.1 rather than a fake transport, because the interesting
 * failures here are socket-level: a packet that never leaves, one sent to the wrong port, and
 * one dropped because the target list was mutated concurrently.
 */
class TestRtpSender : public QObject
{
    Q_OBJECT

private:
    /// Wraps one NAL in the 4-byte length prefix an encoder emits.
    static QByteArray makeAccessUnit(int size, char nalHeader)
    {
        QByteArray nal(size, nalHeader);
        nal[1] = char(0xAA);
        QByteArray accessUnit;
        const auto length = static_cast<quint32>(nal.size());
        accessUnit.append(char((length >> 24) & 0xFF));
        accessUnit.append(char((length >> 16) & 0xFF));
        accessUnit.append(char((length >> 8) & 0xFF));
        accessUnit.append(char(length & 0xFF));
        accessUnit.append(nal);
        return accessUnit;
    }

    /// Waits for one datagram, or returns empty on timeout.
    static QByteArray receiveOne(QUdpSocket& socket, int timeoutMs = 2000)
    {
        if (!socket.waitForReadyRead(timeoutMs)) {
            return {};
        }
        QByteArray datagram;
        datagram.resize(4096);
        const qint64 read = socket.readDatagram(datagram.data(), datagram.size());
        if (read <= 0) {
            return {};
        }
        datagram.resize(static_cast<int>(read));
        return datagram;
    }

private slots:
    void openPublishesBothPorts()
    {
        RtpSender sender;
        QString error;
        QVERIFY2(sender.open(true, &error), qPrintable(error));
        QVERIFY(sender.audioPort() > 0);
        QVERIFY(sender.videoPort() > 0);
        // The two tracks must not collide, or one socket's datagrams are read as the other's.
        QVERIFY(sender.audioPort() != sender.videoPort());
    }

    void openAudioOnlyLeavesVideoPortZero()
    {
        RtpSender sender;
        QString error;
        QVERIFY(sender.open(false, &error));
        QCOMPARE(sender.videoPort(), 0);
    }

    void closeClearsPortsAndTargets()
    {
        RtpSender sender;
        QString error;
        QVERIFY(sender.open(true, &error));
        sender.addTarget({QHostAddress::LocalHost, 1, 2});
        QCOMPARE(sender.targetCount(), 1);
        sender.close();
        QCOMPARE(sender.audioPort(), 0);
        QCOMPARE(sender.videoPort(), 0);
        QCOMPARE(sender.targetCount(), 0);
    }

    void ssrcsAreDistinctAndNonZero()
    {
        RtpSender sender;
        QVERIFY(sender.audioSsrc() != 0);
        QVERIFY(sender.videoSsrc() != 0);
        // A shared SSRC would let a receiver's jitter calculation mix the two tracks.
        QVERIFY(sender.audioSsrc() != sender.videoSsrc());
    }

    void audioReachesTheOfferedAudioPort()
    {
        QUdpSocket sink;
        QVERIFY(sink.bind(QHostAddress::LocalHost, 0));
        const int audioPort = sink.localPort();

        RtpSender sender;
        QString error;
        QVERIFY(sender.open(false, &error));
        sender.addTarget({QHostAddress::LocalHost, audioPort, 0});

        const QByteArray opusFrame = QByteArray::fromHex("0102030405");
        sender.sendAudio(opusFrame);

        const QByteArray datagram = receiveOne(sink);
        QVERIFY(!datagram.isEmpty());

        Rtp::Packet packet;
        QVERIFY(Rtp::parse(datagram, 0, datagram.size(), packet));
        QCOMPARE(packet.payloadType, LocalStream::PayloadTypeAudio);
        QCOMPARE(datagram.mid(packet.payloadOffset, packet.payloadLength), opusFrame);
    }

    void audioOnlyTargetReceivesNoVideo()
    {
        // An audio-only receiver offered no video port; the sender must skip it rather than
        // fail the whole send.
        QUdpSocket sink;
        QVERIFY(sink.bind(QHostAddress::LocalHost, 0));

        RtpSender sender;
        QString error;
        QVERIFY(sender.open(true, &error));
        sender.addTarget({QHostAddress::LocalHost, sink.localPort(), 0});

        sender.sendVideo(makeAccessUnit(2000, char(0x65)));

        // Nothing should arrive on the audio port from a video packet.
        QVERIFY(!sink.waitForReadyRead(300));
    }

    void videoIsFragmentedAcrossDatagrams()
    {
        QUdpSocket sink;
        QVERIFY(sink.bind(QHostAddress::LocalHost, 0));
        const int videoPort = sink.localPort();

        RtpSender sender;
        QString error;
        QVERIFY(sender.open(true, &error));
        sender.addTarget({QHostAddress::LocalHost, 0, videoPort});
        sender.setFrameRate(30);

        // A large access unit must become several datagrams, each within the MTU budget.
        sender.sendVideo(makeAccessUnit(6000, char(0x65)));

        int datagrams = 0;
        while (sink.waitForReadyRead(500)) {
            const QByteArray datagram = receiveOne(sink, 200);
            if (datagram.isEmpty()) {
                break;
            }
            QVERIFY(datagram.size() <= LocalStream::RtpMaxPayload + Rtp::HeaderBytes);
            ++datagrams;
        }
        QVERIFY2(datagrams > 1, "a 6 kB access unit must not fit in one datagram");
    }

    void customMaxPayloadLimitsDatagramSize()
    {
        // Lowering the fragmentation budget must shrink every video datagram, without losing
        // the frame: this is the control the Broadcast tab's "Packets" card writes.
        QUdpSocket sink;
        QVERIFY(sink.bind(QHostAddress::LocalHost, 0));

        RtpSender sender;
        QString error;
        QVERIFY(sender.open(true, &error));
        sender.addTarget({QHostAddress::LocalHost, 0, sink.localPort()});
        sender.setMaxPayload(600);

        sender.sendVideo(makeAccessUnit(4000, char(0x65)));

        int datagrams = 0;
        while (sink.waitForReadyRead(500)) {
            const QByteArray datagram = receiveOne(sink, 200);
            if (datagram.isEmpty()) {
                break;
            }
            QVERIFY(datagram.size() <= 600 + Rtp::HeaderBytes);
            ++datagrams;
        }
        QVERIFY2(datagrams > 1, "a 4 kB access unit must not fit in one 600-byte datagram");
    }

    void packetStatsDescribeTheLastAccessUnit()
    {
        QUdpSocket sink;
        QVERIFY(sink.bind(QHostAddress::LocalHost, 0));

        RtpSender sender;
        QString error;
        QVERIFY(sender.open(true, &error));
        sender.addTarget({QHostAddress::LocalHost, 0, sink.localPort()});

        QCOMPARE(sender.lastAccessUnitPacketCount(), 0);
        sender.sendVideo(makeAccessUnit(4000, char(0x65)));

        QVERIFY(sender.lastAccessUnitPacketCount() > 1);
        QVERIFY(sender.lastAccessUnitFragmentCount() > 0);
        QVERIFY(sender.lastAccessUnitLargestPayload() > 0);
        QVERIFY(sender.lastAccessUnitLargestPayload() <= LocalStream::RtpMaxPayload);
    }

    void onlyTheLastPayloadSetsTheMarker()
    {
        // RFC 6184 section 5.1: the marker bit is the frame boundary signal, so exactly one
        // packet per access unit may set it.
        QUdpSocket sink;
        QVERIFY(sink.bind(QHostAddress::LocalHost, 0));

        RtpSender sender;
        QString error;
        QVERIFY(sender.open(true, &error));
        sender.addTarget({QHostAddress::LocalHost, 0, sink.localPort()});

        sender.sendVideo(makeAccessUnit(4000, char(0x65)));

        int markers = 0;
        int total = 0;
        while (sink.waitForReadyRead(500)) {
            const QByteArray datagram = receiveOne(sink, 200);
            if (datagram.isEmpty()) {
                break;
            }
            Rtp::Packet packet;
            if (Rtp::parse(datagram, 0, datagram.size(), packet) && packet.marker) {
                ++markers;
            }
            ++total;
        }
        QVERIFY(total > 1);
        QCOMPARE(markers, 1);
    }

    void videoSequenceNumbersAreContiguous()
    {
        QUdpSocket sink;
        QVERIFY(sink.bind(QHostAddress::LocalHost, 0));

        RtpSender sender;
        QString error;
        QVERIFY(sender.open(true, &error));
        sender.addTarget({QHostAddress::LocalHost, 0, sink.localPort()});

        QList<quint16> sequences;
        for (int frame = 0; frame < 3; ++frame) {
            sender.sendVideo(makeAccessUnit(2500, char(0x41))); // non-IDR slice

            while (sink.waitForReadyRead(500)) {
                const QByteArray datagram = receiveOne(sink, 200);
                if (datagram.isEmpty()) {
                    break;
                }
                Rtp::Packet packet;
                if (Rtp::parse(datagram, 0, datagram.size(), packet)
                    && packet.payloadType == LocalStream::PayloadTypeVideo) {
                    sequences.append(packet.sequenceNumber);
                }
            }
        }
        QVERIFY(sequences.size() >= 3);
        for (int i = 1; i < sequences.size(); ++i) {
            // A gap here would make the receiver's loss counter report loss that never
            // happened, because it counts sequence numbers.
            QCOMPARE(Rtp::sequenceDelta(sequences.at(i), sequences.at(i - 1)), 1);
        }
    }

    void removingATargetStopsDelivery()
    {
        QUdpSocket sink;
        QVERIFY(sink.bind(QHostAddress::LocalHost, 0));
        const int audioPort = sink.localPort();

        RtpSender sender;
        QString error;
        QVERIFY(sender.open(false, &error));
        sender.addTarget({QHostAddress::LocalHost, audioPort, 0});
        sender.sendAudio(QByteArray(20, char(0x01)));
        QVERIFY(!receiveOne(sink).isEmpty());

        sender.removeTarget(QHostAddress::LocalHost, audioPort, 0);
        QCOMPARE(sender.targetCount(), 0);
        sender.sendAudio(QByteArray(20, char(0x01)));
        QVERIFY(sink.waitForReadyRead(300) == false);
    }

    void bitrateIsZeroBeforeAnyTrafficAndRisesAfter()
    {
        RtpSender sender;
        QString error;
        QVERIFY(sender.open(false, &error));
        QCOMPARE(sender.currentBitrateKbps(), 0);
    }

    void frameRateChangeIsApplied()
    {
        RtpSender sender;
        // A frame rate of 0 would divide by zero when computing the 90 kHz tick duration.
        sender.setFrameRate(0);
        sender.setFrameRate(30);
        sender.setFrameRate(240);
        sender.setFrameRate(30);
    }

    void sendingWithoutTargetsIsHarmless()
    {
        // The encoder keeps producing frames for a moment after the last receiver leaves.
        RtpSender sender;
        QString error;
        QVERIFY(sender.open(true, &error));
        sender.sendAudio(QByteArray(20, char(0x01)));
        sender.sendVideo(QByteArray(100, char(0x65)));
    }
};

QTEST_GUILESS_MAIN(TestRtpSender)
#include "tst_rtpsender.moc"
