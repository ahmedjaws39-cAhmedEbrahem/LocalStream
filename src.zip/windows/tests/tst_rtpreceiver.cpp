#include <QElapsedTimer>
#include <QHostAddress>
#include <QSemaphore>
#include <QThread>
#include <QtTest>
#include <QUdpSocket>

#include "net/RtpReceiver.h"
#include "protocol/H264Rtp.h"
#include "protocol/LocalStream.h"
#include "protocol/Rtp.h"

using namespace localstream;

class TestRtpReceiver : public QObject
{
    Q_OBJECT

private:
    template<typename Predicate>
    static bool waitFor(Predicate&& predicate, int timeoutMs = 2000)
    {
        QElapsedTimer timer;
        timer.start();
        while (!predicate()) {
            if (timer.elapsed() >= timeoutMs) {
                return false;
            }
            QThread::msleep(1);
        }
        return true;
    }

private slots:
    void acceptsOnlyTheNegotiatedSourceAndSsrc()
    {
        net::RtpReceiver receiver;
        QSemaphore received;
        receiver.setAudioHandler([&received](const QByteArray&) { received.release(); });

        QString error;
        QVERIFY2(receiver.open(false, &error), qPrintable(error));
        const int receiverPort = receiver.ports().audio;

        QUdpSocket expectedSender;
        QUdpSocket unexpectedSender;
        QVERIFY(expectedSender.bind(QHostAddress::LocalHost, 0));
        QVERIFY(unexpectedSender.bind(QHostAddress::LocalHost, 0));

        constexpr quint32 ExpectedSsrc = 0x11223344;
        QVERIFY(receiver.setExpectedSource(QHostAddress::LocalHost,
            expectedSender.localPort(), ExpectedSsrc, 0, 0));

        const QByteArray wrongSsrc = protocol::Rtp::build(
            protocol::LocalStream::PayloadTypeAudio, false, 1, 0, 0x55667788, QByteArray("x"));
        QCOMPARE(unexpectedSender.writeDatagram(
                     wrongSsrc, QHostAddress::LocalHost, static_cast<quint16>(receiverPort)),
            static_cast<qint64>(wrongSsrc.size()));
        QVERIFY(!received.tryAcquire(1, 100));

        const QByteArray wrongPort = protocol::Rtp::build(
            protocol::LocalStream::PayloadTypeAudio, false, 2, 0, ExpectedSsrc, QByteArray("x"));
        QCOMPARE(unexpectedSender.writeDatagram(
                     wrongPort, QHostAddress::LocalHost, static_cast<quint16>(receiverPort)),
            static_cast<qint64>(wrongPort.size()));
        QVERIFY(!received.tryAcquire(1, 100));

        const QByteArray valid = protocol::Rtp::build(
            protocol::LocalStream::PayloadTypeAudio, false, 3, 0, ExpectedSsrc, QByteArray("x"));
        QCOMPARE(expectedSender.writeDatagram(
                     valid, QHostAddress::LocalHost, static_cast<quint16>(receiverPort)),
            static_cast<qint64>(valid.size()));
        QVERIFY(received.tryAcquire(1, 2000));

        receiver.close();
    }

    void lostVideoFragmentDoesNotCompleteCorruptPicture()
    {
        net::RtpReceiver receiver;
        QSemaphore decodedAccessUnit;
        receiver.setVideoHandler([&decodedAccessUnit](
                                     const QByteArray& accessUnit, const QByteArray&, const QByteArray&) {
            if (!accessUnit.isEmpty()) {
                decodedAccessUnit.release();
            }
        });

        QString error;
        QVERIFY2(receiver.open(true, &error), qPrintable(error));
        QUdpSocket sender;
        QVERIFY(sender.bind(QHostAddress::LocalHost, 0));
        constexpr quint32 AudioSsrc = 0x11223344;
        constexpr quint32 VideoSsrc = 0x55667788;
        QVERIFY(receiver.setExpectedSource(
            QHostAddress::LocalHost, sender.localPort(), AudioSsrc, sender.localPort(), VideoSsrc));

        const quint8 fuIndicator = static_cast<quint8>(0x60 | protocol::h264::TypeFuA);
        QByteArray start;
        start.append(static_cast<char>(fuIndicator));
        start.append(static_cast<char>(0x80 | protocol::h264::NalSliceIdr));
        start.append("ab");
        QByteArray missingEnd;
        missingEnd.append(static_cast<char>(fuIndicator));
        missingEnd.append(static_cast<char>(0x40 | protocol::h264::NalSliceIdr));
        missingEnd.append("cd");
        QByteArray nextFrame;
        nextFrame.append(static_cast<char>(0x60 | protocol::h264::NalSliceIdr));
        nextFrame.append("ef");

        const QList<QByteArray> packets {
            protocol::Rtp::build(protocol::LocalStream::PayloadTypeVideo, false, 1, 0,
                VideoSsrc, start),
            protocol::Rtp::build(protocol::LocalStream::PayloadTypeVideo, true, 3, 0,
                VideoSsrc, missingEnd),
            protocol::Rtp::build(protocol::LocalStream::PayloadTypeVideo, true, 4, 3000,
                VideoSsrc, nextFrame)
        };
        for (const QByteArray& packet : packets) {
            QCOMPARE(sender.writeDatagram(packet, QHostAddress::LocalHost,
                         static_cast<quint16>(receiver.ports().video)),
                static_cast<qint64>(packet.size()));
        }

        QVERIFY(decodedAccessUnit.tryAcquire(1, 2000));
        QVERIFY(!decodedAccessUnit.tryAcquire(1, 200));
        receiver.close();
    }
};

QTEST_GUILESS_MAIN(TestRtpReceiver)
#include "tst_rtpreceiver.moc"
