#include <QtTest>

#include <QNetworkInterface>

#include "discovery/DnsSd.h"
#include "discovery/ServiceAdvertiser.h"
#include "discovery/ServiceDiscovery.h"
#include "protocol/LocalStream.h"

using namespace localstream;
using namespace localstream::net;

namespace {

// DNS record types, repeated here so the dispatch in the tests reads as a switch on a name.
constexpr quint16 TypeA = 1;
constexpr quint16 TypePtr = 12;
constexpr quint16 TypeTxt = 16;
constexpr quint16 TypeSrv = 33;

/// Appends a 16-bit big-endian value, the way every DNS header and RDATA field is laid out.
void appendU16(QByteArray &out, quint16 value)
{
    out.append(static_cast<char>((value >> 8) & 0xFF));
    out.append(static_cast<char>(value & 0xFF));
}

void appendU32(QByteArray &out, quint32 value)
{
    out.append(static_cast<char>((value >> 24) & 0xFF));
    out.append(static_cast<char>((value >> 16) & 0xFF));
    out.append(static_cast<char>((value >> 8) & 0xFF));
    out.append(static_cast<char>(value & 0xFF));
}

/// Escapes an instance label the way a responder must before it goes into a single DNS label.
QByteArray escapeLabel(const QString &label)
{
    QByteArray out;
    for (const QChar c : label) {
        if (c == QLatin1Char('.') || c == QLatin1Char('\\')) {
            out.append('\\');
        }
        out.append(c.toLatin1());
    }
    return out;
}

/// A name in uncompressed label form. [escapedLabels] marks which leading labels are already
/// escaped, so a test can put a `\.` on the wire without the helper escaping it twice.
QByteArray nameAt(const QString &name, bool escapedLabels = false)
{
    QByteArray out;
    const QStringList labels = name.split(QLatin1Char('.'), Qt::SkipEmptyParts);
    for (int i = 0; i < labels.size(); ++i) {
        // The first label of an instance name is the one that may contain escapes; the
        // service and domain labels that follow never do.
        const QByteArray bytes = (escapedLabels && i == 0) ? escapeLabel(labels.at(i))
                                                           : labels.at(i).toLatin1();
        out.append(static_cast<char>(bytes.size()));
        out.append(bytes);
    }
    out.append('\0');
    return out;
}

/// A compression pointer to [offset]: the top two bits set, the low 14 bits the offset.
QByteArray pointerTo(int offset)
{
    return QByteArray::fromHex(QString::number(0xC000 | offset, 16).toLatin1());
}

/// Assembles a response header with the given section counts.
QByteArray header(quint16 questions, quint16 answers, quint16 authorities, quint16 additional,
    quint16 flags = 0x8400)
{
    QByteArray out;
    appendU16(out, 0);     // ID
    appendU16(out, flags); // response, authoritative
    appendU16(out, questions);
    appendU16(out, answers);
    appendU16(out, authorities);
    appendU16(out, additional);
    return out;
}

QByteArray record(const QString &owner, quint16 type, const QByteArray &rdata, quint32 ttl = 120)
{
    QByteArray out = nameAt(owner);
    appendU16(out, type);
    appendU16(out, 1); // class IN
    appendU32(out, ttl); // TTL is 32 bits on the wire, not 16
    appendU16(out, static_cast<quint16>(rdata.size()));
    out.append(rdata);
    return out;
}

QByteArray srvRdata(quint16 port, const QString &target)
{
    QByteArray out;
    appendU16(out, 0); // priority
    appendU16(out, 0); // weight
    appendU16(out, port);
    out.append(nameAt(target));
    return out;
}

QByteArray aRdata(quint8 a, quint8 b, quint8 c, quint8 d)
{
    QByteArray out;
    out.append(static_cast<char>(a));
    out.append(static_cast<char>(b));
    out.append(static_cast<char>(c));
    out.append(static_cast<char>(d));
    return out;
}

/// TXT RDATA: each `key=value` entry is length-prefixed on its own, per RFC 6763 section 6.1.
QByteArray txtRdata(const QList<QByteArray> &entries)
{
    QByteArray out;
    for (const QByteArray &entry : entries) {
        out.append(static_cast<char>(entry.size()));
        out.append(entry);
    }
    return out;
}

/// The IPv4 address the OS would send from, or a non-loopback address if the probe fails. The
/// advertiser needs a real address to carry in its A record, and the reply is only reachable on
/// the interface that address lives on.
QHostAddress firstLanAddress()
{
    QUdpSocket probe;
    probe.connectToHost(QStringLiteral("192.0.2.1"), 9); // TEST-NET-1: routed, never reachable.
    if (probe.waitForConnected(1000) && probe.state() == QAbstractSocket::ConnectedState) {
        const QHostAddress address = probe.localAddress();
        if (address != QHostAddress::AnyIPv4 && !address.isLoopback()) {
            return address;
        }
    }
    for (const QNetworkInterface &iface : QNetworkInterface::allInterfaces()) {
        if (!iface.flags().testFlag(QNetworkInterface::IsUp)
            || iface.flags().testFlag(QNetworkInterface::IsLoopBack)) {
            continue;
        }
        for (const QNetworkAddressEntry &entry : iface.addressEntries()) {
            if (entry.ip().protocol() == QAbstractSocket::IPv4Protocol && !entry.ip().isLoopback()) {
                return entry.ip();
            }
        }
    }
    return QHostAddress();
}

QNetworkInterface interfaceFor(const QHostAddress &address)
{
    for (const QNetworkInterface &iface : QNetworkInterface::allInterfaces()) {
        for (const QNetworkAddressEntry &entry : iface.addressEntries()) {
            if (entry.ip() == address) {
                return iface;
            }
        }
    }
    return QNetworkInterface();
}

protocol::LocalStream::Description sampleDescription()
{
    protocol::LocalStream::Description description;
    description.sessionId = QStringLiteral("a1b2c3d4");
    description.displayName = QStringLiteral("Studio Mac");
    description.mode = QString::fromLatin1(protocol::LocalStream::ModeAudioVideo);
    description.audioPort = 41000;
    description.videoPort = 41001;
    description.controlPort = 41002;
    return description;
}

/// A complete announcement: PTR, SRV, TXT and A in one message.
/// [wireInstance] is the instance label exactly as it goes on the wire, so a caller can pass an
/// already-escaped label to exercise the decoder's unescaping.
QByteArray answerWith(const protocol::LocalStream::Description &description,
    const QString &wireInstance = QStringLiteral("Studio Mac"))
{
    const QString service = QString::fromLatin1(protocol::LocalStream::ServiceType);
    const QString host = QStringLiteral("studio.local.");
    // The instance is one DNS label, so the escaped wire label is re-escaped by nameAt.
    const QString instance = wireInstance + QLatin1Char('.') + service;

    QByteArray message = header(0, 4, 0, 0);
    message.append(record(service, TypePtr, nameAt(instance, true)));
    message.append(record(instance, TypeSrv, srvRdata(description.controlPort, host)));
    message.append(record(instance, TypeTxt, txtRdata(protocol::LocalStream::txtEntries(description))));
    message.append(record(host, TypeA, aRdata(192, 168, 1, 42)));
    return message;
}

/// An announcement whose TXT record carries hand-picked keys, for the rejection tests.
QByteArray announcementWithTxt(const QList<QByteArray> &txtEntries,
    const QString &instanceLabel = QStringLiteral("Studio Mac"))
{
    const QString service = QString::fromLatin1(protocol::LocalStream::ServiceType);
    const QString instance = instanceLabel + QLatin1Char('.') + service;
    const QString host = QStringLiteral("studio.local.");

    QByteArray message = header(0, 3, 0, 1);
    message.append(record(service, TypePtr, nameAt(instance, true)));
    message.append(record(instance, TypeSrv, srvRdata(41002, host)));
    message.append(record(instance, TypeTxt, txtRdata(txtEntries)));
    message.append(record(host, TypeA, aRdata(192, 168, 1, 42)));
    return message;
}

} // namespace

class TestDnsSd : public QObject
{
    Q_OBJECT

private slots:
    // ---------------------------------------------------------------- names

    void nameRoundTrips()
    {
        const QString name = QStringLiteral("laptop._localstream._tcp.local.");
        const QByteArray encoded = dnssd::encodeName(name);
        int at = 0;
        const auto decoded = dnssd::readName(encoded, at);
        QVERIFY(decoded.has_value());
        QCOMPARE(*decoded, name);
        QCOMPARE(at, encoded.size());
    }

    void emptyNameIsJustTheRootLabel()
    {
        const QByteArray encoded = dnssd::encodeName(QString());
        QCOMPARE(encoded.size(), 1);
        int at = 0;
        const auto decoded = dnssd::readName(encoded, at);
        QVERIFY(decoded.has_value());
        QCOMPARE(*decoded, QString());
    }

    void readNameFollowsACompressionPointer()
    {
        // "_localstream._tcp.local." written once, then an owner that points back at it. Every
        // real responder's response is built this way, so a decoder that does not follow
        // pointers resolves nothing at all.
        QByteArray message;
        message.append(nameAt(QStringLiteral("_localstream._tcp.local.")));
        const int pointerAt = message.size();
        message.append(pointerTo(0)); // the suffix owner, pointing back at offset 0

        int at = pointerAt; // start on the pointer, as a record owner would
        const auto decoded = dnssd::readName(message, at);
        QVERIFY(decoded.has_value());
        QCOMPARE(*decoded, QStringLiteral("_localstream._tcp.local."));
        // `at` must land after the two pointer bytes, not after the name they point at: the
        // fields that follow the owner name are read from where the pointer sat.
        QCOMPARE(at, pointerAt + 2);
    }

    void readNameRejectsASelfPointer()
    {
        // A pointer at its own offset loops forever without a hop limit.
        QByteArray message = pointerTo(0);
        int at = 0;
        QVERIFY(!dnssd::readName(message, at).has_value());
    }

    void readNameRejectsATruncatedLabel()
    {
        QByteArray message;
        message.append('\x05'); // claims a 5-byte label
        message.append("ab", 2);
        int at = 0;
        QVERIFY(!dnssd::readName(message, at).has_value());
    }

    // ---------------------------------------------------------------- records

    void parsesPtrSrvTxtAndA()
    {
        const QString service = QString::fromLatin1(protocol::LocalStream::ServiceType);
        const QString instance = QStringLiteral("Studio Mac.") + service;
        const QString host = QStringLiteral("studio.local.");

        const auto records = dnssd::parseResponse(answerWith(sampleDescription()));
        QVERIFY(records.has_value());
        QCOMPARE(records->size(), 4);

        const dnssd::Record &ptr = records->at(0);
        QCOMPARE(ptr.type, TypePtr);
        QCOMPARE(ptr.name, service);
        QCOMPARE(ptr.target, instance);

        const dnssd::Record &srv = records->at(1);
        QCOMPARE(srv.type, TypeSrv);
        QCOMPARE(srv.name, instance);
        QCOMPARE(srv.port, quint16(41002));
        QCOMPARE(srv.target, host);

        const dnssd::Record &txt = records->at(2);
        QCOMPARE(txt.type, TypeTxt);
        QCOMPARE(txt.name, instance);
        QVERIFY(!txt.txt.isEmpty());

        const dnssd::Record &a = records->at(3);
        QCOMPARE(a.type, TypeA);
        QCOMPARE(a.name, host);
        QCOMPARE(a.address, QHostAddress(QStringLiteral("192.168.1.42")));
    }

    void decodesRecordsFromTheAdditionalSection()
    {
        // A responder normally puts the SRV and A records in the additional section. A decoder
        // that reads only the answer section resolves nothing, which presents as a network
        // problem rather than a parsing one.
        const QString service = QString::fromLatin1(protocol::LocalStream::ServiceType);
        const QString instance = QStringLiteral("Studio Mac.") + service;
        const QString host = QStringLiteral("studio.local.");

        QByteArray message = header(0, 1, 0, 2);
        message.append(record(service, TypePtr, nameAt(instance)));
        message.append(record(instance, TypeSrv, srvRdata(41002, host)));
        message.append(record(host, TypeA, aRdata(10, 0, 0, 7)));

        const auto records = dnssd::parseResponse(message);
        QVERIFY(records.has_value());
        QCOMPARE(records->size(), 3);
        QCOMPARE(records->at(1).port, quint16(41002));
        QCOMPARE(records->at(2).address, QHostAddress(QStringLiteral("10.0.0.7")));
    }

    void skipsRecordTypesItDoesNotKnow()
    {
        // Skipping by declared RDLENGTH is what makes an unknown type harmless rather than
        // fatal: the records after it still decode.
        const QString service = QString::fromLatin1(protocol::LocalStream::ServiceType);
        QByteArray message = header(0, 2, 0, 0);
        message.append(record(service, 99 /* unknown */, QByteArray(7, 'x')));
        message.append(record(service, TypePtr, nameAt(QStringLiteral("A.") + service)));

        const auto records = dnssd::parseResponse(message);
        QVERIFY(records.has_value());
        QCOMPARE(records->size(), 2);
        QCOMPARE(records->at(1).type, TypePtr);
    }

    void rejectsAQuery()
    {
        // Flags without the QR bit: a query, not a response.
        QVERIFY(!dnssd::parseResponse(header(0, 0, 0, 0, 0x0000)).has_value());
    }

    void rejectsAnRdataLengthThatOverrunsTheMessage()
    {
        const QString service = QString::fromLatin1(protocol::LocalStream::ServiceType);
        QByteArray message = header(0, 1, 0, 0);
        message.append(nameAt(service));
        appendU16(message, TypePtr);
        appendU16(message, 1);
        appendU32(message, 0);
        appendU16(message, 120);
        appendU16(message, 200); // claims 200 bytes
        message.append(QByteArray(4, 'x'));

        QVERIFY(!dnssd::parseResponse(message).has_value());
    }

    void rejectsAnAbsurdRecordCount()
    {
        QByteArray message = header(0, 0, 0, 0);
        message[6] = '\xFF'; // ANCOUNT
        message[7] = '\xFF';
        QVERIFY(!dnssd::parseResponse(message).has_value());
    }

    void rejectsAnEmptyMessage()
    {
        QVERIFY(!dnssd::parseResponse(QByteArray()).has_value());
    }

    // ---------------------------------------------------------------- query

    void queryAsksForTheServiceType()
    {
        const QByteArray query = dnssd::buildServiceQuery(
            QString::fromLatin1(protocol::LocalStream::ServiceType));
        QCOMPARE(query.size(), 12 + nameAt(QString::fromLatin1(protocol::LocalStream::ServiceType)).size() + 4);
        QCOMPARE(quint8(query.at(5)), quint8(1)); // QDCOUNT = 1
        QCOMPARE(quint8(query.at(query.size() - 3)), quint8(12)); // QTYPE = PTR
        QCOMPARE(quint8(query.at(query.size() - 1)), quint8(1)); // QCLASS = IN
    }

    void parseQueryDecodesTheServiceQuestion()
    {
        const QString service = QString::fromLatin1(protocol::LocalStream::ServiceType);
        const QByteArray query = dnssd::buildServiceQuery(service);

        const auto questions = dnssd::parseQuery(query);
        QVERIFY(questions.has_value());
        QCOMPARE(int(questions->size()), 1);
        QCOMPARE(questions->front().name, service);
        QCOMPARE(questions->front().type, TypePtr);
    }

    void parseQueryRejectsAResponse()
    {
        // The multicast loopback echoes this advertiser's own announcement back to it, so a
        // responder that could not tell a response from a query would answer itself forever.
        QVERIFY(!dnssd::parseQuery(answerWith(sampleDescription())).has_value());
    }

    void parseQueryRejectsGarbage()
    {
        QVERIFY(!dnssd::parseQuery(QByteArray()).has_value());
        QVERIFY(!dnssd::parseQuery(QByteArray("not a dns message at all")).has_value());

        // A header that claims one question with no question bytes behind it.
        QByteArray truncated;
        appendU16(truncated, 0); // ID
        appendU16(truncated, 0); // flags: query
        appendU16(truncated, 1); // QDCOUNT
        appendU16(truncated, 0); // ANCOUNT
        appendU16(truncated, 0); // NSCOUNT
        appendU16(truncated, 0); // ARCOUNT
        QVERIFY(!dnssd::parseQuery(truncated).has_value());
    }

    // ---------------------------------------------------------------- ingestion

    void announcementResolvesIntoOneConnectableService()
    {
        ServiceDiscovery discovery;
        QList<ServiceDiscovery::Service> added;
        connect(&discovery, &ServiceDiscovery::serviceAdded, this,
            [&added](const ServiceDiscovery::Service &s) { added.append(s); });

        discovery.ingestPacket(answerWith(sampleDescription()));

        QVERIFY(!added.isEmpty());
        const ServiceDiscovery::Service &service = added.last();
        QCOMPARE(service.name, QStringLiteral("Studio Mac"));
        QCOMPARE(service.port, quint16(41002));
        QCOMPARE(service.address, QHostAddress(QStringLiteral("192.168.1.42")));
        QCOMPARE(service.description.controlPort, 41002);
        // Only once the port, the address and the description are all present.
        QVERIFY(service.isConnectable());
    }

    void ptrAloneIsNotOfferedAsConnectable()
    {
        // A PTR says only that the instance exists. Offering it as joinable would put a row
        // in front of the user that cannot be connected to.
        ServiceDiscovery discovery;
        const QString service = QString::fromLatin1(protocol::LocalStream::ServiceType);
        QByteArray message = header(0, 1, 0, 0);
        message.append(record(service, TypePtr, nameAt(QStringLiteral("Studio Mac.") + service)));

        QList<ServiceDiscovery::Service> added;
        connect(&discovery, &ServiceDiscovery::serviceAdded, this,
            [&added](const ServiceDiscovery::Service &s) { added.append(s); });
        discovery.ingestPacket(message);

        QVERIFY(!added.isEmpty());
        QVERIFY(!added.last().isConnectable());
    }

    void anIncompatibleVersionIsIgnored()
    {
        // Version 999 must not become a joinable row: proceeding on guessed defaults would
        // offer a connection that cannot work. The PTR alone still proves the instance exists,
        // so a non-connectable row is fine -- what must not happen is it becoming usable.
        ServiceDiscovery discovery;
        QList<ServiceDiscovery::Service> added;
        connect(&discovery, &ServiceDiscovery::serviceAdded, this,
            [&added](const ServiceDiscovery::Service &s) { added.append(s); });

        discovery.ingestPacket(announcementWithTxt({QByteArrayLiteral("v=999"),
            QByteArrayLiteral("id=a1b2c3d4"), QByteArrayLiteral("cp=41002")}));

        for (const ServiceDiscovery::Service &service : added) {
            QVERIFY(!service.isConnectable());
            QVERIFY(service.description.sessionId.isEmpty());
        }
    }

    void aRecordWithNoControlPortIsIgnored()
    {
        // A TXT record without `cp` describes no way to connect, so it cannot make a row
        // connectable either.
        ServiceDiscovery discovery;
        QList<ServiceDiscovery::Service> added;
        connect(&discovery, &ServiceDiscovery::serviceAdded, this,
            [&added](const ServiceDiscovery::Service &s) { added.append(s); });

        discovery.ingestPacket(announcementWithTxt({QByteArrayLiteral("v=1"),
            QByteArrayLiteral("id=a1b2c3d4")}));

        for (const ServiceDiscovery::Service &service : added) {
            QVERIFY(!service.isConnectable());
        }
    }

    void recordsForAnotherServiceTypeAreIgnored()
    {
        ServiceDiscovery discovery;
        QList<ServiceDiscovery::Service> added;
        connect(&discovery, &ServiceDiscovery::serviceAdded, this,
            [&added](const ServiceDiscovery::Service &s) { added.append(s); });

        const QString other = QStringLiteral("_printer._tcp.local.");
        QByteArray message = header(0, 1, 0, 0);
        message.append(record(other, TypePtr, nameAt(QStringLiteral("HP.") + other)));
        discovery.ingestPacket(message);

        QCOMPARE(added.size(), 0);
    }

    void garbageIsIgnoredWithoutWarning()
    {
        // Unrelated multicast traffic on 5353 must not raise a signal per packet.
        ServiceDiscovery discovery;
        int warnings = 0;
        connect(&discovery, &ServiceDiscovery::warning, this,
            [&warnings](const QString &) { ++warnings; });

        discovery.ingestPacket(QByteArray("not a dns message at all"));
        discovery.ingestPacket(QByteArray());
        QCOMPARE(warnings, 0);
    }

    void aRenamedBroadcasterRetractsItsOldRow()
    {
        // A broadcaster may change the name it advertises at any time. Without retraction the
        // list ends up showing the same broadcaster twice under two names.
        ServiceDiscovery discovery;
        QStringList added;
        QStringList removed;
        connect(&discovery, &ServiceDiscovery::serviceAdded, this,
            [&added](const ServiceDiscovery::Service &s) { added.append(s.name); });
        connect(&discovery, &ServiceDiscovery::serviceRemoved, this,
            [&removed](const QString &name) { removed.append(name); });

        discovery.ingestPacket(answerWith(sampleDescription()));

        auto renamed = sampleDescription();
        renamed.displayName = QStringLiteral("Studio Mac (rebooted)");
        discovery.ingestPacket(answerWith(renamed));

        QVERIFY(added.contains(QStringLiteral("Studio Mac")));
        QVERIFY(added.contains(QStringLiteral("Studio Mac (rebooted)")));
        QCOMPARE(removed.size(), 1);
        QCOMPARE(removed.first(), QStringLiteral("Studio Mac"));
    }

    void anEscapedDotInTheInstanceLabelIsUnescaped()
    {
        // A broadcaster named "Bob's. Laptop" must come back with its dot intact. If the
        // decoder split on the dot instead of honouring the `\.`, the instance would resolve
        // under a different key and the row would never join up with its own address.
        ServiceDiscovery discovery;
        QList<ServiceDiscovery::Service> added;
        connect(&discovery, &ServiceDiscovery::serviceAdded, this,
            [&added](const ServiceDiscovery::Service &s) { added.append(s); });

        discovery.ingestPacket(answerWith(sampleDescription(), QStringLiteral("Bob's. Laptop")));
        QVERIFY(!added.isEmpty());
        QCOMPARE(added.last().instanceKey, QStringLiteral("Bob's. Laptop"));
        QVERIFY(added.last().isConnectable());
    }

    // ---------------------------------------------------------------- advertiser

    void advertiserAnswersABrowseQuery()
    {
        // The full round trip that has no other coverage: the advertiser joins the mDNS group,
        // hears a PTR query and replies. Both ends run on this machine, so no peer is needed.
        const QHostAddress local = firstLanAddress();
        if (local.isNull()) {
            QSKIP("no non-loopback IPv4 address to advertise on");
        }

        auto description = sampleDescription();
        description.controlPort = 45678;

        ServiceAdvertiser advertiser;
        ServiceAdvertiser::Settings settings;
        settings.displayName = description.displayName;
        settings.hostName = QStringLiteral("responder-test.local");
        settings.address = local;
        settings.controlPort = description.controlPort;
        settings.sessionId = description.sessionId;
        settings.txtRecord = protocol::LocalStream::txtWireRecord(description);
        QString error;
        QVERIFY2(advertiser.start(settings, &error), qPrintable(error));
        if (!advertiser.canAnswerQueries()) {
            advertiser.stop();
            QSKIP("another program owns the mDNS port; queries cannot be answered here");
        }

        // A querier beside it, bound to an ephemeral port like a one-shot resolver rather than
        // to 5353. On Windows the last socket to bind the wildcard port receives the inbound
        // multicast, so a second 5353 socket here would take the query away from the advertiser
        // and it would never answer. A query from an ephemeral port is answered directly to that
        // source (RFC 6762 section 6.7), so the reply arrives without the querier joining the
        // group.
        QUdpSocket querier;
        QVERIFY(querier.bind(QHostAddress::AnyIPv4, 0, QUdpSocket::ReuseAddressHint));
        const QNetworkInterface iface = interfaceFor(local);
        QVERIFY(iface.isValid());
        querier.setMulticastInterface(iface); // without this the send leaves on another adapter
        querier.setSocketOption(QAbstractSocket::MulticastTtlOption, QVariant::fromValue<int>(255));
        querier.setSocketOption(QAbstractSocket::MulticastLoopbackOption,
            QVariant::fromValue<int>(1));

        // Let the announcement sent at start() pass, which also clears the responder's per-query
        // floor, so a packet carrying our control port afterwards can only be the reply below.
        QTest::qWait(1500);

        // The reply goes back unicast to this ephemeral port (RFC 6762 section 6.7), so it is not
        // subject to the multicast floor. The query is repeated anyway: Windows' delivery of an
        // inbound multicast datagram to a socket sharing the wildcard port is not guaranteed on
        // every send, and one lost query would fail the test for the wrong reason. Each pass
        // waits with qWait, not waitForReadyRead, so the advertiser's own readyRead gets a
        // running event loop; a blocking wait on the querier descriptor would starve it.
        const QByteArray query =
            dnssd::buildServiceQuery(QString::fromLatin1(protocol::LocalStream::ServiceType));
        bool sawReply = false;
        for (int attempt = 0; attempt < 8 && !sawReply; ++attempt) {
            QVERIFY(querier.writeDatagram(query, QHostAddress(QStringLiteral("224.0.0.251")), 5353)
                > 0);
            QTest::qWait(500);
            while (querier.hasPendingDatagrams()) {
                QByteArray datagram;
                datagram.resize(dnssd::MaxDatagramSize);
                const qint64 read = querier.readDatagram(datagram.data(), datagram.size());
                if (read <= 0) {
                    break;
                }
                datagram.resize(static_cast<int>(read));
                const auto records = dnssd::parseResponse(datagram);
                if (!records) {
                    continue;
                }
                for (const dnssd::Record &record : *records) {
                    if (record.type == TypeSrv && record.port == 45678) {
                        sawReply = true;
                    }
                }
            }
        }
        QVERIFY(sawReply);

        querier.close();
        advertiser.stop();
    }
};

QTEST_MAIN(TestDnsSd)
#include "tst_discovery.moc"
