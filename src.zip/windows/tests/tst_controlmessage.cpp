#include <QtTest>

#include "protocol/ControlMessage.h"
#include "protocol/LocalStream.h"
#include "testvectors.h"

using namespace localstream::protocol;
using namespace localstream::testvectors;

/**
 * Control-channel JSON codec.
 *
 * Every case here is a cross-platform contract. A field that is merely *consistent* inside one
 * implementation is not enough: the Windows and Android apps talk to each other directly, and
 * the failure mode is a session that looks connected and silently carries no media.
 */
class TestControlMessage : public QObject
{
    Q_OBJECT

private:
    static QByteArray encodeOne(const ControlMessage& message)
    {
        return toJsonLine(message);
    }

private slots:
    void acceptCarriesAudioSsrcUnderAs()
    {
        // `as` is the audio SSRC and `vs` the video SSRC. These are track initials, not
        // positions in the object, and swapping them round-trips perfectly within one
        // implementation while breaking every Android <-> Windows session.
        const QByteArray json = encodeOne(Accept {40000, 40001, kAudioSsrc, kVideoSsrc});
        const auto parsed = parse(json);
        const auto* accept = std::get_if<Accept>(&parsed);
        QVERIFY(accept);
        QCOMPARE(accept->audioSsrc, kAudioSsrc);
        QCOMPARE(accept->videoSsrc, kVideoSsrc);
    }

    void acceptOmitsVideoInAudioOnly()
    {
        // Explicit null rather than 0 or omission: a receiver tells audio-only from a
        // malformed accept by the value, and a zero video port is not a legal destination.
        const QByteArray json = encodeOne(Accept {40000, 0, kAudioSsrc, 0});
        QVERIFY(json.contains("\"vs\":null"));
        QVERIFY(!json.contains("\"vp\":0"));

        const auto parsed = parse(json);
        const auto* accept = std::get_if<Accept>(&parsed);
        QVERIFY(accept);
        QCOMPARE(accept->audioPort, 40000);
        QCOMPARE(accept->videoPort, 0);
        QCOMPARE(accept->videoSsrc, 0u);
    }

    void acceptAlwaysCarriesTheAudioSsrc()
    {
        // A parameter-set-only bug: dropping `as` in audio-only mode would leave a receiver
        // with no SSRC to validate the audio stream against.
        const QByteArray json = encodeOne(Accept {40000, 0, kAudioSsrc, 0});
        QVERIFY(json.contains("\"as\""));
    }

    void offerOmitsAbsentVideoPort()
    {
        const QByteArray json = encodeOne(Offer {QStringLiteral("abcd1234"), 40000, 0});
        QVERIFY(!json.contains("\"vp\""));
        const auto parsed = parse(json);
        const auto* offer = std::get_if<Offer>(&parsed);
        QVERIFY(offer);
        QCOMPARE(offer->audioPort, 40000);
        QCOMPARE(offer->videoPort, 0);
    }

    void modeRequestIsDistinguishedByTheRequestFlag()
    {
        // Both messages use type "mode". Without `"r": true` a receiver cannot tell a request
        // from a command, and a request would silently act as a command.
        const QByteArray request = encodeOne(ModeRequest {QStringLiteral("a")});
        QVERIFY(request.contains("\"r\":true"));
        QVERIFY(std::holds_alternative<ModeRequest>(parse(request)));

        const QByteArray changed = encodeOne(ModeChanged {QStringLiteral("a")});
        QVERIFY(!changed.contains("\"r\""));
        QVERIFY(std::holds_alternative<ModeChanged>(parse(changed)));
    }

    void statsAreDisambiguatedByFieldNames()
    {
        // `stats` travels in both directions with different fields; `pkt` marks the
        // receiver's report.
        const QByteArray fromBroadcaster = encodeOne(BroadcasterStats {30, 1500, 0.5, 2, 7});
        QVERIFY(!fromBroadcaster.contains("\"pkt\""));
        const auto parsedBroadcaster = parse(fromBroadcaster);
        const auto* stats = std::get_if<BroadcasterStats>(&parsedBroadcaster);
        QVERIFY(stats);
        QCOMPARE(stats->framesPerSecond, 30);
        QCOMPARE(stats->receiverCount, 2);

        const QByteArray fromReceiver = encodeOne(ReceiverStats {100, 3, 1.25, 1});
        const auto parsedReceiver = parse(fromReceiver);
        const auto* receiverStats = std::get_if<ReceiverStats>(&parsedReceiver);
        QVERIFY(receiverStats);
        QCOMPARE(receiverStats->packets, quint64(100));
        QCOMPARE(receiverStats->jitterMillis, 1.25);
    }

    void unknownTypeIsIgnoredNotRejected()
    {
        // Forward compatibility: a newer peer adding a message type must not tear down a
        // healthy session on an older client.
        QVERIFY(std::holds_alternative<std::monostate>(parse(R"({"t":"teleport","v":1})")));
    }

    void malformedJsonIsIgnored()
    {
        QVERIFY(std::holds_alternative<std::monostate>(parse("")));
        QVERIFY(std::holds_alternative<std::monostate>(parse("{")));
        QVERIFY(std::holds_alternative<std::monostate>(parse("not json at all")));
        QVERIFY(std::holds_alternative<std::monostate>(parse("[1,2,3]")));
    }

    void missingFieldsFallBackToDefaults()
    {
        // A peer that omits an optional field should not be treated as malformed.
        const auto parsed = parse(R"({"t":"hello","v":1})");
        const auto* hello = std::get_if<Hello>(&parsed);
        QVERIFY(hello);
        QCOMPARE(hello->protocolVersion, 1);
        QVERIFY(hello->name.isEmpty());
    }

    void encodeIsCompactAndNewlineTerminated()
    {
        // Whitespace is bytes on the wire, and the framing is exactly one trailing newline.
        const QByteArray line = encode(ModeChanged {QStringLiteral("av")});
        QCOMPARE(line.count('\n'), 1);
        QVERIFY(line.endsWith('\n'));

        const QByteArray bare = toJsonLine(ModeChanged {QStringLiteral("av")});
        QVERIFY(!bare.contains('\n'));
        QVERIFY(!bare.contains("  "));
    }

    void monostateEncodesToNothing()
    {
        QVERIFY(encodeOne(std::monostate {}).isEmpty());
        QVERIFY(typeName(std::monostate {}).isEmpty());
    }

    void typeNameMatchesTheEncodedTag()
    {
        QCOMPARE(typeName(Hello {LocalStream::ProtocolVersion, QStringLiteral("receiver"), QStringLiteral("n"),
                     QStringLiteral("ua")}),
            QStringLiteral("hello"));
        QCOMPARE(typeName(Welcome {LocalStream::ProtocolVersion, QStringLiteral("id"), QStringLiteral("av"),
                     QStringLiteral("name"), QStringLiteral("sdp")}),
            QStringLiteral("welcome"));
        QCOMPARE(typeName(Deny {QString::fromLatin1(deny::Version), QStringLiteral("no")}),
            QStringLiteral("deny"));
        QCOMPARE(typeName(Bye {QStringLiteral("r")}), QStringLiteral("bye"));
    }

    void bitrateRequestOmitsUnsetFields()
    {
        const QByteArray json = encodeOne(BitrateRequest {1500, 0});
        QVERIFY(json.contains("\"vbr\":1500"));
        QVERIFY(!json.contains("\"abr\""));
    }

    void nonAsciiSurvivesTheRoundTrip()
    {
        // Display names are user-supplied and may be Arabic; a mojibake here is visible on
        // every other device in the room.
        const QString name = QString::fromUtf8(kAwkwardDisplayName);
        const auto parsed = parse(encodeOne(Hello {LocalStream::ProtocolVersion, QStringLiteral("receiver"), name,
            QStringLiteral("ua")}));
        const auto* hello = std::get_if<Hello>(&parsed);
        QVERIFY(hello);
        QCOMPARE(hello->name, name);
    }

    void everyVariantRoundTrips()
    {
        // A struct left out here is a struct whose field mapping nobody has checked.
        const QList<ControlMessage> messages {
            Hello {LocalStream::ProtocolVersion, QStringLiteral("receiver"), QStringLiteral("Phone"), QStringLiteral("ua")},
            Welcome {LocalStream::ProtocolVersion, QStringLiteral("abcd1234"), QStringLiteral("av"),
                QStringLiteral("Laptop"), QStringLiteral("v=0\r\n")},
            Offer {QStringLiteral("abcd1234"), 40000, 40001},
            Accept {41000, 41001, kAudioSsrc, kVideoSsrc},
            Deny {QString::fromLatin1(deny::Capacity), QStringLiteral("full")},
            KeyframeRequest {QStringLiteral("abcd1234")},
            BitrateRequest {1500, 48},
            ModeRequest {QStringLiteral("a")},
            ModeChanged {QStringLiteral("av")},
            KeyframeCoalesced {},
            ReceiverStats {10, 1, 2.5, 3},
            BroadcasterStats {30, 1500, 0.25, 1, 0},
            Bye {QString::fromLatin1(bye::Shutdown)},
            AuthRequest {QStringLiteral("abcd1234"), QStringLiteral("hunter2")},
            AuthResult {true, QString()},
            AuthResult {false, QStringLiteral("no")},
            Welcome {LocalStream::ProtocolVersion, QStringLiteral("abcd1234"), QStringLiteral("av"),
                QStringLiteral("Laptop"), QStringLiteral("v=0\r\n"),
                QString::fromLatin1(access::Password)},
        };

        for (const ControlMessage& message : messages) {
            const QByteArray json = encodeOne(message);
            QVERIFY2(!json.isEmpty(), qPrintable(QStringLiteral("empty JSON for %1")
                                                     .arg(typeName(message))));
            const ControlMessage back = parse(json);
            QVERIFY2(!std::holds_alternative<std::monostate>(back),
                qPrintable(QStringLiteral("%1 did not round-trip: %2")
                               .arg(typeName(message), QString::fromUtf8(json))));
            QCOMPARE(typeName(back), typeName(message));
        }
    }

    void authRequestAndResultKeepTheirFields()
    {
        const ControlMessage request =
            parse(encodeOne(AuthRequest {QStringLiteral("s1"), QStringLiteral("hunter2")}));
        const auto* sent = std::get_if<AuthRequest>(&request);
        QVERIFY(sent);
        QCOMPARE(sent->sessionId, QStringLiteral("s1"));
        QCOMPARE(sent->password, QStringLiteral("hunter2"));

        const ControlMessage refusal =
            parse(encodeOne(AuthResult {false, QStringLiteral("That password is not correct.")}));
        const auto* answered = std::get_if<AuthResult>(&refusal);
        QVERIFY(answered);
        QVERIFY(!answered->granted);
        QCOMPARE(answered->reason, QStringLiteral("That password is not correct."));
    }

    void anUnknownAccessModeIsTreatedAsPublic()
    {
        // A broadcaster from a future version could advertise a mode this build has never heard
        // of. Refusing the connection would be worse than letting someone in that the user
        // believes is closed, so the unknown value degrades to the open door and the mode names
        // on both platforms stay in step.
        const QByteArray line =
            "{\"t\":\"welcome\",\"v\":1,\"id\":\"abcd1234\",\"mode\":\"av\",\"name\":\"Laptop\","
            "\"sdp\":\"v=0\\r\\n\",\"access\":\"something-new\"}";
        QCOMPARE(std::get<Welcome>(parse(line)).access, QString::fromLatin1(access::Public));
    }

    void passwordLengthIsBounded()
    {
        // Both ends enforce the same bounds, and this is the shared definition of them.
        QVERIFY(!isValidAccessPassword(QString()));
        QVERIFY(!isValidAccessPassword(QStringLiteral("abc")));
        QVERIFY(isValidAccessPassword(QStringLiteral("abcd")));
        QVERIFY(isValidAccessPassword(QStringLiteral("abcdefghij")));
        QVERIFY(!isValidAccessPassword(QStringLiteral("abcdefghijk")));
    }
};

QTEST_GUILESS_MAIN(TestControlMessage)
#include "tst_controlmessage.moc"
