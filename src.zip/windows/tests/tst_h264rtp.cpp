#include <QtTest>

#include "protocol/H264Rtp.h"
#include "protocol/LocalStream.h"

using namespace localstream::protocol;
using namespace localstream::protocol::h264;

/**
 * H.264 RTP packetization (RFC 6184).
 *
 * The encoder's real output shape is the case that matters: MediaCodec emits an access unit
 * as an AUD, an SPS, a PPS and an IDR slice, and the IDR is far larger than one datagram.
 */
class TestH264Rtp : public QObject
{
    Q_OBJECT

private:
    /// A NAL of `size` bytes whose header carries `type`.
    static QByteArray nal(int type, int size)
    {
        QByteArray unit(size, char(0x00));
        // NRI = 3 so the type is not confused with a forbidden-zero-bit error.
        unit[0] = char(static_cast<char>((0x60 & 0xE0) | (type & 0x1F)));
        if (size > 1) {
            unit[1] = char(0xAA);
        }
        return unit;
    }

    /// Concatenates NALs into the AVCC form an encoder emits: 4-byte big-endian lengths.
    static QByteArray avcc(const QList<QByteArray>& nals)
    {
        QByteArray out;
        for (const QByteArray& unit : nals) {
            const auto length = static_cast<quint32>(unit.size());
            out.append(char((length >> 24) & 0xFF));
            out.append(char((length >> 16) & 0xFF));
            out.append(char((length >> 8) & 0xFF));
            out.append(char(length & 0xFF));
            out.append(unit);
        }
        return out;
    }

private slots:
    void splitAvccReadsBigEndianLengths()
    {
        const QList<QByteArray> nals {nal(NalSps, 8), nal(NalPps, 4)};
        const QList<QByteArray> split = splitAvcc(avcc(nals));
        QCOMPARE(split, nals);
    }

    void splitAvccStopsAtTruncatedTail()
    {
        // A partial final NAL must not be emitted: feeding a truncated SPS to the decoder
        // makes it reject the whole configuration.
        QByteArray buffer = avcc({nal(NalSps, 8)});
        buffer.append(QByteArray::fromHex("000000FF")); // claims 255 bytes, supplies none
        const QList<QByteArray> nals = splitAvcc(buffer);
        QCOMPARE(nals.size(), 1);
        QCOMPARE(nals.first().size(), 8);
    }

    void smallSingleNalStaysWhole()
    {
        const QList<QByteArray> payloads = packetize({nal(NalSliceIdr, 100)});
        QCOMPARE(payloads.size(), 1);
        QCOMPARE(payloads.first().size(), 100);
    }

    void largeNalIsFragmented()
    {
        const int size = LocalStream::RtpMaxPayload * 3;
        const QList<QByteArray> payloads = packetize({nal(NalSliceIdr, size)});

        // Never a payload larger than the MTU budget, or the datagram is fragmented by IP and
        // the loss statistics stop meaning anything.
        for (const QByteArray& payload : payloads) {
            QVERIFY(payload.size() <= LocalStream::RtpMaxPayload);
        }
        // The original byte count must survive, less the one header byte each FU indicator
        // replaces.
        int total = 0;
        for (const QByteArray& payload : payloads) {
            total += payload.size() - 2;
        }
        QCOMPARE(total, size - 1);
    }

    void customBudgetShrinksTheFragments()
    {
        // A broadcaster may lower the fragmentation budget to survive a lossy link. Every
        // payload must then respect the smaller budget, and the frame must still reassemble.
        const int budget = 600;
        const int size = budget * 4;
        const QList<QByteArray> payloads = packetize({nal(NalSliceIdr, size)}, budget);

        QVERIFY(payloads.size() > 1);
        for (const QByteArray& payload : payloads) {
            QVERIFY(payload.size() <= budget);
        }

        Depacketizer d;
        QByteArray accessUnit;
        for (int i = 0; i < payloads.size(); ++i) {
            accessUnit = d.accept(payloads.at(i), i == payloads.size() - 1);
        }
        QVERIFY(!accessUnit.isEmpty());
        QVERIFY(accessUnit.endsWith(nal(NalSliceIdr, size)));
    }

    void firstFragmentSetsStartAndLastSetsEnd()
    {
        const QList<QByteArray> payloads =
            packetize({nal(NalSliceIdr, LocalStream::RtpMaxPayload * 2)});
        QVERIFY(payloads.size() >= 2);
        QVERIFY(payloads.first().at(1) & 0x80);
        QVERIFY(!(payloads.first().at(1) & 0x40));
        QVERIFY(payloads.last().at(1) & 0x40);
        QVERIFY(!(payloads.last().at(1) & 0x80));
        QCOMPARE(int(payloads.first().at(1) & 0x1F), NalSliceIdr);
    }

    void leadingParameterSetsAreAggregated()
    {
        // The MediaCodec shape: AUD, SPS, PPS then a slice. One STAP-A saves two datagrams
        // and, more importantly, gets the parameter sets and the first picture into the same
        // frame boundary so a joining receiver can decode immediately.
        const QList<QByteArray> payloads = packetize(
            {nal(NalAud, 2), nal(NalSps, 8), nal(NalPps, 4), nal(NalSliceIdr, 400)});

        QCOMPARE(payloads.size(), 2);
        QCOMPARE(int(payloads.first().at(0) & 0x1F), TypeStapA);
        QCOMPARE(int(payloads.last().at(0) & 0x1F), NalSliceIdr);
    }

    void parameterSetOnlyAccessUnitIsNotAggregated()
    {
        // With no slice following there is nothing to carry the marker bit, so aggregating
        // would leave the units stuck in the receiver's buffer forever.
        const QList<QByteArray> payloads = packetize({nal(NalSps, 8), nal(NalPps, 4)});
        QCOMPARE(payloads.size(), 2);
        for (const QByteArray& payload : payloads) {
            // Parenthesised deliberately: `!=` binds tighter than `&`, so without the
            // brackets this reduces to `at(0) & (0x1F != TypeStapA)` and tests the wrong bit.
            QVERIFY((payload.at(0) & 0x1F) != TypeStapA);
        }
    }

    void emptyInputProducesNoPayloads()
    {
        QVERIFY(packetize({}).isEmpty());
    }

    void depacketizerReassemblesFragments()
    {
        const QByteArray original = nal(NalSliceIdr, 3000);
        const QList<QByteArray> payloads = packetize({original});

        Depacketizer d;
        QByteArray accessUnit;
        for (int i = 0; i < payloads.size(); ++i) {
            accessUnit = d.accept(payloads.at(i), i == payloads.size() - 1);
        }
        QVERIFY(!accessUnit.isEmpty());
        // Annex-B: the reassembled unit is the original NAL behind a start code.
        QVERIFY(accessUnit.endsWith(original));
        QCOMPARE(accessUnit.size(), 4 + original.size());
    }

    void depacketizerCapturesParameterSetsFromStap()
    {
        Depacketizer d;
        const QList<QByteArray> payloads =
            packetize({nal(NalSps, 8), nal(NalPps, 4), nal(NalSliceIdr, 100)});

        for (int i = 0; i < payloads.size(); ++i) {
            d.accept(payloads.at(i), i == payloads.size() - 1);
        }
        QVERIFY(d.hasParameterSets());
        QCOMPARE(d.sps(), nal(NalSps, 8));
        QCOMPARE(d.pps(), nal(NalPps, 4));
    }

    void depacketizerCapturesSingleNalParameterSets()
    {
        // The regression this guards: a parameter-set-only access unit is sent as individual
        // packets, and a receiver that only looked at VCL types silently never learned the
        // parameter sets, so the decoder could not be configured at all.
        const QList<QByteArray> payloads = packetize({nal(NalSps, 8), nal(NalPps, 4)});

        Depacketizer d;
        for (int i = 0; i < payloads.size(); ++i) {
            d.accept(payloads.at(i), i == payloads.size() - 1);
        }
        QVERIFY(d.hasParameterSets());
        QCOMPARE(d.sps(), nal(NalSps, 8));
        QCOMPARE(d.pps(), nal(NalPps, 4));
    }

    void markerMidFragmentDropsTheFrame()
    {
        // A truncated picture must be dropped, not emitted: a partial frame stays on screen
        // as a smear until the next good one, and a partial frame can also stall a decoder.
        Depacketizer d;
        const QList<QByteArray> payloads =
            packetize({nal(NalSliceIdr, LocalStream::RtpMaxPayload * 3)});

        QVERIFY(d.accept(payloads.first(), true).isEmpty());
    }

    void packetLossDiscardsPartialAccessUnitButKeepsParameterSets()
    {
        Depacketizer d;
        d.accept(nal(NalSps, 8), false);
        d.accept(nal(NalPps, 4), true);
        QVERIFY(d.hasParameterSets());

        const QList<QByteArray> fragments =
            packetize({nal(NalSliceIdr, LocalStream::RtpMaxPayload * 2)});
        QVERIFY(fragments.size() > 1);
        QVERIFY(d.accept(fragments.first(), false).isEmpty());

        d.discardCurrentAccessUnit();
        QVERIFY(d.accept(fragments.last(), true).isEmpty());
        QVERIFY(d.hasParameterSets());

        const QByteArray nextFrame = d.accept(nal(NalSliceIdr, 100), true);
        QVERIFY(!nextFrame.isEmpty());
        QVERIFY(nextFrame.endsWith(nal(NalSliceIdr, 100)));
    }

    void newFragmentSupersedesAnAbandonedOne()
    {
        Depacketizer d;
        const QList<QByteArray> payloads =
            packetize({nal(NalSliceIdr, LocalStream::RtpMaxPayload * 2)});

        // Three, not two: the FU indicator byte is dropped from the body, so 2 * RtpMaxPayload
        // bytes still spill into a third chunk. Assuming two left the sequence ending on a
        // middle fragment, and the test then passed for reasons unrelated to supersession.
        QCOMPARE(payloads.size(), 3);

        // Start a frame, abandon it mid-way, then start a fresh one and carry it through.
        d.accept(payloads.at(0), false);
        d.accept(payloads.at(1), false);
        d.accept(payloads.at(0), false);
        d.accept(payloads.at(1), false);
        const QByteArray out = d.accept(payloads.at(2), true);
        QVERIFY(!out.isEmpty());

        // The strongest form of the claim: the result is byte-identical to an uninterrupted
        // pass, so none of the abandoned attempt's bytes survived anywhere in the output.
        Depacketizer clean;
        QByteArray reference;
        for (int i = 0; i < payloads.size(); ++i) {
            reference = clean.accept(payloads.at(i), i == payloads.size() - 1);
        }
        QCOMPARE(out, reference);
    }

    void unterminatedFrameIsDiscarded()
    {
        Depacketizer d;
        d.accept(nal(NalSliceNonIdr, 50), false);
        QVERIFY(d.accept(QByteArray(), false).isEmpty());
    }

    void unsupportedAggregationsAreIgnored()
    {
        // STAP-B, MTAP and FU-B are not produced by either client; ignoring them keeps a
        // future peer's packet from being misread as a slice.
        Depacketizer d;
        for (int type : {TypeStapB, TypeMtap16, TypeMtap24, TypeFuB}) {
            QByteArray payload(10, char(0x00));
            payload[0] = char(type);
            QVERIFY(d.accept(payload, false).isEmpty());
        }
    }

    void resetClearsEverything()
    {
        Depacketizer d;
        d.accept(nal(NalSps, 8), false);
        d.accept(nal(NalPps, 4), false);
        QVERIFY(d.hasParameterSets());
        d.reset();
        QVERIFY(!d.hasParameterSets());
        QVERIFY(d.sps().isEmpty());
    }
};

QTEST_GUILESS_MAIN(TestH264Rtp)
#include "tst_h264rtp.moc"
