#pragma once

#include <QtGlobal>

namespace localstream::testvectors {

/**
 * Golden values shared with the Android implementation.
 *
 * These exist because both clients are developed on different machines with no shared test
 * runner: a change that is correct on one platform and wrong on the other produces a build
 * that passes everywhere and fails between two devices on the same Wi-Fi. They are the
 * Windows side of a cross-platform contract, so a drift is meant to be caught here.
 */

/// A session id is 8 lowercase hex digits.
inline constexpr int kSessionIdLength = 8;

/// `vs` is the *video* SSRC and `as` the *audio* SSRC. They are track initials, not
/// positions, and getting them backwards is invisible in a single-platform test.
inline constexpr quint32 kAudioSsrc = 0x11223344u;
inline constexpr quint32 kVideoSsrc = 0xAABBCCDDu;

/// A name chosen to break naive TXT escaping: it contains `=`, a space, and non-ASCII.
inline const char* kAwkwardDisplayName = "Ahmed = Boss \xD9\x85\xD9\x83\xD8\xAA\xD8\xAC\xD8\xA8";

} // namespace localstream::testvectors
