#include <QRegularExpression>
#include <QtTest>

#include "protocol/LocalStream.h"
#include "testvectors.h"

using namespace localstream;

/**
 * Session description, TXT record and SDP.
 *
 * The TXT record is the only thing a receiver learns before it opens a TCP connection, so a
 * field rendered wrongly here shows up as a mysterious connection failure rather than as a
 * parse error.
 */
class TestLocalStream : public QObject
{
    Q_OBJECT

private:
    static protocol::LocalStream::Description sample()
    {
        protocol::LocalStream::Description d;
        d.sessionId = QStringLiteral("a1b2c3d4");
        d.displayName = QStringLiteral("Test Device");
        d.mode = QString::fromLatin1(protocol::LocalStream::ModeAudioVideo);
        d.width = 1920;
        d.height = 1080;
        d.frameRate = 30;
        d.videoBitrateKbps = 2000;
        d.audioBitrateKbps = 48;
        d.controlPort = 51234;
        d.videoPort = 51235;
        d.audioPort = 51236;
        return d;
    }

private slots:
    void sessionIdIsEightHexDigits()
    {
        const QString id = protocol::LocalStream::newSessionId();
        QCOMPARE(id.size(), testvectors::kSessionIdLength);
        QVERIFY(QRegularExpression(QStringLiteral("^[0-9a-f]{8}$")).match(id).hasMatch());
    }

    void sessionIdsDiffer()
    {
        // A repeated id would make a stale receiver look like the current session.
        QVERIFY(protocol::LocalStream::newSessionId()
            != protocol::LocalStream::newSessionId());
    }

    void txtEscapesSeparatorsAndNonAscii()
    {
        const QString escaped = protocol::LocalStream::escapeTxtValue(
            QString::fromUtf8(testvectors::kAwkwardDisplayName));
        // `=` separates key from value and inside a TXT record; an unescaped one would split
        // the name and shift every following key.
        QVERIFY(!escaped.contains(QLatin1Char('=')));
        // Percent-escaped, so the record stays 7-bit safe as DNS-SD requires.
        QVERIFY(!escaped.contains(QString::fromUtf8("\xD9\x85")));
    }

    void txtRoundTripsEveryField()
    {
        const auto d = sample();
        const QString text = QString::fromUtf8(
            protocol::LocalStream::joinTxtEntries(protocol::LocalStream::txtEntries(d)));

        QVERIFY(text.contains(QStringLiteral("v=%1").arg(protocol::LocalStream::ProtocolVersion)));
        QVERIFY(text.contains(QStringLiteral("id=a1b2c3d4")));
        QVERIFY(text.contains(QStringLiteral("m=av")));
        QVERIFY(text.contains(QStringLiteral("vid=h264")));
        QVERIFY(text.contains(QStringLiteral("aud=opus")));
        QVERIFY(text.contains(QStringLiteral("dim=1920x1080")));
        QVERIFY(text.contains(QStringLiteral("fps=30")));
        QVERIFY(text.contains(QStringLiteral("vbr=2000")));
        QVERIFY(text.contains(QStringLiteral("abr=48")));
        QVERIFY(text.contains(QStringLiteral("vp=51235")));
        QVERIFY(text.contains(QStringLiteral("ap=51236")));
        QVERIFY(text.contains(QStringLiteral("cp=51234")));
    }

    void txtEntriesSurviveARoundTrip()
    {
        // The real contract: what a receiver parses must equal what a broadcaster built.
        const auto d = sample();
        const auto parsed =
            protocol::LocalStream::descriptionFromTxt(protocol::LocalStream::txtEntries(d));
        QVERIFY(parsed.has_value());

        QCOMPARE(parsed->sessionId, d.sessionId);
        QCOMPARE(parsed->displayName, d.displayName);
        QCOMPARE(parsed->mode, d.mode);
        QCOMPARE(parsed->width, 1920);
        QCOMPARE(parsed->height, 1080);
        QCOMPARE(parsed->frameRate, 30);
        QCOMPARE(parsed->videoBitrateKbps, 2000);
        QCOMPARE(parsed->audioBitrateKbps, 48);
        QCOMPARE(parsed->controlPort, 51234);
        QCOMPARE(parsed->videoPort, 51235);
        QCOMPARE(parsed->audioPort, 51236);
    }

    void txtPreservesAnAwkwardDisplayName()
    {
        // The name round-trips through percent-escaping. A display name that comes back
        // mangled is the most visible possible protocol bug: it is on screen in front of
        // every other device in the room.
        auto d = sample();
        d.displayName = QString::fromUtf8(testvectors::kAwkwardDisplayName);
        const auto parsed =
            protocol::LocalStream::descriptionFromTxt(protocol::LocalStream::txtEntries(d));
        QVERIFY(parsed.has_value());
        QCOMPARE(parsed->displayName, d.displayName);
    }

    void wireRecordIsLengthPrefixed()
    {
        // RFC 6763 section 6.1: every entry is a separate length-prefixed string. A
        // concatenated record would be read as one entry with a bogus length.
        const QByteArray wire = protocol::LocalStream::txtWireRecord(sample());
        const auto entries = protocol::LocalStream::txtEntries(sample());

        int at = 0;
        for (const QByteArray& entry : entries) {
            QVERIFY2(at < wire.size(), "ran out of wire record");
            const int length = static_cast<quint8>(wire.at(at));
            ++at;
            QCOMPARE(length, entry.size());
            QVERIFY(at + length <= wire.size());
            QCOMPARE(wire.mid(at, length), entry);
            at += length;
        }
        QCOMPARE(at, wire.size());
    }

    void rejectsAnIncompatibleVersion()
    {
        // Accepting an unknown version would mean proceeding on guessed defaults and failing
        // somewhere far less obvious than the connection itself.
        QList<QByteArray> entries {QByteArrayLiteral("v=999"), QByteArrayLiteral("id=abcd1234"),
            QByteArrayLiteral("cp=51234")};
        QVERIFY(!protocol::LocalStream::descriptionFromTxt(entries).has_value());
    }

    void rejectsARecordWithNoControlPort()
    {
        QList<QByteArray> entries {QByteArrayLiteral("v=1"), QByteArrayLiteral("id=abcd1234")};
        QVERIFY(!protocol::LocalStream::descriptionFromTxt(entries).has_value());
    }

    void rejectsARecordWithNoSessionId()
    {
        QList<QByteArray> entries {QByteArrayLiteral("v=1"), QByteArrayLiteral("cp=51234")};
        QVERIFY(!protocol::LocalStream::descriptionFromTxt(entries).has_value());
    }

    void rejectsAnUnknownMode()
    {
        QList<QByteArray> entries {QByteArrayLiteral("v=1"), QByteArrayLiteral("id=abcd1234"),
            QByteArrayLiteral("m=hologram"), QByteArrayLiteral("cp=51234")};
        QVERIFY(!protocol::LocalStream::descriptionFromTxt(entries).has_value());
    }

    void audioOnlyRecordOmitsVideoFields()
    {
        // A receiver that saw `vid=h264` alongside `m=a` would have to reconcile a
        // contradiction, whereas an absent key needs no interpretation.
        auto d = sample();
        d.mode = QString::fromLatin1(protocol::LocalStream::ModeAudioOnly);
        d.videoPort = 0;
        const QString text = QString::fromUtf8(
            protocol::LocalStream::joinTxtEntries(protocol::LocalStream::txtEntries(d)));
        QVERIFY(text.contains(QStringLiteral("m=a")));
        QVERIFY(!text.contains(QStringLiteral("vp=")));
        QVERIFY(!text.contains(QStringLiteral("vid=")));
        QVERIFY(!text.contains(QStringLiteral("vbr=")));
        // Audio is still advertised: the session is not video-only.
        QVERIFY(text.contains(QStringLiteral("aud=opus")));
        QVERIFY(text.contains(QStringLiteral("ap=51236")));

        const auto parsed =
            protocol::LocalStream::descriptionFromTxt(protocol::LocalStream::txtEntries(d));
        QVERIFY(parsed.has_value());
        QVERIFY(parsed->isAudioOnly());
        QCOMPARE(parsed->videoPort, 0);
    }

    void txtHasNoEmbeddedNewline()
    {
        // A newline would corrupt a name that is otherwise perfectly legal.
        auto d = sample();
        d.displayName = QStringLiteral("Line one\nLine two");
        const QByteArray joined = protocol::LocalStream::joinTxtEntries(
            protocol::LocalStream::txtEntries(d));
        QVERIFY(!joined.contains('\n'));
    }

    void sdpNamesBothTracks()
    {
        const QByteArray sdp = protocol::LocalStream::buildSdp(
            sample(), testvectors::kVideoSsrc, testvectors::kAudioSsrc);
        const QString text = QString::fromUtf8(sdp);
        QVERIFY(text.contains(QStringLiteral("m=video")));
        QVERIFY(text.contains(QStringLiteral("m=audio")));
        QVERIFY(text.contains(QStringLiteral("a=rtpmap:96")));
        QVERIFY(text.contains(QStringLiteral("a=rtpmap:97")));
        // Both SSRCs must appear; a receiver that validates SSRC needs both.
        QVERIFY(text.contains(QString::number(testvectors::kVideoSsrc)));
        QVERIFY(text.contains(QString::number(testvectors::kAudioSsrc)));
    }

    void descriptionReportsAudioOnly()
    {
        auto d = sample();
        QVERIFY(!d.isAudioOnly());
        d.mode = QString::fromLatin1(protocol::LocalStream::ModeAudioOnly);
        QVERIFY(d.isAudioOnly());
    }

    /**
     * The channel count a receiver reads back out of the SDP.
     *
     * Worth its own cases because the failure is silent: an Opus packet carries no channel count,
     * so a decoder opened with the wrong one does not error, it produces noise. Windows advertises
     * mono and Android stereo, and the receiver has no other way to know which is sending.
     */
    void channelCountIsReadFromTheSdp()
    {
        const QString ours = QString::fromUtf8(protocol::LocalStream::buildSdp(
            sample(), testvectors::kVideoSsrc, testvectors::kAudioSsrc));
        QCOMPARE(protocol::LocalStream::audioChannelsFromSdp(ours), 1);

        // Android's form, verbatim: a stereo broadcaster on the same network.
        const QString stereo = QStringLiteral(
            "m=audio 0 RTP/AVP 97\r\na=rtpmap:97 opus/48000/2\r\n");
        QCOMPARE(protocol::LocalStream::audioChannelsFromSdp(stereo), 2);
    }

    void channelCountFallsBackRatherThanGuessing()
    {
        // No audio section at all, as in an audio-less description.
        QCOMPARE(protocol::LocalStream::audioChannelsFromSdp(QStringLiteral("m=video 0 RTP/AVP 96\r\n")),
            1);

        // A count that would be handed to the decoder as a channel layout. 0 and 9 are not
        // layouts, and the resulting noise is far harder to trace than a refused parse.
        QCOMPARE(protocol::LocalStream::audioChannelsFromSdp(
                     QStringLiteral("a=rtpmap:97 opus/48000/0\r\n")),
            1);
        QCOMPARE(protocol::LocalStream::audioChannelsFromSdp(
                     QStringLiteral("a=rtpmap:97 opus/48000/9\r\n")),
            1);

        // Truncated, and the wrong payload type: the video track must not be read as the audio one.
        QCOMPARE(protocol::LocalStream::audioChannelsFromSdp(QStringLiteral("a=rtpmap:97 opus\r\n")),
            1);
        QCOMPARE(protocol::LocalStream::audioChannelsFromSdp(
                     QStringLiteral("a=rtpmap:96 H264/90000/2\r\na=rtpmap:97 opus/48000/1\r\n")),
            1);
    }

    void channelCountToleratesTheLineEndingsInUse()
    {
        // Browsers and third-party SDPs disagree about CRLF versus LF, and both appear in the
        // wild; a receiver that only handles one reads no channel count and guesses.
        QCOMPARE(protocol::LocalStream::audioChannelsFromSdp(
                     QStringLiteral("a=rtpmap:97 opus/48000/2\n")),
            2);
        QCOMPARE(protocol::LocalStream::audioChannelsFromSdp(
                     QStringLiteral("a=rtpmap:97 opus/48000/2\r\n")),
            2);
    }
};

QTEST_GUILESS_MAIN(TestLocalStream)
#include "tst_protocol.moc"
