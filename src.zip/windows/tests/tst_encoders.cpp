#include <QCoreApplication>
#include <QElapsedTimer>
#include <QList>
#include <QThread>
#include <QTest>

#include <cmath>

extern "C" {
#include <libavcodec/avcodec.h>
#include <libavutil/channel_layout.h>
}

#include "capture/Encoders.h"
#include "capture/FrameSource.h"
#include "protocol/H264Rtp.h"

using namespace localstream;

/**
 * Exercises the real encoders rather than a stub, because the property being checked is a
 * property of libx264's output on this build. A mock would only prove what it was told to.
 */
class EncodersTest : public QObject
{
    Q_OBJECT

private slots:
    void videoEmitsAvccRatherThanAnnexB();
    void videoUnitsParseWithTheShippedSplitter();
    void spsAndPpsArePresentAndPlausible();
    void spsDeclaresTheColourItEncoded();
    void keyframeRequestForcesAnIdr();
    void audioFramesAreTwentyMilliseconds();
    void audioResamplesDeviceFormatToEncoderRate();
    void rawOpusPacketsDecodeWithoutExtradata();
    void audioLevelIsNormalisedAcrossSources();
};

namespace {

/// Collects encoded output from a source that blocks until stopped.
struct VideoRun
{
    QList<capture::EncodedVideo> units;
};

/// Runs [source] on a worker thread for [budgetMs] and returns whatever it encoded.
///
/// The sources block in start() until stop(), so calling start() directly from a test would hang
/// rather than fail. The worker is a QObject moved to the thread: posting an invocation to a
/// QThread object would instead be delivered on the thread that *owns* the QThread, which is the
/// test thread, defeating the whole arrangement.
VideoRun pumpVideo(capture::FrameSource& source, capture::VideoEncoder& encoder,
    int budgetMs)
{
    VideoRun run;

    class Pump : public QObject
    {
    public:
        Pump(capture::FrameSource& s, capture::VideoEncoder& e, VideoRun& r)
            : source_(s), encoder_(e), run_(r)
        {
        }
        void run()
        {
            source_.start([this](const capture::VideoSample& sample) {
                encoder_.encode(sample, [this](const capture::EncodedVideo& frame) {
                    run_.units.append(frame);
                });
            },
                [](const capture::AudioSample&) {}, nullptr);
        }

    private:
        capture::FrameSource& source_;
        capture::VideoEncoder& encoder_;
        VideoRun& run_;
    };

    QThread worker;
    Pump pump(source, encoder, run);
    pump.moveToThread(&worker);
    worker.start();
    QMetaObject::invokeMethod(&pump, &Pump::run, Qt::QueuedConnection);

    QElapsedTimer clock;
    clock.start();
    while (clock.elapsed() < budgetMs && run.units.size() < 6) {
        QCoreApplication::processEvents(QEventLoop::AllEvents, 10);
    }
    source.stop();
    worker.quit();
    worker.wait(3000);
    return run;
}

/// Same shape for audio, collecting packets instead of access units.
QList<capture::EncodedAudio> pumpAudio(capture::FrameSource& source,
    capture::AudioEncoder& encoder, int budgetMs)
{
    QList<capture::EncodedAudio> packets;

    class Pump : public QObject
    {
    public:
        Pump(capture::FrameSource& s, capture::AudioEncoder& e, QList<capture::EncodedAudio>& p)
            : source_(s), encoder_(e), packets_(p)
        {
        }
        void run()
        {
            source_.start([](const capture::VideoSample&) {},
                [this](const capture::AudioSample& sample) {
                    encoder_.encode(sample, [this](const capture::EncodedAudio& audio) {
                        packets_.append(audio);
                    });
                },
                nullptr);
        }

    private:
        capture::FrameSource& source_;
        capture::AudioEncoder& encoder_;
        QList<capture::EncodedAudio>& packets_;
    };

    QThread worker;
    Pump pump(source, encoder, packets);
    pump.moveToThread(&worker);
    worker.start();
    QMetaObject::invokeMethod(&pump, &Pump::run, Qt::QueuedConnection);

    QElapsedTimer clock;
    clock.start();
    while (clock.elapsed() < budgetMs && packets.size() < 5) {
        QCoreApplication::processEvents(QEventLoop::AllEvents, 10);
    }
    source.stop();
    worker.quit();
    worker.wait(3000);
    return packets;
}

/// Reads a bitstream the way H.264 writes it: most significant bit of the first byte first,
/// within each byte least significant bit first.
class BitReader
{
public:
    explicit BitReader(const QByteArray& bytes)
        : bytes_(bytes)
    {
    }

    bool hasBits(int count) const { return position_ + count <= bytes_.size() * 8; }

    unsigned bit()
    {
        if (!hasBits(1)) {
            exhausted_ = true;
            return 0;
        }
        const int byte = position_ / 8;
        const int offset = 7 - (position_ % 8);
        ++position_;
        return (static_cast<quint8>(bytes_.at(byte)) >> offset) & 1u;
    }

    unsigned bits(int count)
    {
        unsigned value = 0;
        for (int i = 0; i < count; ++i) {
            value = (value << 1) | bit();
        }
        return value;
    }

    /// Exp-Golomb, the variable length unsigned integer the syntax is written in.
    unsigned ue()
    {
        int leadingZeros = 0;
        while (!exhausted_ && bit() == 0) {
            ++leadingZeros;
            if (leadingZeros > 32) {
                exhausted_ = true;
                return 0;
            }
        }
        if (exhausted_ || leadingZeros == 0) {
            return 0;
        }
        return (1u << leadingZeros) - 1 + bits(leadingZeros);
    }

    int se() { const int value = ue(); return (value % 2) ? (value + 1) / 2 : -(value / 2); }

    bool exhausted() const { return exhausted_; }

private:
    QByteArray bytes_;
    int position_ = 0;
    bool exhausted_ = false;
};

/// The bits a NAL actually carries: its header byte removed and the emulation prevention bytes
/// dropped, because those exist only to keep a start code from appearing inside the payload and
/// are not part of the syntax the standard defines.
QByteArray readSyntax(const QByteArray& nal)
{
    QByteArray syntax;
    int zeros = 0;
    for (int i = 1; i < nal.size(); ++i) { // index 0 is the NAL header
        const auto byte = static_cast<quint8>(nal.at(i));
        if (zeros >= 2 && byte == 0x03) {
            zeros = 0;
            continue;
        }
        syntax.append(char(byte));
        zeros = (byte == 0) ? zeros + 1 : 0;
    }
    return syntax;
}

/// The colour a stream says it is, as taken from its own sequence parameter set.
///
/// Reading it out of the bitstream rather than off the encoder's settings is the point: the
/// settings are only an intention, and what a receiver sees is the SPS. An encoder asked for a
/// colour and left with none -- because the option naming it was misspelled, or silently
/// ignored -- produces an indistinguishable stream here.
struct ColourDescription
{
    bool vuiPresent = false;
    bool fullRange = false;
    bool described = false;
    int primaries = -1;
    int transfer = -1;
    int matrix = -1;

    bool isSmpte170mLimited() const
    {
        // 6 is SMPTE170M in all three fields, which is what "BT.601" means in a VUI: the
        // primaries and transfer of 525-line television, and the BT.601 matrix.
        constexpr int kSmpte170m = 6;
        return described && primaries == kSmpte170m && transfer == kSmpte170m
            && matrix == kSmpte170m && !fullRange;
    }
};

/// Walks the SPS far enough to reach the colour description, and stops there.
ColourDescription readColour(const QByteArray& sps)
{
    ColourDescription colour;
    if (sps.size() < 4 || protocol::h264::nalType(sps) != 7) {
        return colour;
    }
    const QByteArray syntax = readSyntax(sps);
    BitReader bits(syntax);

    const unsigned profile = bits.bits(8);
    bits.bits(8); // constraint flags and reserved
    bits.bits(8); // level_idc
    bits.ue(); // seq_parameter_set_id

    // The chroma and bit depth block only exists in the high profiles. Anything that follows it
    // is read from a different place, so it has to be stepped over rather than ignored.
    if (profile == 100 || profile == 110 || profile == 122 || profile == 244 || profile == 44
        || profile == 83 || profile == 86 || profile == 118 || profile == 128 || profile == 138
        || profile == 139 || profile == 134 || profile == 135) {
        const unsigned chromaFormat = bits.ue();
        if (chromaFormat == 3) {
            bits.bit(); // separate_colour_plane_flag
        }
        bits.ue(); // bit_depth_luma_minus8
        bits.ue(); // bit_depth_chroma_minus8
        bits.bit(); // qpprime_y_zero_transform_bypass_flag
        if (bits.bit()) { // seq_scaling_matrix_present_flag
            const int lists = (chromaFormat != 3) ? 8 : 12;
            for (int i = 0; i < lists; ++i) {
                if (bits.bit()) { // seq_scaling_list_present_flag
                    const int size = (i < 6) ? 16 : 64;
                    int lastScale = 8;
                    int nextScale = 8;
                    for (int j = 0; j < size; ++j) {
                        if (nextScale != 0) {
                            const int delta = bits.se();
                            nextScale = (lastScale + delta + 256) % 256;
                        }
                        lastScale = (nextScale == 0) ? lastScale : nextScale;
                    }
                }
            }
        }
    }

    bits.ue(); // log2_max_frame_num_minus4
    const unsigned pocType = bits.ue();
    if (pocType == 0) {
        bits.ue(); // log2_max_pic_order_cnt_lsb_minus4
    } else if (pocType == 1) {
        bits.bit(); // delta_pic_order_always_zero_flag
        bits.se(); // offset_for_non_ref_pic
        bits.se(); // offset_for_top_to_bottom_field
        const int cycle = static_cast<int>(bits.ue());
        for (int i = 0; i < cycle; ++i) {
            bits.se(); // offset_for_ref_frame
        }
    }

    bits.ue(); // max_num_ref_frames
    bits.bit(); // gaps_in_frame_num_value_allowed_flag
    bits.ue(); // pic_width_in_mbs_minus1
    bits.ue(); // pic_height_in_map_units_minus1
    if (!bits.bit()) { // frame_mbs_only_flag
        bits.bit(); // mb_adaptive_frame_field_flag
    }
    bits.bit(); // direct_8x8_inference_flag
    if (bits.bit()) { // frame_cropping_flag
        for (int i = 0; i < 4; ++i) {
            bits.ue(); // crop offsets
        }
    }

    if (!bits.bit()) { // vui_parameters_present_flag
        return colour;
    }
    colour.vuiPresent = true;

    if (bits.bit()) { // aspect_ratio_info_present_flag
        const unsigned idc = bits.bits(8);
        if (idc == 255) { // Extended_SAR
            bits.bits(16);
            bits.bits(16);
        }
    }
    if (bits.bit()) { // overscan_info_present_flag
        bits.bit(); // overscan_appropriate_flag
    }
    if (bits.bit()) { // video_signal_type_present_flag
        bits.bits(3); // video_format
        colour.fullRange = bits.bit() != 0;
        if (bits.bit()) { // colour_description_present_flag
            colour.described = true;
            colour.primaries = static_cast<int>(bits.bits(8));
            colour.transfer = static_cast<int>(bits.bits(8));
            colour.matrix = static_cast<int>(bits.bits(8));
        }
    }
    return colour;
}

/// Encodes a 440 Hz mono sine at [amplitude] and returns the RMS of the decoded second half.
///
/// The first half is discarded because the automatic gain control eases toward its target over a
/// few hundred milliseconds; the settled level is the property under test. The decoder's sample
/// format is read from the frame rather than assumed, because libopus emits planar float and
/// reading that as S16 yields noise.
double decodedRmsAfterGainControl(double amplitude, bool normalize = true)
{
    constexpr int rate = 48000;
    constexpr double kPi = 3.14159265358979323846;
    constexpr double seconds = 1.6;
    constexpr int chunkFrames = 960;

    capture::AudioEncoder encoder(rate, 1, 48, normalize);
    if (!encoder.isOpen()) {
        return 0.0;
    }

    QList<capture::EncodedAudio> packets;
    const int totalFrames = static_cast<int>(rate * seconds);
    for (int start = 0; start < totalFrames; start += chunkFrames) {
        const int frames = qMin(chunkFrames, totalFrames - start);
        QByteArray data(frames * static_cast<int>(sizeof(qint16)), Qt::Uninitialized);
        auto* samples = reinterpret_cast<qint16*>(data.data());
        for (int i = 0; i < frames; ++i) {
            const double t = static_cast<double>(start + i) / rate;
            samples[i] = static_cast<qint16>(amplitude * std::sin(2 * kPi * 440 * t));
        }
        capture::AudioSample sample;
        sample.data = data;
        sample.samples = frames;
        sample.sampleRate = rate;
        sample.channels = 1;
        sample.format = AV_SAMPLE_FMT_S16;
        encoder.encode(sample, [&packets](const capture::EncodedAudio& audio) {
            packets.append(audio);
        });
    }

    const AVCodec* codec = avcodec_find_decoder(AV_CODEC_ID_OPUS);
    if (!codec) {
        return 0.0;
    }
    AVCodecContext* context = avcodec_alloc_context3(codec);
    if (!context) {
        return 0.0;
    }
    av_channel_layout_default(&context->ch_layout, 1);
    context->sample_rate = rate;
    if (avcodec_open2(context, codec, nullptr) < 0) {
        avcodec_free_context(&context);
        return 0.0;
    }

    AVPacket* packet = av_packet_alloc();
    AVFrame* frame = av_frame_alloc();
    double sumSquares = 0.0;
    int counted = 0;
    int index = 0;
    const int skip = static_cast<int>(packets.size() / 2);
    for (const capture::EncodedAudio& audio : packets) {
        if (index++ < skip) {
            continue;
        }
        packet->data = reinterpret_cast<uint8_t*>(const_cast<char*>(audio.packet.constData()));
        packet->size = audio.packet.size();
        if (avcodec_send_packet(context, packet) < 0) {
            continue;
        }
        while (avcodec_receive_frame(context, frame) == 0) {
            for (int i = 0; i < frame->nb_samples; ++i) {
                double value = 0.0;
                switch (frame->format) {
                case AV_SAMPLE_FMT_S16:
                case AV_SAMPLE_FMT_S16P:
                    value = reinterpret_cast<const qint16*>(frame->data[0])[i] / 32768.0;
                    break;
                case AV_SAMPLE_FMT_FLT:
                case AV_SAMPLE_FMT_FLTP:
                    value = reinterpret_cast<const float*>(frame->data[0])[i];
                    break;
                default:
                    break;
                }
                sumSquares += value * value;
                ++counted;
            }
            av_frame_unref(frame);
        }
    }
    av_frame_free(&frame);
    av_packet_free(&packet);
    avcodec_free_context(&context);

    return counted > 0 ? std::sqrt(sumSquares / counted) : 0.0;
}

} // namespace

void EncodersTest::videoEmitsAvccRatherThanAnnexB()
{
    capture::TestPatternSource source(320, 240, 30);
    capture::VideoEncoder encoder(320, 240, 30, 500);
    QVERIFY(encoder.isOpen());

    const VideoRun run = pumpVideo(source, encoder, 2500);
    QVERIFY(!run.units.isEmpty());

    for (const capture::EncodedVideo& unit : run.units) {
        const QByteArray& au = unit.accessUnit;
        QVERIFY2(au.size() > 4, "access unit too short to hold a length prefix");
        // An Annex B start code here would mean the conversion regressed. Only the 4-byte form
        // is checked: a 3-byte-looking 00 00 01 is a legitimate small AVCC length prefix, so
        // treating it as a start code here would reject correct output.
        QVERIFY2(!au.startsWith(QByteArray("\x00\x00\x00\x01", 4)),
            "encoder emitted an Annex B start code; expected an AVCC length prefix");

        // Every NAL in the buffer must be reachable, and each prefix must describe exactly the
        // bytes that follow it. Checking the first prefix against the whole buffer would be
        // wrong on its own, since an access unit legitimately holds several NALs; the useful
        // invariant is that walking the prefixes consumes the buffer exactly.
        int at = 0;
        int nalCount = 0;
        while (at + 4 <= au.size()) {
            const quint32 declared
                = (static_cast<quint8>(au.at(at)) << 24)
                | (static_cast<quint8>(au.at(at + 1)) << 16)
                | (static_cast<quint8>(au.at(at + 2)) << 8) | static_cast<quint8>(au.at(at + 3));
            QVERIFY2(declared > 0, "AVCC length prefix of zero");
            QVERIFY2(declared <= static_cast<quint32>(au.size() - at - 4),
                qPrintable(QStringLiteral("NAL at offset %1 declares %2 bytes but only %3 remain")
                               .arg(at)
                               .arg(declared)
                               .arg(au.size() - at - 4)));
            at += 4 + static_cast<int>(declared);
            ++nalCount;
            if (at >= au.size()) {
                break;
            }
        }
        QVERIFY2(at == au.size(),
            qPrintable(QStringLiteral("AVCC walk ended at %1 of %2 bytes")
                           .arg(at)
                           .arg(au.size())));
        QVERIFY2(nalCount > 0, "access unit contained no NAL");
    }
}

void EncodersTest::videoUnitsParseWithTheShippedSplitter()
{
    // The invariant that actually matters: protocol::h264::splitAvcc -- exactly what
    // RtpSender::sendVideo calls -- must recover the NALs, and each NAL must be well formed.
    capture::TestPatternSource source(320, 240, 30);
    capture::VideoEncoder encoder(320, 240, 30, 500);
    QVERIFY(encoder.isOpen());

    const VideoRun run = pumpVideo(source, encoder, 2500);
    QVERIFY(!run.units.isEmpty());

    int sliceCount = 0;
    for (const capture::EncodedVideo& unit : run.units) {
        const QList<QByteArray> nals = protocol::h264::splitAvcc(unit.accessUnit);
        QVERIFY2(!nals.isEmpty(), "splitAvcc found no NALs in an encoded access unit");
        for (const QByteArray& nal : nals) {
            QVERIFY(!nal.isEmpty());
            const int type = protocol::h264::nalType(nal);
            QVERIFY2(type != 0 && type <= 31, "implausible NAL type from the encoder");
            if (type >= 1 && type <= 5) {
                ++sliceCount;
            }
        }
    }
    // Without a VCL NAL there is no picture, so a run that produced none is a failure even
    // though units came out.
    QVERIFY2(sliceCount > 0, "encoded frames contained no VCL NAL");

    // And the packetiser must accept them, producing payloads a receiver could assemble.
    const QList<QByteArray> payloads = protocol::h264::packetize(
        protocol::h264::splitAvcc(run.units.first().accessUnit));
    QVERIFY(!payloads.isEmpty());
}

void EncodersTest::spsAndPpsArePresentAndPlausible()
{
    // Asked after at least one frame, because that is the only point at which they exist: with
    // repeat-headers on the parameter sets arrive inside the first keyframe, and libav does not
    // copy them into the extradata. A broadcaster publishes its SDP once the pipeline is running,
    // so this is the real usage rather than a convenient one.
    capture::TestPatternSource source(320, 240, 30);
    capture::VideoEncoder encoder(320, 240, 30, 500);
    QVERIFY(encoder.isOpen());

    const VideoRun run = pumpVideo(source, encoder, 2500);
    QVERIFY(!run.units.isEmpty());

    const QByteArray sps = encoder.sps();
    const QByteArray pps = encoder.pps();

    QVERIFY2(!sps.isEmpty(), "no SPS after encoding");
    QVERIFY2(!pps.isEmpty(), "no PPS after encoding");
    // A parameter set carries its own type in the low five bits of its first byte after the
    // header byte: SPS is 7 and PPS is 8.
    QVERIFY2(protocol::h264::nalType(sps) == 7,
        qPrintable(QStringLiteral("SPS NAL type is %1, expected 7")
                       .arg(protocol::h264::nalType(sps))));
    QVERIFY2(protocol::h264::nalType(pps) == 8,
        qPrintable(QStringLiteral("PPS NAL type is %1, expected 8")
                       .arg(protocol::h264::nalType(pps))));

    // Both must also survive the packetiser, because that is the path a receiver's parameters
    // actually travel over.
    const QList<QByteArray> payloads = protocol::h264::packetize({sps, pps});
    QVERIFY2(!payloads.isEmpty(), "SPS/PPS could not be packetised");
}

void EncodersTest::spsDeclaresTheColourItEncoded()
{
    // The one thing every other test here cannot check. The picture that comes out of the encoder
    // is BT.601 limited range, because that is what the BGRA-to-YUV conversion below has always
    // produced, and every consumer of this stream assumes it. A receiver can only act on that if
    // the stream says so: with no colour description in the SPS it has to guess, and the guesses
    // that are wrong -- full range on a limited-range picture, BT.709 on a BT.601 one -- land as a
    // green cast over everything dark. Saying it costs four fields and no picture change at all.
    //
    // It was being said, in words, through x264-params, and x264 was throwing the words away:
    // "bt601" is not a colour it knows. Rejected options do not fail avcodec_open2, they do not
    // fail the tests either -- this encoder and this suite's own decoder make the same
    // assumption, so a round trip through both cancels the error out and looks perfect. It only
    // shows on a machine that did not make the assumption. So the check reads the SPS.
    capture::TestPatternSource source(320, 240, 30);
    capture::VideoEncoder encoder(320, 240, 30, 500);
    QVERIFY(encoder.isOpen());

    const VideoRun run = pumpVideo(source, encoder, 2500);
    QVERIFY(!run.units.isEmpty());

    const QByteArray sps = encoder.sps();
    QVERIFY2(!sps.isEmpty(), "no SPS after encoding");

    const ColourDescription colour = readColour(sps);
    QVERIFY2(colour.vuiPresent,
        "the SPS carries no VUI at all, so the stream says nothing about its own colour");
    QVERIFY2(colour.described,
        "the SPS has a VUI but no colour description, so range and matrix are still up to the "
        "receiver's guess");
    QVERIFY2(!colour.fullRange,
        "the stream is encoded limited range but the SPS declares it full, which lifts the dark "
        "end of the picture and shifts hue");
    QVERIFY2(colour.primaries == 6 && colour.transfer == 6 && colour.matrix == 6,
        qPrintable(QStringLiteral("colour described as primaries=%1 transfer=%2 matrix=%3, "
                                   "expected 6/6/6 for BT.601")
                       .arg(colour.primaries)
                       .arg(colour.transfer)
                       .arg(colour.matrix)));
}

void EncodersTest::keyframeRequestForcesAnIdr()
{
    capture::TestPatternSource source(320, 240, 30);
    capture::VideoEncoder encoder(320, 240, 30, 500);
    QVERIFY(encoder.isOpen());

    // Enough frames for the encoder to settle into P-frames, then ask for a keyframe and confirm
    // the very next unit is one. Without this a receiver joining later would wait up to a full
    // keyint before it could decode anything.
    const VideoRun run = pumpVideo(source, encoder, 3000);
    QVERIFY(run.units.size() >= 2);
    // The first unit of a session must be a keyframe or a receiver that connects immediately
    // has nothing to decode until the next one.
    QVERIFY2(run.units.first().keyframe,
        qPrintable(QStringLiteral("first unit was %1 bytes and not flagged as a keyframe")
                       .arg(run.units.first().accessUnit.size())));

    encoder.requestKeyframe();
    VideoRun afterRequest;
    class Pump : public QObject
    {
    public:
        Pump(capture::FrameSource& s, capture::VideoEncoder& e, VideoRun& r)
            : source_(s), encoder_(e), run_(r)
        {
        }
        void run()
        {
            source_.start([this](const capture::VideoSample& sample) {
                encoder_.encode(sample, [this](const capture::EncodedVideo& f) {
                    run_.units.append(f);
                });
            },
                [](const capture::AudioSample&) {}, nullptr);
        }

    private:
        capture::FrameSource& source_;
        capture::VideoEncoder& encoder_;
        VideoRun& run_;
    };
    QThread worker;
    Pump pump(source, encoder, afterRequest);
    pump.moveToThread(&worker);
    worker.start();
    QMetaObject::invokeMethod(&pump, &Pump::run, Qt::QueuedConnection);
    QElapsedTimer clock;
    clock.start();
    while (clock.elapsed() < 1500 && afterRequest.units.isEmpty()) {
        QCoreApplication::processEvents(QEventLoop::AllEvents, 10);
    }
    source.stop();
    worker.quit();
    worker.wait(3000);

    QVERIFY2(!afterRequest.units.isEmpty(), "no unit produced after the keyframe request");
    QVERIFY2(afterRequest.units.first().keyframe,
        "requestKeyframe() did not produce a keyframe on the next frame");
}

void EncodersTest::audioFramesAreTwentyMilliseconds()
{
    capture::TestToneSource source(48000, 1);
    capture::AudioEncoder encoder(48000, 1, 48);
    QVERIFY(encoder.isOpen());

    const QList<capture::EncodedAudio> packets = pumpAudio(source, encoder, 2500);
    QVERIFY(!packets.isEmpty());

    // 48 packets per second at 20 ms each. Allowed some slack for the pump's scheduling, but
    // tight enough that a wrong frame size -- 1024 samples per packet, say -- fails.
    int totalBytes = 0;
    for (const capture::EncodedAudio& audio : packets) {
        QVERIFY(!audio.packet.isEmpty());
        totalBytes += audio.packet.size();
    }

    // A 20 ms Opus packet at 48 kbps is about 120 bytes. Far outside that means the frame size
    // is wrong even if a packet was produced.
    const int average = totalBytes / static_cast<int>(packets.size());
    QVERIFY2(average > 40 && average < 250,
        qPrintable(QStringLiteral("average Opus packet is %1 bytes, expected roughly 120")
                       .arg(average)));
}

void EncodersTest::audioResamplesDeviceFormatToEncoderRate()
{
    // A device running at 44.1 kHz in stereo -- the common default for a Realtek microphone --
    // has to be converted to the encoder's 48 kHz mono. Treating the interleaved stereo samples
    // as if they were already 48 kHz mono is what made playback run at roughly half speed, so
    // the packet count -- one per 20 ms of *real* audio -- is the property to pin.
    capture::AudioEncoder encoder(48000, 1, 48);
    QVERIFY(encoder.isOpen());

    constexpr int inRate = 44100;
    constexpr int inChannels = 2;
    constexpr int chunkFrames = 1024;
    constexpr double seconds = 1.5;
    constexpr double kPi = 3.14159265358979323846;
    const int totalFrames = static_cast<int>(inRate * seconds);

    QList<capture::EncodedAudio> packets;
    for (int start = 0; start < totalFrames; start += chunkFrames) {
        const int frames = qMin(chunkFrames, totalFrames - start);
        QByteArray data(frames * inChannels * static_cast<int>(sizeof(qint16)),
            Qt::Uninitialized);
        auto* samples = reinterpret_cast<qint16*>(data.data());
        for (int i = 0; i < frames; ++i) {
            const double t = static_cast<double>(start + i) / inRate;
            const auto value = static_cast<qint16>(16000 * std::sin(2 * kPi * 440 * t));
            samples[i * inChannels] = value;
            samples[i * inChannels + 1] = value;
        }

        capture::AudioSample sample;
        sample.data = data;
        sample.samples = frames;
        sample.sampleRate = inRate;
        sample.channels = inChannels;
        sample.format = AV_SAMPLE_FMT_S16;
        encoder.encode(sample, [&packets](const capture::EncodedAudio& audio) {
            packets.append(audio);
        });
    }

    // 1.5 s of audio is 75 twenty-millisecond frames. Reading the format wrong would produce
    // 44100/480 ~= 92 frames per second instead, so anything above 85 means this regressed.
    QVERIFY2(packets.size() >= 65 && packets.size() <= 85,
        qPrintable(QStringLiteral("produced %1 packets, expected about 75").arg(packets.size())));
}

// The receiver's exact codec setup: a raw Opus decoder with a channel layout and sample rate but
// no OpusHead extradata, fed the packets an encoder emits. RFC 7587 puts the packet itself on the
// wire, and this is the path Android->Windows takes, so if the decoder needs extradata this fails.
void EncodersTest::rawOpusPacketsDecodeWithoutExtradata()
{
    capture::TestToneSource source(48000, 1);
    capture::AudioEncoder encoder(48000, 1, 48);
    QVERIFY(encoder.isOpen());

    const QList<capture::EncodedAudio> packets = pumpAudio(source, encoder, 1500);
    QVERIFY(!packets.isEmpty());

    const AVCodec* codec = avcodec_find_decoder(AV_CODEC_ID_OPUS);
    QVERIFY(codec != nullptr);
    qInfo("decoder selected: %s", codec->name);

    // Android captures mono but its SDP advertises `opus/48000/2`, so the receiver opens a
    // stereo decoder and feeds it mono packets. Both layouts are tried: the correct one must
    // decode, and the one the wire actually selects must too, or the broadcast is silent.
    const int channelCounts[] = {1, 2};
    for (const int channels : channelCounts) {
        AVCodecContext* context = avcodec_alloc_context3(codec);
        QVERIFY(context != nullptr);
        av_channel_layout_default(&context->ch_layout, channels);
        context->sample_rate = 48000;
        const int opened = avcodec_open2(context, codec, nullptr);
        qInfo("channels=%d avcodec_open2 -> %d (extradata_size=%d)", channels, opened,
            context->extradata_size);
        QVERIFY2(opened >= 0, "the Opus decoder did not open without extradata");

        AVPacket* packet = av_packet_alloc();
        AVFrame* frame = av_frame_alloc();
        QVERIFY(packet != nullptr && frame != nullptr);

        int decoded = 0;
        int sentFailures = 0;
        for (const capture::EncodedAudio& audio : packets) {
            packet->data =
                reinterpret_cast<uint8_t*>(const_cast<char*>(audio.packet.constData()));
            packet->size = audio.packet.size();
            if (avcodec_send_packet(context, packet) < 0) {
                ++sentFailures;
                continue;
            }
            while (avcodec_receive_frame(context, frame) == 0) {
                ++decoded;
                av_frame_unref(frame);
            }
        }
        qInfo("channels=%d packets=%d decoded=%d sendFailures=%d", channels,
            static_cast<int>(packets.size()), decoded, sentFailures);

        av_frame_free(&frame);
        av_packet_free(&packet);
        avcodec_free_context(&context);

        QVERIFY2(decoded > 0,
            qPrintable(QStringLiteral("a %1-channel Opus decoder decoded none of the mono packets")
                           .arg(channels)));
    }
}

// A receiver must hear the broadcast at the same level no matter how loud the broadcaster's
// machine is set or which device is captured. Windows loopback capture carries the post-volume
// signal, so a quiet source is exactly what a broadcaster whose system volume is turned down
// produces. Two inputs 25 dB apart must come out close together, which is what the AGC is for.
void EncodersTest::audioLevelIsNormalisedAcrossSources()
{
    const double quiet = decodedRmsAfterGainControl(800.0);
    const double loud = decodedRmsAfterGainControl(20000.0);
    qInfo("decoded RMS: quiet=%.4f loud=%.4f", quiet, loud);

    QVERIFY2(quiet > 0.02,
        qPrintable(QStringLiteral("the quiet source was not lifted to an audible level (%1)")
                       .arg(quiet)));
    QVERIFY2(loud > 0.0, "the loud source decoded to silence");

    // Opus is lossy and the AGC settles over a few hundred milliseconds, so exact equality is not
    // the point. A loud source that is still several times the quiet one means no normalisation.
    const double ratio = loud > quiet ? loud / quiet : quiet / loud;
    QVERIFY2(ratio < 2.5,
        qPrintable(QStringLiteral("quiet=%1 loud=%2 ratio=%3, expected both to normalise")
                       .arg(quiet)
                       .arg(loud)
                       .arg(ratio)));

    // The toggle must actually bypass it: the same quiet source, normalisation off, has to stay
    // quiet rather than being lifted.
    const double raw = decodedRmsAfterGainControl(800.0, false);
    qInfo("decoded RMS with normalisation off: %f", raw);
    QVERIFY2(raw < 0.03,
        qPrintable(QStringLiteral("normalisation off still produced RMS %1, expected the raw level")
                       .arg(raw)));
}

QTEST_MAIN(EncodersTest)
#include "tst_encoders.moc"
