#include "logging/Log.h"
#include "ui/Language.h"
#include "ui/MainWindow.h"
#include "ui/Theme.h"

#include <QApplication>

#ifndef LOCALSTREAM_VERSION
// Built without the project() version, for instance by a test harness: say so rather than
// claiming a version the build does not have.
#define LOCALSTREAM_VERSION "unknown"
#endif

int main(int argc, char* argv[])
{
    QApplication app(argc, argv);
    app.setApplicationName(QStringLiteral("LocalStream"));
    app.setOrganizationName(QStringLiteral("LocalStream"));
    app.setApplicationDisplayName(QStringLiteral("LocalStream"));
    app.setApplicationVersion(QStringLiteral(LOCALSTREAM_VERSION));

    // Before the window exists, and before the theme touches anything: a crash during start-up
    // is one of the moments a report is most wanted, and it happens long before the Help tab
    // that would write one has been shown.
    localstream::logging::install();
    localstream::logging::event(QStringLiteral("app.started"),
        {{QStringLiteral("version"), QApplication::applicationVersion()}});

    localstream::ui::Theme::instance().install(&app);

    // Before the first widget is built, because a widget's text is fixed when it is constructed:
    // this is where the stored language (or the system's, when the app follows it) reaches the
    // interface, and it is why changing the language later restarts the app.
    localstream::ui::applyEffectiveLanguage();

    MainWindow window;
    window.show();

    const int result = app.exec();
    localstream::logging::event(QStringLiteral("app.stopped"), {{QStringLiteral("code"),
        QString::number(result)}});
    localstream::logging::shutdown();
    return result;
}