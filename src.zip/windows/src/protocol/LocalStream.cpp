#include "protocol/LocalStream.h"

#include <QHash>
#include <QRandomGenerator>
#include <QUrl>

namespace localstream::protocol::LocalStream {

QString newSessionId()
{
    // A session id only has to be unique among the handful of devices on one LAN, so
    // 32 bits from a non-cryptographic generator is ample. A CSPRNG here would be
    // ceremony for a value that only has to avoid colliding with three neighbours.
    const quint32 value = QRandomGenerator::global()->generate();
    return QStringLiteral("%1").arg(value, 8, 16, QLatin1Char('0'));
}

QString escapeTxtValue(const QString& value)
{
    // Percent-escape everything that is not an unreserved character, so the result is safe
    // as both a key and a value inside a DNS-SD TXT record.
    return QString::fromLatin1(QUrl::toPercentEncoding(value.left(32)));
}

QList<QByteArray> txtEntries(const Description& description)
{
    QList<QByteArray> entries;
    entries << QStringLiteral("v=%1").arg(ProtocolVersion).toUtf8();
    entries << QStringLiteral("id=%1").arg(description.sessionId).toUtf8();
    entries << QStringLiteral("n=%1").arg(escapeTxtValue(description.displayName)).toUtf8();
    entries << QStringLiteral("m=%1").arg(description.mode).toUtf8();

    // Codec keys are omitted in audio-only mode rather than sent empty: a receiver that
    // sees `vid=h264` alongside `m=a` has to reconcile a contradiction, whereas an absent
    // key needs no interpretation.
    if (!description.isAudioOnly()) {
        entries << QByteArrayLiteral("vid=h264");
    }
    entries << QByteArrayLiteral("aud=opus");

    if (!description.isAudioOnly()) {
        entries << QStringLiteral("vbr=%1").arg(description.videoBitrateKbps).toUtf8();
        entries << QStringLiteral("dim=%1x%2").arg(description.width).arg(description.height).toUtf8();
        entries << QStringLiteral("fps=%1").arg(description.frameRate).toUtf8();
        entries << QStringLiteral("vp=%1").arg(description.videoPort).toUtf8();
    }
    entries << QStringLiteral("abr=%1").arg(description.audioBitrateKbps).toUtf8();
    entries << QStringLiteral("ap=%1").arg(description.audioPort).toUtf8();
    entries << QStringLiteral("cp=%1").arg(description.controlPort).toUtf8();
    entries << QStringLiteral("st=%1").arg(description.live ? 1 : 0).toUtf8();
    return entries;
}

QByteArray txtWireRecord(const Description& description)
{
    QByteArray record;
    for (const QByteArray& entry : txtEntries(description)) {
        // Each entry is a single length-prefixed string. A name is capped at 32 characters,
        // so no entry can reach 255 bytes and the length always fits in one byte.
        record.append(static_cast<char>(entry.size()));
        record.append(entry);
    }
    return record;
}

QByteArray joinTxtEntries(const QList<QByteArray>& entries)
{
    // Space-separated for readability; the percent-escaping means a value can never contain
    // a space, so this is unambiguous even though it is not the wire format.
    QByteArray joined;
    for (const QByteArray& entry : entries) {
        if (!joined.isEmpty()) {
            joined.append(' ');
        }
        joined.append(entry);
    }
    return joined;
}

std::optional<Description> descriptionFromTxt(const QList<QByteArray>& entries)
{
    QHash<QString, QString> pairs;
    for (const QByteArray& entry : entries) {
        const int equals = entry.indexOf('=');
        if (equals < 0) {
            // A key with an empty value is legal in DNS-SD and means "present but
            // unspecified", not malformed.
            pairs.insert(QString::fromUtf8(entry), QString());
        } else {
            pairs.insert(QString::fromUtf8(entry.left(equals)),
                QString::fromUtf8(entry.mid(equals + 1)));
        }
    }

    bool versionOk = false;
    const int parsedVersion = pairs.value(QStringLiteral("v")).toInt(&versionOk);
    if (!versionOk || parsedVersion != ProtocolVersion) {
        return std::nullopt;
    }

    Description description;
    description.sessionId = pairs.value(QStringLiteral("id"));
    if (description.sessionId.isEmpty()) {
        // Without a session id there is nothing to correlate an `accept` with.
        return std::nullopt;
    }

    description.displayName =
        QUrl::fromPercentEncoding(pairs.value(QStringLiteral("n")).toUtf8());
    if (description.displayName.isEmpty()) {
        description.displayName = QStringLiteral("Broadcaster");
    }

    const QString mode = pairs.value(QStringLiteral("m"), QLatin1String(ModeAudioVideo));
    if (mode != QLatin1String(ModeAudioVideo) && mode != QLatin1String(ModeAudioOnly)) {
        return std::nullopt; // an unknown mode is not a mode this client can honour
    }
    description.mode = mode;

    description.audioBitrateKbps = pairs.value(QStringLiteral("abr")).toInt();
    description.audioPort = pairs.value(QStringLiteral("ap")).toInt();
    description.controlPort = pairs.value(QStringLiteral("cp")).toInt();
    description.live = pairs.value(QStringLiteral("st")) == QLatin1String("1");

    if (!description.isAudioOnly()) {
        const QString dimensions = pairs.value(QStringLiteral("dim"));
        const int cross = dimensions.indexOf(QLatin1Char('x'));
        if (cross > 0) {
            description.width = dimensions.left(cross).toInt();
            description.height = dimensions.mid(cross + 1).toInt();
        }
        description.frameRate = pairs.value(QStringLiteral("fps")).toInt();
        description.videoBitrateKbps = pairs.value(QStringLiteral("vbr")).toInt();
        description.videoPort = pairs.value(QStringLiteral("vp")).toInt();
    }

    // The control port is where the handshake happens, so a record without one is unusable
    // however good the rest looks.
    if (description.controlPort <= 0) {
        return std::nullopt;
    }
    return description;
}

QByteArray buildSdp(const Description& description, quint32 ssrcVideo, quint32 ssrcAudio)
{
    // Built from the same Description as the TXT record, so the two cannot disagree.
    QString sdp;
    sdp += QStringLiteral("v=0\r\n");
    sdp += QStringLiteral("o=- %1 1 IN IP4 127.0.0.1\r\n")
               .arg(description.sessionId.isEmpty() ? QStringLiteral("0") : description.sessionId);
    sdp += QStringLiteral("s=LocalStream\r\n");
    sdp += QStringLiteral("c=IN IP4 0.0.0.0\r\n");
    sdp += QStringLiteral("t=0 0\r\n");
    sdp += QStringLiteral("a=tool:LocalStream-Windows\r\n");

    // Port 0 and a null media address: the receiver binds its own socket and offers it, so
    // the SDP never describes a real path. It is a description of intent, not a route.
    sdp += QStringLiteral("m=audio 0 RTP/AVP %1\r\n").arg(PayloadTypeAudio);
    sdp += QStringLiteral("a=rtpmap:%1 opus/%2/1\r\n")
               .arg(PayloadTypeAudio)
               .arg(AudioClockRate);
    sdp += QStringLiteral("a=rtcp:%1 IN IP4 0.0.0.0\r\n").arg(description.audioPort);
    sdp += QStringLiteral("a=ssrc:%1 cname:localstream-audio\r\n")
               .arg(static_cast<quint32>(ssrcAudio));

    if (!description.isAudioOnly()) {
        sdp += QStringLiteral("m=video 0 RTP/AVP %1\r\n").arg(PayloadTypeVideo);
        sdp += QStringLiteral("a=rtpmap:%1 H264/%2\r\n").arg(PayloadTypeVideo).arg(VideoClockRate);
        sdp += QStringLiteral("a=fmtp:%1 packetization-mode=1\r\n").arg(PayloadTypeVideo);
        sdp += QStringLiteral("a=rtcp:%1 IN IP4 0.0.0.0\r\n").arg(description.videoPort);
        sdp += QStringLiteral("a=ssrc:%1 cname:localstream-video\r\n")
                   .arg(static_cast<quint32>(ssrcVideo));
    }

    return sdp.toUtf8();
}

int audioChannelsFromSdp(const QString& sdp)
{
    // Split on line endings first, then match the rtpmap for the audio payload type. Matching the
    // bare encoding name anywhere in the document would be wrong: an SDP is allowed to describe
    // more than one stream, and only the audio section's channel count is wanted here.
    const QList<QByteArray> lines = sdp.toUtf8().split('\n');
    for (const QByteArray& rawLine : lines) {
        const QByteArray line = rawLine.trimmed();
        if (!line.startsWith("a=rtpmap:" + QByteArray::number(PayloadTypeAudio) + " ")) {
            continue;
        }

        // `a=rtpmap:97 opus/48000/1` -- encoding, clock rate, then channels, per RFC 4566.
        const QList<QByteArray> parts = line.mid(8).split('/');
        if (parts.size() < 3) {
            continue;
        }
        bool ok = false;
        const int channels = QByteArray(parts.at(2)).trimmed().toInt(&ok);
        // Guarded rather than trusted: a 0 or 7 here would be handed to the decoder as a channel
        // layout, and the failure would surface as noise in the speakers instead of an error.
        if (ok && channels >= 1 && channels <= 2) {
            return channels;
        }
    }
    return 1;
}

} // namespace localstream::protocol::LocalStream
