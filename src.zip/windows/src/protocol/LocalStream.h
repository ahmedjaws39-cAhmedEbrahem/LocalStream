#pragma once

#include <QByteArray>
#include <QList>
#include <QString>

#include <optional>

namespace localstream::protocol {

/**
 * Protocol-wide constants, the session description, and the TXT/SDP renderers.
 *
 * Mirrors `android/.../protocol/LocalStream.kt` exactly; the two implementations are
 * interchangeable on the wire and neither may drift from `docs/PROTOCOL.md`.
 */
namespace LocalStream {

inline constexpr int ProtocolVersion = 1;
inline constexpr int MaxReceiversDefault = 4;

/// Service type. See PROTOCOL.md section 2.
inline const char* ServiceType = "_localstream._tcp.local.";

inline constexpr int PayloadTypeVideo = 96;
inline constexpr int PayloadTypeAudio = 97;

/// RTP clock rates, per track.
inline constexpr int VideoClockRate = 90000;
inline constexpr int AudioClockRate = 48000;

/// 20 ms of Opus at 48 kHz, per PROTOCOL.md section 3.2.
inline constexpr int OpusSamplesPerFrame = 960;

/// Video RTP payload target, leaving headroom inside a 1500-byte MTU.
inline constexpr int RtpMaxPayload = 1200;

inline const char* ModeAudioVideo = "av";
inline const char* ModeAudioOnly = "a";

/**
 * Everything the discovery and control layers need to describe a broadcast.
 *
 * One struct rather than several: the TXT record and the SDP are generated from it, which
 * is what makes it impossible for the two to disagree.
 */
struct Description
{
    QString sessionId;
    QString displayName;
    QString mode = QString::fromLatin1(ModeAudioVideo);
    bool live = false;
    int width = 1280;
    int height = 720;
    int frameRate = 30;
    int videoBitrateKbps = 1500;
    int audioBitrateKbps = 48;
    int audioChannels = 1;
    int controlPort = 0;
    int videoPort = 0;
    int audioPort = 0;

    [[nodiscard]] bool isAudioOnly() const { return mode == QLatin1String(ModeAudioOnly); }
};

/// A fresh random 8-hex-digit session id, regenerated each time broadcasting starts.
[[nodiscard]] QString newSessionId();

/**
 * Percent-escapes a display name for the TXT record.
 *
 * mDNS TXT values are byte strings; a name containing '=' or a non-ASCII character would
 * otherwise truncate the record or corrupt every key after it.
 */
[[nodiscard]] QString escapeTxtValue(const QString& value);

/// The TXT record as individual `key=value` entries, in a stable order.
///
/// A list, not one joined string, because DNS-SD length-prefixes every entry separately. A
/// joined string cannot be parsed back without a delimiter that is legal inside a value, and
/// display names are free text.
[[nodiscard]] QList<QByteArray> txtEntries(const Description& description);

/// The DNS-SD wire form: each entry prefixed with its length byte, per RFC 6763 section 6.1.
[[nodiscard]] QByteArray txtWireRecord(const Description& description);

/// Joins entries for logs and assertions. Never put this on the wire.
[[nodiscard]] QByteArray joinTxtEntries(const QList<QByteArray>& entries);

/// Rebuilds a [Description] from received TXT entries.
///
/// Returns nullopt when the record is not ours, is from an incompatible protocol version, or
/// is missing the session id and control port the handshake depends on. Rejecting here is
/// deliberate: a receiver that accepted an unknown version would proceed on guessed defaults
/// and fail later, somewhere far less obvious.
[[nodiscard]] std::optional<Description> descriptionFromTxt(const QList<QByteArray>& entries);

/// Renders an SDP for logging and third-party debugging. Not on the media path.
[[nodiscard]] QByteArray buildSdp(const Description& description, quint32 ssrcVideo, quint32 ssrcAudio);

/**
 * Reads the Opus channel count out of an SDP, e.g. 2 for `a=rtpmap:97 opus/48000/2`.
 *
 * Needed because an Opus packet does not describe its own channel layout: the decoder has to be
 * told, and a mono stream decoded as stereo does not fail, it comes out as noise. The two
 * platforms do not agree on a default either -- Windows sends mono, Android stereo -- so this
 * cannot be hardcoded at either end.
 *
 * Falls back to 1 when the line is missing or unparsable, matching the more common broadcast
 * configuration and keeping playback working against a broadcaster that omits it.
 */
[[nodiscard]] int audioChannelsFromSdp(const QString& sdp);

} // namespace LocalStream

} // namespace localstream::protocol
