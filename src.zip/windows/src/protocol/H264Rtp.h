#pragma once

#include <QByteArray>
#include <QList>

#include "protocol/LocalStream.h"

namespace localstream::protocol::h264 {

inline constexpr int NalSliceNonIdr = 1;
inline constexpr int NalSliceIdr = 5;
inline constexpr int NalSei = 6;
inline constexpr int NalSps = 7;
inline constexpr int NalPps = 8;
inline constexpr int NalAud = 9;

inline constexpr int TypeStapA = 24;
inline constexpr int TypeStapB = 25;
inline constexpr int TypeMtap16 = 26;
inline constexpr int TypeMtap24 = 27;
inline constexpr int TypeFuA = 28;
inline constexpr int TypeFuB = 29;

/// Aggregation and fragmentation formats the depacketizer does not reassemble — neither
/// client emits STAP-B, MTAP or FU-B. Anything else is treated as a single-NAL unit packet.
[[nodiscard]] inline bool isAggregateOrFragment(int type)
{
    return type == TypeStapA || type == TypeStapB || type == TypeMtap16 || type == TypeMtap24
        || type == TypeFuA || type == TypeFuB;
}

[[nodiscard]] inline bool isParameterSet(int type) { return type == NalSps || type == NalPps; }

[[nodiscard]] inline int nalType(const QByteArray& nal)
{
    return static_cast<quint8>(nal.at(0)) & 0x1F;
}

/**
 * Splits an AVCC buffer — a run of 4-byte big-endian length prefixes each followed by one
 * NAL unit — into its NAL units.
 */
[[nodiscard]] QList<QByteArray> splitAvcc(const QByteArray& buffer, int offset = 0, int length = -1);

/**
 * Encapsulates one access unit's NAL units into RTP payloads.
 *
 * The caller assigns sequence numbers and sets the marker bit on the final payload, per
 * RFC 6184 section 5.1.
 *
 * [maxPayload] is the largest RTP payload, in bytes, this run may emit — the fragmentation
 * budget. It defaults to the protocol's nominal 1200 bytes; a broadcaster can lower it to make
 * each datagram smaller (and survive a lossy link better) or raise it to cut the packet rate.
 * Values below 3 are raised to 3 so that FU-A fragmentation always makes progress.
 */
[[nodiscard]] QList<QByteArray> packetize(const QList<QByteArray>& nals,
    int maxPayload = protocol::LocalStream::RtpMaxPayload);

/**
 * Reassembles RTP payloads into access units for the decoder.
 *
 * The marker bit is the only frame-boundary signal, per RFC 6184 section 5.1. Anything still
 * unterminated when the stream ends is discarded: a half-received picture is worthless and
 * buffering it would only add latency.
 */
class Depacketizer
{
public:
    explicit Depacketizer(bool annexB = true) : annexB_(annexB) {}

    /**
     * Feeds one RTP payload.
     *
     * @return the completed access unit when @p marker closes a frame, otherwise an empty
     *         array.
     */
    [[nodiscard]] QByteArray accept(const QByteArray& payload, bool marker);

    [[nodiscard]] bool hasParameterSets() const { return !sps_.isEmpty() && !pps_.isEmpty(); }
    [[nodiscard]] QByteArray sps() const { return sps_; }
    [[nodiscard]] QByteArray pps() const { return pps_; }

    /// Drops the partial access unit without discarding parameter sets learned earlier.
    void discardCurrentAccessUnit();
    void reset();

private:
    void captureParameterSet(int type, const QByteArray& nal);
    void appendNal(const QByteArray& nal);
    void discardCurrent();
    [[nodiscard]] QByteArray finish();

    bool annexB_;
    QByteArray current_;
    QByteArray fragment_;
    bool fragmentActive_ = false;
    QByteArray sps_;
    QByteArray pps_;
};

} // namespace localstream::protocol::h264
