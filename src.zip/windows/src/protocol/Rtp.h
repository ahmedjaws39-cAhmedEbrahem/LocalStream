#pragma once

#include <QByteArray>
#include <QtGlobal>

namespace localstream::protocol {

/**
 * Minimal RTP (RFC 3550) packet codec.
 *
 * The 12-byte fixed header plus the CSRC list. The extension header and the padding bit are
 * parsed but unused by this protocol. Byte-for-byte equivalent to `android/.../Rtp.kt`, so
 * a packet written by one implementation parses identically in the other.
 */
namespace Rtp {

inline constexpr int HeaderBytes = 12;

inline constexpr quint8 FlagMarker = 0x80;
inline constexpr quint8 FlagPadding = 0x20;
inline constexpr quint8 FlagExtension = 0x10;

/**
 * A parsed view over a datagram.
 *
 * `payloadOffset` indexes into the original buffer rather than copying, so the receive path
 * does not allocate per packet. On a 30 fps stream with large frames that is the difference
 * between a few hundred allocations a second and a few thousand.
 */
struct Packet
{
    int payloadType = 0;
    bool marker = false;
    quint16 sequenceNumber = 0;
    quint32 timestamp = 0;
    quint32 ssrc = 0;
    int payloadOffset = 0;
    int payloadLength = 0;
};

[[nodiscard]] QByteArray build(int payloadType,
                               bool marker,
                               quint16 sequenceNumber,
                               quint32 timestamp,
                               quint32 ssrc,
                               const QByteArray& payload);

/**
 * Parses a datagram, returning false for anything that is not plausible RTP.
 *
 * Strict on purpose: a stray non-RTP datagram on a media port would otherwise reach the
 * video decoder as a corrupt frame, and the symptom — a green or grey smear that persists —
 * is far harder to diagnose than a dropped packet.
 */
[[nodiscard]] bool parse(const QByteArray& data, int offset, int length, Packet& out);

/// Forward distance from `older` to `newer`, wrapping at 16 bits as RTP requires.
[[nodiscard]] inline int sequenceDelta(quint16 newer, quint16 older)
{
    return static_cast<int>((static_cast<quint16>(newer - older)));
}

} // namespace Rtp

} // namespace localstream::protocol
