#pragma once

#include <QByteArray>
#include <QString>

#include <optional>
#include <variant>

namespace localstream::protocol {

/**
 * Every control-channel message, as a variant.
 *
 * Modelled on the same closed set as `android/.../ControlMessage.kt`. Unknown `t` values must
 * be ignored rather than treated as errors — that is the forward-compatibility rule in
 * PROTOCOL.md section 4.2, and it is why [parse] returns an optional instead of a default.
 */
using ControlMessage = std::variant<
    std::monostate,
    struct Hello,
    struct Welcome,
    struct AuthRequest,
    struct AuthResult,
    struct Offer,
    struct Accept,
    struct Deny,
    struct KeyframeRequest,
    struct BitrateRequest,
    struct ModeRequest,
    struct ModeChanged,
    struct KeyframeCoalesced,
    struct ReceiverStats,
    struct BroadcasterStats,
    struct Bye>;

/** Deny codes, per PROTOCOL.md section 4.2. */
namespace deny {
inline const char* Version = "version";
inline const char* Capacity = "capacity";
inline const char* Shutdown = "shutdown";
inline const char* Mode = "mode";
/// The broadcaster refused this receiver's request to view the broadcast.
inline const char* Access = "access";
/// The broadcaster refused a password, or one was expected and none arrived.
inline const char* Auth = "auth";
/// This receiver exhausted its rejections and is barred until the broadcast ends. Terminal:
/// retrying cannot succeed, so a receiver must not offer to reconnect.
inline const char* Blocked = "blocked";
} // namespace deny

/**
 * Broadcast access modes, per PROTOCOL.md section 4.4.
 *
 * These are the values that travel in `welcome.access`. A receiver that gets no `access` field
 * at all — an older broadcaster — must treat the session as [Public], because that is what an
 * older broadcaster offered unconditionally.
 */
namespace access {
inline const char* Public = "public";
/// A receiver may ask, and the broadcaster decides per request.
inline const char* Approval = "approval";
/// A receiver must supply the broadcaster's password before it is admitted.
inline const char* Password = "password";
} // namespace access

/// Password length limits, enforced by the broadcaster. Not a protocol constant: both ends
/// agree on them only so the receiver can size its input and validate before sending.
namespace accesslimits {
inline constexpr int MinPasswordLength = 4;
inline constexpr int MaxPasswordLength = 10;
/// Rejections a receiver may accumulate in [Approval] mode before it is barred. The broadcaster
/// counts them; a receiver that reconnects does not start over.
inline constexpr int MaxRejections = 3;
} // namespace accesslimits

/// Bye reasons.
namespace bye {
inline const char* UserLeft = "user-left";
inline const char* Shutdown = "shutdown";
inline const char* ModeChange = "mode-change";
inline const char* Capacity = "capacity";
inline const char* Kicked = "kicked";
inline const char* Error = "error";
} // namespace bye

struct Hello
{
    int protocolVersion = 0;
    QString role;
    QString name;
    QString userAgent;
};

struct Welcome
{
    int protocolVersion = 0;
    QString sessionId;
    QString mode;
    QString displayName;
    QString sdp;
    /// One of [access]. Empty means the sender predates access control, which reads as [Public]:
    /// an older broadcaster admitted everyone, so its absence must not mean "refuse".
    QString access;
};

/// Receiver -> broadcaster. Sent only in [access::Password] mode, after `welcome` and before
/// `offer`. The broadcaster answers [AuthResult]; a receiver must not send `offer` until the
/// result grants access.
struct AuthRequest
{
    QString sessionId;
    QString password;
};

/// Broadcaster -> receiver. The answer to [AuthRequest]; `granted` is authoritative and the
/// receiver's own comparison of the password is irrelevant to it.
struct AuthResult
{
    bool granted = false;
    /// Why it was refused, for the user. Empty when [granted].
    QString reason;
};

struct Offer
{
    QString sessionId;
    int audioPort = 0;
    int videoPort = 0; // 0 in audio-only
};

struct Accept
{
    // The broadcaster's own bound ports, so a receiver can confirm where media will come
    // from. Not an echo of the receiver's offer.
    int audioPort = 0;
    int videoPort = 0;
    quint32 audioSsrc = 0;
    quint32 videoSsrc = 0;
};

struct Deny
{
    QString code;
    QString reason;
};

struct KeyframeRequest
{
    QString sessionId;
};

struct BitrateRequest
{
    int videoKbps = 0;
    int audioKbps = 0;
};

/// Receiver -> broadcaster. Serialised with `"r": true` so it cannot be confused with a
/// command; see PROTOCOL.md section 5.
struct ModeRequest
{
    QString mode;
};

/// Broadcaster -> receiver. Authoritative.
struct ModeChanged
{
    QString mode;
};

struct KeyframeCoalesced
{
};

struct ReceiverStats
{
    quint64 packets = 0;
    quint64 lost = 0;
    double jitterMillis = 0.0;
    quint64 keyframeRequests = 0;
};

struct BroadcasterStats
{
    int framesPerSecond = 0;
    int kilobitsPerSecond = 0;
    double packetLoss = 0.0;
    int receiverCount = 0;
    quint64 droppedFrames = 0;
};

struct Bye
{
    QString reason;
};

/** Serialises to one UTF-8 JSON object, newline-terminated, ready for the wire. */
[[nodiscard]] QByteArray encode(const ControlMessage& message);

/// Serialises without the trailing newline, for tests and logging.
[[nodiscard]] QByteArray toJsonLine(const ControlMessage& message);

/// Parses one line. Returns `std::monostate` for anything unrecognised or malformed.
[[nodiscard]] ControlMessage parse(const QByteArray& line);

/// The `t` tag of a message, or an empty string for `std::monostate`.
[[nodiscard]] QString typeName(const ControlMessage& message);

/**
 * Normalises a wire or UI access-mode string to one of the [access] constants.
 *
 * Anything unrecognised — including empty — becomes [access::Public]. This is a deliberate
 * fail-open, and it is safe only because it is paired with a fail-closed check on the
 * broadcaster side: a broadcaster never derives its own policy from this function, so a peer
 * cannot talk it into a weaker mode by sending a bogus value. A *receiver* normalising to
 * Public here is what lets it talk to an older broadcaster that has no `access` field at all.
 */
[[nodiscard]] QString accessModeOrPublic(const QString& value);

/// True when the password satisfies the length rules in [accesslimits]. A broadcaster must
/// refuse to start rather than run [access::Password] with a password nobody can satisfy.
[[nodiscard]] bool isValidAccessPassword(const QString& password);

} // namespace localstream::protocol
