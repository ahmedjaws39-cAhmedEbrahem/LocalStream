#include "protocol/H264Rtp.h"

#include <cstring>

#include "protocol/LocalStream.h"

namespace localstream::protocol::h264 {

namespace {

const QByteArray& startCode()
{
    // A 4-byte start code rather than the 3-byte form: some decoders mis-detect the 3-byte
    // prefix when it follows another NAL unit without an intervening zero byte.
    static const QByteArray code = QByteArray::fromHex("00000001");
    return code;
}

QList<QByteArray> fragmentIfNeeded(const QByteArray& nal, int maxPayload)
{
    if (nal.size() <= maxPayload) {
        return {nal};
    }

    const int type = nalType(nal);
    const auto indicator = static_cast<quint8>((static_cast<quint8>(nal.at(0)) & 0xE0) | TypeFuA);
    // The FU indicator replaces the NAL header, so its byte is dropped from the body and
    // reconstructed from `type` when the fragment is reassembled.
    const QByteArray body = nal.mid(1);
    const int maxFragment = maxPayload - 2;

    QList<QByteArray> payloads;
    int sent = 0;
    while (sent < body.size()) {
        const int chunk = qMin(maxFragment, body.size() - sent);
        const bool start = (sent == 0);
        const bool end = (sent + chunk >= body.size());

        QByteArray out(2 + chunk, Qt::Uninitialized);
        auto* p = reinterpret_cast<quint8*>(out.data());
        p[0] = indicator;
        p[1] = static_cast<quint8>((start ? 0x80 : 0) | (end ? 0x40 : 0) | type);
        std::memcpy(p + 2, body.constData() + sent, static_cast<size_t>(chunk));
        payloads.append(out);
        sent += chunk;
    }
    return payloads;
}

} // namespace

QList<QByteArray> splitAvcc(const QByteArray& buffer, int offset, int length)
{
    if (length < 0) {
        length = buffer.size() - offset;
    }

    QList<QByteArray> nals;
    const auto* base = reinterpret_cast<const quint8*>(buffer.constData());

    int pos = offset;
    const int end = offset + length;
    while (pos + 4 <= end) {
        int nalLength = (static_cast<int>(base[pos]) << 24)
            | (static_cast<int>(base[pos + 1]) << 16) | (static_cast<int>(base[pos + 2]) << 8)
            | static_cast<int>(base[pos + 3]);
        pos += 4;
        if (nalLength <= 0 || pos + nalLength > end) {
            break;
        }
        nals.append(QByteArray(reinterpret_cast<const char*>(base + pos), nalLength));
        pos += nalLength;
    }
    return nals;
}

QList<QByteArray> packetize(const QList<QByteArray>& nals, int maxPayload)
{
    if (nals.isEmpty()) {
        return {};
    }

    // A budget of 2 or less would leave no room for the FU-A indicator and header, so the loop
    // below could never advance. Raised rather than rejected: this is the packetiser's own
    // progress guarantee, and callers are not expected to police it.
    const int budget = qMax(3, maxPayload);

    if (nals.size() == 1 && nals.first().size() <= budget) {
        return {nals.first()};
    }

    QList<QByteArray> payloads;

    // STAP-A aggregates the leading non-VCL NALs (AUD/SPS/PPS). Only worth doing when a VCL
    // NAL follows: otherwise no packet in the group would carry the marker bit, and the
    // receiver's reassembly buffer would never release the aggregated units.
    QList<QByteArray> leading;
    int leadingBytes = 1;
    bool leadingStopsBeforeVcl = true;
    for (const QByteArray& nal : nals) {
        const int type = nalType(nal);
        if (isParameterSet(type) || type == NalAud || type == NalSei) {
            if (leadingBytes + 2 + nal.size() > budget) {
                leadingStopsBeforeVcl = false;
                break;
            }
            leading.append(nal);
            leadingBytes += 2 + nal.size();
        } else {
            leadingStopsBeforeVcl = false;
            break;
        }
    }

    if (leading.size() >= 2 && !leadingStopsBeforeVcl) {
        QByteArray stap(leadingBytes, Qt::Uninitialized);
        auto* p = reinterpret_cast<quint8*>(stap.data());
        // F=0, NRI=0: the aggregate's NRI is not meaningful when it mixes parameter sets
        // with a slice, and receivers key off the individual NAL headers instead.
        p[0] = TypeStapA;
        int at = 1;
        for (const QByteArray& nal : leading) {
            p[at++] = static_cast<quint8>(nal.size() >> 8);
            p[at++] = static_cast<quint8>(nal.size() & 0xFF);
            std::memcpy(p + at, nal.constData(), static_cast<size_t>(nal.size()));
            at += nal.size();
        }
        payloads.append(stap);
        for (int i = leading.size(); i < nals.size(); ++i) {
            payloads.append(fragmentIfNeeded(nals.at(i), budget));
        }
        return payloads;
    }

    for (const QByteArray& nal : nals) {
        payloads.append(fragmentIfNeeded(nal, budget));
    }
    return payloads;
}

QByteArray Depacketizer::accept(const QByteArray& payload, bool marker)
{
    if (payload.isEmpty()) {
        return {};
    }
    const auto first = static_cast<quint8>(payload.at(0));
    const int type = first & 0x1F;
    const auto* p = reinterpret_cast<const quint8*>(payload.constData());

    if (type == TypeStapA) {
        int at = 1;
        while (at + 2 <= payload.size()) {
            const int nalSize = (static_cast<int>(p[at]) << 8) | static_cast<int>(p[at + 1]);
            at += 2;
            if (nalSize <= 0 || at + nalSize > payload.size()) {
                break;
            }
            const QByteArray nal(reinterpret_cast<const char*>(p + at), nalSize);
            at += nalSize;
            captureParameterSet(nalType(nal), nal);
            appendNal(nal);
        }
    } else if (type == TypeFuA) {
        if (payload.size() < 2) {
            return {};
        }
        const auto fuHeader = static_cast<quint8>(p[1]);
        const bool start = (fuHeader & 0x80) != 0;
        const bool end = (fuHeader & 0x40) != 0;
        const int innerType = fuHeader & 0x1F;

        if (start) {
            // A new fragment supersedes any abandoned one: partial pictures are dropped
            // rather than reassembled from mismatched pieces, which would decode to noise.
            if (fragmentActive_) {
                discardCurrent();
            }
            fragment_.clear();
            fragmentActive_ = true;
            fragment_.append(static_cast<char>((first & 0xE0) | innerType));
        }
        if (!fragmentActive_) {
            return {};
        }
        fragment_.append(payload.constData() + 2, payload.size() - 2);
        if (end) {
            const QByteArray nal = fragment_;
            fragment_.clear();
            fragmentActive_ = false;
            captureParameterSet(innerType, nal);
            appendNal(nal);
        }
    } else if (isAggregateOrFragment(type)) {
        // STAP-B, MTAP16/24 and FU-B are payload-format extensions no encoder on either
        // client produces, so they are ignored rather than treated as errors.
    } else {
        // A single-NAL unit packet. Not only slices: an access unit that carries just
        // SPS/PPS and no picture is sent as individual packets, and a receiver that dropped
        // non-VCL types here would silently never learn the parameter sets.
        captureParameterSet(type, payload);
        appendNal(payload);
    }

    return marker ? finish() : QByteArray();
}

void Depacketizer::captureParameterSet(int type, const QByteArray& nal)
{
    if (type == NalSps) {
        sps_ = nal;
    } else if (type == NalPps) {
        pps_ = nal;
    }
}

void Depacketizer::appendNal(const QByteArray& nal)
{
    if (annexB_) {
        current_.append(startCode());
        current_.append(nal);
    } else {
        const auto size = static_cast<quint32>(nal.size());
        current_.append(static_cast<char>((size >> 24) & 0xFF));
        current_.append(static_cast<char>((size >> 16) & 0xFF));
        current_.append(static_cast<char>((size >> 8) & 0xFF));
        current_.append(static_cast<char>(size & 0xFF));
        current_.append(nal);
    }
}

void Depacketizer::discardCurrent()
{
    current_.clear();
    fragment_.clear();
    fragmentActive_ = false;
}

QByteArray Depacketizer::finish()
{
    if (fragmentActive_) {
        // The marker arrived mid-fragment, so this frame is truncated. Dropping it is
        // correct: the alternative is a partially-decoded picture that stays on screen.
        fragmentActive_ = false;
        current_.clear();
        return {};
    }
    if (current_.isEmpty()) {
        return {};
    }
    const QByteArray accessUnit = current_;
    current_.clear();
    return accessUnit;
}

void Depacketizer::reset()
{
    current_.clear();
    fragment_.clear();
    fragmentActive_ = false;
    sps_.clear();
    pps_.clear();
}

void Depacketizer::discardCurrentAccessUnit()
{
    discardCurrent();
}

} // namespace localstream::protocol::h264
