#include "protocol/Rtp.h"

#include <cstring>

namespace localstream::protocol::Rtp {

QByteArray build(int payloadType,
                 bool marker,
                 quint16 sequenceNumber,
                 quint32 timestamp,
                 quint32 ssrc,
                 const QByteArray& payload)
{
    QByteArray out(HeaderBytes + payload.size(), Qt::Uninitialized);

    auto* p = reinterpret_cast<quint8*>(out.data());
    p[0] = 0x80; // V=2, P=0, X=0, CC=0
    p[1] = static_cast<quint8>((marker ? FlagMarker : 0) | (payloadType & 0x7F));
    p[2] = static_cast<quint8>(sequenceNumber >> 8);
    p[3] = static_cast<quint8>(sequenceNumber & 0xFF);
    p[4] = static_cast<quint8>(timestamp >> 24);
    p[5] = static_cast<quint8>(timestamp >> 16);
    p[6] = static_cast<quint8>(timestamp >> 8);
    p[7] = static_cast<quint8>(timestamp & 0xFF);
    p[8] = static_cast<quint8>(ssrc >> 24);
    p[9] = static_cast<quint8>(ssrc >> 16);
    p[10] = static_cast<quint8>(ssrc >> 8);
    p[11] = static_cast<quint8>(ssrc & 0xFF);

    if (!payload.isEmpty()) {
        std::memcpy(p + HeaderBytes, payload.constData(), static_cast<size_t>(payload.size()));
    }
    return out;
}

bool parse(const QByteArray& data, int offset, int length, Packet& out)
{
    if (offset < 0 || length < HeaderBytes) {
        return false;
    }
    if (offset + length > data.size()) {
        return false;
    }

    const auto* p = reinterpret_cast<const quint8*>(data.constData()) + offset;

    if ((p[0] & 0xC0) != 0x80) {
        return false; // version must be 2
    }

    const int csrcCount = p[0] & 0x0F;
    const bool hasExtension = (p[0] & FlagExtension) != 0;
    const bool hasPadding = (p[0] & FlagPadding) != 0;

    // 15 CSRCs is 60 bytes of attacker-chosen header before any payload. Bounded here so
    // that `payloadOffset` is only ever used for a read after it is known to sit inside
    // this packet.
    if (HeaderBytes + csrcCount * 4 > length) {
        return false;
    }

    int payloadOffset = HeaderBytes + csrcCount * 4;
    int payloadLength = length - payloadOffset;

    if (hasPadding) {
        // The padding count is the last byte of the packet, so it is only meaningful once the
        // packet is known to be long enough to contain a header at all.
        if (payloadLength <= 0) {
            return false;
        }
        const int padBytes = p[length - 1];
        if (padBytes <= 0 || padBytes > payloadLength) {
            return false;
        }
        payloadLength -= padBytes;
    }

    if (hasExtension) {
        // The four fixed extension bytes must be inside this packet. Checked against `length`
        // rather than against the payload length, because a header claiming an extension with
        // only its own two CSRC words left is exactly what arbitrary bytes look like, and the
        // read below would otherwise walk past the end of the buffer.
        if (payloadOffset + 4 > length) {
            return false;
        }
        if (payloadLength < 4) {
            return false;
        }
        const int extWords = (p[payloadOffset + 2] << 8) | p[payloadOffset + 3];
        // Checked before advancing: extWords comes straight off the wire, so it is untrusted,
        // and a large value would push payloadOffset beyond length and turn the payload slice
        // below into a negative-length read.
        const int extBytes = 4 + extWords * 4;
        if (extBytes > payloadLength) {
            return false;
        }
        payloadOffset += extBytes;
        payloadLength -= extBytes;
    }

    out.payloadType = p[1] & 0x7F;
    out.marker = (p[1] & FlagMarker) != 0;
    out.sequenceNumber = static_cast<quint16>((p[2] << 8) | p[3]);
    out.timestamp = (static_cast<quint32>(p[4]) << 24) | (static_cast<quint32>(p[5]) << 16)
        | (static_cast<quint32>(p[6]) << 8) | static_cast<quint32>(p[7]);
    out.ssrc = (static_cast<quint32>(p[8]) << 24) | (static_cast<quint32>(p[9]) << 16)
        | (static_cast<quint32>(p[10]) << 8) | static_cast<quint32>(p[11]);
    out.payloadOffset = offset + payloadOffset;
    out.payloadLength = payloadLength;
    return true;
}

} // namespace localstream::protocol::Rtp
