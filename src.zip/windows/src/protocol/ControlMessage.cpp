#include "protocol/ControlMessage.h"

#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonParseError>
#include <QJsonValue>

#include <variant>

namespace localstream::protocol {

namespace {

QJsonObject objectFor(const ControlMessage& message)
{
    return std::visit(
        [](const auto& value) -> QJsonObject {
            using T = std::decay_t<decltype(value)>;
            if constexpr (std::is_same_v<T, std::monostate>) {
                return {};
            } else if constexpr (std::is_same_v<T, Hello>) {
                QJsonObject o;
                o["t"] = "hello";
                o["v"] = value.protocolVersion;
                o["role"] = value.role;
                o["name"] = value.name;
                o["ua"] = value.userAgent;
                return o;
            } else if constexpr (std::is_same_v<T, Welcome>) {
                QJsonObject o;
                o["t"] = "welcome";
                o["v"] = value.protocolVersion;
                o["id"] = value.sessionId;
                o["m"] = value.mode;
                o["name"] = value.displayName;
                o["sdp"] = value.sdp;
// Omitted when public, and when unset: a receiver reading a missing `access`
                // treats it as public anyway, so sending it adds a byte per session for no
                // behavioural difference - but a locked broadcast must never be announced as
                // locked by omission, so `access` is sent whenever the mode is not public.
                // Empty is omitted rather than written as an empty string, because an empty
                // value is what a caller that does not know about access leaves behind, and
                // putting it on the wire would tell a receiver something nobody chose.
                if (!value.access.isEmpty() && value.access != QLatin1String(access::Public)) {
                    o["access"] = value.access;
                }
                return o;
            } else if constexpr (std::is_same_v<T, AuthRequest>) {
                QJsonObject o;
                o["t"] = "auth";
                if (!value.sessionId.isEmpty()) {
                    o["id"] = value.sessionId;
                }
                o["pw"] = value.password;
                return o;
            } else if constexpr (std::is_same_v<T, AuthResult>) {
                QJsonObject o;
                o["t"] = "authResult";
                o["ok"] = value.granted;
                if (!value.reason.isEmpty()) {
                    o["reason"] = value.reason;
                }
                return o;
            } else if constexpr (std::is_same_v<T, Offer>) {
                QJsonObject o;
                o["t"] = "offer";
                o["id"] = value.sessionId;
                o["ap"] = value.audioPort;
                // Omitted rather than sent as 0: a receiver must not have to interpret
                // "port zero" as "no video".
                if (value.videoPort > 0) {
                    o["vp"] = value.videoPort;
                }
                return o;
            } else if constexpr (std::is_same_v<T, Accept>) {
                QJsonObject o;
                o["t"] = "accept";
                o["ap"] = value.audioPort;
                // `as` is the audio SSRC and `vs` the video SSRC, always — the letters are the
                // track initials. They are not positional, so swapping them is invisible in a
                // Windows-only test and only breaks once an Android peer is involved.
                o["as"] = static_cast<qint64>(value.audioSsrc);
                if (value.videoPort > 0 && value.videoSsrc != 0) {
                    o["vp"] = value.videoPort;
                    o["vs"] = static_cast<qint64>(value.videoSsrc);
                } else {
                    // Explicit null, not omitted: a receiver distinguishes audio-only from a
                    // malformed accept by the presence of the key.
                    o["vp"] = QJsonValue(QJsonValue::Null);
                    o["vs"] = QJsonValue(QJsonValue::Null);
                }
                return o;
            } else if constexpr (std::is_same_v<T, Deny>) {
                QJsonObject o;
                o["t"] = "deny";
                o["code"] = value.code;
                o["reason"] = value.reason;
                return o;
            } else if constexpr (std::is_same_v<T, KeyframeRequest>) {
                QJsonObject o;
                o["t"] = "keyframe";
                if (!value.sessionId.isEmpty()) {
                    o["id"] = value.sessionId;
                }
                return o;
            } else if constexpr (std::is_same_v<T, BitrateRequest>) {
                QJsonObject o;
                o["t"] = "bitrate";
                if (value.videoKbps > 0) {
                    o["vbr"] = value.videoKbps;
                }
                if (value.audioKbps > 0) {
                    o["abr"] = value.audioKbps;
                }
                return o;
            } else if constexpr (std::is_same_v<T, ModeRequest>) {
                QJsonObject o;
                o["t"] = "mode";
                o["m"] = value.mode;
                o["r"] = true;
                return o;
            } else if constexpr (std::is_same_v<T, ModeChanged>) {
                QJsonObject o;
                o["t"] = "mode";
                o["m"] = value.mode;
                return o;
            } else if constexpr (std::is_same_v<T, KeyframeCoalesced>) {
                QJsonObject o;
                o["t"] = "keyframe";
                return o;
            } else if constexpr (std::is_same_v<T, ReceiverStats>) {
                QJsonObject o;
                o["t"] = "stats";
                o["pkt"] = static_cast<qint64>(value.packets);
                o["lost"] = static_cast<qint64>(value.lost);
                o["jitter"] = value.jitterMillis;
                o["nack"] = static_cast<qint64>(value.keyframeRequests);
                return o;
            } else if constexpr (std::is_same_v<T, BroadcasterStats>) {
                QJsonObject o;
                o["t"] = "stats";
                o["fps"] = value.framesPerSecond;
                o["kbps"] = value.kilobitsPerSecond;
                o["pl"] = value.packetLoss;
                o["nrt"] = value.receiverCount;
                o["dropped"] = static_cast<qint64>(value.droppedFrames);
                return o;
            } else if constexpr (std::is_same_v<T, Bye>) {
                QJsonObject o;
                o["t"] = "bye";
                o["reason"] = value.reason;
                return o;
            }
        },
        message);
}

} // namespace

QByteArray toJsonLine(const ControlMessage& message)
{
    const QJsonObject object = objectFor(message);
    if (object.isEmpty()) {
        return {};
    }
    // Compact, not indented: this is a wire format and whitespace is bytes on the wire.
    return QJsonDocument(object).toJson(QJsonDocument::Compact);
}

QByteArray encode(const ControlMessage& message)
{
    QByteArray line = toJsonLine(message);
    if (line.isEmpty()) {
        return {};
    }
    line.append('\n');
    return line;
}

ControlMessage parse(const QByteArray& line)
{
    QJsonParseError error {};
    const QJsonDocument document = QJsonDocument::fromJson(line, &error);
    if (error.error != QJsonParseError::NoError || !document.isObject()) {
        return std::monostate {};
    }

    const QJsonObject o = document.object();
    const QString type = o.value(QStringLiteral("t")).toString();

    if (type == QLatin1String("hello")) {
        return Hello {o.value(QStringLiteral("v")).toInt(), o.value(QStringLiteral("role")).toString(),
            o.value(QStringLiteral("name")).toString(), o.value(QStringLiteral("ua")).toString()};
    }
    if (type == QLatin1String("welcome")) {
        return Welcome {o.value(QStringLiteral("v")).toInt(), o.value(QStringLiteral("id")).toString(),
            o.value(QStringLiteral("m")).toString(), o.value(QStringLiteral("name")).toString(),
            o.value(QStringLiteral("sdp")).toString(), accessModeOrPublic(o.value(QStringLiteral("access")).toString())};
    }
    if (type == QLatin1String("auth")) {
        return AuthRequest {o.value(QStringLiteral("id")).toString(), o.value(QStringLiteral("pw")).toString()};
    }
    if (type == QLatin1String("authResult")) {
        return AuthResult {o.value(QStringLiteral("ok")).toBool(), o.value(QStringLiteral("reason")).toString()};
    }
    if (type == QLatin1String("offer")) {
        return Offer {o.value(QStringLiteral("id")).toString(), o.value(QStringLiteral("ap")).toInt(),
            o.value(QStringLiteral("vp")).toInt()};
    }
    if (type == QLatin1String("accept")) {
        const QJsonValue videoPort = o.value(QStringLiteral("vp"));
        const QJsonValue videoSsrc = o.value(QStringLiteral("vs"));
        return Accept {o.value(QStringLiteral("ap")).toInt(),
            videoPort.isDouble() ? videoPort.toInt() : 0,
            static_cast<quint32>(o.value(QStringLiteral("as")).toInteger()),
            videoSsrc.isDouble() ? static_cast<quint32>(videoSsrc.toInteger()) : 0};
    }
    if (type == QLatin1String("deny")) {
        return Deny {o.value(QStringLiteral("code")).toString(), o.value(QStringLiteral("reason")).toString()};
    }
    if (type == QLatin1String("keyframe")) {
        return KeyframeRequest {o.value(QStringLiteral("id")).toString()};
    }
    if (type == QLatin1String("bitrate")) {
        return BitrateRequest {o.value(QStringLiteral("vbr")).toInt(), o.value(QStringLiteral("abr")).toInt()};
    }
    if (type == QLatin1String("mode")) {
        // `"r": true` marks a receiver's request. Its absence marks the broadcaster's
        // authoritative change. Without the flag the two would be indistinguishable and a
        // request would silently act as a command.
        if (o.value(QStringLiteral("r")).toBool()) {
            return ModeRequest {o.value(QStringLiteral("m")).toString()};
        }
        return ModeChanged {o.value(QStringLiteral("m")).toString()};
    }
    if (type == QLatin1String("stats")) {
        // `stats` travels in both directions and the field names differ; the presence of
        // `pkt` identifies the receiver's report.
        if (o.contains(QStringLiteral("pkt"))) {
            return ReceiverStats {static_cast<quint64>(o.value(QStringLiteral("pkt")).toInteger()),
                static_cast<quint64>(o.value(QStringLiteral("lost")).toInteger()),
                o.value(QStringLiteral("jitter")).toDouble(),
                static_cast<quint64>(o.value(QStringLiteral("nack")).toInteger())};
        }
        return BroadcasterStats {o.value(QStringLiteral("fps")).toInt(),
            o.value(QStringLiteral("kbps")).toInt(), o.value(QStringLiteral("pl")).toDouble(),
            o.value(QStringLiteral("nrt")).toInt(),
            static_cast<quint64>(o.value(QStringLiteral("dropped")).toInteger())};
    }
    if (type == QLatin1String("bye")) {
        return Bye {o.value(QStringLiteral("reason")).toString()};
    }

    // Unknown type: ignored, not an error. See PROTOCOL.md section 4.2.
    return std::monostate {};
}

QString typeName(const ControlMessage& message)
{
    const QJsonObject object = objectFor(message);
    return object.value(QStringLiteral("t")).toString();
}

QString accessModeOrPublic(const QString& value)
{
    if (value == QLatin1String(access::Approval) || value == QLatin1String(access::Password)) {
        return value;
    }
    return QString::fromLatin1(access::Public);
}

bool isValidAccessPassword(const QString& password)
{
    const int length = password.size();
    return length >= accesslimits::MinPasswordLength && length <= accesslimits::MaxPasswordLength;
}

} // namespace localstream::protocol
