#include "engine/PlaybackDecoder.h"

#include <QMetaObject>
#include <QtGlobal>

// Wrapped, and not just because it is the usual requirement: Encoders.h does the same, so a
// translation unit including both would see two declarations of avcodec_alloc_context3 -- one
// C-linkage and one C++-linkage -- and every call would resolve to a mangled symbol the import
// library does not contain.
extern "C" {
#include <libavcodec/avcodec.h>
#include <libswscale/swscale.h>
}

#include <cstring>

namespace localstream::engine {

namespace {

/**
 * Maps H.264 colour metadata to the matrix identifiers used by libswscale. Unspecified H.264
 * colour metadata retains the existing BT.601 limited-range fallback.
 */
int swsColorSpace(AVColorSpace colorSpace)
{
    switch (colorSpace) {
    case AVCOL_SPC_BT709:
        return SWS_CS_ITU709;
    case AVCOL_SPC_FCC:
        return SWS_CS_FCC;
    case AVCOL_SPC_BT470BG:
    case AVCOL_SPC_SMPTE170M:
        return SWS_CS_ITU601;
    case AVCOL_SPC_SMPTE240M:
        return SWS_CS_SMPTE240M;
    case AVCOL_SPC_BT2020_NCL:
        return SWS_CS_BT2020;
    case AVCOL_SPC_UNSPECIFIED:
        return SWS_CS_ITU601;
    default:
        return -1;
    }
}

/**
 * Converts a decoded frame to RGB using its declared YCbCr matrix and range.
 *
 * A single cached scaler handles the common YUV420 path and other pixel formats a hardware or
 * software H.264 decoder may return. RGB output is full range; unspecified H.264 input range is
 * treated as limited range.
 */
QImage toRgb32(const AVFrame& frame, SwsContext*& scaler)
{
    if (frame.width <= 0 || frame.height <= 0 || frame.format < 0) {
        return {};
    }

    scaler = sws_getCachedContext(scaler, frame.width, frame.height,
        static_cast<AVPixelFormat>(frame.format), frame.width, frame.height, AV_PIX_FMT_BGRA,
        SWS_BILINEAR, nullptr, nullptr, nullptr);
    if (!scaler) {
        return {};
    }

    const AVColorSpace colorSpace = frame.colorspace == AVCOL_SPC_UNSPECIFIED
        ? AVCOL_SPC_SMPTE170M
        : frame.colorspace;
    const int coefficientSet = swsColorSpace(colorSpace);
    const int* coefficients = coefficientSet >= 0 ? sws_getCoefficients(coefficientSet) : nullptr;
    if (!coefficients) {
        return {};
    }
    const int sourceRange = frame.color_range == AVCOL_RANGE_JPEG ? 1 : 0;
    if (sws_setColorspaceDetails(scaler, coefficients, sourceRange, coefficients, 1, 0,
            1 << 16, 1 << 16) < 0) {
        return {};
    }

    QImage image(frame.width, frame.height, QImage::Format_RGB32);
    if (image.isNull()) {
        return {};
    }

    uint8_t* destination[4] = {image.bits(), nullptr, nullptr, nullptr};
    const int destinationStride[4] = {static_cast<int>(image.bytesPerLine()), 0, 0, 0};
    if (sws_scale(scaler, frame.data, frame.linesize, 0, frame.height, destination,
            destinationStride) != frame.height) {
        return {};
    }
    return image;
}

} // namespace

/**
 * The decoder and the buffers it works through.
 *
 * Owned by DecodeWorker and reachable only from the decode thread. Destroyed there for the same
 * reason the sockets in RtpReceiver are: freeing a libav object on another thread is undefined,
 * and the failure lands on the next allocation rather than at the free.
 */
struct DecoderState
{
    AVCodecContext* context = nullptr;
    AVFrame* frame = nullptr;
    AVPacket* packet = nullptr;
    SwsContext* scaler = nullptr;

    ~DecoderState()
    {
        sws_freeContext(scaler);
        av_frame_free(&frame);
        av_packet_free(&packet);
        // Frees the extradata allocated with it as well, which is why that is never freed by hand.
        avcodec_free_context(&context);
    }

    DecoderState() = default;
    DecoderState(const DecoderState&) = delete;
    DecoderState& operator=(const DecoderState&) = delete;
};

/**
 * Lives on the decode thread and owns every byte of decoder state.
 *
 * Two methods, and the split is the whole point: close() is reached through a blocking queued call
 * so the libav objects are released on the thread that made them, while decode() is reached through
 * a queued call from the RTP thread and is the only other thing that runs here.
 */
class DecodeWorker : public QObject
{
    Q_OBJECT

public:
    explicit DecodeWorker(PlaybackDecoder* owner) : owner_(owner) {}

    /// Releases the decoder. Must run on this object's thread.
    void close()
    {
        decoder_.reset();
        sps_.clear();
        pps_.clear();
        if (owner_) {
            owner_->open_.store(false, std::memory_order_release);
        }
    }

    /// Decodes one access unit. Must run on this object's thread.
    ///
    /// Every path out of here goes through finishDecodeAndPostNext(), including the early ones. A
    /// single exit is what keeps PlaybackDecoder's pending slot from staying latched: skip it once
    /// and decodeBusy_ is never cleared, which silently freezes the picture for the rest of the
    /// session with nothing in the logs to say why.
    void decode(const QByteArray& annexB, const QByteArray& sps, const QByteArray& pps)
    {
        if (!owner_) {
            return;
        }
        decodeOne(annexB, sps, pps);
        owner_->finishDecodeAndPostNext();
    }

private:
    void decodeOne(const QByteArray& annexB, const QByteArray& sps, const QByteArray& pps)
    {
        if (!owner_->isRunning() || annexB.isEmpty()) {
            return;
        }

        // A unit that carries only one of the two sets keeps the half already held: the
        // depacketiser reports what it saw in this access unit, so an SPS-only unit is normal and
        // must not throw away the PPS from the previous keyframe.
        if (!sps.isEmpty()) {
            sps_ = sps;
        }
        if (!pps.isEmpty()) {
            pps_ = pps;
        }
        if (!ensureDecoder()) {
            return;
        }

        decoder_->packet->data = const_cast<uint8_t*>(reinterpret_cast<const uint8_t*>(annexB.constData()));
        decoder_->packet->size = static_cast<int>(annexB.size());

        // A rejected packet is normal, not exceptional: an access unit can reference a picture the
        // decoder never saw the start of. The next keyframe repairs it, and reporting it would mean
        // interrupting playback for something the decoder already recovers from.
        if (avcodec_send_packet(decoder_->context, decoder_->packet) < 0) {
            return;
        }

        for (;;) {
            if (avcodec_receive_frame(decoder_->context, decoder_->frame) < 0) {
                break;
            }
            const QImage image = toRgb32(*decoder_->frame, decoder_->scaler);
            av_frame_unref(decoder_->frame);
            if (image.isNull()) {
                if (!conversionFailureReported_) {
                    conversionFailureReported_ = true;
                    if (const PlaybackDecoder::FailureHandler handler = owner_->onFailure()) {
                        handler(QStringLiteral(
                            "The received video pixel format or colour metadata could not be converted."));
                    }
                }
                continue;
            }
            if (const PlaybackDecoder::FrameHandler handler = owner_->onFrame()) {
                handler(image);
            }
        }
    }

    bool ensureDecoder()
    {
        if (sps_.isEmpty() || pps_.isEmpty()) {
            return false;
        }
        if (decoder_ && sps_ == openSps_ && pps_ == openPps_) {
            return true;
        }

        const AVCodec* codec = avcodec_find_decoder(AV_CODEC_ID_H264);
        if (!codec) {
            if (const PlaybackDecoder::FailureHandler handler = owner_->onFailure()) {
                handler(QStringLiteral("This FFmpeg build cannot decode H.264."));
            }
            return false;
        }

        auto decoder = std::make_unique<DecoderState>();
        decoder->context = avcodec_alloc_context3(codec);
        if (!decoder->context) {
            return false;
        }

        // Annex B with start codes. The parameter sets are bare NALs by contract, and libavcodec's
        // H.264 decoder expects start codes in its extradata: concatenating them without them yields
        // extradata the decoder rejects, and the failure is a decoder that never produces a frame
        // rather than an error at open.
        //
        // Padded because libavcodec reads past the end of the extradata while parsing it, and an
        // unpadded buffer is a heap overread on some builds rather than a clean parse failure.
        static constexpr char StartCode[4] = { '\0', '\0', '\0', '\1' };

        QByteArray extradata;
        extradata.reserve(8 + sps_.size() + pps_.size());
        extradata.append(StartCode, 4);
        extradata.append(sps_);
        extradata.append(StartCode, 4);
        extradata.append(pps_);
        const int extraSize = extradata.size() + AV_INPUT_BUFFER_PADDING_SIZE;
        decoder->context->extradata = static_cast<uint8_t*>(av_mallocz(static_cast<size_t>(extraSize)));
        if (!decoder->context->extradata) {
            return false;
        }
        std::memcpy(decoder->context->extradata, extradata.constData(), static_cast<size_t>(extradata.size()));
        decoder->context->extradata_size = extraSize;

        if (avcodec_open2(decoder->context, codec, nullptr) < 0) {
            return false;
        }
        decoder->frame = av_frame_alloc();
        decoder->packet = av_packet_alloc();
        if (!decoder->frame || !decoder->packet) {
            return false;
        }

        // The previous decoder is replaced, not merged into: a resolution or profile change means
        // the old context's reference frames are meaningless, and libav has no way to be told that
        // short of a new open.
        decoder_ = std::move(decoder);
        conversionFailureReported_ = false;
        openSps_ = sps_;
        openPps_ = pps_;
        owner_->open_.store(true, std::memory_order_release);
        return true;
    }

    PlaybackDecoder* owner_ = nullptr;

    std::unique_ptr<DecoderState> decoder_;
    QByteArray sps_;
    QByteArray pps_;
    bool conversionFailureReported_ = false;

    /// What the open decoder was built from, so an unchanged pair costs a comparison and not a
    /// re-open -- a re-open per frame would drop every reference frame and never display anything.
    QByteArray openSps_;
    QByteArray openPps_;
};

PlaybackDecoder::PlaybackDecoder() = default;

PlaybackDecoder::~PlaybackDecoder()
{
    stop();
}

bool PlaybackDecoder::start(FrameHandler onFrame, FailureHandler onFailure)
{
    if (running_.load(std::memory_order_acquire)) {
        return true;
    }
    {
        QMutexLocker locker(&handlerMutex_);
        onFrame_ = std::move(onFrame);
        onFailure_ = std::move(onFailure);
    }

    thread_ = std::make_unique<QThread>();
    thread_->setObjectName(QStringLiteral("LocalStream-VideoDecode"));

    // Built here, on the caller's thread, so it starts with that affinity; the move is what puts it
    // on the decode thread. NOT `connect(thread, &QThread::finished, worker, &QObject::deleteLater)`:
    // that idiom deletes the worker while worker_ still owns it, and stop() then resets the pointer
    // -- the double free RtpReceiver::close() documents in full.
    auto worker = std::make_unique<DecodeWorker>(this);
    worker->moveToThread(thread_.get());
    worker_ = std::move(worker);

    thread_->start();
    running_.store(true, std::memory_order_release);
    open_.store(false, std::memory_order_release);
    return true;
}

void PlaybackDecoder::stop()
{
    if (!running_.exchange(false)) {
        return;
    }

    DecodeWorker* raw = worker_.get();
    if (raw && thread_ && thread_->isRunning()) {
        // Blocking, not queued: the libav objects may only be freed on the thread that created
        // them, and the thread must not be told to stop before they have actually been released.
        // A queued call followed immediately by quit() would be dropped along with the loop.
        QMetaObject::invokeMethod(raw, [raw] { raw->close(); }, Qt::BlockingQueuedConnection);
        thread_->quit();
        // Bounded: a wedged decode must not hang the UI on close.
        if (!thread_->wait(2000)) {
            thread_->terminate();
            thread_->wait();
        }
    }

    worker_.reset();
    thread_.reset();

    // Anything submitted while stopping is stale by definition, and keeping it would let the next
    // session decode a frame from the previous broadcaster.
    {
        QMutexLocker locker(&pendingMutex_);
        pending_.clear();
        decodeBusy_ = false;
    }
    open_.store(false, std::memory_order_release);
}

void PlaybackDecoder::submit(const QByteArray& annexB, const QByteArray& sps, const QByteArray& pps)
{
    DecodeWorker* worker = worker_.get();
    if (!worker || annexB.isEmpty() || !running_.load(std::memory_order_acquire)) {
        return;
    }

    {
        QMutexLocker locker(&pendingMutex_);
        if (decodeBusy_) {
            // Queue, bounded. A frame that arrives while another decodes has to wait somewhere,
            // and dropping it outright would make a burst -- the normal shape of Wi-Fi delivery --
            // lose frames the decoder could have absorbed. The cap is what keeps that from
            // becoming unbounded latency: once the queue is as deep as the configured buffer, the
            // oldest frame is the one least worth playing, so it is the one shed.
            const auto cap = static_cast<size_t>(maxQueuedFrames_.load(std::memory_order_relaxed));
            if (pending_.size() >= cap) {
                pending_.pop_front();
            }
            pending_.push_back(PendingUnit{annexB, sps, pps});
            return;
        }
        decodeBusy_ = true;
    }

    postToWorker(worker, annexB, sps, pps);
}

void PlaybackDecoder::setMaxQueuedFrames(int frames)
{
    // Clamped rather than trusted: the value reaches here from a GUI, and 600 frames is already
    // 20 seconds at 30 fps, far past any useful bound.
    maxQueuedFrames_.store(qBound(1, frames, 600), std::memory_order_relaxed);
}

void PlaybackDecoder::postToWorker(
    DecodeWorker* worker, const QByteArray& annexB, const QByteArray& sps, const QByteArray& pps)
{
    // Queued, and every payload captured by value. This runs on the RTP thread, which is about to
    // reuse its depacketiser buffers; a lambda referencing them would decode whatever arrived next.
    // Qt copies the captures before invokeMethod returns, so the media thread is free immediately.
    QMetaObject::invokeMethod(worker,
        [worker, unit = annexB, sps, pps] { worker->decode(unit, sps, pps); }, Qt::QueuedConnection);
}

void PlaybackDecoder::finishDecodeAndPostNext()
{
    DecodeWorker* worker = worker_.get();
    QByteArray unit;
    QByteArray sps;
    QByteArray pps;

    {
        QMutexLocker locker(&pendingMutex_);
        if (pending_.empty() || !running_.load(std::memory_order_acquire)) {
            decodeBusy_ = false;
            return;
        }
        PendingUnit next = std::move(pending_.front());
        pending_.pop_front();
        unit = std::move(next.annexB);
        sps = std::move(next.sps);
        pps = std::move(next.pps);
    }

    // Still decodeBusy_: a unit is moved out rather than the flag being cleared, so a burst that
    // arrives while this frame decodes stays queued instead of being lost.
    if (worker) {
        postToWorker(worker, unit, sps, pps);
    }
}

PlaybackDecoder::FrameHandler PlaybackDecoder::onFrame() const
{
    QMutexLocker locker(&handlerMutex_);
    return onFrame_;
}

PlaybackDecoder::FailureHandler PlaybackDecoder::onFailure() const
{
    QMutexLocker locker(&handlerMutex_);
    return onFailure_;
}

} // namespace localstream::engine

#include "PlaybackDecoder.moc"
