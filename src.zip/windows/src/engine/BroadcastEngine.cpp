﻿#include "engine/BroadcastEngine.h"

#include "logging/Log.h"

#include <QDateTime>
#include <QHostAddress>
#include <QHostInfo>
#include <QNetworkInterface>
#include <QTimer>

#include <limits>

#include "capture/Encoders.h"
#include "capture/FrameSource.h"
#include "discovery/ServiceAdvertiser.h"
#include "net/RtpSender.h"

namespace localstream::engine {

namespace {

/// The name every line from this file carries, so a report reads as one subsystem.
constexpr char kCategory[] = "BroadcastEngine";

/// How often the UI's statistics are refreshed. A second is fast enough to feel live and slow
/// enough that the number does not flicker past being read.
constexpr int StatsIntervalMs = 1000;

constexpr int AudioSampleRate = 48000;
constexpr int AudioChannels = 1;

/// How long the capture pipelines get to produce their first usable output before the broadcast
/// is declared a failure. Long enough for a camera to initialise, short enough that a wedged
/// device does not leave the user staring at a broadcast that looks live but is sending nothing.
constexpr int CaptureWatchdogMs = 5000;

/**
 * Records why a start was refused and hands [reason] back to the caller unchanged.
 *
 * The one place the refusal is logged rather than in seven: a broadcast that did not start is
 * the single most common thing a report is sent about, and the reason it did not start is the
 * one line in it that matters. Setting the error text and writing it down together is what keeps
 * the two from drifting apart.
 */
bool refused(QString* error, const QString& reason)
{
    if (error != nullptr) {
        *error = reason;
    }
    logging::error(QString::fromLatin1(kCategory),
        QStringLiteral("broadcast.start refused: %1").arg(reason));
    return false;
}

/// The same, for a start that handed its reason to something else.
bool refusedWith(QString* error, const char* what)
{
    return refused(error,
        error != nullptr && !error->isEmpty() ? *error
                                              : QStringLiteral("an unknown failure in %1")
                                                    .arg(QString::fromLatin1(what)));
}

/// True for an address on a private LAN, as opposed to link-local or public.
bool isPrivateAddress(const QHostAddress& address)
{
    return address.isInSubnet(QHostAddress(QStringLiteral("10.0.0.0")), 8)
        || address.isInSubnet(QHostAddress(QStringLiteral("172.16.0.0")), 12)
        || address.isInSubnet(QHostAddress(QStringLiteral("192.168.0.0")), 16);
}

/// True for interfaces that are virtual, and so are a poor default to advertise.
///
/// Hyper-V, WSL, Docker and VMware switch adapters are routinely up and running while
/// carrying a private address, and they are frequently enumerated first. A receiver that
/// trusts such an address can connect to nothing, so these are ranked below real hardware.
bool isVirtualInterface(const QNetworkInterface& interface)
{
    const QString name = interface.name() + QLatin1Char(' ') + interface.humanReadableName();
    return name.contains(QStringLiteral("vEthernet"), Qt::CaseInsensitive)
        || name.contains(QStringLiteral("VirtualBox"), Qt::CaseInsensitive)
        || name.contains(QStringLiteral("VMware"), Qt::CaseInsensitive)
        || name.contains(QStringLiteral("Hyper-V"), Qt::CaseInsensitive)
        || name.contains(QStringLiteral("WSL"), Qt::CaseInsensitive)
        || name.contains(QStringLiteral("Docker"), Qt::CaseInsensitive)
        || name.contains(QStringLiteral("Loopback"), Qt::CaseInsensitive)
        || name.contains(QStringLiteral("Tap"), Qt::CaseInsensitive);
}

} // namespace

/// Picks the address a broadcast should advertise, and the address the page prints beside the
/// control port.
///
/// A loopback or link-local address would be unreachable from another machine. Of what is
/// left, a real adapter on a private LAN is preferred over a virtual switch, and a private
/// address over a public one: a receiver is almost always a peer on the same network, and the
/// virtual adapters that carry private addresses (`vEthernet`, VMware) are exactly the
/// ones that will not route to it. A receiver can always override by entering the address
/// by hand.
QHostAddress BroadcastEngine::localAddress()
{
    const QList<QNetworkInterface> interfaces = QNetworkInterface::allInterfaces();

    // Ranked best-first; the first match wins, so the ordering below is the policy.
    const auto rank = [](const QNetworkInterface& interface, const QHostAddress& address) {
        if (isVirtualInterface(interface)) {
            return 3;
        }
        if (isPrivateAddress(address)) {
            return 0;
        }
        // Link-local (169.254/16) means no DHCP lease, so nothing else on the LAN will have
        // a route to it. A public address is a better guess than that, but still unlikely.
        return address.isLinkLocal() ? 2 : 1;
    };

    int bestRank = std::numeric_limits<int>::max();
    QHostAddress best;
    for (const QNetworkInterface& interface : interfaces) {
        const auto flags = interface.flags();
        if (!flags.testFlag(QNetworkInterface::IsUp)
            || !flags.testFlag(QNetworkInterface::IsRunning)
            || flags.testFlag(QNetworkInterface::IsLoopBack)) {
            continue;
        }
        for (const QNetworkAddressEntry& entry : interface.addressEntries()) {
            const QHostAddress address = entry.ip();
            if (address.protocol() != QAbstractSocket::IPv4Protocol || address.isLoopback()) {
                continue;
            }
            const int candidateRank = rank(interface, address);
            if (candidateRank < bestRank) {
                bestRank = candidateRank;
                best = address;
            }
        }
    }
    return best;
}

BroadcastEngine::BroadcastEngine(QObject* parent) : QObject(parent)
{
    captureWatchdog_ = new QTimer(this);
    captureWatchdog_->setSingleShot(true);
    connect(captureWatchdog_, &QTimer::timeout, this, &BroadcastEngine::checkCapture);
}

BroadcastEngine::~BroadcastEngine()
{
    stop();
}

int BroadcastEngine::controlPort() const
{
    return control_.port();
}

protocol::LocalStream::Description BroadcastEngine::currentDescription() const
{
    protocol::LocalStream::Description description;
    description.sessionId = sessionId_;
    description.displayName = settings_.displayName;
    description.mode = mode_;
    // This description only exists while a broadcast is running, so the state advertised
    // to receivers is always live. Leaving it at the default would make every broadcaster
    // look idle in a receiver's list, which is the one thing the flag is there to prevent.
    description.live = true;
    description.width = settings_.width;
    description.height = settings_.height;
    description.frameRate = settings_.frameRate;
    description.videoBitrateKbps = settings_.videoBitrateKbps;
    description.audioBitrateKbps = settings_.audioBitrateKbps;
    description.audioChannels = AudioChannels;
    description.controlPort = control_.port();
    if (sender_) {
        description.videoPort = sender_->videoPort();
        description.audioPort = sender_->audioPort();
    }
    return description;
}

bool BroadcastEngine::start(const Settings& settings, QString* error)
{
    if (running.load()) {
        return true;
    }

    logging::event(QStringLiteral("broadcast.start.requested"),
        {{QStringLiteral("name"), settings.displayName},
            {QStringLiteral("size"),
                QStringLiteral("%1x%2").arg(settings.width).arg(settings.height)},
            {QStringLiteral("fps"), QString::number(settings.frameRate)},
            {QStringLiteral("video"), QString::number(settings.videoBitrateKbps)},
            {QStringLiteral("audio"), QString::number(settings.audioBitrateKbps)},
            {QStringLiteral("access"), settings.accessMode},
            {QStringLiteral("testSources"),
                settings.useTestSources ? QStringLiteral("yes") : QStringLiteral("no")}});

    settings_ = settings;
    // H.264 with 4:2:0 chroma needs even dimensions; an odd height would be rejected by the
    // encoder much later and much less clearly than it is rounded here.
    settings_.width -= settings_.width % 2;
    settings_.height -= settings_.height % 2;
    if (settings_.width < 2 || settings_.height < 2) {
        return refused(error, QStringLiteral("The frame size must be at least 2x2."));
    }
    if (settings_.frameRate <= 0) {
        return refused(error, QStringLiteral("The frame rate must be greater than zero."));
    }
    // Checked before anything is opened, so an unusable password fails as fast as an unusable
    // frame size rather than half way through binding sockets and starting threads.
    if (settings_.accessMode == QLatin1String(protocol::access::Password)
        && !protocol::isValidAccessPassword(settings_.accessPassword)) {
        return refused(error,
            QStringLiteral("The broadcast password must be between %1 and %2 characters.")
                .arg(protocol::accesslimits::MinPasswordLength)
                .arg(protocol::accesslimits::MaxPasswordLength));
    }

    sessionId_ = protocol::LocalStream::newSessionId();
    videoWanted.store(true);
    audioWanted.store(true);
    failureReported.store(false);
    mode_ = QString::fromLatin1(protocol::LocalStream::ModeAudioVideo);

    // 1. Media sockets first: their ports go into the announcement, so they have to be bound
    //    before anything can be advertised.
    sender_ = std::make_unique<net::RtpSender>();
    if (!sender_->open(true, error)) {
        sender_.reset();
        return refusedWith(error, "the media sockets");
    }
    sender_->setFrameRate(settings_.frameRate);
    sender_->setMaxPayload(settings_.rtpMaxPayload);
    sender_->setPacing(settings_.pacingThresholdPackets, settings_.pacingSpreadFrames);

    // The keyframe request arrives on the control thread but the encoder lives on the video
    // thread, so it is forwarded across threads rather than called directly.
    sender_->setKeyframeRequestHook([this] { requestKeyframe(); });

    // 2. Control server second, so the control port is listening before it is announced.
    net::ControlServer::Callbacks callbacks;
    callbacks.description = [this] { return currentDescription(); };
    callbacks.sdp = [this] {
        return protocol::LocalStream::buildSdp(currentDescription(), sender_->videoSsrc(),
            sender_->audioSsrc());
    };
    callbacks.audioSsrc = [this] { return sender_->audioSsrc(); };
    callbacks.videoSsrc = [this] { return sender_->videoSsrc(); };
    callbacks.onOffer = [this](const QHostAddress& address, int audioPort, int videoPort) {
        sender_->addTarget({address, audioPort, videoPort});
        // Asked for here, and not left to the receiver to ask: the receiver cannot decode anything
        // until it has the SPS and PPS, and those only travel in a keyframe, so a receiver that
        // joined between keyframes would sit on a black screen until the broadcaster's next
        // keyint. Asking on the offer makes the join self-healing rather than dependent on how
        // the receiver was written.
        requestKeyframe();
    };
    callbacks.onRemove = [this](const QHostAddress& address, int audioPort, int videoPort) {
        sender_->removeTarget(address, audioPort, videoPort);
    };
    callbacks.onKeyframeRequest = [this] { requestKeyframe(); };
    // A live bitrate change would mean new encoder settings mid-stream. Rather than honour it
    // partially, the session is renegotiated: receivers are told the session is new, so they
    // pick up a description that matches what is actually being encoded.
    callbacks.onBitrateRequest = [this](int videoKbps, int audioKbps) {
        settings_.videoBitrateKbps = videoKbps;
        settings_.audioBitrateKbps = audioKbps;
        sessionId_ = protocol::LocalStream::newSessionId();
        control_.sendModeChanged(mode_);
    };
    // A receiver may request, never decide. The change is made here and then announced, so
    // every receiver converges on the same mode.
    callbacks.onModeRequest = [this](const QString& mode) { setMode(mode); };
    callbacks.onReceiverConnected = [this](const QString& name) {
        logging::event(QStringLiteral("receiver.joined"),
            {{QStringLiteral("name"), name},
                {QStringLiteral("total"), QString::number(control_.receiverCount())}});
        emit receiverJoined(name);
    };
    callbacks.onReceiverDisconnected = [this](const QString& name) {
        logging::event(QStringLiteral("receiver.left"),
            {{QStringLiteral("name"), name},
                {QStringLiteral("remaining"), QString::number(control_.receiverCount())}});
        emit receiverLeft(name);
    };
    // Arrives on the control thread, and a signal is thread-safe, so it is emitted from here and
    // the UI decides how to present it. The queued connection to the UI is made by Qt, not here.
    callbacks.onAccessRequest
        = [this](quint64 key, const QString& name) { emit accessRequested(key, name); };
    control_.setCallbacks(callbacks);
    control_.setMaxReceivers(settings_.maxReceivers);
    // Applied before `listen` so the very first `welcome` already carries the access mode; a
    // receiver that connected between listen and this call would otherwise be told "public" and
    // let in without asking.
    control_.setAccessMode(settings_.accessMode);
    control_.setAccessPassword(settings_.accessPassword);

    if (!control_.listen(error)) {
        sender_.reset();
        return refusedWith(error, "the control port");
    }

    // The encoders are created here, on the calling thread, but are only ever used by their own
    // pipeline thread afterwards. Opening them before the threads start keeps a codec failure --
    // an unsupported profile, a missing x264 -- reported synchronously through [error] instead
    // of arriving later as a signal nobody is connected to yet.
    if (settings_.useTestSources) {
        video_.source = std::make_unique<capture::TestPatternSource>(settings_.width,
            settings_.height, settings_.frameRate);
        audio_.source
            = std::make_unique<capture::TestToneSource>(AudioSampleRate, AudioChannels);
    } else {
        video_.source = std::make_unique<capture::ScreenCapture>(settings_.width, settings_.height,
            settings_.frameRate);

        // A real microphone, so the audio a viewer hears is the broadcaster's voice rather than a
        // tone. An empty name means "the first recording device", which is the right default for
        // a machine with one microphone and the only sensible one to ship.
        const QList<capture::DeviceOption> microphones = capture::listMicrophones();
        if (microphones.isEmpty()) {
            control_.close();
            sender_.reset();
            return refused(error,
                QStringLiteral("No microphone was found. Connect one, or tick the test pattern to "
                               "broadcast without a microphone."));
        }

        const auto chosen = std::find_if(microphones.cbegin(), microphones.cend(),
            [&settings](const capture::DeviceOption& device) {
                return device.name == settings.audioDeviceName;
            });
        // Falls back to the first device when the requested name is not among them, which is what
        // happens when a headset is unplugged between opening the list and pressing Start.
        // Broadcasting from a different microphone is recoverable; refusing to start is not.
        audio_.source = std::make_unique<capture::DeviceCapture>(
            chosen != microphones.cend() ? *chosen : microphones.first(), true);
    }

    video_.videoEncoder = std::make_unique<capture::VideoEncoder>(settings_.width,
        settings_.height, settings_.frameRate, settings_.videoBitrateKbps);
    if (!video_.videoEncoder->isOpen()) {
        control_.close();
        sender_.reset();
        return refused(error, QStringLiteral("Could not start the H.264 encoder."));
    }
    audio_.audioEncoder
        = std::make_unique<capture::AudioEncoder>(AudioSampleRate, AudioChannels,
            settings_.audioBitrateKbps, settings_.normalizeAudio);
    if (!audio_.audioEncoder->isOpen()) {
        control_.close();
        sender_.reset();
        return refused(error, QStringLiteral("Could not start the Opus encoder."));
    }

    running.store(true);
    statsWindowStartMs_ = QDateTime::currentMSecsSinceEpoch();
    startedAtMs_ = statsWindowStartMs_;
    statsTimer_ = new QTimer(this);
    connect(statsTimer_, &QTimer::timeout, this, &BroadcastEngine::publishStats);
    statsTimer_->start(1000);

    startVideoPipeline();
    startAudioPipeline();

    // Armed after both pipelines have been asked to run. A device that opens but never delivers
    // is otherwise indistinguishable from a healthy one until a viewer notices the silence.
    captureWatchdog_->start(CaptureWatchdogMs);

    // 3. Advertise last, so a receiver that reacts to the announcement finds everything already
    //    listening.
    advertiser_ = std::make_unique<net::ServiceAdvertiser>();
    net::ServiceAdvertiser::Settings advertise;
    advertise.displayName = settings_.displayName;
    advertise.hostName = QHostInfo::localHostName();
    advertise.address = localAddress();
    advertise.controlPort = control_.port();
    advertise.txtRecord = protocol::LocalStream::txtWireRecord(currentDescription());
    advertise.sessionId = sessionId_;
    QString advertiseError;
    advertiser_->start(advertise, &advertiseError);
    // A failure here is worth reporting but not worth refusing to broadcast over: a receiver
    // given the host and port by hand still works.
    if (!advertiseError.isEmpty()) {
        logging::warning(QString::fromLatin1(kCategory),
            QStringLiteral("broadcast.advertise.failed: %1").arg(advertiseError));
        emit warning(advertiseError);
    }

    logging::event(QStringLiteral("broadcast.started"),
        {{QStringLiteral("session"), sessionId_},
            {QStringLiteral("controlPort"), QString::number(control_.port())},
            {QStringLiteral("audioPort"), QString::number(sender_->audioPort())},
            {QStringLiteral("videoPort"), QString::number(sender_->videoPort())},
            {QStringLiteral("advertise"),
                advertiseError.isEmpty() ? QStringLiteral("ok") : QStringLiteral("degraded")}});

    // Started after the pipelines so that the first frames a receiver receives are real ones.
    QTimer::singleShot(0, this, &BroadcastEngine::started);
    return true;
}

void BroadcastEngine::startVideoPipeline()
{
    video_.thread = new QThread(this);
    video_.thread->setObjectName(QStringLiteral("localstream-video"));
    // Created here, on the caller's thread, so it starts with this thread's affinity; the move is
    // what gives it the capture thread's. Addressing the queued call to the worker is the whole
    // point -- see Pipeline::worker.
    video_.worker = new QObject;
    video_.worker->moveToThread(video_.thread);
    connect(video_.thread, &QThread::finished, video_.thread, &QObject::deleteLater);
    video_.thread->start();
    QMetaObject::invokeMethod(video_.worker, [this] { runVideo(); }, Qt::QueuedConnection);
}

void BroadcastEngine::startAudioPipeline()
{
    audio_.thread = new QThread(this);
    audio_.thread->setObjectName(QStringLiteral("localstream-audio"));
    audio_.worker = new QObject;
    audio_.worker->moveToThread(audio_.thread);
    connect(audio_.thread, &QThread::finished, audio_.thread, &QObject::deleteLater);
    audio_.thread->start();
    QMetaObject::invokeMethod(audio_.worker, [this] { runAudio(); }, Qt::QueuedConnection);
}

void BroadcastEngine::runVideo()
{
    QString deviceError;
    const bool opened = video_.source->start(
        [this](const capture::VideoSample& sample) {
            // Mode is re-read per frame so a change takes effect without restarting the device.
            if (!videoWanted.load() || !video_.videoEncoder) {
                return;
            }
            video_.videoEncoder->encode(sample, [this](const capture::EncodedVideo& frame) {
                if (!running.load()) {
                    return;
                }
                sender_->sendVideo(frame.accessUnit);
                ++framesEncoded;
                videoBytesSent.fetch_add(
                    static_cast<quint64>(frame.accessUnit.size()));
            });
        },
        [](const capture::AudioSample&) {},
        &deviceError);

    if (!opened && !deviceError.isEmpty() && running.load()) {
        // Reported across to the owning thread rather than handled here, because reportFailure
        // emits a signal and tears the broadcast down, and neither is safe from this thread.
        QMetaObject::invokeMethod(this,
            [this, reason = deviceError] { reportFailure(reason); }, Qt::QueuedConnection);
    }
}

void BroadcastEngine::runAudio()
{
    QString deviceError;
    const bool opened = audio_.source->start([](const capture::VideoSample&) {},
        [this](const capture::AudioSample& sample) {
            if (!audioWanted.load() || !audio_.audioEncoder) {
                return;
            }
            audio_.audioEncoder->encode(sample, [this](const capture::EncodedAudio& audio) {
                if (!running.load()) {
                    return;
                }
                sender_->sendAudio(audio.packet);
                audioBytesSent.fetch_add(static_cast<quint64>(audio.packet.size()));
            });
        },
        &deviceError);

    if (!opened && !deviceError.isEmpty() && running.load()) {
        QMetaObject::invokeMethod(this,
            [this, reason = deviceError] { reportFailure(reason); }, Qt::QueuedConnection);
    }
}

void BroadcastEngine::checkCapture()
{
    if (!running.load() || failureReported.load()) {
        return;
    }

    // Bytes sent and frames encoded, not "a callback fired": a device can deliver a stream of
    // empty samples, which is exactly the shape of the silent-audio bug this guards against.
    const bool noAudio = audioWanted.load() && audioBytesSent.load() == 0;
    const bool noVideo = videoWanted.load() && framesEncoded.load() == 0;
    if (!noAudio && !noVideo) {
        return;
    }

    const int seconds = CaptureWatchdogMs / 1000;
    QString reason;
    if (noAudio && noVideo) {
        reason = QStringLiteral("Neither audio nor video was captured in the first %1 seconds. "
                                "The capture device did not respond, so the broadcast has been "
                                "stopped.")
                     .arg(seconds);
    } else if (noAudio) {
        reason = QStringLiteral("No sound was captured from the microphone in the first %1 "
                                "seconds. It may be in use by another app, muted, or disabled in "
                                "Windows sound settings. The broadcast has been stopped.")
                     .arg(seconds);
    } else {
        reason = QStringLiteral("No video was captured in the first %1 seconds. The screen or "
                                "camera did not respond, so the broadcast has been stopped.")
                     .arg(seconds);
    }
    reportFailure(reason);
}

void BroadcastEngine::reportFailure(const QString& reason)
{
    // Only the first caller wins, so a wedged device and the watchdog cannot both end the same
    // broadcast. Exchange, not load-then-store, because the two run on different threads.
    if (failureReported.exchange(true)) {
        return;
    }

    logging::error(QString::fromLatin1(kCategory),
        QStringLiteral("broadcast.capture.failed: %1").arg(reason));

    // Emitted before stop() so the page reports the reason rather than a plain "stopped".
    emit failed(reason);
    // Stopping here is what makes the failure recoverable: the page has already set itself back
    // to idle, and a broadcast still holding its ports would make the next start a silent no-op.
    stop();
}

void BroadcastEngine::stopPipeline(Pipeline& pipeline)
{
    if (pipeline.source) {
        pipeline.source->stop();
    }
    if (pipeline.thread) {
        pipeline.thread->quit();
        // Waits for the capture loop to leave its blocking read. Bounded because a wedged
        // device would otherwise hang the UI on quit forever.
        if (!pipeline.thread->wait(5000)) {
            pipeline.thread->terminate();
            pipeline.thread->wait();
        }
        pipeline.thread = nullptr;
    }
    // Deleted here, after the thread is joined, and NOT via connect(finished, worker,
    // deleteLater): that deletes the worker on the dying thread while this struct still points
    // at it, and the next stop() would free it again. PlaybackDecoder::stop documents the same
    // double free in full.
    delete pipeline.worker;
    pipeline.worker = nullptr;
}

void BroadcastEngine::requestKeyframe()
{
    // The worker is nulled once the pipeline has been torn down, and a control message can
    // still arrive in that window, so the address has to be checked rather than assumed.
    QObject* worker = video_.worker;
    if (!worker || !video_.videoEncoder) {
        return;
    }
    // Forwarded to the video thread, which is the only thread allowed to touch the encoder. The
    // worker is the object with that thread's affinity, so it is the only correct address here.
    QMetaObject::invokeMethod(worker, [this] {
        if (video_.videoEncoder) {
            video_.videoEncoder->requestKeyframe();
        }
    }, Qt::QueuedConnection);
}

void BroadcastEngine::publishStats()
{
    if (!running.load()) {
        return;
    }
    const qint64 now = QDateTime::currentMSecsSinceEpoch();
    const qint64 elapsed = now - statsWindowStartMs_;
    if (elapsed < 500) {
        return;
    }

    const int fps = static_cast<int>(framesEncoded.load() * 1000 / elapsed);
    const int kbps = static_cast<int>(
        (videoBytesSent.load() + audioBytesSent.load()) * 8 / elapsed);
    framesEncoded.store(0);
    videoBytesSent.store(0);
    audioBytesSent.store(0);
    statsWindowStartMs_ = now;

    const int receiverCount = control_.receiverCount();

    protocol::BroadcasterStats stats;
    stats.framesPerSecond = fps;
    stats.kilobitsPerSecond = kbps;
    stats.receiverCount = receiverCount;
    control_.sendStats(stats);

    emit statsChanged(fps, kbps, receiverCount, sender_->lastAccessUnitPacketCount(),
        sender_->lastAccessUnitFragmentCount(), sender_->lastAccessUnitLargestPayload());

    // Once a second is too often for a report to carry, and too useful to leave out: a run of
    // these is the fastest way to see where a stall was - whether the frame rate fell, the
    // bitrate collapsed, or the last receiver left.
    const int sendFailures = sender_->sendFailureCount();
    logging::debug(QString::fromLatin1(kCategory),
        QStringLiteral("stats fps=%1 kbps=%2 receivers=%3 senddrop=%4").arg(fps).arg(kbps)
            .arg(receiverCount).arg(sendFailures));
}

void BroadcastEngine::setMode(const QString& mode)
{
    if (mode == mode_ || !running.load()) {
        return;
    }
    // Validated against the known modes rather than echoed blindly, because this value ends up
    // in the TXT record and in a control message that receivers switch on.
    if (mode == QLatin1String(protocol::LocalStream::ModeAudioVideo)) {
        videoWanted.store(true);
        audioWanted.store(true);
    } else if (mode == QLatin1String(protocol::LocalStream::ModeAudioOnly)) {
        videoWanted.store(false);
        audioWanted.store(true);
    } else {
        emit warning(QStringLiteral("Ignored an unknown mode: %1").arg(mode));
        return;
    }

    mode_ = mode;
    control_.sendModeChanged(mode_);
    emit modeChanged(mode_);
}

bool BroadcastEngine::setAccess(const QString& mode, const QString& password)
{
    // Rejects anything the receiver side does not know, so a typo cannot leave the session in a
    // state where the UI says "locked" and the wire says nothing.
    const QString normalised = protocol::accessModeOrPublic(mode);
    if (normalised != mode) {
        emit warning(QStringLiteral("Ignored an unknown access mode: %1").arg(mode));
        return false;
    }
    if (normalised == QLatin1String(protocol::access::Password)
        && !protocol::isValidAccessPassword(password)) {
        return false;
    }

    settings_.accessMode = normalised;
    settings_.accessPassword = password;
    if (!running.load()) {
        return true; // taken by start() from the settings it is given
    }
    control_.setAccessMode(normalised);
    control_.setAccessPassword(password);
    return true;
}

void BroadcastEngine::resolveAccessRequest(quint64 requestKey, bool allow)
{
    control_.resolveAccessRequest(requestKey, allow);
}

void BroadcastEngine::stop()
{
    if (!running.exchange(false)) {
        return;
    }

    logging::event(QStringLiteral("broadcast.stopping"),
        {{QStringLiteral("session"), sessionId_},
            {QStringLiteral("uptimeMs"),
                QString::number(QDateTime::currentMSecsSinceEpoch() - startedAtMs_)},
            {QStringLiteral("receivers"), QString::number(control_.receiverCount())}});

    // Before anything else, so a publishStats() cannot land between the teardown steps below and
    // read a sender that no longer exists.
    if (statsTimer_) {
        statsTimer_->stop();
    }
    // A user who stops within the first few seconds must not get an error dialog afterwards.
    if (captureWatchdog_) {
        captureWatchdog_->stop();
    }

    // Stopped before anything is torn down so the capture loops do not call into a sender that
    // is being destroyed.
    stopPipeline(video_);
    stopPipeline(audio_);

    // Told why before the sockets go away, so a receiver learns the broadcast ended rather than
    // seeing a socket disappear and having to guess.
    control_.closeAll(QString::fromLatin1(protocol::bye::Shutdown));

    // The encoders are drained after the loops stop but before the sockets close: those last
    // frames are real output that would otherwise be discarded.
    if (video_.videoEncoder) {
        video_.videoEncoder->flush([this](const capture::EncodedVideo& frame) {
            sender_->sendVideo(frame.accessUnit);
        });
    }
    if (audio_.audioEncoder) {
        audio_.audioEncoder->flush([this](const capture::EncodedAudio& audio) {
            sender_->sendAudio(audio.packet);
        });
    }

    if (advertiser_) {
        // Sends the goodbye records before the socket goes away.
        advertiser_->stop();
        advertiser_.reset();
    }
    // The rejections and bans belong to the broadcast, not to the app: a viewer who was blocked
    // from the session that just ended is judged afresh by the next one. Before `close`, because
    // `close` destroys the core thread and the clear would then have nothing to act on.
    control_.clearAccessHistory();
    control_.close();
    if (sender_) {
        sender_->removeAllTargets();
        sender_->close();
        sender_.reset();
    }

    video_.source.reset();
    audio_.source.reset();
    video_.videoEncoder.reset();
    audio_.audioEncoder.reset();

    emit stopped();
    logging::event(QStringLiteral("broadcast.stopped"), {{QStringLiteral("session"), sessionId_}});
}

} // namespace localstream::engine
