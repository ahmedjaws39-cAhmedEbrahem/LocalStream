#include "engine/PlaybackEngine.h"

#include "logging/Log.h"

#include <QTimer>

namespace localstream::engine {

namespace {

/// One Opus packet carries 20 ms. Clamped so a mistyped buffer cannot queue unbounded audio.
int packetsForBufferMs(int ms)
{
    return qBound(1, ms / 20, 1000);
}

/// Nominal duration of a video frame at 30 fps, which is what the buffer presets are sized
/// against. A frame's real duration varies with the stream, so this is an approximation on
/// purpose: the setting is a duration, and the queue has to hold whole frames.
constexpr int NominalFrameMs = 33;

/// A receive buffer in milliseconds as a video queue depth, in frames. Clamped like the audio one.
int framesForBufferMs(int ms)
{
    return qBound(1, ms / NominalFrameMs, 600);
}

} // namespace

PlaybackEngine::PlaybackEngine(QObject* parent) : QObject(parent)
{
    connect(&control_, &net::ControlClient::handshakeSucceeded, this,
        [this](const net::ControlClient::Handshake& handshake) {
            if (!receiver_ || !receiver_->setExpectedSource(handshake.peerAddress,
                    handshake.audioPort, handshake.audioSsrc,
                    handshake.videoPort, handshake.videoSsrc)) {
                const QString reason =
                    QStringLiteral("The broadcaster returned invalid media source details.");
                control_.disconnectFromBroadcaster();
                emit failed(reason);
                return;
            }

            // The broadcaster's answer is what says whether video is coming; the sockets were
            // opened before the connection existed, so both were bound in anticipation and this
            // only decides whether to feed them to the decoder.
            videoExpected.store(handshake.videoPort > 0);
            audioExpected.store(handshake.audioPort > 0);

            if (handshake.videoPort > 0) {
                control_.requestKeyframe();
            }

            // Opened here, once the channel count is known, and not before: a decoder configured
            // for the wrong layout decodes to noise rather than failing, so the SDP is the only
            // safe moment to choose one.
            if (audioExpected.load() && audio_ == nullptr) {
                audio_ = std::make_unique<AudioPlayer>();
                audio_->setMaxQueuedPackets(packetsForBufferMs(settings_.receiveBufferMs));
                if (!audio_->start(handshake.audioChannels, [this](const QString& reason) {
                        QMutexLocker locker(&audioErrorMutex_);
                        audioError_ = reason;
                    })) {
                    // Not fatal. A receiver with no audio device should still show the picture,
                    // and saying so is more useful than dropping the session. The reason is kept
                    // rather than only logged: a GUI with no console loses a warning, and "no
                    // sound" with no explanation is the hardest kind of bug to act on.
                    {
                        QMutexLocker locker(&audioErrorMutex_);
                        if (audioError_.isEmpty()) {
                            audioError_ = QStringLiteral("The audio device could not be opened.");
                        }
                    }
                    audio_.reset();
                }
            }
            emit started();
            logging::event(QStringLiteral("receive.started"),
                {{QStringLiteral("broadcaster"), control_.broadcasterName()},
                    {QStringLiteral("mode"), control_.mode()},
                    {QStringLiteral("audio"), QString::number(handshake.audioPort)},
                    {QStringLiteral("video"), QString::number(handshake.videoPort)},
                    {QStringLiteral("channels"), QString::number(handshake.audioChannels)},
                    {QStringLiteral("audioDevice"),
                        audio_ != nullptr ? QStringLiteral("open") : QStringLiteral("none")}});
        });

    connect(&control_, &net::ControlClient::stateChanged, this,
        [this](net::ControlClient::State state) {
            // Only the terminal rejection needs its own signal. `failed` alone cannot carry it,
            // because the two refusals want opposite remedies: one is worth retrying, the other
            // must not be offered again.
            if (state == net::ControlClient::State::Blocked) {
                logging::warning(QStringLiteral("PlaybackEngine"),
                    QStringLiteral("receive.blocked: %1")
                        .arg(net::ControlClient::blockedMessage()));
                emit blocked(net::ControlClient::blockedMessage());
            }
        });

    connect(&control_, &net::ControlClient::passwordRequired, this,
        &PlaybackEngine::passwordRequired);
    connect(&control_, &net::ControlClient::accessRequested, this,
        &PlaybackEngine::accessRequested);
    connect(&control_, &net::ControlClient::passwordRejected, this,
        &PlaybackEngine::passwordRejected);

    connect(&control_, &net::ControlClient::handshakeFailed, this, &PlaybackEngine::failed);

    connect(&control_, &net::ControlClient::ended, this, [this](const QString& reason, bool graceful) {
        if (!running_.load()) {
            return;
        }
        if (graceful) {
            // The broadcaster stopped on purpose. End silently: `stop()` emits `stopped`, and
            // the receive page uses that to return to searching without an error dialog.
            logging::event(QStringLiteral("receive.ended"),
                {{QStringLiteral("reason"), QStringLiteral("the broadcaster stopped")},
                    {QStringLiteral("graceful"), QStringLiteral("yes")}});
            stop();
        } else {
            logging::error(QStringLiteral("PlaybackEngine"),
                QStringLiteral("receive.ended: %1").arg(reason));
            emit failed(reason);
            stop();
        }
    });

    connect(&control_, &net::ControlClient::modeChanged, this, [this](const QString& mode) {
        Q_UNUSED(mode)
        // A switch to audio-only means nothing more video is coming; asking for a keyframe on the
        // way back means the picture does not have to wait out a keyframe interval to return.
        if (mode == QLatin1String(protocol::LocalStream::ModeAudioVideo)) {
            control_.requestKeyframe();
        }
    });

    connect(&control_, &net::ControlClient::broadcasterStatsReceived, this,
        [this](const protocol::BroadcasterStats& stats) {
            emit statsChanged(stats.framesPerSecond, stats.kilobitsPerSecond);
        });

    // Reported to the broadcaster rather than shown: what a receiver sends back is what lets the
    // broadcaster tell a stalled network from a stalled encoder, which is the question the
    // broadcaster's own counters cannot answer.
    statsTimer_ = new QTimer(this);
    statsTimer_->setInterval(1000);
    connect(statsTimer_, &QTimer::timeout, this, [this] {
        if (!running_.load() || !receiver_) {
            return;
        }
        const net::RtpReceiver::Stats received = receiver_->stats();
        protocol::ReceiverStats stats;
        stats.packets = received.audioPackets + received.videoPackets;
        stats.lost = received.lostPackets;
        stats.jitterMillis = received.jitterMillis;
        stats.keyframeRequests = received.keyframeRequests;
        control_.sendStats(stats);
        emit receptionStatsChanged(received.audioPackets, received.videoPackets, received.lostPackets,
                                   received.haveVideoParameters, decodedFrames(), audioPlayed(),
                                   isAudioOpen(), audioError());
    });
}

PlaybackEngine::~PlaybackEngine()
{
    stop();
}

bool PlaybackEngine::start(const QString& host, int controlPort, const Settings& settings,
    QString* error)
{
    if (running_.load()) {
        return true;
    }
    if (controlPort <= 0 || controlPort > 65535) {
        if (error != nullptr) {
            *error = QStringLiteral("The control port must be between 1 and 65535.");
        }
        logging::error(QStringLiteral("PlaybackEngine"),
            QStringLiteral("receive.start refused: control port %1 is out of range")
                .arg(controlPort));
        return false;
    }

    logging::event(QStringLiteral("receive.start.requested"),
        {{QStringLiteral("host"), host},
            {QStringLiteral("controlPort"), QString::number(controlPort)},
            {QStringLiteral("name"), settings.receiverName},
            {QStringLiteral("bufferMs"), QString::number(settings.receiveBufferMs)}});

    settings_ = settings;
    running_.store(true);
    decodedFrames_.store(0, std::memory_order_relaxed);
    {
        QMutexLocker locker(&audioErrorMutex_);
        audioError_.clear();
    }

    // Opened before the control connection, because the offer carries these ports and a packet
    // that arrives between `accept` and the socket existing is simply lost -- at 60 frames a
    // second that is the first frame after every join, which is the one carrying the parameter
    // sets.
    receiver_ = std::make_unique<net::RtpReceiver>();
    // Counts as audioExpected rather than playing immediately: the channel count is in the
    // broadcaster's SDP, which arrives with the welcome, and Opus packets carry no layout of
    // their own. Starting the player before that would mean guessing.
    receiver_->setAudioHandler([this](const QByteArray& packet) {
        if (!audioExpected.load() || !audio_) {
            return;
        }
        audio_->submit(packet);
    });
    receiver_->setVideoHandler(
        [this](const QByteArray& accessUnit, const QByteArray& sps, const QByteArray& pps) {
        // On the media thread, and it stays that way: decide, hand over, return. Nothing here
        // blocks, and nothing here touches libav. The decoder is opened lazily on the decode
        // thread the first time a unit carries both parameter sets, which is why a receiver that
        // joins mid-broadcast can decode without waiting for anything but its keyframe.
        if (accessUnit.isEmpty() || !videoExpected.load() || !decoder_) {
            return;
        }
        decoder_->submit(accessUnit, sps, pps);
    });

    decoder_ = std::make_unique<PlaybackDecoder>();
    decoder_->setMaxQueuedFrames(framesForBufferMs(settings_.receiveBufferMs));
    decoder_->start(
        [this](const QImage& frame) {
            // Counting here rather than in the decoder: this is the exact point where a packet
            // has become a displayable picture, so it is what "is it actually playing" has to be
            // measured against. Packets arriving is not the same question.
            decodedFrames_.fetch_add(1, std::memory_order_relaxed);
            emit videoFrameReady(frame);
        },
        [this](const QString& reason) { emit failed(reason); });

    // Both sockets are bound even if the broadcaster turns out to be audio-only. The alternative
    // is reconnecting when the mode changes, and an idle bound UDP socket costs nothing.
    if (!receiver_->open(true, error)) {
        decoder_->stop();
        decoder_.reset();
        receiver_.reset();
        running_.store(false);
        logging::error(QStringLiteral("PlaybackEngine"),
            QStringLiteral("receive.start refused: %1")
                .arg(error != nullptr && !error->isEmpty()
                        ? *error
                        : QStringLiteral("the media sockets could not be opened")));
        return false;
    }

    const net::RtpReceiver::Ports ports = receiver_->ports();
    control_.connectToBroadcaster(host, controlPort, settings_.receiverName, ports.audio, ports.video);
    statsTimer_->start();
    return true;
}


void PlaybackEngine::requestKeyframe()
{
    if (running_.load()) {
        control_.requestKeyframe();
    }
}

void PlaybackEngine::requestBitrate(int videoKbps, int audioKbps)
{
    if (running_.load()) {
        control_.requestBitrate(videoKbps, audioKbps);
    }
}

void PlaybackEngine::setReceiveBufferMs(int ms)
{
    settings_.receiveBufferMs = ms;
    // Live: both caps are read on every submit, so a retune takes effect on the next packet or
    // frame without restarting either decoder.
    if (audio_) {
        audio_->setMaxQueuedPackets(packetsForBufferMs(ms));
    }
    if (decoder_) {
        decoder_->setMaxQueuedFrames(framesForBufferMs(ms));
    }
}

void PlaybackEngine::submitPassword(const QString& password)
{
    control_.submitPassword(password);
}

void PlaybackEngine::cancelPasswordPrompt()
{
    control_.cancelPasswordPrompt();
}

void PlaybackEngine::stop()
{
    if (!running_.exchange(false)) {
        return;
    }

    statsTimer_->stop();
    // The control connection first, so the broadcaster learns the receiver is gone before its
    // packets start arriving at a socket that is about to be gone too.
    control_.disconnectFromBroadcaster();
    if (receiver_) {
        receiver_->close();
        receiver_.reset();
    }
    // Then the decoder, joined rather than reset: it owns a thread that may be inside libav, and
    // the libav objects in it may only be freed on the thread that created them. Resetting the
    // unique_ptr alone would destroy the worker from this thread.
    if (decoder_) {
        decoder_->stop();
        decoder_.reset();
    }
    // Same rule, and ordered first of the two: the audio worker holds both a codec context and a
    // waveOut handle, and the device will not release its buffers until the thread that queued
    // them has stopped.
    if (audio_) {
        audio_->stop();
        audio_.reset();
    }
    audioExpected.store(false);

    emit stopped();
}

} // namespace localstream::engine
