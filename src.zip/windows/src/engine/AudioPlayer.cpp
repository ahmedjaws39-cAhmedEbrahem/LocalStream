#include "engine/AudioPlayer.h"

#include "protocol/LocalStream.h"

#include <QMutexLocker>
#include <QtGlobal>

#include <cstring>

extern "C" {
#include <libavcodec/avcodec.h>
#include <libavutil/channel_layout.h>
#include <libavutil/frame.h>
#include <libswresample/swresample.h>
// windows.h first, then the multimedia header: mmeapi.h needs the types windows.h defines, and
// in the other order it fails on MMVERSION. mmeapi.h is the one that declares waveOut, not
// mmsystem.h -- the latter only guards the block and forwards here.
#include <windows.h>
#include <mmeapi.h>
}

#include <algorithm>
#include <cstdlib>
#include <vector>

namespace localstream::engine {

namespace {

constexpr int BitsPerSample = 16;
/// Enough buffers to stay ahead of the device without adding enough latency to feel wrong.
constexpr int BufferCount = 8;
const char* AudioThreadName = "LocalStream-Audio";

} // namespace

/**
 * The decode and playback thread.
 *
 * A QObject so that libav work and device work can be posted to it and run in the thread's event
 * loop, which is what makes the "created, used and freed on one thread" rule hold: a QObject's
 * slots run in its own thread, and a blocking close posted to this object is guaranteed to be the
 * last thing that touches the codec and the device.
 */
class AudioWorker : public QObject
{
    Q_OBJECT

public:
    explicit AudioWorker(int channels)
        : channels_(channels >= 2 ? 2 : 1)
    {
        bytesPerBuffer_ = protocol::LocalStream::OpusSamplesPerFrame * channels_
            * (BitsPerSample / 8);
    }

    ~AudioWorker() override { close(); }

    /**
     * Opens the codec and the output device.
     *
     * Must be called on the audio thread, and AudioPlayer::start() does that with a blocking
     * queued invocation before the event loop begins. Opening it on the caller's thread instead
     * would satisfy the "fail fast" goal while breaking the rule this class exists to keep: the
     * codec context and the device handle would be created on one thread and then used and freed
     * on another.
     */
    bool open(QString* error)
    {
        const AVCodec* codec = avcodec_find_decoder(AV_CODEC_ID_OPUS);
        if (codec == nullptr) {
            if (error) {
                *error = QStringLiteral("This build has no Opus decoder.");
            }
            return false;
        }

        codecContext_ = avcodec_alloc_context3(codec);
        if (codecContext_ == nullptr) {
            if (error) {
                *error = QStringLiteral("Could not allocate the audio decoder.");
            }
            return false;
        }

        // Set before opening, and from the broadcaster's SDP rather than a default: an Opus
        // packet carries no channel count, so a decoder opened with the wrong layout does not
        // fail, it produces noise. Windows advertises mono and Android stereo, so neither end can
        // assume.
        av_channel_layout_default(&codecContext_->ch_layout, channels_);

        if (avcodec_open2(codecContext_, codec, nullptr) < 0) {
            if (error) {
                *error = QStringLiteral("Could not open the audio decoder.");
            }
            avcodec_free_context(&codecContext_);
            codecContext_ = nullptr;
            return false;
        }

        if (!openDevice(error)) {
            avcodec_free_context(&codecContext_);
            codecContext_ = nullptr;
            return false;
        }
        return true;
    }

    /// Releases the device and the codec. Only ever called on the audio thread, from stop().
    void close()
    {
        closeDevice();
        if (resampler_ != nullptr) {
            swr_free(&resampler_);
            resampler_ = nullptr;
        }
        if (frame_ != nullptr) {
            av_frame_free(&frame_);
            frame_ = nullptr;
        }
        if (packet_ != nullptr) {
            av_packet_free(&packet_);
            packet_ = nullptr;
        }
        if (codecContext_ != nullptr) {
            avcodec_free_context(&codecContext_);
            codecContext_ = nullptr;
        }
        open_ = false;
    }

    /// Decodes one packet and queues the samples. Called on the audio thread.
    void decode(const QByteArray& packet)
    {
        if (!open_ || packet.isEmpty() || codecContext_ == nullptr || device_ == nullptr) {
            return;
        }
        decodeCalls_.fetch_add(1, std::memory_order_relaxed);
        if (frame_ == nullptr) {
            frame_ = av_frame_alloc();
            if (frame_ == nullptr) {
                return;
            }
        }

        // The packet is the RTP payload, which is the Opus packet itself with no OpusHead wrapper
        // (RFC 7587). That is exactly what the codec was opened for above.
        if (packet_ == nullptr) {
            packet_ = av_packet_alloc();
            if (packet_ == nullptr) {
                return;
            }
        }
        av_packet_unref(packet_);
        // A view, not a copy: the payload is a single Opus frame, and the decoder consumes it
        // before submit() returns to the event loop.
        packet_->data = reinterpret_cast<uint8_t*>(const_cast<char*>(packet.constData()));
        packet_->size = static_cast<int>(packet.size());

        if (avcodec_send_packet(codecContext_, packet_) < 0) {
            // One undecodable packet is normal on a lossy network and is not worth interrupting
            // playback over: the next one is 20 ms away. Counted so a stream that is entirely
            // undecodable -- a framing mismatch, not loss -- does not look like silence.
            sendFailures_.fetch_add(1, std::memory_order_relaxed);
            return;
        }

        while (avcodec_receive_frame(codecContext_, frame_) == 0) {
            enqueue(frame_);
            av_frame_unref(frame_);
            decodedPackets_.fetch_add(1, std::memory_order_relaxed);
        }
    }

    [[nodiscard]] quint64 decodedPackets() const
    {
        return decodedPackets_.load(std::memory_order_relaxed);
    }

    [[nodiscard]] quint64 decodeCalls() const
    {
        return decodeCalls_.load(std::memory_order_relaxed);
    }

    [[nodiscard]] quint64 sendFailures() const
    {
        return sendFailures_.load(std::memory_order_relaxed);
    }

    [[nodiscard]] quint64 queued() const
    {
        return queued_.load(std::memory_order_relaxed);
    }

    [[nodiscard]] int peak() const
    {
        return peak_.load(std::memory_order_relaxed);
    }

private:
    bool openDevice(QString* error)
    {
        WAVEFORMATEX format;
        ZeroMemory(&format, sizeof(format));
        format.wFormatTag = WAVE_FORMAT_PCM;
        format.nChannels = static_cast<WORD>(channels_);
        format.nSamplesPerSec = protocol::LocalStream::AudioClockRate;
        format.wBitsPerSample = BitsPerSample;
        format.nBlockAlign = static_cast<WORD>(channels_ * (BitsPerSample / 8));
        format.nAvgBytesPerSec = format.nSamplesPerSec * format.nBlockAlign;
        format.cbSize = 0;

        // A Win32 event, signalled by the driver each time it finishes a buffer, rather than
        // waveOutWait: that function is not declared by this SDK's headers or exported by its
        // import library, and an event is the mechanism waveOut documents for a thread that
        // needs to know when playback has drained.
        doneEvent_ = CreateEventW(nullptr, FALSE, FALSE, nullptr);
        if (doneEvent_ == nullptr) {
            if (error) {
                *error = QStringLiteral("Could not create the audio completion event.");
            }
            return false;
        }

        const MMRESULT opened = waveOutOpen(&device_, WAVE_MAPPER, &format,
            reinterpret_cast<DWORD_PTR>(doneEvent_), 0, CALLBACK_EVENT);
        if (opened != MMSYSERR_NOERROR) {
            if (error) {
                *error = QStringLiteral("Could not open the audio output device.");
            }
            CloseHandle(doneEvent_);
            doneEvent_ = nullptr;
            device_ = nullptr;
            return false;
        }

        // Allocated up front, one header per buffer, so the device never waits on an allocation
        // mid-stream: waveOut reads each header to find its data.
        const int bytesPerBuffer = bytesPerBuffer_;
        headers_.resize(BufferCount);
        for (WAVEHDR& header : headers_) {
            ZeroMemory(&header, sizeof(header));
            header.lpData = static_cast<char*>(std::malloc(static_cast<size_t>(bytesPerBuffer)));
            if (header.lpData == nullptr) {
                if (error) {
                    *error = QStringLiteral("Could not allocate audio buffers.");
                }
                closeDevice();
                return false;
            }
            header.dwBufferLength = static_cast<DWORD>(bytesPerBuffer);
        }

        // The resampler runs even though the codec already emits the device's rate, because that
        // is a property of this build rather than of the stream, and an Android broadcaster can
        // be configured for a different one.
        av_channel_layout_default(&outLayout_, channels_);
        if (swr_alloc_set_opts2(&resampler_, &outLayout_, AV_SAMPLE_FMT_S16,
                protocol::LocalStream::AudioClockRate, &codecContext_->ch_layout,
                codecContext_->sample_fmt, codecContext_->sample_rate, 0, nullptr)
            < 0) {
            if (error) {
                *error = QStringLiteral("Could not set up the audio converter.");
            }
            closeDevice();
            return false;
        }
        if (swr_init(resampler_) < 0) {
            if (error) {
                *error = QStringLiteral("Could not set up the audio converter.");
            }
            swr_free(&resampler_);
            resampler_ = nullptr;
            closeDevice();
            return false;
        }

        // Reset so a restarted session's counter describes this session, not the previous one.
        decodedPackets_.store(0, std::memory_order_relaxed);
        queued_.store(0, std::memory_order_relaxed);
        peak_.store(0, std::memory_order_relaxed);
        open_ = true;
        return true;
    }

    void closeDevice()
    {
        if (device_ != nullptr) {
            // Reset first: the device must not be left holding buffers this class is about to
            // free, and a later waveOutOpen needs a clean handle.
            waveOutReset(device_);
            waveOutClose(device_);
            device_ = nullptr;
        }
        if (doneEvent_ != nullptr) {
            CloseHandle(doneEvent_);
            doneEvent_ = nullptr;
        }
        for (WAVEHDR& header : headers_) {
            std::free(header.lpData);
            header.lpData = nullptr;
        }
        headers_.clear();
    }

    /// Converts one decoded frame and queues it on whichever buffer the device has returned.
    void enqueue(AVFrame* decoded)
    {
        // One conversion, and one only. libswresample consumes the input it is given, so a second
        // swr_convert with the same frame -- whether an out-of-band "drain" or a retry -- feeds
        // every sample twice and doubles the output. The call that actually matters is the one
        // below, which both consumes this frame and produces its output.
        //
        // An upper bound on what this conversion can produce, given this frame's input. Reserved
        // before converting so the output buffer cannot be resized underneath libswr.
        const int capacity = swr_get_out_samples(resampler_, decoded->nb_samples);
        if (capacity <= 0) {
            return;
        }
        const int bytesPerFrame = channels_ * (BitsPerSample / 8);
        converted_.resize(static_cast<size_t>(capacity * bytesPerFrame));
        uint8_t* out = converted_.data();
        const int written =
            swr_convert(resampler_, &out, capacity, decoded->extended_data, decoded->nb_samples);
        if (written <= 0) {
            return;
        }

        // Track how loud the decoded stream actually is. A stream that decodes but stays at zero
        // is silence at the source, which is a different fault from one that never reaches the
        // device.
        {
            const auto* samples = reinterpret_cast<const qint16*>(converted_.data());
            const int count = written * channels_;
            int peak = peak_.load(std::memory_order_relaxed);
            for (int i = 0; i < count; ++i) {
                const int magnitude = std::abs(static_cast<int>(samples[i]));
                if (magnitude > peak) {
                    peak = magnitude;
                }
            }
            peak_.store(peak, std::memory_order_relaxed);
        }

        // Padded to a whole buffer rather than split across two, so every buffer the device holds
        // is full length. A partial buffer would play at the wrong rate.
        const size_t produced = static_cast<size_t>(written * bytesPerFrame);
        if (produced > static_cast<size_t>(bytesPerBuffer_)) {
            return; // more than one buffer: would need queueing, and one packet is 20 ms
        }

        // Find a buffer the device has finished with. WHDR_INQUEUE is the flag that says the
        // driver still owns the buffer, and it is the only one that does: the buffer cannot be
        // read from or written to while it is set.
        WAVEHDR* free = freeHeader();
        if (free == nullptr) {
            // Every buffer is with the device. Wait for one rather than allocating another: the
            // queue is bounded on purpose, so a slow device turns into dropped audio, which is
            // inaudible, instead of unbounded memory growth.
            //
            // Bounded, and treated as a drop on timeout. A screen-share receiver where the sound
            // card has gone to sleep should lose a few milliseconds of audio, not wedge the
            // thread that video decoding also depends on.
            if (WaitForSingleObject(doneEvent_, 100) != WAIT_OBJECT_0) {
                return;
            }
            free = freeHeader();
            if (free == nullptr) {
                return;
            }
        }

        waveOutUnprepareHeader(device_, free, sizeof(WAVEHDR));
        const size_t copied = std::min(produced, static_cast<size_t>(bytesPerBuffer_));
        std::memcpy(free->lpData, converted_.data(), copied);
        // Zero the remainder of a short frame, so padding is silence rather than whatever the
        // previous packet left in the buffer.
        if (copied < static_cast<size_t>(bytesPerBuffer_)) {
            std::memset(free->lpData + copied, 0, static_cast<size_t>(bytesPerBuffer_) - copied);
        }
        if (waveOutPrepareHeader(device_, free, sizeof(WAVEHDR)) == MMSYSERR_NOERROR) {
            if (waveOutWrite(device_, free, static_cast<UINT>(bytesPerBuffer_)) == MMSYSERR_NOERROR) {
                queued_.fetch_add(1, std::memory_order_relaxed);
            }
        }
    }

    /// The first header the device has released, or null if all of them are still in flight.
    WAVEHDR* freeHeader()
    {
        for (WAVEHDR& header : headers_) {
            if ((header.dwFlags & WHDR_INQUEUE) == 0) {
                return &header;
            }
        }
        return nullptr;
    }

    int channels_ = 1;
    /// One Opus packet, padded to the device's buffer. Depends on channels_, so it is not a
    /// constant: a mono stream needs half the bytes of a stereo one for the same 20 ms.
    int bytesPerBuffer_ = 0;

    bool open_ = false;
    /// Counted here rather than in AudioPlayer, because only this thread knows a packet became
    /// audio rather than merely arriving.
    std::atomic<quint64> decodedPackets_ {0};
    std::atomic<quint64> decodeCalls_ {0};
    std::atomic<quint64> sendFailures_ {0};
    std::atomic<quint64> queued_ {0};
    std::atomic<int> peak_ {0};

    AVCodecContext* codecContext_ = nullptr;
    AVPacket* packet_ = nullptr;
    AVFrame* frame_ = nullptr;
    SwrContext* resampler_ = nullptr;
    AVChannelLayout outLayout_ {};
    std::vector<uint8_t> converted_;

    HWAVEOUT device_ = nullptr;
    /// Signalled by the driver through CALLBACK_EVENT as each buffer finishes playing.
    HANDLE doneEvent_ = nullptr;
    std::vector<WAVEHDR> headers_;
};

AudioPlayer::AudioPlayer() = default;

AudioPlayer::~AudioPlayer()
{
    stop();
}

bool AudioPlayer::start(int channels, FailureHandler onFailure)
{
    if (running_.load(std::memory_order_acquire)) {
        return true;
    }

    {
        QMutexLocker locker(&handlerMutex_);
        onFailure_ = std::move(onFailure);
    }

    // Built here, on the caller's thread, so it starts with that affinity; the move below is what
    // puts it on the audio thread. Not `connect(thread, &QThread::finished, worker,
    // &QObject::deleteLater)`: that idiom deletes the worker while worker_ still owns it, and
    // stop() then resets the pointer -- the double free RtpReceiver::close() documents in full.
    auto worker = std::make_unique<AudioWorker>(channels);

    thread_ = std::make_unique<QThread>();
    thread_->setObjectName(QString::fromLatin1(AudioThreadName));
    worker->moveToThread(thread_.get());
    worker_ = std::move(worker);

    thread_->start();

    // Opened on the audio thread, and waited for, so a missing decoder or a silent sound card is
    // still reported synchronously from start() rather than arriving later as an error on a
    // screen the user has already looked away from. Blocking here rather than letting open()
    // happen lazily on the first packet is what keeps that guarantee while still creating the
    // codec and the device on the thread that will use and free them.
    QString error;
    AudioWorker* raw = worker_.get();
    const bool opened = QMetaObject::invokeMethod(
        raw, [raw, &error] { return raw->open(&error); }, Qt::BlockingQueuedConnection);

    if (!opened || !error.isEmpty()) {
        const QString reason = error.isEmpty() ? QStringLiteral("The audio thread did not respond.")
                                               : error;
        if (auto handler = this->onFailure()) {
            handler(reason);
        }
        // Unwinds the thread that was just started, and frees the worker on that same thread.
        // teardown() rather than stop(): running_ is still false here, so stop() would return
        // early and leak both.
        teardown();
        return false;
    }

    {
        QMutexLocker locker(&pendingMutex_);
        pendingPackets_.clear();
        drainScheduled_ = false;
    }
    submitted_.store(0, std::memory_order_relaxed);
    running_.store(true, std::memory_order_release);
    open_.store(true, std::memory_order_release);
    return true;
}

void AudioPlayer::stop()
{
    if (!running_.exchange(false)) {
        return;
    }
    teardown();
}

void AudioPlayer::teardown()
{
    AudioWorker* raw = worker_.get();
    if (raw != nullptr && thread_ != nullptr && thread_->isRunning()) {
        // Blocking, not queued: the device handle and the codec may only be freed on the thread
        // that created them, and the thread must not be told to quit before they are released. A
        // queued call followed by quit() would be dropped along with the loop.
        QMetaObject::invokeMethod(raw, [raw] { raw->close(); }, Qt::BlockingQueuedConnection);
        thread_->quit();
        // Bounded, so a wedged device cannot hang the UI on close.
        if (!thread_->wait(2000)) {
            thread_->terminate();
            thread_->wait();
        }
    }

    worker_.reset();
    thread_.reset();
    open_.store(false, std::memory_order_release);
}

void AudioPlayer::setMaxQueuedPackets(int packets)
{
    // Clamped rather than trusted: the value reaches here from a GUI, and 1000 packets is
    // already 20 seconds, far past any useful bound.
    maxQueuedPackets_.store(qBound(1, packets, 1000), std::memory_order_relaxed);
}

void AudioPlayer::submit(const QByteArray& opusPacket)
{
    if (!running_.load(std::memory_order_acquire) || opusPacket.isEmpty()) {
        return;
    }

    // Wi-Fi hands packets over in bursts, so accepting only one at a time would discard most of
    // each burst and be heard as a stutter every few frames. Queue the burst and decode it as
    // fast as this thread can; waveOut's own buffer pool blocks once it is full and thereby
    // paces playback to the device clock. A packet is only dropped once the queue is deep
    // enough that the stream is already behind by the configured buffer, which is the point at
    // which a late packet really is worth less than a gap.
    bool schedule = false;
    {
        QMutexLocker locker(&pendingMutex_);
        const auto cap = static_cast<size_t>(maxQueuedPackets_.load(std::memory_order_relaxed));
        if (pendingPackets_.size() >= cap) {
            dropped_.fetch_add(1, std::memory_order_relaxed);
            return;
        }
        pendingPackets_.push_back(opusPacket);
        submitted_.fetch_add(1, std::memory_order_relaxed);
        if (!drainScheduled_) {
            drainScheduled_ = true;
            schedule = true;
        }
    }

    if (!schedule) {
        // A drain is already posted or running; it takes whatever is queued when it next looks.
        return;
    }

    AudioWorker* raw = worker_.get();
    if (raw == nullptr) {
        QMutexLocker locker(&pendingMutex_);
        drainScheduled_ = false;
        return;
    }

    // Qt copies the captures before invokeMethod returns, so the media thread is free
    // immediately rather than waiting for the decode. One drain empties the queue before it
    // clears the flag, and clears the flag only under the lock, so a packet submitted at the
    // tail of the previous drain cannot be stranded waiting for a wake-up that never comes.
    QMetaObject::invokeMethod(raw, [this, raw] {
        for (;;) {
            QByteArray packet;
            {
                QMutexLocker locker(&pendingMutex_);
                if (pendingPackets_.empty()) {
                    drainScheduled_ = false;
                    break;
                }
                packet = std::move(pendingPackets_.front());
                pendingPackets_.pop_front();
            }
            raw->decode(packet);
        }
    }, Qt::QueuedConnection);
}

AudioPlayer::FailureHandler AudioPlayer::onFailure() const
{
    QMutexLocker locker(&handlerMutex_);
    return onFailure_;
}

quint64 AudioPlayer::packetsPlayed() const
{
    // Safe without a lock: the worker pointer is only replaced under stop()/start() on the UI
    // thread, and the counter it is read from is atomic. A concurrent teardown can at worst yield
    // the last value before the reset, which is exactly what a UI wants to show.
    AudioWorker* raw = worker_.get();
    return raw != nullptr ? raw->decodedPackets() : 0;
}

AudioPlayer::Stats AudioPlayer::stats() const
{
    Stats out;
    out.submitted = submitted_.load(std::memory_order_relaxed);
    out.dropped = dropped_.load(std::memory_order_relaxed);
    AudioWorker* raw = worker_.get();
    if (raw != nullptr) {
        out.decodeCalls = raw->decodeCalls();
        out.decoded = raw->decodedPackets();
        out.sendFailed = raw->sendFailures();
        out.queued = raw->queued();
        out.peak = raw->peak();
    }
    return out;
}

} // namespace localstream::engine

#include "AudioPlayer.moc"
