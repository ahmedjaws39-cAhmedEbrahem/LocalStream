#pragma once

#include <QObject>
#include <QString>
#include <QThread>
#include <QTimer>

#include <QHostAddress>

#include <atomic>
#include <memory>

#include "net/ControlServer.h"
#include "protocol/LocalStream.h"

namespace localstream::capture {
class AudioEncoder;
class FrameSource;
class VideoEncoder;
} // namespace localstream::capture

namespace localstream::net {
class RtpSender;
class ServiceAdvertiser;
} // namespace localstream::net

namespace localstream::engine {

/**
 * Runs one broadcast: capture, encode, packetise, answer receivers.
 *
 * Owns the whole pipeline and the ordering between its parts, which is the part that is easy to
 * get wrong. The order is not arbitrary:
 *
 *  1. The RTP sockets bind first, so the ports they choose are known and can be published.
 *  2. The control server binds second, so a receiver that answers a PTR query with a TCP
 *     connection finds the control port already accepting.
 *  3. Advertising starts last, so a receiver that sees the announcement can connect immediately
 *     rather than racing a socket that is not listening yet.
 *
 * Threading: the video and audio pipelines each own a thread, because a device read blocks for
 * as long as the device takes to produce a frame. They cannot share a thread -- whichever ran
 * first would starve the other, and audio at 20 ms per packet tolerates far less jitter than
 * video at 33 ms. Neither runs on the thread that called start(), because start() is on the GUI
 * thread and a blocked capture there freezes the interface.
 *
 * Everything the UI needs arrives as a signal; the UI never polls and never reaches inside.
 */
class BroadcastEngine : public QObject
{
    Q_OBJECT

public:
    struct Settings
    {
      QString displayName;
      /// A generated pattern instead of a real screen, used for testing without a desktop.
      bool useTestSources = false;

      /**
       * Microphone to capture from, by DirectShow name. Empty means the first recording device
       * Windows offers, which is what most users want and what an empty combo box should mean.
       *
       * A setting rather than a hardcoded source because the choice is not derivable: the machine
       * may have a webcam microphone, a headset and an aggregate device, and only the user knows
       * which one carries the voice they intend to broadcast. Under `useTestSources` it is
       * ignored, since there is no microphone to pick.
       */
      QString audioDeviceName;

        /// Normalise the captured audio level, so a receiver hears a steady volume whatever the
        /// system volume or the capture device is set to. On by default.
        bool normalizeAudio = true;

        int width = 1280;
        int height = 720;
        int frameRate = 30;
        int videoBitrateKbps = 1500;
        int audioBitrateKbps = 48;
        int maxReceivers = protocol::LocalStream::MaxReceiversDefault;

        /**
         * Largest RTP payload the video packetiser may emit, in bytes. Read once, at start().
         * See net::RtpSender::setMaxPayload for the trade-off.
         */
        int rtpMaxPayload = protocol::LocalStream::RtpMaxPayload;
        /**
         * A video frame that fragments into at least this many packets is paced across the
         * frame time instead of sent in one burst. Read once, at start().
         */
        int pacingThresholdPackets = 8;
        /// How many frame times a paced burst may be spread over. 1 is the historic behaviour.
        int pacingSpreadFrames = 1;

        /// One of the `protocol::access` constants. Public is the default because it is the
        /// behaviour that existed before access control, and a release that silently started
        /// prompting viewers would be a worse surprise than one that silently allows them.
        QString accessMode = QString::fromLatin1(protocol::access::Public);
        /// Required when [accessMode] is password. Validated by the engine, not only the UI, so a
        /// bad password cannot reach the wire even if some other caller starts a broadcast.
        QString accessPassword;
    };

    explicit BroadcastEngine(QObject* parent = nullptr);
    ~BroadcastEngine() override;

    BroadcastEngine(const BroadcastEngine&) = delete;
    BroadcastEngine& operator=(const BroadcastEngine&) = delete;

    /// Opens the media sockets, the control server and the announcement. Blocking for the
    /// duration of the setup, which is fast; capture starts on its own threads.
    bool start(const Settings& settings, QString* error);

    /// Stops everything and waits for the capture threads to finish.
    ///
    /// Blocking by design. The alternative is returning while a capture thread is still inside
    /// FFmpeg, and the UI being torn down underneath it.
    void stop();

    [[nodiscard]] int controlPort() const;

    /// The address a viewer on this network should be given.
    ///
    /// Public because the page prints it next to the control port, and the announcement carries
    /// it under the same name on the network. Two implementations of "which address is this
    /// machine" disagree sooner or later -- typically on a virtual adapter that happens to be
    /// enumerated first, where the UI prints one address and discovery publishes another and the
    /// viewer cannot explain why the printed one fails -- so the choice is made once, here, and
    /// read from everywhere. Computed on each call: adapters come and go while the app runs, and
    /// a cached answer is wrong the moment a laptop changes network.
    [[nodiscard]] static QHostAddress localAddress();

    /// Switches between sending audio and video, or both, and tells every receiver.
    ///
    /// Takes effect on the next encoded frame. The broadcasters' own capture keeps running: a
    /// user who turns video off still wants the microphone, and tearing down a device to do it
    /// would cost a re-open every time.
    void setMode(const QString& mode);

    /**
     * Changes who may join, live. Receivers already admitted keep their stream; everyone who
     * connects from now on is judged against [mode].
     *
     * @return false when [password] does not satisfy the length rules, in which case the current
     *         mode is left untouched. Called on every keystroke-free commit from the UI, so
     *         validation here is what stops a half-typed password from locking the broadcaster
     *         out of their own stream.
     */
    bool setAccess(const QString& mode, const QString& password);

    /// Answers a pending viewer request. See [accessRequested].
    void resolveAccessRequest(quint64 requestKey, bool allow);

    /// Asks every receiver for a keyframe now, e.g. after one joins.
    void requestKeyframe();

    /// The access mode currently in force. The UI reads this back after a refused change so it
    /// can put its control where the broadcast actually is.
    [[nodiscard]] QString accessMode() const { return settings_.accessMode; }

signals:
    void started();
    void stopped();
    void failed(const QString& reason);
    /// Something non-fatal: the broadcast is running, but part of it is degraded.
    void warning(const QString& message);

    void statsChanged(int framesPerSecond, int kilobitsPerSecond, int receiverCount,
        int packetsPerFrame, int fragmentsPerFrame, int largestPayloadBytes);
    void modeChanged(const QString& mode);
    void receiverJoined(const QString& name);
    void receiverLeft(const QString& name);

    /// A viewer wants in and the broadcast is set to ask first. The UI must show a prompt and
    /// then call [resolveAccessRequest] with this key; until it does, the viewer waits.
    void accessRequested(quint64 requestKey, const QString& name);

private:
    /// The two capture pipelines. Each runs on its own thread for the reasons in the class
    /// comment; they are declared as one type because the video and audio halves differ only in
    /// which callback they fill and which encoder they feed.
    struct Pipeline
    {
        std::unique_ptr<capture::FrameSource> source;
        /// Null in the audio pipeline, and in the video pipeline only until the encoder opens.
        std::unique_ptr<capture::VideoEncoder> videoEncoder;
        std::unique_ptr<capture::AudioEncoder> audioEncoder;
        QThread* thread = nullptr;
        /// A bare object whose only job is to have the pipeline's thread affinity, so work can be
        /// marshalled onto that thread. Invoking on the QThread instead does NOT work: a QThread
        /// object belongs to the thread that created it, so a queued call addressed to it runs
        /// on the caller's thread and the capture loop ends up wedging the GUI.
        QObject* worker = nullptr;
    };

    void startVideoPipeline();
    void startAudioPipeline();
    void stopPipeline(Pipeline& pipeline);

    /// Runs on the video thread. Blocks in the source's pump until asked to stop.
    void runVideo();
    /// Runs on the audio thread.
    void runAudio();

    /// Fires once, a few seconds after the pipelines start, to catch a device that opened but
    /// never produced anything. Without it that failure mode is invisible: the broadcast looks
    /// live and the UI reads "0 kbps", because nothing ever reaches the encoders to be counted.
    void checkCapture();

    /// Ends the broadcast with [reason] exactly once, on the owning thread. The capture threads
    /// and [checkCapture] both route through here, so a wedged device and the watchdog cannot
    /// produce two dialogs, and a failure always tears the broadcast down instead of leaving the
    /// sockets open after the UI has already been told the stream ended.
    void reportFailure(const QString& reason);

    void publishStats();

    [[nodiscard]] protocol::LocalStream::Description currentDescription() const;
    Settings settings_;
    QString sessionId_;
    QString mode_;
    /// Written from the GUI thread, read from the capture threads.
    std::atomic<bool> videoWanted {true};
    std::atomic<bool> audioWanted {true};
    std::atomic<bool> running {false};
    /// Claims the single failure report for the session. See reportFailure().
    std::atomic<bool> failureReported {false};

    Pipeline video_;
    Pipeline audio_;

    std::unique_ptr<net::RtpSender> sender_;
    net::ControlServer control_;
    std::unique_ptr<net::ServiceAdvertiser> advertiser_;

    /// Drives publishStats. Without it the fps and bitrate line in the UI, and the stats sent to
    /// every viewer, are never produced at all.
    QTimer* statsTimer_ = nullptr;

    /// Armed by start() and stopped by stop(); see checkCapture().
    QTimer* captureWatchdog_ = nullptr;

    std::atomic<quint64> framesEncoded {0};
    std::atomic<quint64> videoBytesSent {0};
    std::atomic<quint64> audioBytesSent {0};
    qint64 statsWindowStartMs_ = 0;
    /// When this broadcast began, kept apart from the statistics window so a report can say how
    /// long the session actually lasted rather than how long ago the last tick was.
    qint64 startedAtMs_ = 0;
};

} // namespace localstream::engine
