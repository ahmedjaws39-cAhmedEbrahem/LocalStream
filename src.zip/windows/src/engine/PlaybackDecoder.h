#pragma once

#include <QByteArray>
#include <QImage>
#include <QMutex>
#include <QString>
#include <QThread>

#include <atomic>
#include <deque>
#include <functional>
#include <memory>

namespace localstream::engine {

class DecodeWorker;

/**
 * One H.264 decoder, running on a thread of its own.
 *
 * Not a QObject: it owns its worker thread explicitly, because every libav object in here has to
 * be created, used and destroyed on one single thread. An AVCodecContext shared across two threads
 * does not report an error, it produces a corrupt stream, so the ownership is this narrow on
 * purpose and is why libav is not visible from PlaybackEngine at all.
 *
 * The thread is not decoration. Access units arrive on the RTP media thread and frames are handed
 * to a UI, so decoding inline on either of those means one slow picture -- the keyframe after a
 * receiver joins, or an IDR at 1080p -- stalls the interface or the receive loop. Both present to
 * the user as the stream freezing, which is the symptom this class exists to prevent.
 *
 * submit() copies, posts and returns. The caller goes back to reading datagrams while libav is
 * still working through the previous frame.
 */
class PlaybackDecoder
{
public:
    /// Called on the decode thread, once per decoded frame.
    using FrameHandler = std::function<void(const QImage&)>;

    /// Called on the decode thread when the stream cannot be decoded at all, as opposed to
    /// dropping the odd undecodable frame, which is normal and not worth interrupting playback.
    using FailureHandler = std::function<void(const QString&)>;

    PlaybackDecoder();
    ~PlaybackDecoder();

    PlaybackDecoder(const PlaybackDecoder&) = delete;
    PlaybackDecoder& operator=(const PlaybackDecoder&) = delete;

    /// Starts the decode thread. The handlers are called from it, never from the caller's thread.
    bool start(FrameHandler onFrame, FailureHandler onFailure);

    /// Blocking: the thread may be inside libav, and the decoder may only be freed where it was
    /// created. Mirrors RtpReceiver::close(), bounded so a wedged decode cannot hang the UI.
    void stop();

    [[nodiscard]] bool isRunning() const { return running_.load(std::memory_order_acquire); }

    /// True once both parameter sets have arrived and a decoder is open. Cleared by stop().
    [[nodiscard]] bool isOpen() const { return open_.load(std::memory_order_acquire); }

    /**
     * Hands one access unit to the decoder. Called from the RTP media thread.
     *
     * `sps` and `pps` travel with the unit rather than being fetched from a getter here. They only
     * ever change at a keyframe, so a getter would be a race against the media thread that owns
     * them, and a unit that arrives together with the sets it depends on cannot be attributed to a
     * set the decoder has already replaced.
     *
     * Both are bare NALs by contract -- that is what RtpReceiver's depacketiser returns, and what
     * protocol::h264::splitAvcc produces -- and the Annex B start codes libav wants are added by
     * the worker, so no caller has to know which of those paths filled them.
     *
     * Never blocks. Queues a bounded number of units and drops the oldest when that is exceeded,
     * so a sender that outruns the decoder becomes dropped frames rather than growing latency.
     */
    void submit(const QByteArray& annexB, const QByteArray& sps, const QByteArray& pps);

    /**
     * Caps how many access units may wait behind the one being decoded, trading latency against
     * jitter tolerance: at a nominal 30 fps, 15 frames is about 500 ms. Applied live and clamped,
     * so a mistyped value cannot grow the queue without bound. The value reaches here from the
     * receiver's buffer setting, which the UI expresses in milliseconds.
     */
    void setMaxQueuedFrames(int frames);

private:
    friend class DecodeWorker;

    /// Runs on the decode thread, at the end of every unit, to hand over whatever is waiting.
    void finishDecodeAndPostNext();

    void postToWorker(DecodeWorker* worker, const QByteArray& annexB, const QByteArray& sps,
        const QByteArray& pps);

    [[nodiscard]] FrameHandler onFrame() const;
    [[nodiscard]] FailureHandler onFailure() const;

    std::unique_ptr<QThread> thread_;
    std::unique_ptr<DecodeWorker> worker_;

    mutable QMutex handlerMutex_;
    FrameHandler onFrame_;
    FailureHandler onFailure_;

    /// One queued access unit and the parameter sets it depends on. The sets travel with the unit
    /// so a keyframe that arrives with new sets is decoded against the ones that arrived with it.
    struct PendingUnit
    {
        QByteArray annexB;
        QByteArray sps;
        QByteArray pps;
    };

    /// Written by the media thread, read by the decode thread, so it is always held under the lock.
    mutable QMutex pendingMutex_;

    /// True from the moment a unit is handed over until the worker reports it finished.
    bool decodeBusy_ = false;

    /// Units waiting for the decoder, oldest first. Bounded by maxQueuedFrames_ so a sender that
    /// outruns the decoder turns into dropped frames, which the eye forgives, rather than
    /// unbounded latency. The bound is a duration in disguise: the UI configures it in
    /// milliseconds and PlaybackEngine converts at a nominal frame rate.
    std::deque<PendingUnit> pending_;

    /// Cap on [pending_], in frames. Atomic because the UI can retune it live.
    std::atomic<int> maxQueuedFrames_ {16};

    std::atomic<bool> running_ {false};
    std::atomic<bool> open_ {false};
};

} // namespace localstream::engine
