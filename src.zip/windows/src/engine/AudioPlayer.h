#pragma once

#include <QByteArray>
#include <QMutex>
#include <QThread>

#include <atomic>
#include <deque>
#include <functional>
#include <memory>

namespace localstream::engine {

class AudioWorker;

/**
 * One Opus decoder, playing through the default Windows output device.
 *
 * Shaped like PlaybackDecoder and for the same reasons. Every libav object has to be created,
 * used and freed on one thread, so the thread is owned explicitly rather than borrowed from Qt;
 * and the thread is not decoration, because audio is the one place where inline work is
 * immediately audible. Decoding a 20 ms packet on the RTP media thread would put a few
 * milliseconds of libav between two datagram reads, and the receiver's reorder buffer would
 * start dropping the packets that arrived during it.
 *
 * The output device is another reason to stay off the caller's thread: waveOut takes ownership
 * of the buffers it is handed and only returns them once the device has played them, so the
 * calls that fill and recycle them have to be made from somewhere that is allowed to wait.
 *
 * submit() copies into a small bounded queue and posts one drain, rather than decoding inline.
 * Wi-Fi delivers packets in bursts, and decoding them faster than the device plays them back
 * would still stutter if a burst could only ever hold one packet: every arrival while the
 * previous was decoding would be discarded, which is exactly what a burst guarantees. The queue
 * lets a burst drain into waveOut's own buffer pool, whose blocking writes then pace the stream
 * at the device clock. Only once the queue itself is full, i.e. the sender has outrun the
 * device for a few hundred milliseconds, is an arriving packet dropped as too late to be worth
 * playing.
 */
class AudioPlayer
{
public:
    /// Called on the audio thread when the device cannot be opened or the codec is missing.
    using FailureHandler = std::function<void(const QString&)>;

    AudioPlayer();
    ~AudioPlayer();

    AudioPlayer(const AudioPlayer&) = delete;
    AudioPlayer& operator=(const AudioPlayer&) = delete;

    /**
     * Opens the codec and the output device, then starts the thread.
     *
     * `channels` is the broadcaster's, from its SDP: an Opus packet carries no channel count of
     * its own, and a mono stream handed to a stereo decoder does not fail, it comes out as noise.
     */
    bool start(int channels, FailureHandler onFailure);

    /// Blocking, for the same reason PlaybackDecoder::stop() is.
    void stop();

    /// True once the device is open and the codec is decoding. Cleared by stop().
    [[nodiscard]] bool isOpen() const { return open_.load(std::memory_order_acquire); }

    /// Hands one Opus packet to the decoder. Called from the RTP media thread. Never blocks.
    void submit(const QByteArray& opusPacket);

    /**
     * Caps how many 20 ms packets may wait for the device, trading latency against jitter
     * tolerance: 25 is 500 ms. Applied live and clamped, so a mistyped value cannot grow the
     * queue without bound. The queue only fills when the sender runs ahead of the device.
     */
    void setMaxQueuedPackets(int packets);

    /// Packets this player has actually decoded and handed to the device. Stays zero while audio
    /// packets keep arriving if the device never opened, so "the stream has audio" and "this
    /// machine is playing it" stay distinguishable.
    [[nodiscard]] quint64 packetsPlayed() const;

    /// Counters for diagnosing a silent session, in the order packets pass through them:
    /// submitted -> decoded -> played. A gap between the first two is a decoder problem; a gap
    /// between the last two is a device problem.
    struct Stats
    {
        quint64 submitted = 0;
        quint64 decodeCalls = 0;
        quint64 decoded = 0;
        quint64 sendFailed = 0;
        /// Buffers actually handed to waveOut. Below `decoded` means enqueue() bailed early, which
        /// is a drop on the playback side rather than a decode failure.
        quint64 queued = 0;
        /// Packets discarded because the previous one was still decoding. Arrival in bursts, not
        /// loss, is what makes this climb, and it is what a jitter buffer has to absorb.
        quint64 dropped = 0;
        /// Peak sample magnitude seen since the player started, 0..32767. Zero after packets have
        /// decoded means the stream is carrying silence, not that playback is broken.
        int peak = 0;
    };
    [[nodiscard]] Stats stats() const;

private:
    friend class AudioWorker;

    [[nodiscard]] FailureHandler onFailure() const;

    /// Stops the thread and frees the worker. Split from stop() so the start() failure path can
    /// unwind a thread it started without depending on the running_ flag it has not set yet.
    void teardown();

    std::unique_ptr<QThread> thread_;
    std::unique_ptr<AudioWorker> worker_;

    mutable QMutex handlerMutex_;
    FailureHandler onFailure_;

    /// Encoded packets waiting for the audio thread, newest at the back. Bounded so a sender
    /// running ahead of the device cannot grow latency without limit.
    mutable QMutex pendingMutex_;
    std::deque<QByteArray> pendingPackets_;
    bool drainScheduled_ = false;

    /// Cap on [pendingPackets_], in 20 ms packets. Atomic because a UI can retune it live.
    std::atomic<int> maxQueuedPackets_ {25};

    std::atomic<bool> running_ {false};
    std::atomic<bool> open_ {false};
    std::atomic<quint64> submitted_ {0};
    std::atomic<quint64> dropped_ {0};
};

} // namespace localstream::engine
