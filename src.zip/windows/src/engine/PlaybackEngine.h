#pragma once

#include <QImage>
#include <QMutex>
#include <QObject>
#include <QString>
#include <QTimer>
#include <atomic>
#include <memory>

#include "engine/AudioPlayer.h"
#include "engine/PlaybackDecoder.h"
#include "net/ControlClient.h"
#include "net/RtpReceiver.h"

namespace localstream::engine {

/**
 * Receives one broadcast: control handshake, RTP, depacketise, decode, present.
 *
 * The pieces run on separate threads because they block for unrelated reasons and starving any
 * one of them shows up as a different symptom:
 *
 *  - the control client lives on the calling thread, as a Qt socket driven by its own signals;
 *  - the RTP receiver has a private event loop, because two UDP sockets reading on the GUI
 *    thread would stutter the interface on every late datagram;
 *  - decoding runs on a thread of its own, inside PlaybackDecoder, because a single slow frame --
 *    the keyframe after a receiver joins, or an IDR at a high resolution -- takes long enough to
 *    drop audio packets if it happens inline;
 *  - audio decodes and plays on a fourth thread, inside AudioPlayer, for the same reason plus one
 *    more: waveOut does not hand a buffer back until the device has played it, so the calls that
 *    fill and recycle buffers can only be made from somewhere allowed to wait.
 *
 * This class therefore holds no decoder and no libav state at all. It decides, forwards and
 * reports; PlaybackDecoder owns the one thing that must not be touched from two threads.
 *
 * Frames reach the UI as QImage, emitted from the decode thread. That copies once per frame, but
 * it keeps libav out of the UI thread entirely: handing a decoder buffer to a widget and hoping it
 * is consumed before the next frame arrives is exactly the lifetime bug that shows up once a week
 * and never on the machine it was written on. The copy is from a YUV420 buffer about a tenth the
 * size of the equivalent image, so it is cheaper than the decode it follows.
 *
 * Both videoFrameReady and failed are emitted from the decode thread. Qt queues them to any
 * receiver living on another thread, so a UI connecting from its own thread needs no marshalling
 * of its own.
 */
class PlaybackEngine : public QObject
{
    Q_OBJECT

public:
    struct Settings
    {
        QString receiverName = QStringLiteral("Receiver");
        /// How much of the stream may be buffered before playback, in milliseconds, for audio and
        /// video together. More absorbs more network jitter at the cost of a longer live delay;
        /// 500 ms matches the Android default.
        int receiveBufferMs = 500;
    };

    explicit PlaybackEngine(QObject* parent = nullptr);
    ~PlaybackEngine() override;

    PlaybackEngine(const PlaybackEngine&) = delete;
    PlaybackEngine& operator=(const PlaybackEngine&) = delete;

    /// Connects to a broadcaster and starts receiving. Returns once the handshake has been sent;
    /// the outcome arrives as handshakeSucceeded or handshakeFailed.
    bool start(const QString& host, int controlPort, const Settings& settings, QString* error);

    /// Blocking, for the same reason BroadcastEngine::stop() is: the RTP thread is inside a
    /// socket read and the decode thread is inside libav.
    void stop();

    /// Asks the broadcaster for a keyframe. Worth sending after joining, and whenever the
    /// picture changes, so the next frame is decodable without waiting out a keyframe interval.
    void requestKeyframe();

    /// What has actually arrived since the session started. A UI showing reception health needs
    /// this, and it is the only way to tell a silent network from a decoder that is not being
    /// fed: both look identical from the frame signal alone.
    [[nodiscard]] net::RtpReceiver::Stats receptionStats() const
    {
        return receiver_ ? receiver_->stats() : net::RtpReceiver::Stats {};
    }

    /// Adjusts what the broadcaster encodes, applied at its next keyframe boundary.
    void requestBitrate(int videoKbps, int audioKbps);

    /// Retunes the receive buffer for the live session, or for the next one when idle. Applied
    /// immediately to both the audio and the video queue when those decoders are already running.
    void setReceiveBufferMs(int ms);

    /// Counters for the audio pipeline, so a UI can say which stage is failing and tests can
    /// assert on it. Zero when the broadcaster sends no audio.
    [[nodiscard]] AudioPlayer::Stats audioStats() const
    {
        return audio_ ? audio_->stats() : AudioPlayer::Stats {};
    }

/// Supplies the password for a broadcast that demanded one. Ignored unless the handshake is
    /// waiting for it, so a stale dialog cannot send a password to a later session.
    void submitPassword(const QString& password);

    /// Gives up on a password prompt, returning to the browse list.
    void cancelPasswordPrompt();

signals:
    void started();
    void stopped();
    void failed(const QString& reason);

    /// The broadcaster requires a password. The connection is held open until the UI answers.
    void passwordRequired(const QString& broadcasterName);
    /// The offer was sent and the broadcaster is deciding whether to admit this viewer.
    void accessRequested(const QString& broadcasterName);
    /// A password attempt was refused; the prompt stays open so the user can retype.
    void passwordRejected(const QString& reason);
    /// The broadcaster refused this viewer for good. Retrying cannot help, so a UI should not
    /// offer it.
    void blocked(const QString& reason);

    /// A decoded frame, ready to display. Emitted from the decode thread.
    void videoFrameReady(const QImage& frame);

    /// The broadcaster's own counters: what it believes it is sending.
    void statsChanged(int framesPerSecond, int kilobitsPerSecond);

    /// What this machine has actually received, sampled on the same one-second tick as the
    /// report sent back to the broadcaster. A UI needs both: the broadcaster's counters stay
    /// healthy across a firewall that drops every media packet, and this is the only place the
    /// difference shows up.
    void receptionStatsChanged(quint64 audioPackets, quint64 videoPackets, quint64 lostPackets,
                               bool haveVideoParameters, quint64 decodedFrames, quint64 audioPlayed,
                               bool audioOpen, const QString& audioError);

private:
    /// Total frames handed to the UI since the session started. Zero while packets are arriving
    /// is the signature of a decoder that is not being fed, and it is not visible anywhere else.
    quint64 decodedFrames() const
    {
        return decodedFrames_.load(std::memory_order_relaxed);
    }

    /// Packets the audio player decoded and sent to the output device.
    quint64 audioPlayed() const
    {
        return audio_ ? audio_->packetsPlayed() : 0;
    }

    /// Whether an audio device is open. False for an audio-less broadcast and for one whose
    /// device could not be opened; audioError() tells the two apart.
    bool isAudioOpen() const
    {
        return audio_ != nullptr && audio_->isOpen();
    }

    /// Empty unless audio was expected and the player could not start.
    QString audioError() const
    {
        QMutexLocker locker(&audioErrorMutex_);
        return audioError_;
    }

    Settings settings_;

    net::ControlClient control_;
    std::unique_ptr<net::RtpReceiver> receiver_;
    std::unique_ptr<PlaybackDecoder> decoder_;
    /// Null when the broadcaster is sending no audio, or when the device could not be opened.
    /// Either way the picture is unaffected, which is why a failure here is a warning and not a
    /// reason to end the session.
    std::unique_ptr<AudioPlayer> audio_;

    std::atomic<bool> videoExpected {false};
    std::atomic<bool> audioExpected {false};
    std::atomic<bool> running_ {false};
    std::atomic<quint64> decodedFrames_ {0};

    /// Sends this receiver's counters to the broadcaster once a second.
    QTimer* statsTimer_ = nullptr;

    /// Written on the control/handshake thread, read on the GUI thread when the label refreshes.
    mutable QMutex audioErrorMutex_;
    QString audioError_;
};

} // namespace localstream::engine
