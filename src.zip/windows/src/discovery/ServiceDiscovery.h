#pragma once

#include <QAbstractSocket>
#include <QByteArray>
#include <QHash>
#include <QHostAddress>
#include <QObject>
#include <QString>
#include <QTimer>
#include <QUdpSocket>

#include <optional>
#include <vector>

#include "discovery/DnsSd.h"
#include "protocol/LocalStream.h"

namespace localstream::net {

/**
 * Finds broadcasters on the local network via DNS-SD.
 *
 * Runs entirely on the caller's thread: one UDP socket, one timer, no threads and no blocking
 * calls, because browsing is inherently idle-time work and a dedicated thread would buy
 * nothing. The socket is joined to the mDNS group so replies are accepted on the multicast
 * socket itself, which avoids the two-socket IPv4/IPv6 arrangement the OS would otherwise
 * need.
 *
 * Only IPv4 is handled. Every current consumer of this app resolves its media endpoints from
 * the control handshake anyway, so an AAAA record adds a second address family to carry but
 * no new capability; the port always comes from the SRV record either way.
 */
class ServiceDiscovery : public QObject
{
    Q_OBJECT

public:
    struct Service
    {
        /// The DNS-SD instance label, before any display name is applied. Stable for the
        /// lifetime of an instance and used as the cache key, since a broadcaster is free to
        /// change the name it advertises at any time.
        QString instanceKey;
        /// What to show the user. Taken from the TXT `n` key when present.
        QString name;
        QString hostName;
        QHostAddress address;
        quint16 port = 0;
        protocol::LocalStream::Description description;

        /// True once enough has arrived to attempt a handshake: a host, a control port and an
        /// address. Without all three there is nothing to connect to, and offering the row
        /// anyway would produce a connection attempt that can only fail.
        [[nodiscard]] bool isConnectable() const
        {
            return port > 0 && !address.isNull() && description.controlPort > 0;
        }
    };

    explicit ServiceDiscovery(QObject* parent = nullptr);
    ~ServiceDiscovery() override;

    ServiceDiscovery(const ServiceDiscovery&) = delete;
    ServiceDiscovery& operator=(const ServiceDiscovery&) = delete;

    /// Begins browsing. [serviceType] defaults to the app's own record type.
    void start(const QString& serviceType = protocol::LocalStream::ServiceType);
    void stop();

    /// Drains the socket and feeds every pending datagram through the decoder.
    void refresh();

    /// Restarts the search from scratch: the cache is retracted and the socket is rebound on
    /// whatever the network is now, then a fresh query goes out.
    ///
    /// Distinct from the periodic query timer, which keeps asking on the same socket and is
    /// enough while the network is stable. This is the recovery path for the events that break
    /// that socket: an adapter that went away and came back, a returning LAN, or a user asking
    /// again. Safe to call whether or not browsing is active.
    void rescan();

    /// Feeds one datagram through the decoder. Public so the parser is testable with no network.
    void ingestPacket(const QByteArray& datagram);

signals:
    void serviceAdded(const Service& service);
    /// Emitted when a known instance stops resolving or its TTL lapses.
    void serviceRemoved(const QString &instanceKey);
    /// A record arrived but was not one of ours, or could not be decoded. Diagnostic only.
    void warning(const QString &message);

private:
    void sendQuery();
    void queryFor(const QString &name);
    void expireOldEntries();

    /// Binds the socket, joins the group, starts the timers and sends the first query. Shared
    /// by start() and rescan() so the two cannot drift on which interface they pick.
    void beginBrowsing();

    /// Retracts every cached entry and clears the caches. Every retraction is keyed by instance
    /// label, which is what a list row carries, so a row is actually removed.
    void retractAll();

    /// @return the instance label, or nullopt when the record is not for our service type.
    [[nodiscard]] static std::optional<QString> instanceFor(
        const QString &owner, const QString &serviceType);

    /// Turns the escaped label the decoder produced back into display text.
    [[nodiscard]] static QString unescapeInstance(const QString &label);

    [[nodiscard]] bool ingest(const std::vector<dnssd::Record> &records);

    /// Resolves a record's address and publishes it, or removes the entry if it no longer holds.
    void publish(const QHash<QString, Service> &touched);

    QUdpSocket socket_;

    QTimer queryTimer_;
    /// Entries are swept on this cadence. TTLs are honoured per record in `expireOldEntries`.
    QTimer expiryTimer_;

    // Defaults to the app's own service type so records can be ingested before `start()` is
    // called, which is what makes the cache testable without a socket. `start()` overrides it.
    QString serviceType_ = QString::fromLatin1(protocol::LocalStream::ServiceType);

    /// Keyed by [Service::instanceKey].
    QHash<QString, Service> services_;
    /// Host name to instance key, so an A record can be matched back to its instance.
    QHash<QString, QString> hostToInstance_;
    /// Instance key to the name last published, so a rename can retract the old row.
    QHash<QString, QString> publishedName_;
    /**
     * Instance key to a one-line summary of what was last published for it.
     *
     * Not for the UI, which already keeps its own rows: this exists so the log records a
     * broadcaster appearing, moving or changing, rather than one line every time a service
     * re-announces itself. A name alone is not enough - a broadcaster that comes back on a new
     * address or port is the same row with a different problem behind it.
     */
    QHash<QString, QString> publishedFingerprint_;
    /// Instance key to the monotonic millisecond it last saw a record for it.
    QHash<QString, qint64> lastSeen_;
    bool active_ = false;
};

} // namespace localstream::net
