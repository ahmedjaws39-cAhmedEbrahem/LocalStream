#pragma once

#include <QByteArray>
#include <QHostAddress>
#include <QObject>
#include <QString>
#include <QTimer>
#include <QUdpSocket>

namespace localstream::net {

/**
 * Announces this machine as a broadcaster over DNS-SD.
 *
 * The counterpart to `ServiceDiscovery`, and built on the same decoder assumptions: the records
 * are constructed by hand from a `protocol::LocalStream::Description`, and only the four types
 * a browse needs are sent (PTR, SRV, TXT and A). Sending exactly what the receiver parses is
 * the point; announcing extra types a client does not understand would only make the packet
 * larger for no gain.
 *
 * It both answers browse queries and re-announces on a timer. One socket is bound to the mDNS
 * port (AnyIPv4, or a single address in the fallback when the port is held); when it owns port
 * 5353 it joins the multicast group, so a receiver's PTR query arrives on it and can be answered
 * with the announcement. Ownership is what matters: a reply from an ephemeral source port is
 * discarded by strict resolvers such as Android's, so the periodic announcement remains the only
 * path when another program holds 5353. Qt 6.8 offers no per-send interface selection, so the
 * egress interface is pinned to the one the advertised address lives on.
 */
class ServiceAdvertiser : public QObject
{
    Q_OBJECT

public:
    struct Settings
    {
        /// The name shown in a receiver's list.
        QString displayName;
        /// The host name to advertise. Resolved to an address and announced as an A record.
        QString hostName;
        QHostAddress address;
        /// The control port, which is also what the SRV record points at.
        int controlPort = 0;
        /// Pre-rendered TXT entries, from `protocol::LocalStream::txtEntries`.
        QByteArray txtRecord;
        /// Announced TTL in seconds. 120 is what a live service conventionally uses.
        int ttlSeconds = 120;
        /**
         * Identifies this run of the broadcaster, and is appended to the advertised instance
         * label. Empty means no suffix.
         *
         * A restarted broadcaster must not reuse the previous instance label: peers key their
         * DNS-SD cache on the instance name, so re-announcing the same name reads as a record
         * update to a name they have already resolved, and they keep serving the old SRV and
         * TXT — an address and control port from a process that no longer exists.
         */
        QString sessionId;
    };

    explicit ServiceAdvertiser(QObject* parent = nullptr);
    ~ServiceAdvertiser() override;

    ServiceAdvertiser(const ServiceAdvertiser&) = delete;
    ServiceAdvertiser& operator=(const ServiceAdvertiser&) = delete;

    /**
     * Begins announcing, re-announcing on a timer.
     *
     * RFC 6762 section 8.3 requires re-announcing at 80, 85, 90 and 95 percent of the TTL, and
     * a listener that missed the first announcement would otherwise never see the service at
     * all. Re-announcing far more often than that is what makes a receiver that starts up late
     * find an already-running broadcast.
     */
    bool start(const Settings& settings, QString* error);

    /// Sends goodbye records and stops. Safe to call when not started, and safe twice.
    void stop();

    /// True when the socket owns port 5353 and can therefore answer browse queries. When false,
    /// another program holds the port and discovery falls back to the periodic announcements.
    [[nodiscard]] bool canAnswerQueries() const { return responsive_; }

private:
    void announce();
    void sendGoodbye();

    /// Reads any pending multicast datagrams and answers a matching browse query.
    void handleQuery();

    /// True when a question for `name` of record `type` is one this service should answer.
    [[nodiscard]] bool shouldAnswer(const QString& name, quint16 type) const;

    /// Sends the full record set in reply to a query, at most once per RFC 6762's floor.
    /// A query from a source port other than 5353 is a one-shot one and is answered directly to
    /// that source; a normal query is answered on the group.
    void respondToQuery(const QHostAddress& sender, quint16 senderPort);

    /// Builds the full response: header plus the four records, all in one message so a listener
    /// gets a complete answer from a single datagram.
    [[nodiscard]] QByteArray buildAnnouncement() const;

    /// The record names, each encoded in wire form.
    [[nodiscard]] QByteArray serviceNameWire() const;
    /// The instance name without the service type, escaped: display name plus session label.
    [[nodiscard]] QByteArray instanceNameWireLabel() const;
    [[nodiscard]] QByteArray instanceNameWire() const;
    [[nodiscard]] QByteArray hostNameWire() const;

    /// Sends [packet] once to the mDNS group, on the interface the advertised address lives on.
    void sendToGroup(const QByteArray& packet);

    QUdpSocket socket_;
    QTimer announceTimer_;

    Settings settings_;
    /// The display name, unescaped, before the service type and session id are appended.
    QString advertisedName_;
    /// The session id, appended as its own label. Empty means the name is used as-is.
    QString sessionLabel_;
    /// Set once a send has failed, so the failure is reported a single time.
    bool warnedAboutSend_ = false;
    /// True when the socket owns port 5353 rather than an ephemeral port. Only then is it
    /// joined to the group and able to answer a browse query; an ephemeral reply would not be
    /// trusted by a strict resolver, so the periodic announcement carries discovery instead.
    bool responsive_ = false;
    /// The last time a query was answered, so the same response is not multicast more than
    /// once per second (RFC 6762 section 6.6). Zero until the first answer.
    qint64 lastResponseMs_ = 0;
    bool active_ = false;
};

} // namespace localstream::net
