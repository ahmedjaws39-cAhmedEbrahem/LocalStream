#pragma once

#include <QByteArray>
#include <QHostAddress>
#include <QString>

#include <optional>
#include <vector>

namespace localstream::net::dnssd {

/// The largest DNS message read off the wire. RFC 6762 section 17 caps a multicast DNS packet at
/// 9000 bytes so it fits an Ethernet jumbo frame; a smaller receive buffer would silently
/// truncate a large response and drop whatever service it carried.
inline constexpr int MaxDatagramSize = 9000;

/**
 * Just enough of the DNS wire format to browse `_localstream._tcp.local`.
 *
 * This is deliberately a self-contained decoder rather than a dependency on the Bonjour SDK.
 * DNS-SD responses are plain DNS messages over multicast UDP, and the subset a browse needs is
 * small and completely specified (RFC 6762 and RFC 6763 section 9). Keeping it in-tree means
 * the receiver side of the app builds on a clean Windows box with no extra install, and it
 * means the parser can be tested against synthetic packets with no network at all.
 *
 * Only the record types a service browse produces are decoded: PTR, SRV, TXT and A. Anything
 * else is skipped by its declared length, which is what makes unknown records harmless.
 */

/**
 * A record as it appears on the wire, decoded.
 *
 * `name` is always the *owner* name in full. For a record inside a PTR's additional section
 * that is `_localstream._tcp.local`, which is precisely the name a receiver needs to key its
 * cache on.
 */
struct Record
{
    QString name;
    quint16 type = 0;
    quint16 ttl = 0;

    // PTR: the single target label. SRV: split below. TXT: the raw entries.
    QString target;
    quint16 priority = 0;
    quint16 weight = 0;
    quint16 port = 0;
    QByteArray txt;
    QHostAddress address;
};

/**
 * Decodes one DNS message, including the additional section.
 *
 * Returns nullopt when the header is not a response, when the question count is implausible,
 * or when a name runs past the end of the buffer. A truncated packet is treated as absent
 * rather than partially believed: a half-decoded SRV record with a missing port would send a
 * handshake to port 0.
 */
[[nodiscard]] std::optional<std::vector<Record>> parseResponse(const QByteArray& message);

/**
 * One question from a query: the name being asked about and the record type wanted.
 *
 * `name` is fully qualified, like `Record::name`, so `_localstream._tcp.local.` compares equal
 * to the same string a caller would write.
 */
struct Question
{
    QString name;
    quint16 type = 0;
};

/**
 * Decodes the question section of a query message.
 *
 * Returns nullopt for a response (the QR bit is set) and for a malformed or truncated message.
 * A responder uses this to tell a browse query apart from another responder's answer, both of
 * which arrive on the same multicast group.
 */
[[nodiscard]] std::optional<std::vector<Question>> parseQuery(const QByteArray& message);

/// Writes a name in DNS label form: length-prefixed labels, terminated by a zero byte.
[[nodiscard]] QByteArray encodeName(const QString& name);

/**
 * Escapes a display name so it can be used as a single DNS label.
 *
 * RFC 6763 section 4.3: a literal dot becomes `\.` and a literal backslash becomes `\\`.
 * Without this, a broadcaster called "Bob's. Laptop" would be announced as two labels and
 * would resolve under a different instance key than the receiver computes from the name.
 */
[[nodiscard]] QString escapeLabel(const QString& label);

/**
 * Expands the message-compression pointers in [name].
 *
 * @param message the whole datagram, since a pointer is an offset into it rather than into
 *        the record being decoded.
 * @param at the offset of the name field; advanced past the name in [message].
 * @return nullopt if the pointer chain is malformed or loops.
 */
[[nodiscard]] std::optional<QString> readName(const QByteArray& message, int& at);

/// Builds a PTR query for one service type, used to start a browse.
[[nodiscard]] QByteArray buildServiceQuery(const QString& serviceType);

} // namespace localstream::net::dnssd
