﻿#include "discovery/ServiceDiscovery.h"

#include "logging/Log.h"

#include <QDateTime>
#include <QList>
#include <QNetworkInterface>
#include <QtEndian>

namespace localstream::net {

namespace {

// DNS record types, repeated here so the dispatch below reads as a switch on a name.
constexpr quint16 TypeA = 1;
constexpr quint16 TypePtr = 12;
constexpr quint16 TypeTxt = 16;
constexpr quint16 TypeSrv = 33;

/// RFC 6762 section 3: the multicast group every responder and querier joins, and the port.
const QHostAddress &mdnsGroup()
{
    static const QHostAddress group = QHostAddress(QStringLiteral("224.0.0.251"));
    return group;
}

constexpr quint16 MdnsPort = 5353;

/// A browse re-asks at roughly this interval. RFC 6762 section 5.2 puts the floor at one
/// second for the first two queries and then allows backing off; five seconds keeps a joiner
/// from waiting long without hammering the network.
constexpr int QueryIntervalMs = 5000;

/// Records older than this are dropped. A broadcaster advertises a TXT TTL of 120s, so a
/// couple of missed queries must not make it vanish.
constexpr int MaxEntryAgeMs = 150000;

constexpr int SweepIntervalMs = 5000;

/**
 * The unicast address the OS would send from on the default route, or a null address if it
 * cannot be determined.
 *
 * Asking a throwaway UDP socket to "connect" to a public address sends nothing -- UDP connect
 * only fixes the route -- but it makes the OS pick an interface, and the local address it
 * reports is exactly the one a real packet would leave from. This is the only way to tell a
 * real LAN apart from a VPN or a VMware adapter without reimplementing route lookup, and
 * guessing wrong is not a cosmetic problem: binding multicast to the wrong adapter leaves the
 * user staring at an empty list while the phone sits on the Wi-Fi one.
 */
QHostAddress preferredSourceAddress()
{
    QUdpSocket probe;
    probe.connectToHost(QStringLiteral("192.0.2.1"), 9); // TEST-NET-1: routed, never reachable.
    // Waiting rather than testing the state directly: there is no handshake to complete for UDP,
    // so this returns at once, but the socket is briefly ConnectingState and reading state()
    // straight after connectToHost is a race that quietly yields no preferred address.
    if (!probe.waitForConnected(1000) || probe.state() != QAbstractSocket::ConnectedState) {
        return QHostAddress();
    }
    const QHostAddress address = probe.localAddress();
    return address == QHostAddress::AnyIPv4 ? QHostAddress() : address;
}

QList<QHostAddress> bindCandidates()
{
    QList<QHostAddress> candidates;

    const QHostAddress preferred = preferredSourceAddress();
    if (!preferred.isNull()) {
        candidates.append(preferred);
    }

    for (const QNetworkInterface &iface : QNetworkInterface::allInterfaces()) {
        if (iface.flags().testFlag(QNetworkInterface::IsLoopBack)
            || !iface.flags().testFlag(QNetworkInterface::IsUp)) {
            continue;
        }
        for (const QNetworkAddressEntry &entry : iface.addressEntries()) {
            if (entry.ip().protocol() != QAbstractSocket::IPv4Protocol || entry.ip().isNull()
                || candidates.contains(entry.ip())) {
                continue;
            }
            candidates.append(entry.ip());
        }
    }

    // The wildcard last, not first: it is the fallback for the single-interface case and the
    // option least likely to be refused.
    candidates.append(QHostAddress::AnyIPv4);
    return candidates;
}

/**
 * The interface owning `address`, or an invalid one if there is none.
 *
 * Needed because pinning the multicast group to an interface is a separate operation from
 * binding to it: the socket is bound to a unicast address, but the group still needs to be told
 * which adapter to leave from, or Windows may route it elsewhere and no reply ever arrives.
 */
QNetworkInterface interfaceForAddress(const QHostAddress &address)
{
    for (const QNetworkInterface &iface : QNetworkInterface::allInterfaces()) {
        for (const QNetworkAddressEntry &entry : iface.addressEntries()) {
            if (entry.ip() == address) {
                return iface;
            }
        }
    }
    return QNetworkInterface();
}

} // namespace

ServiceDiscovery::ServiceDiscovery(QObject *parent) : QObject(parent)
{
    connect(&socket_, &QUdpSocket::readyRead, this, &ServiceDiscovery::refresh);

    queryTimer_.setInterval(QueryIntervalMs);
    connect(&queryTimer_, &QTimer::timeout, this, &ServiceDiscovery::sendQuery);

    expiryTimer_.setInterval(SweepIntervalMs);
    connect(&expiryTimer_, &QTimer::timeout, this, &ServiceDiscovery::expireOldEntries);
}

ServiceDiscovery::~ServiceDiscovery()
{
    stop();
}

void ServiceDiscovery::start(const QString &serviceType)
{
    serviceType_ = serviceType;
    retractAll();
    beginBrowsing();
    logging::info(QStringLiteral("ServiceDiscovery"),
        QStringLiteral("discovery.browsing started for %1").arg(serviceType_));
}

void ServiceDiscovery::rescan()
{
    if (!active_) {
        start();
        return;
    }
    // Drop what is on screen before looking again. After a network change those rows point at
    // addresses and ports that no longer exist, and waiting for the TTL sweep would leave a
    // stale list up for the whole expiry window.
    retractAll();
    // Rebind rather than only re-query: an adapter that disappeared and came back leaves the
    // socket bound to an interface that no longer exists, and a query sent on it goes nowhere.
    socket_.close();
    beginBrowsing();
}

void ServiceDiscovery::retractAll()
{
    // Keyed by instance label, not by the display name: a list row is keyed on the instance, so
    // a retraction by name would never match and the row would stay up.
    const QList<QString> keys = services_.keys();
    services_.clear();
    hostToInstance_.clear();
    publishedName_.clear();
    // Cleared with the names: after a rescan the next announcement of the same broadcaster is
    // genuinely new information again, and the log should say so rather than stay quiet.
    publishedFingerprint_.clear();
    lastSeen_.clear();
    for (const QString &key : keys) {
        emit serviceRemoved(key);
    }
}

void ServiceDiscovery::beginBrowsing()
{
    // Join on the socket we both send on and receive on. Binding before joining matters: a
    // socket that has not bound cannot join a group, and one that binds after joining can end
    // up bound to the wrong interface.
    //
    // Each candidate address is tried in turn rather than only the first: a machine can have
    // several, and the one the OS prefers may be the one something else already holds.
    QString bindError;
    // The modes are tried in order of how likely they are to be allowed, not alphabetically.
    // ReuseAddressHint comes first because it is the only one that works on Windows against the
    // DNS Client service, which owns UDP 5353 for the entire machine: a plain ShareAddress bind
    // is refused with WSAEACCES there, and the user-visible result is a broadcaster list that
    // silently stays empty rather than an error anyone can act on.
    const QList<QUdpSocket::BindMode> bindModes = {QUdpSocket::ReuseAddressHint,
                                                   QUdpSocket::ShareAddress,
                                                   QUdpSocket::DontShareAddress};

    // Remembered so the group can be joined on the very interface the socket was bound to.
    QNetworkInterface boundInterface;
    for (const QHostAddress &candidate : bindCandidates()) {
        // A socket that has already failed a bind is not in a clean state, and retrying on it
        // produces a misleading second error that hides the real one.
        socket_.close();
        for (const QUdpSocket::BindMode mode : bindModes) {
            if (socket_.bind(candidate, MdnsPort, mode)) {
                // Pin the group to the interface that was just bound. Left unset, Windows may
                // route the group onto a different adapter than the one the socket is bound to,
                // and the replies never arrive. A wildcard bind has no single interface to pin
                // to, and is correct as it stands.
                if (candidate != QHostAddress::AnyIPv4) {
                    const QNetworkInterface iface = interfaceForAddress(candidate);
                    if (iface.isValid()) {
                        socket_.setMulticastInterface(iface);
                        boundInterface = iface;
                    }
                }
                break;
            }
        }
        if (socket_.state() == QAbstractSocket::BoundState) {
            break;
        }
        bindError = socket_.errorString();
    }

    const bool bound = socket_.state() == QAbstractSocket::BoundState;
    if (!bound) {
        // Reaching here means nothing could take the port -- adb does this while a device is
        // attached for wireless debugging, and so does the Windows DNS Client. It is not fatal:
        // the group is still joined below, and the OS delivers multicast to any socket that has
        // joined it regardless of port, so browsing can still work. It is only the replies a
        // responder unicasts to port 5353 that are lost.
        logging::warning(QStringLiteral("ServiceDiscovery"),
            QStringLiteral("discovery.bind.degraded: %1").arg(bindError));
        emit warning(QStringLiteral("Could not bind the mDNS port (%1); browsing may be "
                                    "incomplete while another responder holds it.")
                         .arg(bindError));
    }

    // Joined unconditionally, and not in the same branch as the bind result: making this an
    // `else if` meant a failed bind also skipped the join, so a browser that could have worked
    // over an ephemeral port silently saw nothing at all.
    // `joinMulticastGroup` returns bool, so `< 0` was always false and a failed join never
    // warned; `!` is what actually reports it.
    //
    // The interface is passed explicitly when the bind picked one: left to the stack, the group
    // can be joined on a VPN or a virtual adapter and no multicast from the LAN is ever
    // delivered. A wildcard bind has no single interface, so the join is left interface-less.
    const bool joined = boundInterface.isValid()
        ? socket_.joinMulticastGroup(mdnsGroup(), boundInterface)
        : socket_.joinMulticastGroup(mdnsGroup());
    if (!joined) {
        logging::warning(QStringLiteral("ServiceDiscovery"),
            QStringLiteral("discovery.join.failed: %1").arg(socket_.errorString()));
        emit warning(QStringLiteral("Could not join the mDNS group: %1").arg(socket_.errorString()));
    }

    // Hop limit 255 is required by RFC 6762 section 11: it is how a receiver detects a packet
    // that has crossed a router and must not be trusted for cache flushing.
    socket_.setSocketOption(QAbstractSocket::MulticastTtlOption,
        QVariant::fromValue<int>(255));
    // Loopback stays on so a broadcaster running on this machine sees its own announcement.
    socket_.setSocketOption(QAbstractSocket::MulticastLoopbackOption,
        QVariant::fromValue<int>(1));

    active_ = true;
    queryTimer_.start();
    expiryTimer_.start();
    sendQuery();
}

void ServiceDiscovery::stop()
{
    if (!active_) {
        return;
    }
    active_ = false;
    queryTimer_.stop();
    expiryTimer_.stop();
    socket_.close();
    services_.clear();
    hostToInstance_.clear();
    publishedName_.clear();
    lastSeen_.clear();
}

void ServiceDiscovery::refresh()
{
    while (socket_.hasPendingDatagrams()) {
        QByteArray datagram;
        datagram.resize(dnssd::MaxDatagramSize);
        const qint64 read = socket_.readDatagram(datagram.data(), datagram.size());
        if (read <= 0) {
            break;
        }
        datagram.resize(static_cast<int>(read));
        ingestPacket(datagram);
    }
}

void ServiceDiscovery::ingestPacket(const QByteArray &datagram)
{
    const auto records = dnssd::parseResponse(datagram);
    if (!records) {
        // Not fatal and not worth a signal per packet: unrelated multicast traffic on 5353 is
        // routine on a busy network.
        return;
    }
    // The ingest call reports whether anything changed through the signals; callers watch those,
    // not a flag, so the return value is discarded.
    ingest(*records);
}

QString ServiceDiscovery::unescapeInstance(const QString &label)
{
    // DNS escapes a literal dot inside an instance name as `\.` and a literal backslash as
    // `\\`. Decoded label by label rather than by repeated string replacement, because
    // replacing `\.` first would also mangle the `\\.` that means "backslash, then dot".
    QString out;
    out.reserve(label.size());
    for (int i = 0; i < label.size(); ++i) {
        const QChar c = label.at(i);
        if (c == QLatin1Char('\\') && i + 1 < label.size()) {
            const QChar next = label.at(i + 1);
            if (next == QLatin1Char('.') || next == QLatin1Char('\\')) {
                out.append(next);
                ++i;
                continue;
            }
        }
        out.append(c);
    }
    return out;
}

std::optional<QString> ServiceDiscovery::instanceFor(const QString &owner, const QString &serviceType)
{
    // A PTR owner is the bare service type (`_localstream._tcp.local.`), whereas SRV, TXT and A
    // owners are full instance names (`My Laptop._localstream._tcp.local.`). One rule covers
    // both: the owner must end in the service type and have a label in front of it.
    if (serviceType.isEmpty() || !owner.endsWith(serviceType)) {
        return std::nullopt;
    }
    const QString prefix = owner.left(owner.size() - serviceType.size());
    // One trailing dot separates the instance from the service type.
    if (prefix.size() < 2 || !prefix.endsWith(QLatin1Char('.'))) {
        return std::nullopt;
    }
    const QString label = prefix.left(prefix.size() - 1);
    if (label.isEmpty()) {
        return std::nullopt;
    }
    return unescapeInstance(label);
}

bool ServiceDiscovery::ingest(const std::vector<dnssd::Record> &records)
{
    // Collect first, publish after: emitting a signal mid-pass lets a slot re-enter and see a
    // half-updated cache, which is exactly the state a list UI would then render wrongly.
    //
    // Keyed rather than a list, because one announcement carries a PTR, an SRV, a TXT and an A
    // for the same instance. Appending each would publish that instance four times, and the
    // intermediate states between them (an instance with a port but no name yet) would each look
    // like a rename and retract the row that was on screen a moment earlier.
    const qint64 now = QDateTime::currentMSecsSinceEpoch();
    QHash<QString, Service> touched;

    for (const dnssd::Record &record : records) {
        if (record.type == TypePtr) {
            const auto key = instanceFor(record.target, serviceType_);
            if (!key) {
                continue;
            }
            // A PTR alone carries no address or port; it only says the instance exists.
            if (!services_.contains(*key)) {
                Service service;
                service.instanceKey = *key;
                services_.insert(*key, service);
                touched.insert(*key, service);
            }
            lastSeen_[*key] = now;
        } else if (record.type == TypeSrv) {
            const auto key = instanceFor(record.name, serviceType_);
            if (!key || record.port == 0) {
                continue;
            }
            Service service = services_.value(*key);
            service.instanceKey = *key;
            service.hostName = record.target;
            service.port = record.port;
            services_.insert(*key, service);
            touched.insert(*key, service);
            hostToInstance_.insert(record.target, *key);
            lastSeen_[*key] = now;
        } else if (record.type == TypeTxt) {
            const auto key = instanceFor(record.name, serviceType_);
            if (!key) {
                continue;
            }
            // The TXT payload is a sequence of length-prefixed entries, not one string.
            QList<QByteArray> entries;
            int at = 0;
            while (at < record.txt.size()) {
                const auto length = static_cast<quint8>(record.txt.at(at));
                ++at;
                if (length == 0 || at + length > record.txt.size()) {
                    break;
                }
                entries.append(record.txt.mid(at, length));
                at += length;
            }
            const auto description = protocol::LocalStream::descriptionFromTxt(entries);
            if (!description) {
                // An incompatible version, or a record missing its control port: not ours to
                // show, and guessing would produce a connection that cannot work.
                continue;
            }
            Service service = services_.value(*key);
            service.instanceKey = *key;
            service.description = *description;
            // The TXT `n` key is what the UI shows, and is more specific than the label the
            // responder derived from the hostname.
            service.name = description->displayName;
            if (service.name.isEmpty()) {
                service.name = *key;
            }
            services_.insert(*key, service);
            lastSeen_[*key] = now;
            touched.insert(*key, service);
        } else if (record.type == TypeA) {
            const QString key = hostToInstance_.value(record.name);
            if (key.isEmpty() || !services_.contains(key)) {
                continue;
            }
            Service service = services_.value(key);
            service.address = record.address;
            services_.insert(key, service);
            lastSeen_[key] = now;
            touched.insert(key, service);
        }
    }

    if (!touched.isEmpty()) {
        publish(touched);
    }
    return !touched.isEmpty();
}

void ServiceDiscovery::publish(const QHash<QString, Service> &touched)
{
    // A broadcaster may change the name it advertises at any time. Retract the previously
    // published row before announcing the new one, or the list ends up showing the same
    // broadcaster twice under two names. The retraction carries the instance label, which is
    // the key a list row holds, not the display name it happens to be showing.
    for (auto it = touched.cbegin(); it != touched.cend(); ++it) {
        const QString previous = publishedName_.value(it.key());
        // An instance that has no name yet has never been on screen under a name, so there is
        // nothing to retract. Only a genuine name change emits a removal.
        if (!it.value().name.isEmpty() && !previous.isEmpty() && previous != it.value().name) {
            emit serviceRemoved(it.key());
        }
    }
for (auto it = touched.cbegin(); it != touched.cend(); ++it) {
        publishedName_.insert(it.key(), it.value().name);

        // Logged only when something a user would notice has changed. A service re-announces
        // itself every few seconds for as long as it is up, and a log that says so once a cycle
        // buries the one line that matters: the broadcaster that appeared, or the one that came
        // back somewhere else.
        const QString fingerprint =
            QStringLiteral("%1|%2|%3|%4").arg(it.value().name, it.value().address.toString())
                .arg(it.value().port)
                .arg(it.value().description.mode);
        if (publishedFingerprint_.value(it.key()) != fingerprint) {
            const bool isNew = !publishedFingerprint_.contains(it.key());
            logging::event(isNew ? QStringLiteral("discovery.broadcaster.found")
                                 : QStringLiteral("discovery.broadcaster.changed"),
                {{QStringLiteral("name"), it.value().name},
                    {QStringLiteral("address"), it.value().address.toString()},
                    {QStringLiteral("port"), QString::number(it.value().port)},
                    {QStringLiteral("mode"), it.value().description.mode},
                    {QStringLiteral("controlPort"),
                        QString::number(it.value().description.controlPort)}});
            publishedFingerprint_.insert(it.key(), fingerprint);
        }

        emit serviceAdded(services_.value(it.key()));
    }
}

void ServiceDiscovery::sendQuery()
{
    if (!active_) {
        return;
    }
    queryFor(serviceType_);
    // Asking for the host name as well resolves an instance in one exchange when the
    // responder is already up, instead of making the user wait for a second browse cycle.
    const QList<Service> known = services_.values();
    for (const Service &service : known) {
        if (!service.hostName.isEmpty()) {
            queryFor(service.hostName);
        }
    }
}

void ServiceDiscovery::queryFor(const QString &name)
{
    if (name.isEmpty()) {
        return;
    }
    const QByteArray query = dnssd::buildServiceQuery(name);
    if (query.isEmpty()) {
        return;
    }
    socket_.writeDatagram(query, mdnsGroup(), MdnsPort);
}

void ServiceDiscovery::expireOldEntries()
{
    if (!active_ || lastSeen_.isEmpty()) {
        return;
    }
    const qint64 now = QDateTime::currentMSecsSinceEpoch();
    QList<QString> stale;
    for (auto it = lastSeen_.begin(); it != lastSeen_.end(); ++it) {
        if (now - it.value() > MaxEntryAgeMs) {
            stale.append(it.key());
        }
    }
// Collected, then removed, then signalled: a slot is free to call back in here, and
    // mutating the hash under a live iterator is how that goes wrong.
    if (!stale.isEmpty()) {
        logging::debug(QStringLiteral("ServiceDiscovery"),
            QStringLiteral("discovery.expired: %1 entr%s").arg(stale.size()).arg(
                stale.size() == 1 ? QStringLiteral("y") : QStringLiteral("ies")));
    }
    for (const QString &key : stale) {
        services_.remove(key);
        hostToInstance_.remove(key);
        lastSeen_.remove(key);
        publishedName_.remove(key);
        publishedFingerprint_.remove(key);
        // Keyed by instance label: that is what the list row carries, so the row is actually
        // removed. Emitting the display name here left stale rows up until the next rename.
        emit serviceRemoved(key);
    }
}

} // namespace localstream::net
