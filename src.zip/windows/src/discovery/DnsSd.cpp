#include "discovery/DnsSd.h"

#include <QStringList>

namespace localstream::net::dnssd {

namespace {

// DNS record types and flags, from RFC 1035. Only the ones a browse yields are named.
constexpr quint16 TypeA = 1;
constexpr quint16 TypePtr = 12;
constexpr quint16 TypeTxt = 16;
constexpr quint16 TypeSrv = 33;

// The top two bits of the second header word mark the message as a response.
constexpr quint16 FlagResponse = 0x8000;

/// Refuse to allocate for absurd counts. A 255-record ceiling is far above any real browse
/// response and keeps a hostile length field from turning into a huge vector.
constexpr int MaxRecords = 255;

/// How many labels a name may have before it is treated as malformed.
constexpr int MaxLabels = 128;

quint16 readU16(const QByteArray& message, int at)
{
    return static_cast<quint16>((static_cast<quint8>(message.at(at)) << 8)
        | static_cast<quint8>(message.at(at + 1)));
}

bool headerCountsArePlausible(const QByteArray& message)
{
    if (message.size() < 12) {
        return false;
    }
    const quint16 questions = readU16(message, 4);
    const quint16 answers = readU16(message, 6);
    const quint16 authorities = readU16(message, 8);
    const quint16 additional = readU16(message, 10);
    const int total = questions + answers + authorities + additional;
    if (total > MaxRecords) {
        return false;
    }
    return true;
}

} // namespace

std::optional<QString> readName(const QByteArray& message, int& at)
{
    QStringList labels;
    int cursor = at;
    // Bounded separately from `at`: a pointer chain can jump backwards, so the real limit is
    // iterations, not distance travelled.
    int hops = 0;
    bool followed = false;

    for (;;) {
        if (cursor < 0 || cursor >= message.size()) {
            return std::nullopt;
        }
        const auto length = static_cast<quint8>(message.at(cursor));

        if ((length & 0xC0) == 0xC0) {
            // Compression pointer: two bytes, the low 14 bits being an offset into the message.
            if (cursor + 1 >= message.size()) {
                return std::nullopt;
            }
            const int target = ((length & 0x3F) << 8) | static_cast<quint8>(message.at(cursor + 1));
            if (!followed) {
                at = cursor + 2;
                followed = true;
            }
            if (target >= cursor || ++hops > MaxLabels) {
                // Pointing forwards would loop; real names always point backwards.
                return std::nullopt;
            }
            cursor = target;
            continue;
        }

        if ((length & 0xC0) != 0) {
            return std::nullopt; // reserved label type
        }
        if (length == 0) {
            if (!followed) {
                at = cursor + 1;
            }
            break;
        }
        if (cursor + 1 + length > message.size()) {
            return std::nullopt;
        }
        if (labels.size() >= MaxLabels) {
            return std::nullopt;
        }
        labels.append(QString::fromLatin1(message.constData() + cursor + 1, length));
        cursor += 1 + length;
    }

    // A fully qualified name keeps its terminating root dot, so `laptop._localstream._tcp.local.`
    // round-trips to the same string a caller would write as the service type. Without it no
    // owner name would ever compare equal to the service type being browsed.
    if (labels.isEmpty()) {
        return QString(); // the bare root name, which is just the zero-length label
    }
    return labels.join(QLatin1Char('.')) + QLatin1Char('.');
}

std::optional<std::vector<Record>> parseResponse(const QByteArray& message)
{
    if (!headerCountsArePlausible(message)) {
        return std::nullopt;
    }
    if ((readU16(message, 2) & FlagResponse) == 0) {
        return std::nullopt; // a query, not a response
    }

    const quint16 questions = readU16(message, 4);
    const quint16 answers = readU16(message, 6);
    const quint16 authorities = readU16(message, 8);
    const quint16 additional = readU16(message, 10);

    std::vector<Record> records;
    records.reserve(questions + answers + authorities + additional);

    int at = 12;
    for (int i = 0; i < questions; ++i) {
        const auto name = readName(message, at);
        if (!name) {
            return std::nullopt;
        }
        if (at + 4 > message.size()) {
            return std::nullopt;
        }
        at += 4; // QTYPE and QCLASS
    }

    const int total = answers + authorities + additional;
    for (int i = 0; i < total; ++i) {
        const auto owner = readName(message, at);
        if (!owner) {
            return std::nullopt;
        }
        if (at + 10 > message.size()) {
            return std::nullopt;
        }

        Record record;
        record.name = *owner;
        record.type = readU16(message, at);
        record.ttl = readU16(message, at + 6);
        const quint16 dataLength = readU16(message, at + 8);
        at += 10;

        if (at + dataLength > message.size()) {
            return std::nullopt;
        }
        const int dataEnd = at + dataLength;

        switch (record.type) {
        case TypePtr: {
            int cursor = at;
            const auto target = readName(message, cursor);
            if (!target) {
                return std::nullopt;
            }
            record.target = *target;
            break;
        }
        case TypeSrv: {
            // Priority and weight precede the port, then the target name. All three are
            // needed before the name, so the offsets are not sequential with `at`.
            if (dataLength < 7) {
                return std::nullopt;
            }
            record.priority = readU16(message, at);
            record.weight = readU16(message, at + 2);
            record.port = readU16(message, at + 4);
            int cursor = at + 6;
            const auto target = readName(message, cursor);
            if (!target) {
                return std::nullopt;
            }
            record.target = *target;
            break;
        }
        case TypeTxt: {
            // TXT data is a sequence of length-prefixed strings. The outer RDLENGTH has
            // already been consumed, so this is just the raw payload for the caller to split.
            record.txt = message.mid(at, dataLength);
            break;
        }
        case TypeA: {
            if (dataLength != 4) {
                return std::nullopt;
            }
            const auto *p = reinterpret_cast<const quint8 *>(message.constData()) + at;
            // Qt 6.8 dropped the four-octet QHostAddress constructor, and its quint32 overload
            // takes the address in network byte order, so the wire bytes are reassembled
            // big-endian rather than reinterpreted as a host integer.
            const quint32 ipv4 = (quint32(p[0]) << 24) | (quint32(p[1]) << 16)
                | (quint32(p[2]) << 8) | quint32(p[3]);
            record.address = QHostAddress(ipv4);
            break;
        }
        default:
            // An unknown type is not an error: its RDLENGTH says how much to skip, which is
            // the whole point of putting lengths on the wire.
            break;
        }

        records.push_back(std::move(record));
        at = dataEnd;
    }

    return records;
}

std::optional<std::vector<Question>> parseQuery(const QByteArray& message)
{
    if (!headerCountsArePlausible(message)) {
        return std::nullopt;
    }
    if ((readU16(message, 2) & FlagResponse) != 0) {
        return std::nullopt; // a response, not a query
    }

    const quint16 questions = readU16(message, 4);

    std::vector<Question> parsed;
    parsed.reserve(questions);

    int at = 12;
    for (int i = 0; i < questions; ++i) {
        const auto name = readName(message, at);
        if (!name) {
            return std::nullopt;
        }
        if (at + 4 > message.size()) {
            return std::nullopt;
        }
        Question question;
        question.name = *name;
        question.type = readU16(message, at);
        at += 4; // QTYPE and QCLASS
        parsed.push_back(std::move(question));
    }

    return parsed;
}

QString escapeLabel(const QString& label)
{
    QString out;
    out.reserve(label.size());
    for (const QChar c : label) {
        if (c == QLatin1Char('.') || c == QLatin1Char('\\')) {
            out.append(QLatin1Char('\\'));
        }
        out.append(c);
    }
    return out;
}

QByteArray encodeName(const QString& name)
{
    QByteArray out;
    // The root label is written even for an empty name, so the result is always a valid name.
    if (name.isEmpty()) {
        out.append('\0');
        return out;
    }
    for (const QString& label : name.split(QLatin1Char('.'), Qt::SkipEmptyParts)) {
        const QByteArray bytes = label.toLatin1();
        if (bytes.size() > 63) {
            continue; // a label cannot exceed 63 bytes; skip rather than write an illegal one
        }
        out.append(static_cast<char>(bytes.size()));
        out.append(bytes);
    }
    out.append('\0');
    return out;
}

QByteArray buildServiceQuery(const QString& serviceType)
{
    QByteArray message;
    // A query ID of zero is what a browse should use: responders multicast their reply
    // anyway, and an ID would only invite a unicast answer to a socket with no query pending.
    message.append('\0');
    message.append('\0');
    // Flags: standard query, no recursion desired. The rest of the header is zero.
    message.append('\0');
    message.append('\0');
    // QDCOUNT = 1, everything else zero.
    message.append('\0');
    message.append('\x01');
    for (int i = 0; i < 6; ++i) {
        message.append('\0');
    }

    message.append(encodeName(serviceType));
    // QTYPE = PTR (12), QCLASS = IN (1).
    message.append('\0');
    message.append('\x0C');
    message.append('\0');
    message.append('\x01');
    return message;
}

} // namespace localstream::net::dnssd
