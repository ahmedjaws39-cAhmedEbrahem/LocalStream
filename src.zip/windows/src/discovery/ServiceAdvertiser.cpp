#include "discovery/ServiceAdvertiser.h"

#include <QDateTime>
#include <QNetworkInterface>
#include <QVariant>

#include "discovery/DnsSd.h"
#include "protocol/LocalStream.h"

namespace localstream::net {

namespace {

constexpr quint16 TypeA = 1;
constexpr quint16 TypePtr = 12;
constexpr quint16 TypeTxt = 16;
constexpr quint16 TypeSrv = 33;

constexpr int MdnsPort = 5353;

/// The group every responder and querier joins (RFC 6762 section 3).
const QHostAddress& mdnsGroup()
{
    static const QHostAddress group = QHostAddress(QStringLiteral("224.0.0.251"));
    return group;
}

/// A query is answered at most this often, per RFC 6762 section 6.6. Every querier on the link
/// hears one multicast response, so a query that lands inside the floor is already served by it.
constexpr qint64 ResponseFloorMs = 1000;

/// Re-announced well inside the TTL, so a listener that missed one round still sees the next.
/// Only used once the socket owns 5353 and can answer a browse query; see
/// UnresponsiveAnnounceIntervalMs for the case where it cannot.
constexpr int AnnounceIntervalMs = 30000;

/// How often to re-announce when port 5353 is held by another program and queries cannot be
/// answered. This then becomes the worst-case discovery delay: a receiver that starts just after
/// an announcement waits out the rest of the interval. Five seconds matches the receiver's own
/// browse-retry cadence, so a new viewer waits no longer than it would have anyway.
constexpr int UnresponsiveAnnounceIntervalMs = 5000;

/// The interface owning `address`, or an invalid one if there is none. The multicast group has
/// to be sent and joined on the interface the advertised address lives on, which is a separate
/// decision from which address the socket is bound to.
QNetworkInterface interfaceForAddress(const QHostAddress& address)
{
    for (const QNetworkInterface& iface : QNetworkInterface::allInterfaces()) {
        for (const QNetworkAddressEntry& entry : iface.addressEntries()) {
            if (entry.ip() == address) {
                return iface;
            }
        }
    }
    return QNetworkInterface();
}

/// Compares two DNS names, ignoring case and one optional trailing root dot.
bool sameDnsName(const QString& a, const QString& b)
{
    const auto normalized = [](const QString& name) {
        return name.endsWith(QLatin1Char('.')) ? name.left(name.size() - 1) : name;
    };
    return normalized(a).compare(normalized(b), Qt::CaseInsensitive) == 0;
}

void appendU16(QByteArray& out, quint16 value)
{
    out.append(static_cast<char>((value >> 8) & 0xFF));
    out.append(static_cast<char>(value & 0xFF));
}

void appendU32(QByteArray& out, quint32 value)
{
    out.append(static_cast<char>((value >> 24) & 0xFF));
    out.append(static_cast<char>((value >> 16) & 0xFF));
    out.append(static_cast<char>((value >> 8) & 0xFF));
    out.append(static_cast<char>(value & 0xFF));
}

/// Encodes the answer section for one record.
void appendRecord(QByteArray& out, const QByteArray& owner, quint16 type,
    const QByteArray& rdata, int ttlSeconds)
{
    out.append(owner);
    appendU16(out, type);
    appendU16(out, 1); // class IN
    appendU32(out, static_cast<quint32>(ttlSeconds));
    appendU16(out, static_cast<quint16>(rdata.size()));
    out.append(rdata);
}

} // namespace

ServiceAdvertiser::ServiceAdvertiser(QObject* parent) : QObject(parent)
{
    connect(&socket_, &QUdpSocket::readyRead, this, &ServiceAdvertiser::handleQuery);

    announceTimer_.setInterval(AnnounceIntervalMs);
    connect(&announceTimer_, &QTimer::timeout, this, &ServiceAdvertiser::announce);
}

ServiceAdvertiser::~ServiceAdvertiser()
{
    stop();
}

bool ServiceAdvertiser::start(const Settings& settings, QString* error)
{
    if (active_) {
        return true;
    }

    if (settings.controlPort <= 0 || settings.controlPort > 65535) {
        if (error) {
            *error = QStringLiteral("The control port is not set, so there is nothing to "
                                    "advertise.");
        }
        return false;
    }
    if (settings.address.isNull()) {
        if (error) {
            *error = QStringLiteral("No local address is available to advertise.");
        }
        return false;
    }

    settings_ = settings;
    // The label the user would recognise. The session id is held separately and appended as a
    // sub-label when the instance name is built, so that restarting the broadcaster produces a
    // genuinely new DNS-SD instance; see Settings::sessionId for why the name cannot simply be
    // reused. Receivers show the TXT `n` key, not this label, so the suffix never reaches a user.
    advertisedName_ = settings.displayName.isEmpty() ? QStringLiteral("LocalStream")
                                                     : settings.displayName;
    sessionLabel_ = settings.sessionId;

    // Port 5353 is a shared resource that Windows itself occupies: the DNS Client service binds
    // it on every machine with multicast name resolution enabled, and it does not always allow
    // another socket to join it. Each attempt below is tried in turn, because which one works
    // is a property of the machine rather than something that can be decided here.
    //
    // A socket that is not bound still accepts and silently discards writes, so failing to bind
    // looks exactly like a network the peer cannot see us on. That has to be reported, and a
    // usable fallback has to be found, rather than left to be diagnosed from the far end.
    // A failed bind leaves the socket in an error state where every later call fails with the
    // same error, so each attempt starts from a closed socket. Without the close, the fallback
    // below reports the first error rather than its own.
    const auto tryBind = [this](const QHostAddress& address, quint16 port, QUdpSocket::BindMode mode) {
        socket_.close();
        const bool ok = socket_.bind(address, port, mode);
        qInfo("mDNS bind %s", qPrintable(QStringLiteral("%1:%2 -> %3")
                                            .arg(address.toString())
                                            .arg(port)
                                            .arg(ok ? QStringLiteral("ok") : socket_.errorString())));
        return ok;
    };

    // The wildcard is tried first, and with ReuseAddressHint, because that is the only bind
    // Windows delivers inbound multicast to while the DNS Client holds 0.0.0.0:5353 for the
    // whole machine. Measured on Windows 11: a socket bound to the single LAN address receives
    // no multicast at all -- not even a query sent by a phone a metre away -- whereas the same
    // socket on the wildcard receives it, and the address-reuse hint is what lets it bind
    // alongside the DNS Client. A responder that cannot hear a browse query never answers one.
    const bool boundAny = tryBind(QHostAddress::AnyIPv4, MdnsPort, QUdpSocket::ReuseAddressHint);
    const bool boundAddress =
        !boundAny && tryBind(settings_.address, MdnsPort, QUdpSocket::ReuseAddressHint);
    const bool boundEphemeral =
        !(boundAny || boundAddress)
        && tryBind(QHostAddress::AnyIPv4, 0, QUdpSocket::ReuseAddressHint);

    if (!(boundAny || boundAddress || boundEphemeral)) {
        // Without any socket there is no way to reach the network at all, and the caller has to
        // hear about it: the broadcast still works for anyone given the address by hand.
        if (error) {
            *error = QStringLiteral("Could not open an mDNS socket (%1); the broadcast will run "
                                    "but will not be discoverable. Viewers can still connect by "
                                    "entering the control port shown here.")
                         .arg(socket_.errorString());
        }
        qWarning("Could not open an mDNS socket: %s", qPrintable(QStringLiteral("%1")
                                                                     .arg(socket_.errorString())));
        return false;
    }

    responsive_ = boundAny || boundAddress;
    if (!responsive_) {
        // Announcements still reach receivers, because they are unsolicited multicast; what is
        // lost is the ability to answer a query, so a receiver that browses after the last
        // announcement would have to wait for the next one to be sent.
        if (error) {
            *error = QStringLiteral("Another program is holding the mDNS port, so this "
                                    "broadcaster announces itself but cannot answer discovery "
                                    "queries. Receivers may take up to %1 seconds to find it.")
                         .arg(UnresponsiveAnnounceIntervalMs / 1000);
        }
        qWarning("The mDNS port is held by another program; announcing from port %d instead. "
                 "Discovery still works, but queries cannot be answered.",
            static_cast<int>(socket_.localPort()));
    }
    socket_.setSocketOption(QAbstractSocket::MulticastTtlOption,
        QVariant::fromValue<int>(255));
    socket_.setSocketOption(QAbstractSocket::MulticastLoopbackOption,
        QVariant::fromValue<int>(1));

    // Pin the group to the interface the advertised address lives on, then join it. The pin has
    // to come first: joining uses the socket's current multicast interface, and left to the
    // routing table Windows may pick a VPN or a virtual adapter, so neither the announcement nor
    // the received query would travel the LAN. A wildcard bind has no address of its own, so
    // `settings_.address` is what chooses the interface either way.
    const QNetworkInterface advertisedInterface = interfaceForAddress(settings_.address);
    if (advertisedInterface.isValid()) {
        socket_.setMulticastInterface(advertisedInterface);
    }
    if (responsive_) {
        // Only a socket that owns 5353 is joined. Answering from an ephemeral source port would
        // be discarded by a strict resolver, so there is nothing to gain from joining then, and
        // the periodic announcement remains the discovery path.
        //
        // The interface is given explicitly rather than left to setMulticastInterface, because
        // that setting chooses the send interface and the join can still land on whatever the
        // stack prefers -- on a machine with a VPN or a virtual adapter that is the wrong one,
        // and a group joined on the wrong adapter hears nothing from the LAN.
        const bool joined = advertisedInterface.isValid()
            ? socket_.joinMulticastGroup(mdnsGroup(), advertisedInterface)
            : socket_.joinMulticastGroup(mdnsGroup());
        if (!joined) {
            // Not fatal: the announcement still gets the service found, just without answering a
            // browse query. Said once rather than on the timer, which would repeat it forever.
            qWarning("Could not join the mDNS group; browse queries will not be answered: %s",
                qPrintable(socket_.errorString()));
        }
    }

    active_ = true;
    // An owner of 5353 answers a browse query, so the periodic announcement is only a safety
    // net and can afford the full TTL-ish interval. One that cannot answer has no such net, and
    // a 30-second wait for the next announcement is the only thing a new viewer would see, so
    // it announces far more often instead.
    announceTimer_.setInterval(responsive_ ? AnnounceIntervalMs : UnresponsiveAnnounceIntervalMs);
    announceTimer_.start();
    // Announced immediately so the row appears without waiting out a timer.
    announce();
    qInfo("Advertising %s", qPrintable(QStringLiteral("%1 as %2 on control port %3")
                                           .arg(settings_.address.toString(),
                                               instanceNameWireLabel())
                                           .arg(settings_.controlPort)));
    return true;
}

void ServiceAdvertiser::stop()
{
    if (!active_) {
        return;
    }
    active_ = false;
    announceTimer_.stop();
    sendGoodbye();
}

QByteArray ServiceAdvertiser::serviceNameWire() const
{
    return dnssd::encodeName(QString::fromLatin1(protocol::LocalStream::ServiceType));
}

QByteArray ServiceAdvertiser::instanceNameWireLabel() const
{
    QString label = dnssd::escapeLabel(advertisedName_);
    if (!sessionLabel_.isEmpty()) {
        label += QLatin1Char('.') + sessionLabel_;
    }
    return label.toLatin1();
}

QByteArray ServiceAdvertiser::instanceNameWire() const
{
    // Only the user-supplied part is escaped: escaping the assembled string would turn the
    // separator before the session id into a literal dot inside one label, producing an
    // instance name no peer would match against the service type.
    return dnssd::encodeName(QString::fromLatin1(instanceNameWireLabel()) + QLatin1Char('.')
        + QString::fromLatin1(protocol::LocalStream::ServiceType));
}

QByteArray ServiceAdvertiser::hostNameWire() const
{
    return dnssd::encodeName(settings_.hostName);
}

QByteArray ServiceAdvertiser::buildAnnouncement() const
{
    QByteArray message;

    // A response header with the answer count only; the additional records are carried inside
    // the answer count here because every record belongs to the same announcement and a
    // listener reading any count sees all four.
    appendU16(message, 0);     // ID
    appendU16(message, 0x8400); // response, authoritative
    appendU16(message, 0);     // questions
    appendU16(message, 4);     // answers
    appendU16(message, 0);     // authorities
    appendU16(message, 0);     // additional

    const QByteArray service = serviceNameWire();
    const QByteArray instance = instanceNameWire();
    const QByteArray host = hostNameWire();
    const int ttl = settings_.ttlSeconds;

    // PTR: the service type points at the instance.
    appendRecord(message, service, TypePtr, instance, ttl);

    // SRV: the instance points at the control port on the host.
    QByteArray srv;
    appendU16(srv, 0); // priority
    appendU16(srv, 0); // weight
    appendU16(srv, static_cast<quint16>(settings_.controlPort));
    srv.append(host);
    appendRecord(message, instance, TypeSrv, srv, ttl);

    // TXT: the session description, already in DNS-SD length-prefixed form.
    appendRecord(message, instance, TypeTxt, settings_.txtRecord, ttl);

    // A: the address the host resolves to on this network.
    QByteArray address;
    if (settings_.address.protocol() == QAbstractSocket::IPv4Protocol) {
        const quint32 packed = settings_.address.toIPv4Address();
        address.append(static_cast<char>((packed >> 24) & 0xFF));
        address.append(static_cast<char>((packed >> 16) & 0xFF));
        address.append(static_cast<char>((packed >> 8) & 0xFF));
        address.append(static_cast<char>(packed & 0xFF));
        appendRecord(message, host, TypeA, address, ttl);
    }

    return message;
}

void ServiceAdvertiser::announce()
{
    if (!active_) {
        return;
    }
    sendToGroup(buildAnnouncement());
}

void ServiceAdvertiser::sendGoodbye()
{
    if (settings_.controlPort <= 0) {
        return;
    }
    // A goodbye is the same announcement with TTL zero, which is how RFC 6762 section 10.1
    // retires a record: a listener that sees it removes the entry immediately rather than
    // waiting out the TTL.
    const int savedTtl = settings_.ttlSeconds;
    settings_.ttlSeconds = 0;
    const QByteArray packet = buildAnnouncement();
    settings_.ttlSeconds = savedTtl;

    sendToGroup(packet);
}

void ServiceAdvertiser::sendToGroup(const QByteArray& packet)
{
    // Sent once, not once per interface: sending it N times delivers N copies to a receiver on
    // the loopback path and makes the announcement look like several distinct broadcasters.
    //
    // Qt 6.8 offers no per-send interface selection, so the egress interface is the one the
    // routing table picks for 224.0.0.251, and on a multi-homed machine the announcement may
    // leave only one of them. It is a limitation of this approach rather than a guarantee that
    // every interface is reached; when the bind above fell back to `settings_.address`, the
    // socket is interface-bound and only that interface can carry the announcement at all.
    const qint64 written = socket_.writeDatagram(packet, mdnsGroup(), MdnsPort);
    if (written < 0 && !warnedAboutSend_) {
        // An unbound socket accepts the call and drops it, which looks exactly like a network
        // problem on the receiving side. Reported once, because the timer repeats it forever.
        warnedAboutSend_ = true;
        qWarning("Could not send the mDNS announcement: %s",
            qPrintable(QStringLiteral("%1").arg(socket_.errorString())));
    }
}

void ServiceAdvertiser::handleQuery()
{
    while (socket_.hasPendingDatagrams()) {
        QByteArray datagram;
        datagram.resize(dnssd::MaxDatagramSize);
        QHostAddress sender;
        quint16 senderPort = 0;
        const qint64 read =
            socket_.readDatagram(datagram.data(), datagram.size(), &sender, &senderPort);
        if (read <= 0) {
            break;
        }
        datagram.resize(static_cast<int>(read));

        const auto questions = dnssd::parseQuery(datagram);
        if (!questions) {
            // A response -- this advertiser's own announcement echoed back by the loopback copy,
            // or another responder's -- as well as unrelated multicast on 5353. Neither is a
            // request, and answering either is how a responder talks to itself forever.
            continue;
        }
        for (const dnssd::Question& question : *questions) {
            if (shouldAnswer(question.name, question.type)) {
                respondToQuery(sender, senderPort);
                break;
            }
        }
    }
}

bool ServiceAdvertiser::shouldAnswer(const QString& name, quint16 type) const
{
    if (!active_ || !responsive_) {
        return false;
    }
    // The record types this service can speak to. ANY (255) is allowed because a browser may
    // ask for every type at once.
    const bool knownType =
        type == TypePtr || type == TypeSrv || type == TypeTxt || type == TypeA || type == 255;
    if (!knownType) {
        return false;
    }
    // Only the three names this service owns. `_localstream._tcp.local.` as a whole is shared
    // with every other broadcaster, and answering for a sibling instance would hand a querier
    // this machine's address under someone else's name.
    const QString service = QString::fromLatin1(protocol::LocalStream::ServiceType);
    const QString instance =
        QString::fromLatin1(instanceNameWireLabel()) + QLatin1Char('.') + service;
    return sameDnsName(name, service) || sameDnsName(name, instance)
        || sameDnsName(name, settings_.hostName);
}

void ServiceAdvertiser::respondToQuery(const QHostAddress& sender, quint16 senderPort)
{
    // RFC 6762 section 6.7: a query whose source port is not 5353 is a legacy one-shot query,
    // and its answer goes back to that source alone -- the querier is not listening on the
    // group. The one-second floor of section 6.6 limits how often a record may be *multicast*,
    // so it does not apply here: a legacy querier inside that window would otherwise get
    // nothing at all, since no multicast reply reaches it.
    if (senderPort != 0 && senderPort != MdnsPort) {
        const qint64 written = socket_.writeDatagram(buildAnnouncement(), sender, senderPort);
        if (written < 0 && !warnedAboutSend_) {
            warnedAboutSend_ = true;
            qWarning("Could not send the mDNS query reply: %s",
                qPrintable(socket_.errorString()));
        }
        return;
    }
    // A normal query (source port 5353) is answered on the group, at most once per second, so a
    // burst from several resolvers still produces a single multicast response. The response is
    // the full record set, which is exactly what the announcement already is: the same four
    // authoritative records.
    const qint64 now = QDateTime::currentMSecsSinceEpoch();
    if (lastResponseMs_ != 0 && now - lastResponseMs_ < ResponseFloorMs) {
        return;
    }
    lastResponseMs_ = now;
    announce();
}

} // namespace localstream::net
