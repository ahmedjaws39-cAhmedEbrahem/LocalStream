#pragma once

#include <QDateTime>
#include <QList>
#include <QPair>
#include <QString>
#include <QStringList>

namespace localstream::logging {

/**
 * How much detail a line carries, and how much a reader is expected to care.
 *
 * The names are the ones Qt already uses for its own message types, on purpose: a line that
 * says `Warning` in this log says `W` in a Qt console message for the same event, and a report
 * quoted in a bug thread stays readable next to either.
 */
enum class Level {
    Debug = 0, ///< Per-frame and per-packet detail. Useful when chasing a glitch, noisy otherwise.
    Info,      ///< Something a person did, or a stage the app reached.
    Warning,   ///< The app carried on without what it wanted.
    Error,     ///< Something failed that the user will notice.
};

/// `Debug`, `Info`, `Warning` or `Error`. Also what [parseLevel] reads back.
[[nodiscard]] QString levelName(Level level);

/**
 * The five-character form that goes inside the brackets of a log line.
 *
 * Uppercase and padded to a fixed width so the level column starts in the same place on every
 * line. Reading a thousand lines for the handful that say `WARN` is much easier when they line
 * up.
 */
[[nodiscard]] QString levelTag(Level level);

/// Reads [name] back, case-insensitively. Returns false and leaves [level] alone when unknown.
bool parseLevel(const QString& name, Level* level);

/// One `key=value` pair attached to an [event].
using Field = QPair<QString, QString>;

/**
 * Everything the user can change about the log, in one struct.
 *
 * A struct rather than a series of setters because the Help tab edits all of them at once and
 * has to be able to show what is currently in force without asking a dozen questions, and
 * because the settings are written to disk as one blob so a half-saved set can never be read
 * back.
 */
struct Settings {
    /// The automatic recording switch. Off means nothing is written to disk at all.
    bool recordAutomatically = true;
    /// Lines below this level are dropped before they are formatted.
    Level minimumLevel = Level::Debug;
    /// Whether the time of day carries milliseconds. On by default: the gap between two lines
    /// is often the whole diagnosis.
    bool milliseconds = true;
    /// Whether the time of day is written as `09:14:02.481 am` instead of `09:14:02.481 +02:00`.
    bool twelveHourClock = false;
    /// How many days of log files to keep before pruning them.
    int keepDays = 7;
    /// The ceiling for one day's file. Past it, the file is rolled over rather than allowed to
    /// fill the disk.
    int maxFileSizeMiB = 4;
};

/**
 * Starts recording.
 *
 * Installs a Qt message handler, so the qDebug/qWarning calls in this codebase - and Qt's own
 * internal messages - land in the same file in the same format as the rest of the log, then
 * writes a header naming the build, the machine and the settings this run started with. A log
 * that does not say which build wrote it is worth much less when reading it back.
 *
 * Console output is not swallowed: every line is still handed to whichever handler was in place
 * before, so a developer with the debugger attached sees the same thing in the IDE's output
 * window that the file records.
 *
 * @param directory where the files go, overriding the standard settings folder. Empty means
 *        the normal place; the tests pass a temporary folder so a test run cannot touch a real
 *        log or leave one behind.
 */
void install(const QString& directory = {});

/// Flushes, closes the current file and puts the previous Qt message handler back.
void shutdown();

/// The settings in force right now.
[[nodiscard]] Settings settings();

/**
 * Applies [next], writes it to the settings file and records the change in the log.
 *
 * Persisted rather than kept in memory so that turning recording off is still off tomorrow,
 * which is the entire point of a privacy switch.
 */
void setSettings(const Settings& next);

/// Writes one line at [level] under [category]. `category` is the class or subsystem name.
void write(Level level, const QString& category, const QString& message);

/// Shorthands for the four [Level]s.
void debug(const QString& category, const QString& message);
void info(const QString& category, const QString& message);
void warning(const QString& category, const QString& message);
void error(const QString& category, const QString& message);

/**
 * Records a named moment with its fields, rather than a sentence.
 *
 * `event("broadcast.started", {{"port", "53525"}})` writes
 * `[broadcast.started] port=53525`, which is greppable, countable and comparable between the
 * two apps. Sentences are for the user; the things worth searching for are events.
 */
void event(const QString& name, const QList<Field>& fields = {});

/**
 * The timestamp as it appears at the front of a line.
 *
 * Local time with an explicit UTC offset rather than a bare clock time: a report is read on a
 * different machine, often in a different timezone, and an unqualified `09:14:02` cannot be
 * lined up against anything else that happened that day.
 */
[[nodiscard]] QString formatTimestamp(const QDateTime& when, const Settings& options);

/**
 * One complete line, without the trailing newline.
 *
 * Public because it is the part worth testing: the format is a promise to whoever reads the
 * file later, and a promise that is never asserted is a promise that quietly changes.
 */
[[nodiscard]] QString formatLine(Level level, const QString& category, const QString& message,
    quintptr threadId, const QDateTime& when, const Settings& options);

/// The folder the files are written to.
[[nodiscard]] QString directory();

/// Today's file, named after the date so a folder listing sorts into order.
[[nodiscard]] QString currentFilePath();

/// Every log file that exists, newest first.
[[nodiscard]] QStringList filesNewestFirst();

/**
 * The last [maxBytes] of the log, oldest line first.
 *
 * Reads backwards in chunks rather than loading a whole file to hand back a screenful: a
 * four-megabyte day is the case this exists for.
 *
 * @param newestFileOnly reads today's file and nothing else, for a report about a problem that
 *        is still happening.
 * @param filesUsed, when given, receives the files that went in, oldest first, so a report can
 *        say which ones it is quoting.
 */
[[nodiscard]] QString tail(int maxBytes, bool newestFileOnly = false,
    QStringList* filesUsed = nullptr);

/// A short id for this run, written into the header, so two reports can be told apart.
[[nodiscard]] QString sessionId();

/// How much is in today's file right now, in bytes. Zero when nothing has been recorded yet.
[[nodiscard]] qint64 currentFileSize();

} // namespace localstream::logging