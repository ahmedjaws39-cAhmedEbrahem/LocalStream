#include "logging/Log.h"

#include <QCoreApplication>
#include <QDateTime>
#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QMutex>
#include <QRegularExpression>
#include <QSettings>
#include <QStandardPaths>
#include <QSysInfo>
#include <QThread>
#include <QUuid>
#include <QtGlobal>

#include <algorithm>

namespace localstream::logging {

namespace {

// Settings keys. Grouped under "logging/" the way the theme's key sits under "ui/".
constexpr auto kRecordKey = "logging/recordAutomatically";
constexpr auto kLevelKey = "logging/minimumLevel";
constexpr auto kMillisecondsKey = "logging/milliseconds";
constexpr auto kTwelveHourKey = "logging/twelveHourClock";
constexpr auto kKeepDaysKey = "logging/keepDays";
constexpr auto kMaxSizeKey = "logging/maxFileSizeMiB";

/// The name every file starts with. The date follows it, so a folder listing reads in order.
constexpr char kFilePrefix[] = "LocalStream-";

/// How many rolled-over files to keep beside today's. Five is a week of a very noisy run.
constexpr int kKeptRollovers = 5;

/// Between the first three failures to open the file, give up and stay on the console.
///
/// Opening a file per line is the kind of thing that turns a broken path into a frozen window:
/// the log call is supposed to be free, and a user whose settings folder has gone read-only
/// should get a console line, not a hang.
constexpr int kOpenAttemptsBeforeGivingUp = 3;

constexpr int kMinKeepDays = 1;
constexpr int kMaxKeepDays = 365;
constexpr int kMinSizeMiB = 1;
constexpr int kMaxSizeMiB = 256;

/**
 * Everything the logger owns, behind one lock.
 *
 * A single struct rather than a set of file-scope variables so it can be handed to a function
 * by reference, which is how the message handler - a free function with a fixed signature -
/// gets at it without a global that has to be declared before it.
 */
struct State {
    QRecursiveMutex mutex;
    Settings options;
    QString folder;
    QString session;
    QFile file;
    QDate openDate;
    qint64 written = 0;
    int failedOpens = 0;
    bool installed = false;
    QtMessageHandler previous = nullptr;
};

State& state()
{
    static State instance;
    return instance;
}

/// `+02:00`, `-05:30`, or `Z`-free `+00:00`. Written out rather than using `Qt::TimeZone`
/// formatting so the offset is always two digits either side of the colon.
QString formatOffset(const QDateTime& when)
{
    const int seconds = when.offsetFromUtc();
    const int sign = seconds < 0 ? -1 : 1;
    const int total = std::abs(seconds);
    return QStringLiteral("%1%2:%3")
        .arg(sign < 0 ? QStringLiteral("-") : QStringLiteral("+"))
        .arg(total / 3600, 2, 10, QLatin1Char('0'))
        .arg((total % 3600) / 60, 2, 10, QLatin1Char('0'));
}

/// The date-stamped file name for [day], without a directory.
QString fileNameFor(const QDate& day)
{
    return QString::fromLatin1(kFilePrefix) + day.toString(QStringLiteral("yyyy-MM-dd"))
        + QStringLiteral(".log");
}

/// Turns Qt's message types into our levels. Qt has no level below warning in this build, so
/// `QtDebugMsg` carries both the debug and the info traffic.
Level levelFor(QtMsgType type)
{
    switch (type) {
    case QtDebugMsg:
        return Level::Debug;
    case QtInfoMsg:
        return Level::Info;
    case QtWarningMsg:
        return Level::Warning;
    case QtCriticalMsg:
    case QtFatalMsg:
        return Level::Error;
    }
    return Level::Info;
}

/// Closes today's file so the next write reopens it. The caller holds the lock.
void closeFile()
{
    if (state().file.isOpen()) {
        state().file.flush();
        state().file.close();
    }
    state().written = 0;
}

/// Moves today's file aside and clears the counter, so the line that hit the ceiling starts a
/// new file rather than pushing the old one past it. The caller holds the lock.
void rollOver(const QString& path)
{
    closeFile();
    if (!QFile::exists(path)) {
        return;
    }

    QFile::remove(QStringLiteral("%1.%2").arg(path).arg(kKeptRollovers));
    for (int index = kKeptRollovers - 1; index >= 1; --index) {
        const QString from = QStringLiteral("%1.%2").arg(path).arg(index);
        if (QFile::exists(from)) {
            QFile::remove(QStringLiteral("%1.%2").arg(path).arg(index + 1));
            QFile::rename(from, QStringLiteral("%1.%2").arg(path).arg(index + 1));
        }
    }
    QFile::rename(path, QStringLiteral("%1.1").arg(path));
}

/**
 * The Qt message handler.
 *
 * Qt routes every qDebug/qWarning in the tree - and its own internal messages - through here,
 * which is what makes the file complete without editing every existing call site. Console
 * output is handed on to the handler that was already installed rather than reproduced, so
 * installing the file sink cannot change what a developer sees in the debugger.
 */
void qtMessageHandler(QtMsgType type, const QMessageLogContext& context, const QString& message)
{
    const QString category = context.category != nullptr ? QString::fromLatin1(context.category)
                                                         : QStringLiteral("qt");
    write(levelFor(type), category, message);
}

/// Opens today's file if it is not already open. Returns false once it has given up.
bool ensureOpen()
{
    State& s = state();
    if (s.failedOpens >= kOpenAttemptsBeforeGivingUp) {
        return false;
    }

    const QDate today = QDate::currentDate();
    if (s.file.isOpen() && s.openDate == today) {
        return true;
    }

    closeFile();

    if (!QDir().mkpath(s.folder)) {
        ++s.failedOpens;
        return false;
    }

    const QString path = QDir(s.folder).filePath(fileNameFor(today));
    s.file.setFileName(path);
    if (!s.file.open(QIODevice::WriteOnly | QIODevice::Append)) {
        ++s.failedOpens;
        return false;
    }

    s.openDate = today;
    // Seeded from the file rather than zero: a second run on the same day appends to what the
    // first one wrote, and the ceiling has to count the whole file, not just this session's part.
    s.written = QFileInfo(path).size();
    return true;
}

/// Reads the persisted settings, filling in anything a hand-edited file has mangled.
Settings loadSettings()
{
    const QSettings stored;
    Settings options;
    options.recordAutomatically = stored.value(kRecordKey, options.recordAutomatically).toBool();

    Level level = options.minimumLevel;
    if (parseLevel(stored.value(kLevelKey, levelName(options.minimumLevel)).toString(), &level)) {
        options.minimumLevel = level;
    }

    options.milliseconds = stored.value(kMillisecondsKey, options.milliseconds).toBool();
    options.twelveHourClock = stored.value(kTwelveHourKey, options.twelveHourClock).toBool();
    options.keepDays = std::clamp(
        stored.value(kKeepDaysKey, options.keepDays).toInt(), kMinKeepDays, kMaxKeepDays);
    options.maxFileSizeMiB = std::clamp(
        stored.value(kMaxSizeKey, options.maxFileSizeMiB).toInt(), kMinSizeMiB, kMaxSizeMiB);
    return options;
}

/**
 * The day a log file belongs to, taken from its name rather than its timestamp.
 *
 * The name is the authority because a copied or restored file carries a modification time from
 * wherever it came from: pruning on that would delete the only copy of the day a user is trying
 * to report, and keep a months-old file that happened to be touched this morning.
 *
 * An empty date means the name is not one of ours, and the caller leaves such a file alone.
 */
QDate dateFromFileName(const QString& name)
{
    static const QRegularExpression pattern(
        QStringLiteral("^LocalStream-(\\d{4}-\\d{2}-\\d{2})\\.log"));
    const QRegularExpressionMatch match = pattern.match(name);
    if (!match.hasMatch()) {
        return {};
    }
    return QDate::fromString(match.captured(1), Qt::ISODate);
}

/// Deletes the days that have aged out. The caller holds the lock.
void pruneOldFiles()
{
    State& s = state();
    const QDate cutoff = QDate::currentDate().addDays(-s.options.keepDays);
    const QDir folder(s.folder);
    const QStringList entries =
        folder.entryList({QStringLiteral("%1*.log*").arg(QString::fromLatin1(kFilePrefix))},
            QDir::Files, QDir::Name);

    for (const QString& name : entries) {
        const QDate day = dateFromFileName(name);
        if (day.isValid() && day < cutoff) {
            QFile::remove(folder.filePath(name));
        }
    }
}

/// The block written at the top of a fresh file, naming the build and the machine.
QString sessionHeader(const Settings& options)
{
    const QDateTime started = QDateTime::currentDateTime();
    const QString rule(80, QLatin1Char('='));
    const QString application =
        QCoreApplication::applicationName().isEmpty() ? QStringLiteral("LocalStream")
                                                      : QCoreApplication::applicationName();
    const QString version = QCoreApplication::applicationVersion();

    QStringList lines;
    lines << rule;
    lines << QStringLiteral("%1 log").arg(application);
    lines << QStringLiteral("version    : %1").arg(
        version.isEmpty() ? QStringLiteral("unknown") : version);
    lines << QStringLiteral("started    : %1").arg(formatTimestamp(started, options));
    lines << QStringLiteral("session    : %1").arg(state().session);
    lines << QStringLiteral("computer   : %1").arg(QSysInfo::prettyProductName());
    lines << QStringLiteral("system     : %1 (%2)").arg(QSysInfo::productVersion())
                 .arg(QSysInfo::currentCpuArchitecture());
    lines << QStringLiteral("host       : %1").arg(QSysInfo::machineHostName());
    lines << QStringLiteral("settings   : recording %1, level %2, keep %3 day(s), %4 MiB per file")
                 .arg(options.recordAutomatically ? QStringLiteral("on") : QStringLiteral("off"))
                 .arg(levelName(options.minimumLevel))
                 .arg(options.keepDays)
                 .arg(options.maxFileSizeMiB);
    lines << rule;
    return lines.join(QLatin1Char('\n')) + QLatin1Char('\n');
}

} // namespace

QString levelName(Level level)
{
    switch (level) {
    case Level::Debug:
        return QStringLiteral("Debug");
    case Level::Info:
        return QStringLiteral("Info");
    case Level::Warning:
        return QStringLiteral("Warning");
    case Level::Error:
        return QStringLiteral("Error");
    }
    return QStringLiteral("Info");
}

QString levelTag(Level level)
{
    switch (level) {
    case Level::Debug:
        return QStringLiteral("DEBUG");
    case Level::Info:
        return QStringLiteral("INFO ");
    case Level::Warning:
        return QStringLiteral("WARN ");
    case Level::Error:
        return QStringLiteral("ERROR");
    }
    return QStringLiteral("INFO ");
}

bool parseLevel(const QString& name, Level* level)
{
    const QString wanted = name.trimmed().toLower();
    if (wanted == QLatin1String("debug")) {
        *level = Level::Debug;
        return true;
    }
    if (wanted == QLatin1String("info")) {
        *level = Level::Info;
        return true;
    }
    if (wanted == QLatin1String("warning") || wanted == QLatin1String("warn")) {
        *level = Level::Warning;
        return true;
    }
    if (wanted == QLatin1String("error")) {
        *level = Level::Error;
        return true;
    }
    return false;
}

QString formatTimestamp(const QDateTime& when, const Settings& options)
{
    QString clock = options.twelveHourClock ? QStringLiteral("hh:mm:ss") : QStringLiteral("HH:mm:ss");
    if (options.milliseconds) {
        clock += QStringLiteral(".zzz");
    }

    QString text = QStringLiteral("%1 %2").arg(when.toString(QStringLiteral("yyyy-MM-dd")),
                                        when.toString(clock));
    if (options.twelveHourClock) {
        // Forced upper case: Qt follows the locale here, and a log file that says "am" on one
        // machine and "AM" on another is needlessly harder to grep.
        text += QLatin1Char(' ') + when.toString(QStringLiteral("ap")).toUpper();
    }
    return text + QLatin1Char(' ') + formatOffset(when);
}

QString formatLine(Level level, const QString& category, const QString& message, quintptr threadId,
    const QDateTime& when, const Settings& options)
{
    return QStringLiteral("%1 [%2] [%3] [T%4] %5")
        .arg(formatTimestamp(when, options), levelTag(level),
            category.isEmpty() ? QStringLiteral("app") : category)
        .arg(QString::number(threadId))
        .arg(message);
}

void install(const QString& directory)
{
    State& s = state();
    QMutexLocker locker(&s.mutex);

    if (s.installed) {
        return;
    }
    s.installed = true;
    s.options = loadSettings();
    s.session = QUuid::createUuid().toString(QUuid::Id128).left(8);
    s.folder = directory.isEmpty()
        ? QDir(QStandardPaths::writableLocation(QStandardPaths::AppDataLocation))
              .filePath(QStringLiteral("logs"))
        : QDir(directory).absolutePath();

    s.previous = qInstallMessageHandler(&qtMessageHandler);

    if (!s.options.recordAutomatically) {
        return;
    }
    if (ensureOpen()) {
        pruneOldFiles();
        s.file.write(sessionHeader(s.options).toUtf8());
        s.written = s.file.size();
    }
}

void shutdown()
{
    State& s = state();
    QMutexLocker locker(&s.mutex);
    if (!s.installed) {
        return;
    }
    closeFile();
    if (s.previous != nullptr) {
        qInstallMessageHandler(s.previous);
        s.previous = nullptr;
    }
    s.installed = false;
}

Settings settings()
{
    State& s = state();
    QMutexLocker locker(&s.mutex);
    return s.options;
}

void setSettings(const Settings& next)
{
    State& s = state();
    QMutexLocker locker(&s.mutex);

    Settings applied = next;
    applied.keepDays = std::clamp(applied.keepDays, kMinKeepDays, kMaxKeepDays);
    applied.maxFileSizeMiB = std::clamp(applied.maxFileSizeMiB, kMinSizeMiB, kMaxSizeMiB);

    const bool wasRecording = s.options.recordAutomatically;
    const bool nowRecording = applied.recordAutomatically;
    s.options = applied;

    QSettings stored;
    stored.setValue(kRecordKey, applied.recordAutomatically);
    stored.setValue(kLevelKey, levelName(applied.minimumLevel));
    stored.setValue(kMillisecondsKey, applied.milliseconds);
    stored.setValue(kTwelveHourKey, applied.twelveHourClock);
    stored.setValue(kKeepDaysKey, applied.keepDays);
    stored.setValue(kMaxSizeKey, applied.maxFileSizeMiB);
    stored.sync();

    if (!s.installed) {
        return;
    }

    if (!nowRecording) {
        // Closing rather than only filtering: with recording off there should be nothing to
        // come back to, and an open handle is an open handle.
        closeFile();
        return;
    }

    if (wasRecording) {
        pruneOldFiles();
        return;
    }

    s.failedOpens = 0;
    if (!ensureOpen()) {
        return;
    }

    if (s.written == 0) {
        s.file.write(sessionHeader(s.options).toUtf8());
    } else {
        // Not a header: nothing restarted. The app was still the same process with the same
        // session, so writing a second "log started" block here would put a second false start
        // time in the middle of one run, and a report quoting this file would carry it.
        s.file.write(formatLine(Level::Info, QStringLiteral("logging"),
                          QStringLiteral("[logging.resumed] recording turned back on"),
                          quintptr(QThread::currentThreadId()), QDateTime::currentDateTime(),
                          s.options)
                        .toUtf8());
    }
    s.written = s.file.size();
}

void write(Level level, const QString& category, const QString& message)
{
    State& s = state();
    QMutexLocker locker(&s.mutex);

    // Console first and unconditionally: turning the file off must not silence the developer
    // who is using the same build to debug something else.
    if (s.previous != nullptr) {
        s.previous(level == Level::Debug     ? QtDebugMsg
                   : level == Level::Info    ? QtInfoMsg
                   : level == Level::Warning ? QtWarningMsg
                                             : QtCriticalMsg,
            QMessageLogContext(),
            QStringLiteral("[%1] %2").arg(category, message));
    }

    if (!s.installed || !s.options.recordAutomatically || level < s.options.minimumLevel) {
        return;
    }
    if (!ensureOpen()) {
        return;
    }

    QString line = formatLine(level, category, message, quintptr(QThread::currentThreadId()),
                      QDateTime::currentDateTime(), s.options);

    const qint64 ceiling = qint64(s.options.maxFileSizeMiB) * 1024 * 1024;
    if (s.written + line.toUtf8().size() + 1 > ceiling) {
        const QString path = s.file.fileName();
        rollOver(path);
        // Reopening after the roll: the handle rollOver closed belonged to the old file.
        if (!ensureOpen()) {
            return;
        }
        line += QStringLiteral("\n(log rolled over at %1 MiB)")
                    .arg(s.options.maxFileSizeMiB);
    }

    line += QLatin1Char('\n');
    const QByteArray encoded = line.toUtf8();
    if (s.file.write(encoded) < 0) {
        return;
    }
    s.written += encoded.size();
}

void debug(const QString& category, const QString& message)
{
    write(Level::Debug, category, message);
}

void info(const QString& category, const QString& message)
{
    write(Level::Info, category, message);
}

void warning(const QString& category, const QString& message)
{
    write(Level::Warning, category, message);
}

void error(const QString& category, const QString& message)
{
    write(Level::Error, category, message);
}

void event(const QString& name, const QList<Field>& fields)
{
    QStringList parts;
    parts.reserve(fields.size());
    for (const Field& field : fields) {
        // A space inside a value would make the line ambiguous to read and to split, so it is
        // quoted the way a shell would: report text is often a sentence.
        QString value = field.second;
        value.replace(QLatin1Char('"'), QLatin1String("\\\""));
        const bool needsQuotes = value.contains(QLatin1Char(' ')) || value.isEmpty();
        parts.append(QStringLiteral("%1=%2").arg(field.first,
            needsQuotes ? QStringLiteral("\"%1\"").arg(value) : value));
    }

    QString message = name;
    if (!parts.isEmpty()) {
        message += QLatin1Char(' ') + parts.join(QLatin1Char(' '));
    }
    write(Level::Info, name, message);
}

QString directory()
{
    State& s = state();
    QMutexLocker locker(&s.mutex);
    if (!s.folder.isEmpty()) {
        return s.folder;
    }
    // Read before install() as well: the Help tab asks for the folder while building itself,
    // which happens after install(), but a test may not install at all.
    return QDir(QStandardPaths::writableLocation(QStandardPaths::AppDataLocation))
        .filePath(QStringLiteral("logs"));
}

QString currentFilePath()
{
    State& s = state();
    QMutexLocker locker(&s.mutex);
    if (!s.folder.isEmpty() && s.file.isOpen()) {
        return s.file.fileName();
    }
    const QString folder = s.folder.isEmpty()
        ? QDir(QStandardPaths::writableLocation(QStandardPaths::AppDataLocation))
              .filePath(QStringLiteral("logs"))
        : s.folder;
    return QDir(folder).filePath(fileNameFor(QDate::currentDate()));
}

QStringList filesNewestFirst()
{
    const QString folder = directory();
    const QDir dir(folder);
    const QStringList names =
        dir.entryList({QStringLiteral("%1*.log*").arg(QString::fromLatin1(kFilePrefix))},
            QDir::Files, QDir::Time);

    QStringList paths;
    paths.reserve(names.size());
    for (const QString& name : names) {
        paths.append(dir.filePath(name));
    }
    return paths;
}

QString tail(int maxBytes, bool newestFileOnly, QStringList* filesUsed)
{
    if (maxBytes <= 0) {
        return {};
    }

    // Oldest file first, so the result reads in the order things happened.
    QStringList ordered = filesNewestFirst();
    std::reverse(ordered.begin(), ordered.end());
    if (newestFileOnly && ordered.size() > 1) {
        ordered = QStringList{ordered.last()};
    }

    QString out;
    int budget = maxBytes;
    for (const QString& path : ordered) {
        if (budget <= 0) {
            break;
        }
        QFile file(path);
        if (!file.open(QIODevice::ReadOnly)) {
            continue;
        }
        const qint64 size = file.size();
        const qint64 take = std::min(qint64(budget), size);
        if (!file.seek(size - take)) {
            continue;
        }
        const QByteArray chunk = file.read(take);
        if (chunk.isEmpty()) {
            continue;
        }
        out += QString::fromUtf8(chunk);
        budget -= int(take);
        if (filesUsed != nullptr) {
            filesUsed->append(path);
        }
    }
    return out;
}

QString sessionId()
{
    State& s = state();
    QMutexLocker locker(&s.mutex);
    return s.session;
}

qint64 currentFileSize()
{
    State& s = state();
    QMutexLocker locker(&s.mutex);
    if (s.file.isOpen()) {
        s.file.flush();
        return s.file.size();
    }
    const QString folder = s.folder.isEmpty()
        ? QDir(QStandardPaths::writableLocation(QStandardPaths::AppDataLocation))
              .filePath(QStringLiteral("logs"))
        : s.folder;
    return QFileInfo(QDir(folder).filePath(fileNameFor(QDate::currentDate()))).size();
}

} // namespace localstream::logging