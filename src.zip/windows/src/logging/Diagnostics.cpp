#include "logging/Diagnostics.h"

#include "logging/Log.h"

#include <QCoreApplication>
#include <QDateTime>
#include <QDir>
#include <QFileInfo>
#include <QSaveFile>
#include <QStandardPaths>
#include <QStorageInfo>
#include <QSysInfo>

#include <algorithm>

namespace localstream::logging {

namespace {

/// The subfolder of Documents that reports are written to.
constexpr char kReportFolder[] = "LocalStream Reports";

/// The name a report gets, to the second so two in one afternoon do not collide.
QString reportFileName(const QDateTime& when)
{
    return QStringLiteral("LocalStream-report-%1.txt")
        .arg(when.toString(QStringLiteral("yyyy-MM-dd-HHmmss")));
}

/// The rule that separates the sections of a report.
QString rule()
{
    return QString(78, QLatin1Char('-'));
}

QString orUnknown(const QString& value)
{
    return value.isEmpty() ? QStringLiteral("unknown") : value;
}

} // namespace

QString defaultReportDirectory()
{
    const QString documents = QStandardPaths::writableLocation(QStandardPaths::DocumentsLocation);
    if (!documents.isEmpty()) {
        return QDir(documents).filePath(QString::fromLatin1(kReportFolder));
    }
    // A machine with no Documents folder - a locked-down account, or a redirected profile that
    // has not been created yet - still needs somewhere that works.
    return QDir(QStandardPaths::writableLocation(QStandardPaths::AppDataLocation))
        .filePath(QStringLiteral("reports"));
}

QString systemSummary()
{
    const QString application = QCoreApplication::applicationName().isEmpty()
        ? QStringLiteral("LocalStream")
        : QCoreApplication::applicationName();
    const QString version = QCoreApplication::applicationVersion();

    QStringList lines;
    lines << QStringLiteral("application  : %1 %2").arg(application, orUnknown(version));
    lines << QStringLiteral("build time  : %1")
                 .arg(QFileInfo(QCoreApplication::applicationFilePath())
                          .lastModified()
                          .toString(Qt::ISODate));
    lines << QStringLiteral("windows     : %1").arg(QSysInfo::prettyProductName());
    lines << QStringLiteral("kernel      : %1 %2 (build %3)")
                 .arg(QSysInfo::productType(), QSysInfo::kernelVersion(), QSysInfo::productVersion());
    lines << QStringLiteral("architecture: %1 (built %2)")
                 .arg(QSysInfo::currentCpuArchitecture(), QSysInfo::buildCpuArchitecture());
    const QStorageInfo system(QStorageInfo::root());
    lines << QStringLiteral("free space  : %1 GiB on %2")
                 .arg(system.bytesAvailable() / (1024LL * 1024 * 1024))
                 .arg(orUnknown(system.displayName()));
    lines << QStringLiteral("host name   : %1").arg(orUnknown(QSysInfo::machineHostName()));
    lines << QStringLiteral("qt          : %1 (built against %2)")
                 .arg(QString::fromLatin1(qVersion()), QString::fromLatin1(QT_VERSION_STR));
    lines << QStringLiteral("log folder  : %1").arg(directory());
    return lines.join(QLatin1Char('\n'));
}

ReportResult writeReport(const ReportOptions& options, const QString& directory)
{
    ReportResult result;

    const QString folder =
        directory.isEmpty() ? defaultReportDirectory() : QDir(directory).absolutePath();
    if (!QDir().mkpath(folder)) {
        result.error = QStringLiteral("The reports folder could not be created: %1").arg(folder);
        error(QStringLiteral("report"), result.error);
        return result;
    }

    const QDateTime now = QDateTime::currentDateTime();
    const Settings current = settings();

    // Recorded before the tail is read, so the report contains the line saying it was made.
    // The file it names is the one being written, which is the only way a reader can tell a
    // report from the log it quotes.
    const QString path = QDir(folder).filePath(reportFileName(now));
    event(QStringLiteral("report.started"),
        {{QStringLiteral("path"), path}, {QStringLiteral("logLines"), QString::number(options.logTailKib)}});

    QStringList used;
    QString body;
    if (options.includeLogLines) {
        body = tail(std::max(options.logTailKib, 0) * 1024, !options.includeEarlierDays, &used);
    }
    result.includedFiles = used;

    QStringList lines;
    lines << QStringLiteral("LocalStream report");
    lines << QStringLiteral("written at  : %1").arg(formatTimestamp(now, current));
    lines << QStringLiteral("session     : %1").arg(orUnknown(sessionId()));
    lines << QStringLiteral("report file : %1").arg(path);
    lines << rule();

    if (options.includeSystemInfo) {
        lines << QStringLiteral("SYSTEM");
        lines << systemSummary();
        lines << rule();
    }

    if (options.includeSettings) {
        lines << QStringLiteral("LOGGING SETTINGS");
        lines << QStringLiteral("recording   : %1")
                     .arg(current.recordAutomatically ? QStringLiteral("on")
                                                      : QStringLiteral("off"));
        lines << QStringLiteral("level       : %1 and above").arg(levelName(current.minimumLevel));
        lines << QStringLiteral("clock       : %1")
                     .arg(current.twelveHourClock
                              ? QStringLiteral("12-hour with AM/PM")
                              : QStringLiteral("24-hour with UTC offset"));
        lines << QStringLiteral("precision   : %1")
                     .arg(current.milliseconds ? QStringLiteral("milliseconds")
                                               : QStringLiteral("seconds"));
        lines << QStringLiteral("keep        : %1 day(s), up to %2 MiB per file")
                     .arg(current.keepDays)
                     .arg(current.maxFileSizeMiB);
        lines << rule();
    }

    lines << QStringLiteral("LOG LINES");
    if (options.includeLogLines) {
        if (used.isEmpty()) {
            lines << QStringLiteral("(no log lines: recording is off, or nothing has been "
                                    "recorded yet)");
        } else {
            for (const QString& file : used) {
                lines << QStringLiteral("--- %1").arg(QFileInfo(file).fileName());
            }
            lines << body;
        }
    } else {
        lines << QStringLiteral("(not included in this report)");
    }
    lines << rule();
    lines << QStringLiteral("End of report.");

    // QSaveFile rather than QFile: this file is meant to be attached to a message, and a
    // half-written one that survived a crash would be worse than none at all.
    QSaveFile file(path);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Truncate)) {
        result.error = QStringLiteral("The report could not be written to %1 (%2).")
                           .arg(path, file.errorString());
        error(QStringLiteral("report"), result.error);
        return result;
    }

    const QByteArray encoded = lines.join(QLatin1Char('\n')).toUtf8();
    if (file.write(encoded) < 0 || !file.commit()) {
        result.error = QStringLiteral("The report could not be finished: %1").arg(file.errorString());
        error(QStringLiteral("report"), result.error);
        return result;
    }

    result.ok = true;
    result.path = path;
    result.bytes = encoded.size();
    event(QStringLiteral("report.saved"),
        {{QStringLiteral("path"), path},
            {QStringLiteral("bytes"), QString::number(result.bytes)},
            {QStringLiteral("files"), QString::number(used.size())}});
    return result;
}

} // namespace localstream::logging