#pragma once

#include <QString>
#include <QStringList>

namespace localstream::logging {

/**
 * What goes into a report, beyond the log lines themselves.
 *
 * Every part is optional because the two audiences are different: someone reading a report to
 * work out what went wrong wants the log and little else, while someone forwarding a problem
 * onwards needs the machine described as well, since "it does not work" on an old Windows build
 * with a firewall is a different conversation from the same words on a fresh laptop.
 */
struct ReportOptions {
    /// The build, the machine and the settings this run started with.
    bool includeSystemInfo = true;
    /// The tail of the log, which is where the answer usually is.
    bool includeLogLines = true;
    /// How much of the log to include, in kibibytes. Enough for the last few minutes of a
    /// normal run without producing a file too big to attach to a message.
    int logTailKib = 256;
    /// Whether to include the days before today as well, for a problem that started yesterday
    /// and was only noticed this morning.
    bool includeEarlierDays = false;
    /// The logging settings and the window layout, which decide what the log even contains.
    bool includeSettings = true;
};

/// What [writeReport] managed to do, and where it put it.
struct ReportResult {
    bool ok = false;
    QString path;
    QString error;
    /// The log files that went in, oldest first. Empty when the report has no log lines.
    QStringList includedFiles;
    qint64 bytes = 0;
};

/**
 * Writes a report to a fresh file in [directory] and returns what happened.
 *
 * A new file every time rather than one file that is overwritten: the moment a problem is
 * noticed is usually after it stopped happening, and the run that caused it should still be
 * there. The name carries the date and time to the second, so two reports in one afternoon do
 * not collide.
 *
 * Recording the attempt is part of the job: a report that silently failed to save is worse than
 * no report, because the user walks away believing they have sent something.
 */
ReportResult writeReport(const ReportOptions& options, const QString& directory = {});

/**
 * Where reports go: a folder of their own in Documents, which is the one place a user is
 * certain they can find again without the app telling them.
 */
[[nodiscard]] QString defaultReportDirectory();

/**
 * The machine, as a short block of lines.
 *
 * Reported from the app rather than asked for, because "what does your machine look like" is
 * the first question after "what happened" and answering it should not need a second round trip.
 */
[[nodiscard]] QString systemSummary();

} // namespace localstream::logging