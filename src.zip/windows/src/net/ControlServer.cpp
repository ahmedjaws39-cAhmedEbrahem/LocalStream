#include "net/ControlServer.h"

#include "logging/Log.h"

#include <QAbstractSocket>
#include <QHash>
#include <QMetaObject>

namespace localstream::net {

namespace {

/// A receiver is not a client of this app's own socket implementation, so cap what we will
/// buffer for one connection. Past this the peer is either broken or hostile.
constexpr int MaxQueuedBytesPerSession = 64 * 1024;

constexpr int MaxLineBytes = 64 * 1024;

} // namespace

// -------------------------------------------------------------------------- Core

/**
 * The object that owns every socket, and the only thing that runs on the control thread.
 *
 * Splitting it out of [ControlServer] is what makes the blocking calls safe:
 * `QMetaObject::invokeMethod` delivers to the affinity of the object it is given, so a
 * blocking call aimed at the facade would queue onto the very thread that is blocked waiting
 * for it.
 */
class ControlServer::Core : public QObject
{
    Q_OBJECT

public:
    /**
     * One receiver's connection.
     *
     * Outbound messages are appended to a buffer and written only as fast as the socket
     * accepts them, so two messages can never interleave mid-line. `close` lets the buffer
     * drain first; `abort` drops it. That distinction is the whole reason this is not just a
     * call to `QTcpSocket::close`: a `deny` or `bye` queued at teardown would otherwise be
     * discarded and the receiver would see a bare disconnect with no explanation.
     */
    class Session : public QObject
    {
    public:
        // A QObject purely so that `deleteLater` exists. A session is freed from inside a
        // slot that is still holding its pointer, so the destruction has to be deferred to
        // the event loop; a raw `delete` there would pull the ground out from under the
        // ready-read loop.
        explicit Session(QTcpSocket* socket) : socket_(socket) {}

        void send(const protocol::ControlMessage& message);
        void close(); // graceful
        void abort(); // immediate

        /// Appends freshly read bytes and hands back one whole line at a time.
        /// @return false when no complete line is buffered yet.
        bool takeLine(QByteArray& line);
        [[nodiscard]] bool readOverflowed() const { return readOverflowed_; }

        /// True once nothing is buffered and nothing is in flight.
        [[nodiscard]] bool isDrained() const;
        [[nodiscard]] bool finished() const { return finished_; }

        [[nodiscard]] QString name() const { return name_; }
        void setName(const QString& name) { name_ = name; }
        /// True once the greeting has gone out, i.e. the handshake has begun.
        ///
        /// Push messages are withheld until this is set: a socket that has only been
        /// accepted has not yet been told what the session is, and injecting a
        /// broadcaster-wide message into the middle of its handshake makes a strict
        /// client read the wrong line as its greeting.
        [[nodiscard]] bool greeted() const { return greeted_; }
        void setGreeted() { greeted_ = true; }
        [[nodiscard]] int offeredAudioPort() const { return offeredAudio_; }
        [[nodiscard]] int offeredVideoPort() const { return offeredVideo_; }
        void setOfferedPorts(int audio, int video)
        {
            offeredAudio_ = audio;
            offeredVideo_ = video;
        }

        /// True once this connection proved it knows the password. Only consulted in password
        /// mode, and set per connection rather than per peer so a second connection from an
        /// admitted device still has to authenticate.
        [[nodiscard]] bool authenticated() const { return authenticated_; }
        void setAuthenticated() { authenticated_ = true; }

        /// Key of the approval request this session is waiting on, or 0 when it is not waiting.
        /// Lets [ControlServer::resolveAccessRequest] find the session again after the UI has
        /// taken an arbitrary amount of time to answer.
        [[nodiscard]] quint64 accessRequestKey() const { return accessRequestKey_; }
        void setAccessRequestKey(quint64 key) { accessRequestKey_ = key; }

        [[nodiscard]] QTcpSocket* socket() const { return socket_; }
        [[nodiscard]] bool isClosing() const { return closing_; }

    private:
        // C++ gives an enclosing class no access to a nested class's privates, and the core
        // is the only thing that starts and finishes sessions.
        friend class Core;

        bool flush();
        void finish();

        QTcpSocket* socket_;
        QByteArray readBuffer_;
        QByteArray pending_;
        QString name_;
        int offeredAudio_ = 0;
        int offeredVideo_ = 0;
        bool readOverflowed_ = false;
        bool closing_ = false;
        bool finished_ = false;
        bool greeted_ = false;
        bool authenticated_ = false;
        quint64 accessRequestKey_ = 0;
    };

    Core(Callbacks callbacks, int maxReceivers, std::atomic<int>* receiverCountOut,
            QString accessMode, QString accessPassword)
        : callbacks_(std::move(callbacks))
        , maxReceivers_(maxReceivers)
        , receiverCountOut_(receiverCountOut)
        // Taken at construction rather than applied by a queued call after it. A setting sent
        // before the core exists has nowhere to go, and the one that matters most is the one
        // applied before listen(): a broadcast started with a password must be locked from its
        // very first `welcome`, not from whenever the event loop next runs.
        , accessMode_(std::move(accessMode))
        , accessPassword_(std::move(accessPassword))
    {
    }

    /// Binds the listening socket. Must run on the core's thread.
    bool listen(QString* error)
    {
        server_ = new QTcpServer(this);
        if (!server_->listen(QHostAddress::AnyIPv4, 0)) {
            if (error) {
                *error = QStringLiteral("Could not open the control port: %1")
                             .arg(server_->errorString());
            }
            delete server_;
            server_ = nullptr;
            return false;
        }
        port_ = server_->serverPort();
        connect(server_, &QTcpServer::newConnection, this, &Core::onNewConnection);
        return true;
    }

    /// Hard teardown. Must run on the core's thread.
    void shutdown()
    {
        if (server_) {
            server_->close();
        }
        const QList<Session*> snapshot = sessions_;
        sessions_.clear();
        publishCount();
        for (Session* session : snapshot) {
            // Nothing queued is worth delivering once the broadcast is going away, so the
            // sockets are dropped rather than drained.
            session->finish();
            // Immediate deletion is safe here and only here: shutdown runs to completion
            // before any other core slot can re-enter, and the loop is about to stop anyway.
            delete session;
        }
        if (server_) {
            delete server_;
            server_ = nullptr;
        }
        port_ = 0;
    }

    /// Delivers a message to every receiver that has completed the handshake.
    ///
    /// `greeted()` is the gate on purpose. A socket sits in `sessions_` from the moment
    /// the TCP connection is accepted, which is before its `hello` has been read. A
    /// broadcaster-wide message sent in that window lands in the middle of a handshake,
    /// and a client that is waiting for its greeting will read the stats line instead and
    /// give up. Only the handshake's own replies (welcome, accept, deny, bye) may go out
    /// before the greeting; everything else waits.
    void broadcast(const protocol::ControlMessage& message)
    {
        for (Session* session : sessions_) {
            if (session->greeted()) {
                session->send(message);
            }
        }
    }

    /// Live sessions, for the core's own use only; the list never leaves this thread.
    [[nodiscard]] QList<Session*> sessions() const { return sessions_; }

    [[nodiscard]] int port() const { return port_; }

    /// Must run on the core's thread.
    void setAccessMode(const QString& mode) { accessMode_ = mode; }
    void setAccessPassword(const QString& password) { accessPassword_ = password; }

    void clearAccessHistory()
    {
        rejections_.clear();
        nextRequestKey_ = 1;
    }

    /**
     * Answers a held request. Must run on the core's thread.
     *
     * The session is looked up by key rather than captured, because the UI may answer after the
     * peer has gone: a key that matches nothing is dropped rather than treated as an error.
     */
    void resolveAccessRequest(quint64 requestKey, bool allow)
    {
        if (requestKey == 0) {
            return;
        }
        Session* session = sessionForRequestKey(requestKey);
        if (!session || session->finished()) {
            return;
        }
        // Cleared before the decision so a second click on the dialog cannot answer twice.
        session->setAccessRequestKey(0);

        if (allow) {
            // The mode can change while the dialog is up - that is what allowing a live change
            // is for - so an approval given under an older mode is not consent to walk past a
            // password set since. Approval under a still-open or now-public broadcast is fine;
            // anything else has a step the viewer has not taken.
            const QString current = accessMode_;
            if (current != QLatin1String(protocol::access::Approval)
                && current != QLatin1String(protocol::access::Public)) {
                session->send(protocol::Deny {QString::fromLatin1(protocol::deny::Auth),
                    QStringLiteral("This broadcast needs a password now. "
                                    "Reconnect to enter it.")});
                closeGracefully(session);
                return;
            }
            admit(session);
            return;
        }
        rejectAccess(session);
    }

    /// Only sessions that completed the handshake count as receivers.
    ///
    /// A socket sits in `sessions_` from the moment it is accepted, before its `hello` is read,
    /// so counting the list would let a bare TCP connect -- a port scan, a client that never
    /// greets -- inflate the number shown to the user and push a real receiver over capacity.
    [[nodiscard]] int receiverCount() const
    {
        int count = 0;
        for (const Session* session : sessions_) {
            if (session->greeted()) {
                ++count;
            }
        }
        return count;
    }

private slots:
    void onNewConnection()
    {
        while (server_ && server_->hasPendingConnections()) {
            QTcpSocket* socket = server_->nextPendingConnection();
            auto* session = new Session(socket);
            // Connected to `this`, not to a lambda holding the session: the slot looks the
            // session up through `sender()`, so nothing can dangle when a session is freed.
            connect(socket, &QTcpSocket::readyRead, this, &Core::onSessionReadyRead);
            connect(socket, &QTcpSocket::disconnected, this, &Core::onSessionDisconnected);
            connect(socket, &QTcpSocket::bytesWritten, this, &Core::onSessionBytesWritten);
            sessions_.append(session);
            logging::debug(QStringLiteral("ControlServer"),
                QStringLiteral("control.session.opened from %1:%2 (sessions=%3)")
                    .arg(socket->peerAddress().toString())
                    .arg(socket->peerPort())
                    .arg(sessions_.size()));
            publishCount();
        }
    }

    void onSessionReadyRead()
    {
        Session* session = sessionForSender();
        if (!session || session->finished()) {
            return;
        }

        QByteArray line;
        while (session->takeLine(line)) {
            if (!line.trimmed().isEmpty()) {
                handleLine(session, line);
            }
            // `handleLine` may have closed the session (a `deny`, or a `bye`). Sessions are
            // freed with `deleteLater`, so the object is still alive to be asked; it is
            // destroyed once this event returns and control reaches the event loop again.
            if (session->finished()) {
                return;
            }
        }
        if (session->readOverflowed()) {
            // Unrecoverable framing error: drop the peer rather than guess where the next
            // line begins.
            dropSession(session);
        }
    }

    void onSessionBytesWritten()
    {
        Session* session = sessionForSender();
        if (!session || session->finished()) {
            return;
        }
        session->flush();
        if (session->isClosing() && session->isDrained()) {
            completeClose(session);
        }
    }

    void onSessionDisconnected()
    {
        Session* session = sessionForSender();
        if (!session || session->finished()) {
            return;
        }
        // A peer that vanished mid-conversation still counts as leaving: its RTP target has
        // to be withdrawn, or the sender keeps fanning packets at a dead port.
        dropSession(session);
    }

private:
    /// Resolves the session behind a socket signal. `sender()` avoids capturing a Session
    /// pointer in a lambda, which would dangle the moment the session is freed.
    [[nodiscard]] Session* sessionForSender() const
    {
        auto* socket = qobject_cast<QTcpSocket*>(sender());
        if (!socket) {
            return nullptr;
        }
        for (Session* session : sessions_) {
            if (session->socket() == socket) {
                return session;
            }
        }
        return nullptr;
    }

    void publishCount()
    {
        if (receiverCountOut_) {
            receiverCountOut_->store(receiverCount());
        }
    }

    void dropSession(Session* session)
    {
        if (session->finished()) {
            return;
        }
        // Read the peer's details before finishing: `finish` schedules the socket for
        // deletion, and nothing should depend on it outliving this function.
        const QHostAddress peer = session->socket()->peerAddress();
        const int audioPort = session->offeredAudioPort();
        const int videoPort = session->offeredVideoPort();
        const QString name = session->name();

        session->finish();
        sessions_.removeOne(session);
        publishCount();

        if (audioPort > 0 && callbacks_.onRemove) {
            callbacks_.onRemove(peer, audioPort, videoPort);
        }
        if (callbacks_.onReceiverDisconnected) {
            callbacks_.onReceiverDisconnected(name);
        }
        // Deferred, never immediate: `dropSession` is reachable from a slot that is still
        // holding this pointer, and from `handleLine`, whose caller keeps using it.
        session->deleteLater();
    }

    void completeClose(Session* session)
    {
        if (session->finished()) {
            return;
        }
        session->socket()->close();
        dropSession(session);
    }

    /// Queues any pending writes, then closes as soon as they have drained.
    void closeGracefully(Session* session)
    {
        session->close();
        // Usually the buffer is already empty and this closes the socket right away; when a
        // `deny` is still in the socket's own write buffer, `onSessionBytesWritten` finishes it.
        if (session->isDrained()) {
            completeClose(session);
        }
    }

    void handleLine(Session* session, const QByteArray& line)
    {
        const protocol::ControlMessage message = protocol::parse(line);
        if (std::holds_alternative<std::monostate>(message)) {
            return; // unknown or malformed; ignored, per PROTOCOL.md section 4.2
        }

        if (const auto* hello = std::get_if<protocol::Hello>(&message)) {
            handleHello(session, *hello);
        } else if (const auto* auth = std::get_if<protocol::AuthRequest>(&message)) {
            handleAuth(session, *auth);
        } else if (const auto* offer = std::get_if<protocol::Offer>(&message)) {
            handleOffer(session, *offer);
        } else if (std::get_if<protocol::KeyframeRequest>(&message)) {
            if (callbacks_.onKeyframeRequest) {
                callbacks_.onKeyframeRequest();
            }
        } else if (const auto* bitrate = std::get_if<protocol::BitrateRequest>(&message)) {
            if (callbacks_.onBitrateRequest) {
                callbacks_.onBitrateRequest(bitrate->videoKbps, bitrate->audioKbps);
            }
        } else if (const auto* request = std::get_if<protocol::ModeRequest>(&message)) {
            // A request, not a command. Whatever the broadcaster decides, the requester is
            // told: replying with the authoritative mode answers the question either way,
            // so a refused request is never silent.
            if (callbacks_.onModeRequest) {
                callbacks_.onModeRequest(request->mode);
            }
            if (callbacks_.description) {
                session->send(protocol::ModeChanged {callbacks_.description().mode});
            }
        } else if (const auto* stats = std::get_if<protocol::ReceiverStats>(&message)) {
            if (callbacks_.onReceiverStats) {
                callbacks_.onReceiverStats(*stats);
            }
        } else if (std::get_if<protocol::Bye>(&message)) {
            closeGracefully(session);
        }
    }

    void handleHello(Session* session, const protocol::Hello& hello)
    {
        session->setName(hello.name);

        if (hello.protocolVersion != protocol::LocalStream::ProtocolVersion) {
            logging::warning(QStringLiteral("ControlServer"),
                QStringLiteral("control.denied version: %1 speaks %2, we speak %3")
                    .arg(hello.name)
                    .arg(hello.protocolVersion)
                    .arg(protocol::LocalStream::ProtocolVersion));
            session->send(protocol::Deny {QString::fromLatin1(protocol::deny::Version),
                QStringLiteral("This broadcaster speaks protocol version %1; the receiver asked for "
                               "%2. Update one of the apps.")
                    .arg(protocol::LocalStream::ProtocolVersion)
                    .arg(hello.protocolVersion)});
            closeGracefully(session);
            return;
        }

        if (receiverCount() >= maxReceivers_) {
            logging::warning(QStringLiteral("ControlServer"),
                QStringLiteral("control.denied capacity: %1 (full at %2)")
                    .arg(hello.name)
                    .arg(maxReceivers_));
            session->send(protocol::Deny {QString::fromLatin1(protocol::deny::Capacity),
                QStringLiteral("This broadcast already has the maximum of %1 receivers.")
                    .arg(maxReceivers_)});
            closeGracefully(session);
            return;
        }

        if (callbacks_.description) {
            const protocol::LocalStream::Description description = callbacks_.description();
            session->send(protocol::Welcome {protocol::LocalStream::ProtocolVersion,
                description.sessionId, description.mode, description.displayName,
                callbacks_.sdp ? callbacks_.sdp() : QByteArray {}, accessMode_});
            // The greeting is queued, so the session is now entitled to broadcaster-wide
            // push messages.
            session->setGreeted();
            // The count now includes this session, so the published figure has to move with it.
            // It is deliberately not published on accept: a socket that never greets is not a
            // receiver and must not appear as one.
            publishCount();
        }
        if (callbacks_.onReceiverConnected) {
            callbacks_.onReceiverConnected(hello.name);
        }
        logging::debug(QStringLiteral("ControlServer"),
            QStringLiteral("control.session.greeted: %1 from %2")
                .arg(hello.name, session->socket()->peerAddress().toString()));
    }

    /// Answers a password attempt. The receiver has not been admitted at this point, so a wrong
    /// password costs nothing but the round trip: the session stays open so the viewer can
    /// retype, and no RTP target has been published yet.
    void handleAuth(Session* session, const protocol::AuthRequest& auth)
    {
        // Sent only in password mode. A receiver that offers a password to a public broadcast has
        /// probably misread a `welcome`, and saying so is more useful than a bare refusal.
        if (accessMode_ != QLatin1String(protocol::access::Password)) {
            session->send(protocol::AuthResult {false,
                QStringLiteral("This broadcast is not password protected.")});
            return;
        }
        if (auth.password == accessPassword_) {
            session->setAuthenticated();
            session->send(protocol::AuthResult {true, QString()});
            return;
        }
        session->send(protocol::AuthResult {false, QStringLiteral("That password is not correct.")});
    }

    /**
     * The gate every connection passes through.
     *
     * In order: a receiver who has spent its rejections is refused without troubling the user;
     * a receiver that must authenticate has to; approval mode holds the offer and asks. The
     * order matters — a barred viewer should never raise a prompt, and a correct password should
     * not be offered to the UI as though a human had to approve it.
     */
    void handleOffer(Session* session, const protocol::Offer& offer)
    {
        if (accessMode_ == QLatin1String(protocol::access::Approval)) {
            if (rejections_.value(session->socket()->peerAddress()) >= protocol::accesslimits::MaxRejections) {
                denyBlocked(session);
                return;
            }
            // The ports are recorded before the hold, so a session that is admitted later can be
            // accepted from here without the receiver having to offer again.
            session->setOfferedPorts(offer.audioPort, offer.videoPort);
            // A second offer from a session already waiting is ignored rather than prompting
            // twice: the user would be asked to approve the same viewer in two dialogs.
            if (session->accessRequestKey() != 0) {
                return;
            }
            const quint64 key = nextRequestKey_++;
            session->setAccessRequestKey(key);
            logging::event(QStringLiteral("control.access.requested"),
                {{QStringLiteral("name"), session->name()},
                    {QStringLiteral("address"), session->socket()->peerAddress().toString()},
                    {QStringLiteral("rejections"),
                        QString::number(rejections_.value(session->socket()->peerAddress()))}});
            if (callbacks_.onAccessRequest) {
                callbacks_.onAccessRequest(key, session->name());
            } else {
                // No UI attached to answer, so nobody would ever admit this viewer. Refusing is
                // the only outcome that cannot leak the stream.
                session->setAccessRequestKey(0);
                rejectAccess(session);
            }
            return;
        }

        if (accessMode_ == QLatin1String(protocol::access::Password)
            && !session->authenticated()) {
            // The viewer skipped `auth`. A peer that ignores the protocol must not get in by
            // omission, so the missing step is named rather than reported as a bad password.
            logging::warning(QStringLiteral("ControlServer"),
                QStringLiteral("control.denied auth: %1 offered without authenticating")
                    .arg(session->name()));
            session->send(protocol::Deny {QString::fromLatin1(protocol::deny::Auth),
                QStringLiteral("This broadcast is password protected.")});
            closeGracefully(session);
            return;
        }

        session->setOfferedPorts(offer.audioPort, offer.videoPort);
        admit(session);
    }

    /// Publishes the receiver as an RTP target and sends the `accept`.
    void admit(Session* session)
    {
        if (callbacks_.onOffer) {
            callbacks_.onOffer(session->socket()->peerAddress(), session->offeredAudioPort(),
                session->offeredVideoPort());
        }
        if (!callbacks_.description) {
            return;
        }
        // The accept carries the broadcaster's own bound ports, not an echo of the offer: the
        // receiver needs to know where media will actually arrive from.
        const protocol::LocalStream::Description description = callbacks_.description();
        const bool hasVideo = !description.isAudioOnly() && description.videoPort > 0;
        session->send(protocol::Accept {description.audioPort,
            hasVideo ? description.videoPort : 0,
            callbacks_.audioSsrc ? callbacks_.audioSsrc() : 0,
            hasVideo && callbacks_.videoSsrc ? callbacks_.videoSsrc() : 0});
    }

    /**
     * Records a rejection against the peer and refuses it.
     *
     * The count is keyed by IP address, not by the control connection, because the rule the
     * user asked for is about a *device*: reconnecting on a new socket must not hand back the
     * attempts already spent. It is cleared by [clearAccessHistory] when the broadcast ends,
     * so the next broadcast judges everyone fresh.
     */
    void rejectAccess(Session* session)
    {
        const QHostAddress peer = session->socket()->peerAddress();
        const int count = rejections_.value(peer) + 1;
        rejections_.insert(peer, count);

        // Logged before the ban check so the count in the log explains the ban that may follow:
        // read on its own, a refusal with no tally looks arbitrary.
        logging::warning(QStringLiteral("ControlServer"),
            QStringLiteral("control.denied access: %1 at %2, attempt %3 of %4")
                .arg(session->name(), peer.toString())
                .arg(count)
                .arg(protocol::accesslimits::MaxRejections));

        if (count >= protocol::accesslimits::MaxRejections) {
            denyBlocked(session);
            return;
        }
        const int remaining = protocol::accesslimits::MaxRejections - count;
        session->send(protocol::Deny {QString::fromLatin1(protocol::deny::Access),
            QStringLiteral("The broadcaster declined your request to watch.")
                + (remaining == 1
                          ? QStringLiteral(" This is your last attempt.")
                          : QStringLiteral(" %1 attempts remaining.").arg(remaining))});
        closeGracefully(session);
    }

    /// The final refusal: over the limit, so the viewer is told not to try again and the
    /// connection is closed without offering a path back.
    void denyBlocked(Session* session)
    {
        logging::warning(QStringLiteral("ControlServer"),
            QStringLiteral("control.denied blocked: %1 at %2 is barred from this broadcast")
                .arg(session->name(), session->socket()->peerAddress().toString()));
        session->send(protocol::Deny {QString::fromLatin1(protocol::deny::Blocked),
            QStringLiteral("You have been blocked from this broadcast after %1 rejected requests. "
                           "Do not try again; the broadcaster rejected you.")
                .arg(protocol::accesslimits::MaxRejections)});
        closeGracefully(session);
    }

    [[nodiscard]] Session* sessionForRequestKey(quint64 key) const
    {
        for (Session* session : sessions_) {
            if (session->accessRequestKey() == key) {
                return session;
            }
        }
        return nullptr;
    }

    Callbacks callbacks_;
    int maxReceivers_;
    std::atomic<int>* receiverCountOut_;
    QTcpServer* server_ = nullptr;
    int port_ = 0;

    QString accessMode_ = QString::fromLatin1(protocol::access::Public);
    /// Kept as a QString because that is what the comparison against an AuthRequest needs; it is
    /// never logged and never leaves the process.
    QString accessPassword_;
    /// Rejections per peer IP for this broadcast. See [rejectAccess].
    QHash<QHostAddress, int> rejections_;
    quint64 nextRequestKey_ = 1;

    // Guarded by nothing, and needs no guard: every method above runs on the core's thread,
    // and the owning ControlServer only ever reads the published count.
    QList<Session*> sessions_;
};

// ---------------------------------------------------------------------- Session

void ControlServer::Core::Session::send(const protocol::ControlMessage& message)
{
    if (finished_) {
        return;
    }
    const QByteArray line = protocol::encode(message);
    if (line.isEmpty()) {
        return;
    }
    if (pending_.size() + line.size() > MaxQueuedBytesPerSession) {
        // Never block the caller's thread to make room: the callers here are the encoder's
        // frame callback and the stats timer, and stalling either would damage media. A
        // dropped control message is far cheaper than a stalled broadcast.
        pending_.clear();
    }
    pending_.append(line);
    flush();
}

bool ControlServer::Core::Session::takeLine(QByteArray& line)
{
    readBuffer_.append(socket_->readAll());
    if (readOverflowed_) {
        return false;
    }
    if (readBuffer_.size() > MaxLineBytes) {
        // No newline in a whole line's worth of bytes: the peer is not speaking the protocol
        // (or is malicious). Dropping the buffer is better than resyncing byte by byte.
        readBuffer_.clear();
        readOverflowed_ = true;
        return false;
    }

    const int newline = readBuffer_.indexOf('\n');
    if (newline < 0) {
        return false;
    }
    line = readBuffer_.left(newline);
    readBuffer_.remove(0, newline + 1);
    return true;
}

bool ControlServer::Core::Session::flush()
{
    while (!pending_.isEmpty() && socket_->state() == QAbstractSocket::ConnectedState) {
        const qint64 written = socket_->write(pending_);
        if (written <= 0) {
            return false; // socket buffer full; `bytesWritten` will call us back
        }
        pending_.remove(0, static_cast<int>(written));
    }
    return isDrained();
}

bool ControlServer::Core::Session::isDrained() const
{
    return pending_.isEmpty() && socket_->bytesToWrite() == 0;
}

void ControlServer::Core::Session::close()
{
    if (closing_ || finished_) {
        return;
    }
    closing_ = true;
    flush();
}

void ControlServer::Core::Session::abort()
{
    pending_.clear();
    closing_ = true;
}

void ControlServer::Core::Session::finish()
{
    if (finished_) {
        return;
    }
    finished_ = true;
    // Sever every signal first: a queued `disconnected` must not re-enter `dropSession`
    // for a session that is already being freed.
    socket_->disconnect();
    socket_->abort();
    socket_->deleteLater();
}

// -------------------------------------------------------------------- ControlServer

ControlServer::ControlServer(QObject* parent) : QObject(parent)
{
    thread_.setObjectName(QStringLiteral("LocalStream-ControlTx"));
}

ControlServer::~ControlServer()
{
    close();
    thread_.quit();
    thread_.wait();
}

bool ControlServer::listen(QString* error)
{
    if (thread_.isRunning()) {
        return port_.load() > 0;
    }

    port_.store(0);
    receiverCount_.store(0);

    core_ = new Core(callbacks_, maxReceivers_.load(), &receiverCount_, accessMode_, accessPassword_);
    // The move has to happen before the thread starts: `moveToThread` refuses once the target
    // is running, and the core must already be associated with it for a blocking call to be
    // delivered at all.
    core_->moveToThread(&thread_);
    connect(&thread_, &QThread::finished, core_, &QObject::deleteLater);

    thread_.start();

    QString bindError;
    int chosenPort = 0;
    Core* core = core_;
    // Aimed at `core`, never at `this`: only the core lives on the thread that can answer.
    // This call blocks the caller, which is precisely why the target must not be the
    // caller's own thread.
    const bool delivered =
        QMetaObject::invokeMethod(
            core,
            [core, &bindError, &chosenPort] {
                if (!core->listen(&bindError)) {
                    return;
                }
                chosenPort = core->port();
            },
            Qt::BlockingQueuedConnection);

    if (!delivered) {
        if (error) {
            *error = QStringLiteral("The control thread did not respond.");
        }
        thread_.quit();
        thread_.wait(BlockingCallTimeoutMs);
        return false;
    }
    if (!bindError.isEmpty()) {
        if (error) {
            *error = bindError;
        }
        thread_.quit();
        thread_.wait(BlockingCallTimeoutMs);
        return false;
    }

    port_.store(chosenPort);
    return true;
}

void ControlServer::close()
{
    if (!core_) {
        thread_.quit();
        thread_.wait(BlockingCallTimeoutMs);
        return;
    }

    Core* core = core_;
    QMetaObject::invokeMethod(core, [core] { core->shutdown(); }, Qt::BlockingQueuedConnection);

    thread_.quit();
    thread_.wait(BlockingCallTimeoutMs);

    // `core_` is destroyed by the finished -> deleteLater connection, once the loop has
    // stopped and run its deferred deletions.
    core_ = nullptr;
    port_.store(0);
    receiverCount_.store(0);
}

void ControlServer::sendModeChanged(const QString& mode)
{
    if (!core_) {
        return;
    }
    Core* core = core_;
    QMetaObject::invokeMethod(
        core, [core, mode] { core->broadcast(protocol::ModeChanged {mode}); }, Qt::QueuedConnection);
}

void ControlServer::setAccessMode(const QString& mode)
{
    // Kept here as well as on the core. This is the caller's thread, and a setting made before
    // listen() has no core to reach - it has to survive to the core that is built later.
    accessMode_ = mode;
    if (!core_) {
        return;
    }
    Core* core = core_;
    QMetaObject::invokeMethod(
        core, [core, mode] { core->setAccessMode(mode); }, Qt::QueuedConnection);
}

void ControlServer::setAccessPassword(const QString& password)
{
    accessPassword_ = password;
    if (!core_) {
        return;
    }
    Core* core = core_;
    QMetaObject::invokeMethod(
        core, [core, password] { core->setAccessPassword(password); }, Qt::QueuedConnection);
}

void ControlServer::clearAccessHistory()
{
    if (!core_) {
        return;
    }
    Core* core = core_;
    QMetaObject::invokeMethod(
        core, [core] { core->clearAccessHistory(); }, Qt::QueuedConnection);
}

void ControlServer::resolveAccessRequest(quint64 requestKey, bool allow)
{
    if (!core_) {
        return;
    }
    Core* core = core_;
    QMetaObject::invokeMethod(
        core,
        [core, requestKey, allow] { core->resolveAccessRequest(requestKey, allow); },
        Qt::QueuedConnection);
}

void ControlServer::sendStats(const protocol::BroadcasterStats& stats)
{
    if (!core_) {
        return;
    }
    Core* core = core_;
    QMetaObject::invokeMethod(core, [core, stats] { core->broadcast(stats); }, Qt::QueuedConnection);
}

void ControlServer::sendKeyframeCoalesced()
{
    if (!core_) {
        return;
    }
    Core* core = core_;
    QMetaObject::invokeMethod(
        core, [core] { core->broadcast(protocol::KeyframeCoalesced {}); }, Qt::QueuedConnection);
}

void ControlServer::closeAll(const QString& reason)
{
    if (!core_) {
        return;
    }
    Core* core = core_;
    QMetaObject::invokeMethod(
        core,
        [core, reason] {
            core->broadcast(protocol::Bye {reason});
            // Graceful: the `bye` goes out before the socket closes, once the write drains.
            for (auto* session : core->sessions()) {
                session->close();
            }
        },
        Qt::BlockingQueuedConnection);
}

} // namespace localstream::net

// Core carries Q_OBJECT and is defined in this file, so AUTOMOC's output is included by hand
// rather than swept into the target's mocs_compilation unit.
#include "ControlServer.moc"
