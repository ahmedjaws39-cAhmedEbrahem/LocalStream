#include "net/RtpReceiver.h"

#include <QDateTime>
#include <QMetaObject>
#include <QMutexLocker>

#include <map>

#include "protocol/H264Rtp.h"
#include "protocol/LocalStream.h"
#include "protocol/Rtp.h"

namespace localstream::net {

namespace {

constexpr qint64 MaxDatagram = 4096;

/// Three frames of 20 ms is 60 ms of slack: enough for the reordering Wi-Fi introduces,
/// small enough to stay inside the latency budget.
constexpr int ReorderWindowPackets = 3;

/**
 * Sequence-ordered release buffer for Opus.
 *
 * Holds packets until the next in sequence arrives, then releases everything contiguous. If
 * the head is never filled — a packet genuinely lost — the oldest buffered packet is
 * released once the window is full, so one loss costs a click rather than unbounded latency.
 */
class AudioReorderBuffer
{
public:
    explicit AudioReorderBuffer(int windowPackets) : windowPackets_(windowPackets) {}

    void push(quint16 sequence, const QByteArray& frame)
    {
        if (nextSequence_ < 0) {
            nextSequence_ = sequence;
        }

        // A large forward jump means packets were lost outright; resynchronise rather than
        // stalling forever waiting for a number that will never arrive.
        const auto expected = static_cast<quint16>(nextSequence_);
        const int forwardGap = protocol::Rtp::sequenceDelta(sequence, expected);
        if (forwardGap > 0x8000 || forwardGap > windowPackets_ * 4) {
            nextSequence_ = sequence;
            pending_.clear();
        }

        if (protocol::Rtp::sequenceDelta(sequence, static_cast<quint16>(nextSequence_)) >= 0x8000) {
            return; // too old to matter
        }
        pending_[sequence] = frame;
    }

    // The callback is deliberately not named `emit`: Qt defines that as an empty macro, so
    // `emit(frame);` would silently compile to `(frame);` and drop every packet.
    template<typename Deliver>
    void drainTo(Deliver&& deliver)
    {
        if (static_cast<int>(pending_.size()) > windowPackets_) {
            const auto oldest = pending_.begin();
            if (oldest != pending_.end() && oldest->first != static_cast<quint16>(nextSequence_)) {
                nextSequence_ = oldest->first + 1;
            }
        }
        for (;;) {
            auto it = pending_.find(static_cast<quint16>(nextSequence_));
            if (it == pending_.end()) {
                break;
            }
            const QByteArray frame = it->second;
            pending_.erase(it);
            nextSequence_ = (nextSequence_ + 1) & 0xFFFF;
            deliver(frame);
        }
    }

private:
    int windowPackets_;
    std::map<quint16, QByteArray> pending_;
    int nextSequence_ = -1;
};

} // namespace

/**
 * Owns both sockets and the event loop they live in.
 *
 * Every socket call — bind, readDatagram, close — happens on this object's thread, which is
 * what makes tearing down while a read is pending safe. `close()` in particular is only ever
 * reached through a queued invocation from the GUI thread, never called directly.
 */
class MediaWorker : public QObject
{
    Q_OBJECT

public:
    explicit MediaWorker(RtpReceiver* owner) : owner_(owner), reorder_(ReorderWindowPackets) {}

    /**
     * Re-homes the sockets onto the media thread.
     *
     * Required, and not optional tidiness: they are member objects with no parent, so moving
     * the worker that contains them does not move them. Left behind, every `readDatagram`
     * would run on a socket whose affinity is the caller's thread.
     *
     * Must be called from the sockets' current thread, before the target thread starts.
     */
    void moveSocketsTo(QThread* target)
    {
        audioSocket_.moveToThread(target);
        videoSocket_.moveToThread(target);
    }

    /// Must run on this object's thread. Called through a blocking queued invocation.
    bool bind(bool withVideo, QString* error)
    {
        // A generous receive buffer is what keeps a 1.5 Mbit stream from shedding packets
        // during a Wi-Fi retransmit burst.
        audioSocket_.setSocketOption(QAbstractSocket::ReceiveBufferSizeSocketOption, 512 * 1024);
        if (!audioSocket_.bind(QHostAddress::AnyIPv4, 0, QUdpSocket::ShareAddress)) {
            if (error) {
                *error = QStringLiteral("Could not bind the audio socket: %1")
                             .arg(audioSocket_.errorString());
            }
            return false;
        }
        owner_->ports_.audio = audioSocket_.localPort();

        if (withVideo) {
            videoSocket_.setSocketOption(QAbstractSocket::ReceiveBufferSizeSocketOption, 512 * 1024);
            if (!videoSocket_.bind(QHostAddress::AnyIPv4, 0, QUdpSocket::ShareAddress)) {
                if (error) {
                    *error = QStringLiteral("Could not bind the video socket: %1")
                                 .arg(videoSocket_.errorString());
                }
                audioSocket_.close();
                owner_->ports_.audio = 0;
                return false;
            }
            owner_->ports_.video = videoSocket_.localPort();
        }

        connect(&audioSocket_, &QUdpSocket::readyRead, this, &MediaWorker::onAudioReady);
        if (withVideo) {
            connect(&videoSocket_, &QUdpSocket::readyRead, this, &MediaWorker::onVideoReady);
        }
        return true;
    }

    void close()
    {
        audioSocket_.close();
        videoSocket_.close();
    }

private slots:
    void onAudioReady() { drain(audioSocket_, true); }
    void onVideoReady() { drain(videoSocket_, false); }

private:
    void drain(QUdpSocket& socket, bool isAudio)
    {
        QByteArray datagram;
        datagram.resize(MaxDatagram);
        quint64 burst = 0;
        for (;;) {
            QHostAddress senderAddress;
            quint16 senderPort = 0;
            const qint64 read = socket.readDatagram(
                datagram.data(), datagram.size(), &senderAddress, &senderPort);
            if (read <= 0) {
                break;
            }
            datagram.resize(static_cast<int>(read));
            if (isAudio) {
                handleAudio(datagram, senderAddress, senderPort);
            } else {
                handleVideo(datagram, senderAddress, senderPort);
            }
            ++burst;
            datagram.resize(MaxDatagram);
        }
        if (isAudio && burst > 0) {
            QMutexLocker locker(&owner_->statsMutex_);
            if (burst > owner_->stats_.audioMaxBurst) {
                owner_->stats_.audioMaxBurst = burst;
            }
        }
    }

    void handleAudio(
        const QByteArray& datagram, const QHostAddress& senderAddress, quint16 senderPort)
    {
        protocol::Rtp::Packet packet;
        if (!protocol::Rtp::parse(datagram, 0, datagram.size(), packet)) {
            return;
        }
        if (packet.payloadType != protocol::LocalStream::PayloadTypeAudio) {
            return;
        }
        if (!owner_->matchesExpectedSource(senderAddress, senderPort, true, packet.ssrc)) {
            return;
        }

        noteAudioPacket(packet.sequenceNumber);
        const QByteArray payload = datagram.mid(packet.payloadOffset, packet.payloadLength);
        reorder_.push(packet.sequenceNumber, payload);
        reorder_.drainTo([this](const QByteArray& frame) {
            const RtpReceiver::AudioHandler handler = owner_->audioHandler();
            if (handler) {
                handler(frame);
            }
        });
    }

    void handleVideo(
        const QByteArray& datagram, const QHostAddress& senderAddress, quint16 senderPort)
    {
        protocol::Rtp::Packet packet;
        if (!protocol::Rtp::parse(datagram, 0, datagram.size(), packet)) {
            return;
        }
        if (packet.payloadType != protocol::LocalStream::PayloadTypeVideo) {
            return;
        }
        if (!owner_->matchesExpectedSource(senderAddress, senderPort, false, packet.ssrc)) {
            return;
        }

        if (lastVideoSequence_ >= 0) {
            const auto expected = static_cast<quint16>(lastVideoSequence_ + 1);
            const int delta = protocol::Rtp::sequenceDelta(packet.sequenceNumber, expected);
            if (delta != 0) {
                // Video is not reordered for latency. Clear partial FU-A state on loss and
                // ignore packets that arrived late so they cannot corrupt a newer frame.
                depacketizer_.discardCurrentAccessUnit();
                if (delta >= 0x8000) {
                    return;
                }
            }
        }
        lastVideoSequence_ = packet.sequenceNumber;
        noteVideoPacket(packet.sequenceNumber);
        const QByteArray payload = datagram.mid(packet.payloadOffset, packet.payloadLength);
        const QByteArray accessUnit = depacketizer_.accept(payload, packet.marker);
        if (accessUnit.isEmpty()) {
            return;
        }

        const QByteArray sps = depacketizer_.sps();
        const QByteArray pps = depacketizer_.pps();

        const RtpReceiver::VideoHandler handler = owner_->videoHandler();
        if (handler) {
            handler(accessUnit, sps, pps);
        }
        if (!sps.isEmpty() && !pps.isEmpty()) {
            QMutexLocker locker(&owner_->statsMutex_);
            owner_->stats_.haveVideoParameters = true;
        }
    }

    void noteAudioPacket(quint16 sequence)
    {
        QMutexLocker locker(&owner_->statsMutex_);
        ++owner_->stats_.audioPackets;
        noteGap(owner_->lastAudioSequence_, sequence);
        owner_->lastAudioSequence_ = sequence;
    }

    void noteVideoPacket(quint16 sequence)
    {
        QMutexLocker locker(&owner_->statsMutex_);
        ++owner_->stats_.videoPackets;
        noteGap(owner_->lastVideoSequence_, sequence);
        owner_->lastVideoSequence_ = sequence;

        const qint64 now = QDateTime::currentMSecsSinceEpoch();
        if (owner_->lastArrivalMs_ != 0) {
            // Smoothed so the readout does not flicker frame to frame.
            const double delta = static_cast<double>(now - owner_->lastArrivalMs_);
            owner_->stats_.jitterMillis = owner_->stats_.jitterMillis * 0.9 + delta * 0.1;
        }
        owner_->lastArrivalMs_ = now;
    }

    void noteGap(qint64& previous, quint16 sequence)
    {
        if (previous < 0) {
            return;
        }
        const auto expected = static_cast<quint16>(previous + 1);
        if (sequence != expected) {
            const int gap = protocol::Rtp::sequenceDelta(sequence, expected);
            // A wild jump means the sender restarted or the stream desynchronised; counting
            // every "missing" packet would report nonsense.
            if (gap > 0 && gap <= 999) {
                owner_->stats_.lostPackets += static_cast<quint64>(gap);
            }
        }
    }

    RtpReceiver* owner_;
    QUdpSocket audioSocket_;
    QUdpSocket videoSocket_;
    AudioReorderBuffer reorder_;
    protocol::h264::Depacketizer depacketizer_;
    qint64 lastVideoSequence_ = -1;
};

// RtpReceiver -------------------------------------------------------------

RtpReceiver::RtpReceiver() = default;

RtpReceiver::~RtpReceiver()
{
    close();
}

void RtpReceiver::setAudioHandler(AudioHandler handler)
{
    QMutexLocker locker(&handlerMutex_);
    audioHandler_ = std::move(handler);
}

void RtpReceiver::setVideoHandler(VideoHandler handler)
{
    QMutexLocker locker(&handlerMutex_);
    videoHandler_ = std::move(handler);
}

bool RtpReceiver::setExpectedSource(const QHostAddress& address, int audioPort,
    quint32 audioSsrc, int videoPort, quint32 videoSsrc)
{
    if (address.isNull() || audioPort < 1 || audioPort > 65535 || audioSsrc == 0
        || videoPort < 0 || videoPort > 65535
        || (videoPort > 0 && videoSsrc == 0)
        || (videoPort == 0 && videoSsrc != 0)) {
        return false;
    }

    QMutexLocker locker(&sourceMutex_);
    expectedSource_ = ExpectedSource {address, static_cast<quint16>(audioPort),
        static_cast<quint16>(videoPort), audioSsrc, videoSsrc, true};
    return true;
}

bool RtpReceiver::matchesExpectedSource(const QHostAddress& address, quint16 port,
    bool isAudio, quint32 ssrc) const
{
    QMutexLocker locker(&sourceMutex_);
    if (!expectedSource_.configured
        || !address.isEqual(expectedSource_.address, QHostAddress::ConvertV4MappedToIPv4)) {
        return false;
    }

    const quint16 expectedPort = isAudio ? expectedSource_.audioPort : expectedSource_.videoPort;
    const quint32 expectedSsrc = isAudio ? expectedSource_.audioSsrc : expectedSource_.videoSsrc;
    return expectedPort != 0 && port == expectedPort && ssrc == expectedSsrc;
}

RtpReceiver::AudioHandler RtpReceiver::audioHandler() const
{
    QMutexLocker locker(&handlerMutex_);
    return audioHandler_;
}

RtpReceiver::VideoHandler RtpReceiver::videoHandler() const
{
    QMutexLocker locker(&handlerMutex_);
    return videoHandler_;
}

bool RtpReceiver::open(bool withVideo, QString* error)
{
    if (running_.load(std::memory_order_acquire)) {
        return true;
    }

    {
        QMutexLocker locker(&sourceMutex_);
        expectedSource_ = ExpectedSource {};
    }

    thread_ = std::make_unique<QThread>();
    thread_->setObjectName(QStringLiteral("LocalStream-MediaRx"));

    // The worker is built here, on the caller's thread, so it starts out with that affinity.
    auto worker = std::make_unique<MediaWorker>(this);
    MediaWorker* raw = worker.get();

    // Both moves must happen before the thread starts, while the caller still owns the
    // objects. The sockets are not children of the worker, so moving the worker alone would
    // leave them bound to this thread and every later read issued from the wrong one.
    raw->moveToThread(thread_.get());
    raw->moveSocketsTo(thread_.get());

    thread_->start();

    // NOT `connect(thread, &QThread::finished, worker, &QObject::deleteLater)`.
    //
    // That idiom deletes the worker from the event loop while `worker_` still holds a
    // unique_ptr to it, and close() then resets that pointer -- a double free on every close,
    // which showed up as a hard crash on the first close rather than on any packet. The worker
    // is owned by `worker_` instead, and released below once the thread has stopped.
    //
    // The sockets are the exception: they are members of the worker and must not be destroyed
    // on a thread other than their own, which is why the thread is always joined before
    // `worker_` is reset.

    worker_ = std::move(worker);

    // Binding must happen on the media thread, and the caller needs the bound ports before
    // it can send its `offer`, so this has to block until it is done.
    QString bindError;
    const bool ok = QMetaObject::invokeMethod(
        raw,
        [raw, withVideo, &bindError] { raw->bind(withVideo, &bindError); },
        Qt::BlockingQueuedConnection);

    if (!ok || !bindError.isEmpty()) {
        if (error) {
            *error = bindError.isEmpty() ? QStringLiteral("The media thread did not respond.")
                                         : bindError;
        }
        // Torn down directly rather than through `close()`: `close()` is a no-op while
        // `running_` is still false, and this is exactly the path where a live thread and
        // worker would otherwise be left behind.
        QMetaObject::invokeMethod(raw, "close", Qt::BlockingQueuedConnection);
        thread_->quit();
        thread_->wait(2000);
        worker_.reset();
        thread_.reset();
        ports_ = Ports {};
        return false;
    }

    running_.store(true, std::memory_order_release);
    return true;
}

void RtpReceiver::close()
{
    {
        QMutexLocker locker(&sourceMutex_);
        expectedSource_ = ExpectedSource {};
    }
    if (!running_.exchange(false)) {
        return;
    }

    MediaWorker* raw = worker_.get();
    if (raw && thread_ && thread_->isRunning()) {
        // Blocking, not queued: the sockets may only be touched on their own thread, and the
        // thread must not be asked to stop until they are actually closed. A queued call
        // followed immediately by `quit()` would usually be dropped along with the loop.
        //
        // Invoked as a lambda rather than by name: `close` is not a slot, so the string-based
        // overload fails to resolve it with "No such method", which leaves the sockets open
        // while the thread is asked to quit -- the sockets then outlive their event loop and the
        // ports stay bound, so the next open() on the same machine fails.
        QMetaObject::invokeMethod(raw, [raw] { raw->close(); }, Qt::BlockingQueuedConnection);
        thread_->quit();
        // Bounded: a wedged socket must not hang the UI on close.
        if (!thread_->wait(2000)) {
            thread_->terminate();
            thread_->wait();
        }
    }

    worker_.reset();
    thread_.reset();
    ports_ = Ports {};
}

RtpReceiver::Stats RtpReceiver::stats() const
{
    QMutexLocker locker(&statsMutex_);
    return stats_;
}

void RtpReceiver::noteKeyframeRequest()
{
    QMutexLocker locker(&statsMutex_);
    ++stats_.keyframeRequests;
}

} // namespace localstream::net

#include "RtpReceiver.moc"
