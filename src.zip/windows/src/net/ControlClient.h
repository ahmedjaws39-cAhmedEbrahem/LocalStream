#pragma once

#include <QByteArray>
#include <QHostAddress>
#include <QObject>
#include <QString>
#include <QTcpSocket>
#include <QTimer>

#include "protocol/ControlMessage.h"
#include "protocol/LocalStream.h"

namespace localstream::net {

/**
 * Receiver side of the control channel.
 *
 * Drives the handshake in `docs/PROTOCOL.md` section 4.1: connect, `hello`, wait for
 * `welcome`, then `offer` the already-bound media ports and wait for `accept`. Media starts
 * arriving immediately after `accept`, which is why the RTP sockets are opened before the TCP
 * connection is even made.
 *
 * The handshake reads from a queue rather than a blocking receive, for the same reason the
 * Android client uses a `Channel`: `welcome` can arrive before the code that waits for it is
 * reached, and a queue that drops early arrivals fails the connection for no reason.
 */
class ControlClient : public QObject
{
    Q_OBJECT

public:
    enum class State
    {
        Idle,
        Connecting,
        /// The broadcaster wants a password. [passwordRequired] has been emitted and the
        /// handshake is parked until [submitPassword] is called; the connection stays open so
        /// the answer can be sent on the socket that is already connected.
        AwaitingPassword,
        /// The offer has been sent and the broadcaster is deciding. No timeout runs: how long a
        /// person takes to answer a request is not a fault, and cutting them off would count as
        /// a rejection they never got to make.
        AwaitingApproval,
        Connected,
        Rejected,
        /// Refused for good -- over the broadcaster's rejection limit. Retrying cannot work, so
        /// the UI must not offer it.
        Blocked,
        Failed,
        Disconnected,
    };
    Q_ENUM(State)

    /// The message shown when [State::Blocked] is reached.
    [[nodiscard]] static QString blockedMessage();

    struct Handshake
    {
        int audioPort = 0;
        int videoPort = 0;
        quint32 audioSsrc = 0;
        quint32 videoSsrc = 0;
        QHostAddress peerAddress;
        /// From the broadcaster's SDP, because an Opus packet does not carry its own channel
        /// layout and the two platforms do not default to the same one.
        int audioChannels = 1;
    };

    explicit ControlClient(QObject* parent = nullptr);
    ~ControlClient() override;

    [[nodiscard]] static QString userAgent();

    [[nodiscard]] QString broadcasterName() const { return broadcasterName_; }
    [[nodiscard]] QString mode() const { return mode_; }

public slots:
    /// Connects and completes the handshake; the result arrives via [handshakeSucceeded].
    ///
    /// A password-protected or approval-protected broadcast completes later: the flow pauses at
    /// [State::AwaitingPassword] or [State::AwaitingApproval] and resumes from [passwordRequired],
    /// [accessRequested] or the user's answer.
    void connectToBroadcaster(const QString& host, int controlPort, const QString& receiverName,
        int audioPort, int videoPort);

    /// Answers [passwordRequired]. Ignored unless the handshake is waiting for exactly this.
    void submitPassword(const QString& password);

    /// Abandons a password prompt, so the viewer can back out instead of being left on a
    /// dialog with no way to leave.
    void cancelPasswordPrompt();

    void requestKeyframe();
    void requestBitrate(int videoKbps, int audioKbps);
    void requestMode(const QString& mode);
    void sendStats(const protocol::ReceiverStats& stats);

    void disconnectFromBroadcaster();

signals:
    void stateChanged(State state);
    void handshakeSucceeded(const Handshake& handshake);
    /// `deny` or a failed handshake, with a message fit to show the user.
    void handshakeFailed(const QString& reason);

    /// The broadcaster requires a password. The UI collects it and calls [submitPassword].
    void passwordRequired(const QString& broadcasterName);
    /// The offer was sent and the broadcaster is deciding whether to let this viewer in.
    void accessRequested(const QString& broadcasterName);
    /// A password attempt was refused. The prompt stays open so the viewer can retype, and
    /// [passwordRequired] is not re-emitted -- the UI keeps whatever it showed.
    void passwordRejected(const QString& reason);
    /// Authoritative mode change from the broadcaster.
    void modeChanged(const QString& mode);
    void broadcasterStatsReceived(const protocol::BroadcasterStats& stats);
    void keyframeCoalesced();

    /// The session is over. [graceful] is true when the broadcaster ended it deliberately (a
    /// `bye`, or a clean socket close): that is a normal end, not an error, so a viewer returns
    /// to searching rather than being shown a failure dialog.
    void ended(const QString& reason, bool graceful);

private slots:
    void onConnected();
    void onReadyRead();
    void onDisconnected();
    void onSocketError();
    void onHandshakeTimeout();

private:
    enum class Stage
    {
        None,
        AwaitingWelcome,
        /// A `welcome` arrived and a password was demanded; the offer is held until
        /// [AuthResult] grants access.
        AwaitingAuthResult,
        AwaitingAccept,
        Done,
    };

    void setState(State state);
    /// Consumes one parsed line. Returns false when the connection was torn down by it.
    bool handleMessage(const protocol::ControlMessage& message);
    /// Sends the offer, which the receiver does as soon as it is allowed to.
    void sendOffer();
    void send(const protocol::ControlMessage& message);
    /// Ends the handshake with a transport-level failure. [refuse] is for a decision the
    /// broadcaster made, which reads differently to the user even though both emit
    /// [handshakeFailed].
    void fail(const QString& reason);
    void resetSession();
    /// Ends the session from a terminal path: clears per-session state, marks the teardown as
    /// owned, then aborts the socket.
    void teardown();

    QTcpSocket socket_;
    QTimer handshakeTimer_;

    State state_ = State::Idle;
    Stage stage_ = Stage::None;
    /// Set once a terminal path (bye, deny, socket error, local disconnect) has taken ownership of
    /// ending the session. abort() can deliver disconnected() synchronously, which would otherwise
    /// re-enter onDisconnected() and misread the already-cleared stage_ as a failed handshake.
    bool terminal_ = false;

    QString broadcasterName_;
    QString mode_ = QString::fromLatin1(protocol::LocalStream::ModeAudioVideo);
    /// What the broadcaster's `welcome` said about access; one of the `protocol::access`
    /// constants. Drives whether this client offers immediately, asks first, or asks for a
    /// password, so it is the single input to the branching in [handleMessage].
    QString accessMode_ = QString::fromLatin1(protocol::access::Public);
    /// The welcome's SDP, kept for the audio channel count the accept does not carry.
    QString welcomeSdp_;
    QString sessionId_;
    QByteArray readBuffer_;

    /// Held between `connectToBroadcaster` and the `offer`, so the handshake can be driven
    /// entirely from the socket's signals.
    QString receiverName_;
    int offeredAudioPort_ = 0;
    int offeredVideoPort_ = 0;

    int handshakeTimeoutMs_ = 15000;
};

} // namespace localstream::net
