#pragma once

#include <QByteArray>
#include <QHostAddress>
#include <QList>
#include <QString>
#include <QTcpServer>
#include <QTcpSocket>
#include <QThread>

#include <atomic>
#include <functional>

#include "protocol/ControlMessage.h"
#include "protocol/LocalStream.h"

namespace localstream::net {

/**
 * Broadcaster side of the control channel.
 *
 * One connection per receiver, capped at [maxReceivers]. The server owns the authoritative
 * answers: it decides whether a receiver is admitted (`deny`), and it is the only party that
 * may announce a mode change, so a receiver can request but never force a switch.
 *
 * Every method here is safe to call from the GUI thread; the work is marshalled onto a
 * dedicated thread through [Core], because `QTcpServer` and `QTcpSocket` are QObjects and must
 * not be used from two threads.
 *
 * The split matters: this object stays on the caller's thread, and only [core_] is moved to
 * [thread_]. `QMetaObject::invokeMethod` targets the affinity of the object it is given, so
 * a blocking call aimed at `this` from the GUI thread would queue onto the very thread that
 * is blocked waiting for it, and deadlock.
 */
class ControlServer : public QObject
{
    Q_OBJECT

public:
    /// Everything the server needs from the engine, as callbacks. All run on the server thread.
    struct Callbacks
    {
        std::function<protocol::LocalStream::Description()> description;
        std::function<QByteArray()> sdp;
        std::function<quint32()> audioSsrc;
        std::function<quint32()> videoSsrc;
        std::function<void(const QHostAddress&, int audioPort, int videoPort)> onOffer;
        std::function<void(const QHostAddress&, int audioPort, int videoPort)> onRemove;
        std::function<void()> onKeyframeRequest;
        std::function<void(int videoKbps, int audioKbps)> onBitrateRequest;
        std::function<void(const QString& mode)> onModeRequest;
        std::function<void(const protocol::ReceiverStats&)> onReceiverStats;
        std::function<void(const QString& name)> onReceiverConnected;
        std::function<void(const QString& name)> onReceiverDisconnected;

        /// A receiver wants to watch and the current mode is `approval`. [requestKey] identifies
        /// the request and must be passed back to [ControlServer::resolveAccessRequest]; [name]
        /// is the receiver's own display name, shown to the user so they know who is asking.
        ///
        /// Runs on the server thread, so the UI implementation must marshal to its own thread.
        /// The server does not block waiting for the answer -- the offer is held and answered
        /// whenever the user acts, which may be seconds later or never.
        std::function<void(quint64 requestKey, const QString& name)> onAccessRequest;
    };

    /// Bounded so a wedged peer cannot freeze the caller, which is usually the GUI thread.
    static constexpr int BlockingCallTimeoutMs = 3000;

    explicit ControlServer(QObject* parent = nullptr);
    ~ControlServer() override;

    ControlServer(const ControlServer&) = delete;
    ControlServer& operator=(const ControlServer&) = delete;

    /// Must be called before [listen]; the callbacks are read from the server thread.
    void setCallbacks(Callbacks callbacks) { callbacks_ = std::move(callbacks); }
    void setMaxReceivers(int max) { maxReceivers_.store(max); }

    /**
     * Sets who may join. One of the `protocol::access` constants.
     *
     * Safe to call while broadcasting: it affects the next request, and receivers already
     * admitted keep their session. A receiver mid-request is re-checked against the new mode
     * when the user answers, so tightening the mode cannot be defeated by a stale prompt.
     *
     * May be called before [listen]: the setting is remembered and handed to the core when it
     * is built, so a broadcast can be locked from its very first greeting.
     */
    void setAccessMode(const QString& mode);
    void setAccessPassword(const QString& password);

    /// Forgets rejections and bans. Called when a broadcast ends, so a new broadcast starts
    /// clean and a receiver who was barred from the last one is judged fresh.
    void clearAccessHistory();

    /**
     * Answers a pending request from [Callbacks::onAccessRequest].
     *
     * @param requestKey The key from the request.
     * @param allow True to admit, false to reject. A rejection counts towards the receiver's
     *        three-rejection limit; one that happens after the limit is final and closes the
     *        connection instead of counting again.
     */
    void resolveAccessRequest(quint64 requestKey, bool allow);

    /// Binds the control socket and returns the chosen port in [error]'s caller.
    bool listen(QString* error);

    /// Stops accepting, drops every connection, and stops the thread.
    void close();

    [[nodiscard]] int port() const { return port_.load(); }
    [[nodiscard]] int receiverCount() const { return receiverCount_.load(); }

    void sendModeChanged(const QString& mode);
    void sendStats(const protocol::BroadcasterStats& stats);
    void sendKeyframeCoalesced();

    /// Tells every receiver the session is ending, then lets the writes drain.
    void closeAll(const QString& reason);

private:
    /// The object that owns the sockets and lives on [thread_]. See the class comment.
    class Core;

    Core* core_ = nullptr;
    QThread thread_;

    Callbacks callbacks_;
    std::atomic<int> maxReceivers_ {protocol::LocalStream::MaxReceiversDefault};

    /**
     * The access settings, held here so they can be set before [listen] has built a core to
     * carry them.
     *
     * Written and read only from the thread that owns this server, which is the same thread that
     * calls [listen] and [setAccessMode], so no synchronisation is needed: the core gets its own
     * copy and is the only other reader.
     */
    QString accessMode_ {QString::fromLatin1(protocol::access::Public)};
    QString accessPassword_;

    // Published by the core thread, read from the caller's thread.
    std::atomic<int> port_ {0};
    std::atomic<int> receiverCount_ {0};
};

} // namespace localstream::net
