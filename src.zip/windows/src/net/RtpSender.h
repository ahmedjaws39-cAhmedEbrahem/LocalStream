#pragma once

#include <QByteArray>
#include <QHash>
#include <QHostAddress>
#include <QMutex>
#include <QString>
#include <QUdpSocket>

#include <atomic>
#include <functional>
#include <utility>

#include "protocol/LocalStream.h"

namespace localstream::net {

/**
 * Sends RTP to every receiver that has offered ports.
 *
 * Unicast only, one socket per track, bound to port 0. The bound port is published rather
 * than chosen, so a port conflict degrades to a different port instead of a failure
 * (PROTOCOL.md section 7).
 */
class RtpSender
{
public:
    struct Target
    {
        QHostAddress address;
        int audioPort = 0;
        int videoPort = 0; // 0 in audio-only
    };

    RtpSender();
    ~RtpSender();

    RtpSender(const RtpSender&) = delete;
    RtpSender& operator=(const RtpSender&) = delete;

    [[nodiscard]] bool open(bool withVideo, QString* error);
    void close();

    [[nodiscard]] int audioPort() const { return audioPort_; }
    [[nodiscard]] int videoPort() const { return videoPort_; }

    [[nodiscard]] quint32 audioSsrc() const { return audioSsrc_; }
    [[nodiscard]] quint32 videoSsrc() const { return videoSsrc_; }

    void setFrameRate(int framesPerSecond);

    /**
     * Sets the largest RTP payload, in bytes, the video packetiser may emit.
     *
     * This is the fragmentation budget: a NAL larger than this is split into FU-A packets, and
     * a smaller budget means more, smaller datagrams. Lowering it helps a lossy link (a lost
     * datagram costs less of a picture and IP-level fragmentation is avoided); raising it cuts
     * the packet rate. Clamped to a usable range; safe to call before or during a broadcast.
     */
    void setMaxPayload(int bytes);

    /**
     * Controls how a large access unit's burst is spread across the frame time.
     *
     * A frame that fragments into at least [thresholdPackets] packets is paced; [spreadFrames]
     * multiplies how long the burst may take, so a value above 1 trades a little latency for a
     * gentler peak rate. [thresholdPackets] of 1 paces every video frame.
     */
    void setPacing(int thresholdPackets, int spreadFrames);

    /// The largest payload, in bytes, of the most recently sent video access unit.
    [[nodiscard]] int lastAccessUnitLargestPayload() const;
    /// How many RTP packets the most recent video access unit became.
    [[nodiscard]] int lastAccessUnitPacketCount() const;
    /// How many of those packets were FU-A fragments.
    [[nodiscard]] int lastAccessUnitFragmentCount() const;

    void addTarget(const Target& target);
    void removeTarget(const QHostAddress& address, int audioPort, int videoPort);
    void removeAllTargets();
    [[nodiscard]] int targetCount() const;

    /// One Opus packet; per RFC 7587 the payload is the packet itself, with no OpusHead.
    void sendAudio(const QByteArray& frame);

    /// One access unit in AVCC form, as an encoder emits it.
    void sendVideo(const QByteArray& accessUnit);

    /// Datagrams the OS refused to queue, since the last [close].
    [[nodiscard]] int sendFailureCount() const;

    /// Forces an IDR on the next encoded frame, via the encoder's out-of-band request.
    void setKeyframeRequestHook(std::function<void()> hook) { keyframeHook_ = std::move(hook); }
    void requestKeyframe();

    /**
     * The bitrate actually achieving, averaged over roughly a second.
     *
     * Averaged rather than instantaneous: a per-frame figure would flicker faster than it
     * could be read aloud by a screen reader.
     */
    [[nodiscard]] int currentBitrateKbps() const;

private:
    /// `isVideo` selects which port of each target the datagram goes to.
    /// Not const: QUdpSocket::writeDatagram has a non-const receiver, and a const socket here
    /// would only be achievable by mutating through a const_cast.
    void broadcast(QUdpSocket& socket, const QByteArray& packet, bool isVideo);

    QUdpSocket audioSocket_;
    QUdpSocket videoSocket_;
    int audioPort_ = 0;
    int videoPort_ = 0;

    quint32 audioSsrc_ = 0;
    quint32 videoSsrc_ = 0;

    quint16 audioSequence_ = 0;
    quint16 videoSequence_ = 0;
    quint32 audioTimestamp_ = 0;
    quint32 videoTimestamp_ = 0;

    // 90 kHz ticks per frame. Recomputed whenever the frame rate changes.
    quint32 frameDuration90kHz_ = 3000;

    // Fragmentation and pacing, read from the video thread on every access unit. Atomic rather
    // than mutex-guarded: they are independent scalars written by the GUI thread while a frame
    // is being packetised, and a torn read of any one of them is not a state a mutex would
    // prevent anyway.
    std::atomic<int> maxPayload_ {protocol::LocalStream::RtpMaxPayload};
    std::atomic<int> pacingThresholdPackets_ {8};
    std::atomic<int> pacingSpreadFrames_ {1};

    // Reported to the UI through the engine's statistics tick. Written on the video thread,
    // read on the GUI thread; each is a single value, so the last frame's shape is all that is
    // ever shown.
    std::atomic<int> lastAccessUnitLargestPayload_ {0};
    std::atomic<int> lastAccessUnitPacketCount_ {0};
    std::atomic<int> lastAccessUnitFragmentCount_ {0};

    QHash<QString, Target> targets_;
    mutable QMutex targetsMutex_;

    std::atomic<bool> running_ {false};
    std::atomic<quint64> bytesSent_ {0};
    std::atomic<quint64> sendFailures_ {0};

    // Sampling state is mutable so the const bitrate query can advance the window: a caller
    // polling a statistic should not have to be handed a mutable object to do it.
    mutable QMutex rateMutex_;
    mutable qint64 lastRateSampleAt_ = 0;
    mutable quint64 lastRateSampleBytes_ = 0;
    mutable int lastBitrateKbps_ = 0;

    std::function<void()> keyframeHook_;
};

} // namespace localstream::net
