#pragma once

#include <QByteArray>
#include <QHostAddress>
#include <QMutex>
#include <QString>
#include <QThread>
#include <QUdpSocket>

#include <atomic>
#include <functional>
#include <memory>

namespace localstream::net {

class MediaWorker;

/**
 * Receives RTP from one broadcaster and emits frames ready for the decoders.
 *
 * Both sockets live in one dedicated event loop, driven by their `readyRead` signals. That
 * is what keeps a busy audio stream from starving video: with blocking reads a single thread
 * would sit in the audio receive and never touch the video queue, but with a selector-based
 * loop each socket is dispatched independently, so neither can hold the other up.
 *
 * Audio passes through a small reorder buffer, because one reordered Opus packet is
 * audibly damaging. Video has no reorder buffer at all: a late frame is worthless, and
 * buffering it would display a picture that is already stale.
 *
 * Not a QObject: it owns its worker thread explicitly, because the sockets must be created,
 * used and destroyed on that one thread and never touched from the GUI thread.
 */
class RtpReceiver
{
public:
    struct Ports
    {
        int audio = 0;
        int video = 0;
    };

    /// Counters surfaced to the user and reported to the broadcaster once a second.
    struct Stats
    {
        quint64 audioPackets = 0;
        quint64 videoPackets = 0;
        quint64 lostPackets = 0;
        quint64 keyframeRequests = 0;
        double jitterMillis = 0.0;
        /// Most audio packets delivered by a single socket wake-up. A value above one means the
        /// network coalesced them, which is what a downstream jitter buffer has to absorb.
        quint64 audioMaxBurst = 0;
        /// Whether the parameter sets have arrived. Without them no decoder can be opened, and
        /// it is the difference between "no picture because the network is silent" and "no picture
        /// because nothing said how to decode it".
        bool haveVideoParameters = false;
    };

    RtpReceiver();
    ~RtpReceiver();

    RtpReceiver(const RtpReceiver&) = delete;
    RtpReceiver& operator=(const RtpReceiver&) = delete;

    /**
     * Opens the media sockets before the caller sends its `offer`, so no packet can arrive
     * before there is somewhere to put it.
     */
    bool open(bool withVideo, QString* error);
    void close();

    /// Installs the media endpoint and SSRC values negotiated on the control connection.
    bool setExpectedSource(const QHostAddress& address, int audioPort, quint32 audioSsrc,
        int videoPort, quint32 videoSsrc);

    [[nodiscard]] bool isOpen() const { return running_.load(std::memory_order_acquire); }
    [[nodiscard]] Ports ports() const { return ports_; }
    [[nodiscard]] Stats stats() const;

    void noteKeyframeRequest();

    /// Both handlers are called on the media thread, never the GUI thread.
    using AudioHandler = std::function<void(const QByteArray&)>;
    using VideoHandler = std::function<void(const QByteArray&, const QByteArray&, const QByteArray&)>;

    void setAudioHandler(AudioHandler handler);
    void setVideoHandler(VideoHandler handler);

private:
    friend class MediaWorker;

    [[nodiscard]] AudioHandler audioHandler() const;
    [[nodiscard]] VideoHandler videoHandler() const;
    [[nodiscard]] bool matchesExpectedSource(const QHostAddress& address, quint16 port,
        bool isAudio, quint32 ssrc) const;

    struct ExpectedSource
    {
        QHostAddress address;
        quint16 audioPort = 0;
        quint16 videoPort = 0;
        quint32 audioSsrc = 0;
        quint32 videoSsrc = 0;
        bool configured = false;
    };

    std::unique_ptr<QThread> thread_;
    std::unique_ptr<MediaWorker> worker_;
    Ports ports_;
    std::atomic<bool> running_ {false};

    mutable QMutex statsMutex_;
    Stats stats_;
    qint64 lastAudioSequence_ = -1;
    qint64 lastVideoSequence_ = -1;
    qint64 lastArrivalMs_ = 0;

    mutable QMutex handlerMutex_;
    AudioHandler audioHandler_;
    VideoHandler videoHandler_;

    mutable QMutex sourceMutex_;
    ExpectedSource expectedSource_;
};

} // namespace localstream::net
