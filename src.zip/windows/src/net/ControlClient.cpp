#include "net/ControlClient.h"

#include "logging/Log.h"

namespace localstream::net {

namespace {

/// A `hello`/`offer`/stats line is tiny; anything larger is not this protocol.
constexpr int MaxLineBytes = 64 * 1024;

} // namespace

ControlClient::ControlClient(QObject* parent) : QObject(parent)
{
    // Nagle would coalesce a `hello` and the `offer` that follows it into one segment, adding
    // a round trip to every connection. The control channel is request/response, so latency
    // matters more than packet count.
    socket_.setSocketOption(QAbstractSocket::LowDelayOption, 1);

    connect(&socket_, &QTcpSocket::connected, this, &ControlClient::onConnected);
    connect(&socket_, &QTcpSocket::readyRead, this, &ControlClient::onReadyRead);
    connect(&socket_, &QTcpSocket::disconnected, this, &ControlClient::onDisconnected);
    connect(&socket_, &QTcpSocket::errorOccurred, this, &ControlClient::onSocketError);

    handshakeTimer_.setSingleShot(true);
    connect(&handshakeTimer_, &QTimer::timeout, this, &ControlClient::onHandshakeTimeout);
}

ControlClient::~ControlClient() = default;

QString ControlClient::userAgent()
{
    return QStringLiteral("LocalStream-Windows/1.0.0");
}

QString ControlClient::blockedMessage()
{
    return QStringLiteral("The broadcaster rejected you. Do not try again.");
}

void ControlClient::setState(State state)
{
    if (state_ == state) {
        return;
    }
    state_ = state;
    emit stateChanged(state);
}

void ControlClient::connectToBroadcaster(const QString& host, int controlPort,
    const QString& receiverName, int audioPort, int videoPort)
{
    disconnectFromBroadcaster();
    resetSession();
    terminal_ = false;

    setState(State::Connecting);

    sessionId_.clear();
    broadcasterName_.clear();
    receiverName_ = receiverName;
    offeredAudioPort_ = audioPort;
    offeredVideoPort_ = videoPort;

    // The timer starts before connecting, not after: a host that silently drops packets never
    // calls connected(), so a timer armed only post-connect would never fire. This one
    // therefore covers "could not reach the broadcaster" as well as a stalled handshake.
    handshakeTimer_.start(handshakeTimeoutMs_);

    // Returns void; failure arrives later as errorOccurred, and as this timer if the host
    // never answers at all.
    socket_.connectToHost(host, static_cast<quint16>(controlPort));
}

void ControlClient::onConnected()
{
    // The socket is up; the handshake proper is `hello` -> `welcome` -> `offer` -> `accept`.
    stage_ = Stage::AwaitingWelcome;
    handshakeTimer_.start(handshakeTimeoutMs_);
    logging::event(QStringLiteral("control.connected"),
        {{QStringLiteral("peer"), socket_.peerAddress().toString()},
            {QStringLiteral("peerPort"), QString::number(socket_.peerPort())},
            {QStringLiteral("name"), receiverName_},
            {QStringLiteral("audioPort"), QString::number(offeredAudioPort_)},
            {QStringLiteral("videoPort"), QString::number(offeredVideoPort_)}});
    send(protocol::Hello {protocol::LocalStream::ProtocolVersion, QStringLiteral("receiver"),
        receiverName_, userAgent()});
}

void ControlClient::onReadyRead()
{
    readBuffer_.append(socket_.readAll());
    if (readBuffer_.size() > MaxLineBytes && readBuffer_.indexOf('\n') < 0) {
        fail(QStringLiteral("The broadcaster sent a line that is too long to be valid."));
        return;
    }

    for (;;) {
        const int newline = readBuffer_.indexOf('\n');
        if (newline < 0) {
            break;
        }
        const QByteArray line = readBuffer_.left(newline);
        readBuffer_.remove(0, newline + 1);
        if (line.trimmed().isEmpty()) {
            continue;
        }

        const protocol::ControlMessage message = protocol::parse(line);
        if (std::holds_alternative<std::monostate>(message)) {
            continue; // unknown or malformed; ignored, per PROTOCOL.md section 4.2
        }
        if (!handleMessage(message)) {
            return; // the message tore the connection down
        }
    }
}

bool ControlClient::handleMessage(const protocol::ControlMessage& message)
{
    // `deny` and `bye` end the session in every stage, so they are checked first.
    if (const auto* deny = std::get_if<protocol::Deny>(&message)) {
        // A `blocked` deny is terminal and is told apart from an ordinary rejection, because the
        // remedy differs: one is worth retrying after a word with the broadcaster, the other is
        // exactly the case where retrying must not be offered.
        if (deny->code == QLatin1String(protocol::deny::Blocked)) {
            const QString reason = deny->reason.isEmpty() ? blockedMessage() : deny->reason;
            teardown();
            setState(State::Blocked);
            // Only `ended` here. The state change is what raises the terminal `blocked` signal,
            // and a handshake failure on top of it would give the viewer two dialogs about one
            // refusal - one saying not now, the other saying could not connect - with the
            // second one hiding the answer to the question they actually asked.
            emit ended(reason, false);
            return false;
        }
        const QString reason = deny->reason;
        teardown();
        setState(State::Rejected);
        emit handshakeFailed(reason);
        emit ended(reason, false);
        return false;
    }
    if (const auto* bye = std::get_if<protocol::Bye>(&message)) {
        const QString reason = bye->reason.isEmpty()
            ? QString::fromLatin1(protocol::bye::UserLeft)
            : bye->reason;
        teardown();
        setState(State::Disconnected);
        // A goodbye is the broadcaster stopping on purpose, so this is a clean end rather than
        // a handshake failure. Emitting handshakeFailed here would show the viewer an error
        // dialog for something that is not an error.
        emit ended(reason, true);
        return false;
    }

    if (stage_ == Stage::AwaitingWelcome) {
        const auto* welcome = std::get_if<protocol::Welcome>(&message);
        if (!welcome) {
            return true; // out of order; the timeout will catch a genuinely stuck handshake
        }
        broadcasterName_ = welcome->displayName;
        mode_ = welcome->mode;
        sessionId_ = welcome->sessionId;
        // Held, not parsed here: the accept arrives on a later line, and re-parsing the whole
        // SDP at that point would be work done twice for one field.
        welcomeSdp_ = welcome->sdp;
        // Normalised, so a value this build does not know cannot select a branch below. An
        // older broadcaster omits the field, which reads as public -- see accessModeOrPublic.
        accessMode_ = protocol::accessModeOrPublic(welcome->access);
        // Stopped here and re-armed only on the branch that hands the next move back to the
        // broadcaster. Below this point the connection is waiting on a person, and the timer
        // would otherwise fail a viewer for typing slowly or a broadcaster for answering late.
        handshakeTimer_.stop();

        // The sockets were bound before this connection was made, so the ports are real and can
        // be offered the instant this session is allowed to.
        if (accessMode_ == QLatin1String(protocol::access::Password)) {
            // Asked before anything is offered, so a wrong password costs a round trip rather
            // than waking the encoder for a viewer that will be refused.
            stage_ = Stage::AwaitingAuthResult;
            setState(State::AwaitingPassword);
            emit passwordRequired(broadcasterName_);
            return true;
        }
        if (accessMode_ == QLatin1String(protocol::access::Approval)) {
            stage_ = Stage::AwaitingAccept;
            sendOffer();
            setState(State::AwaitingApproval);
            emit accessRequested(broadcasterName_);
            return true;
        }

        sendOffer();
        stage_ = Stage::AwaitingAccept;
        handshakeTimer_.start(handshakeTimeoutMs_);
        return true;
    }

    if (stage_ == Stage::AwaitingAuthResult) {
        const auto* result = std::get_if<protocol::AuthResult>(&message);
        if (!result) {
            return true;
        }
        if (!result->granted) {
            // The session is left open on purpose: a mistyped password should not cost a
            // reconnect, and the prompt is already on screen to take the correction.
            emit passwordRejected(result->reason);
            return true;
        }
        sendOffer();
        stage_ = Stage::AwaitingAccept;
        handshakeTimer_.start(handshakeTimeoutMs_);
        return true;
    }

    // An approval-mode offer is answered by an `accept` or a `deny`, both handled above, so this
    // stage behaves the same whether the answer came instantly or after the user decided.
    if (stage_ == Stage::AwaitingAccept) {
        const auto* accept = std::get_if<protocol::Accept>(&message);
        if (!accept) {
            return true;
        }
        handshakeTimer_.stop();
        stage_ = Stage::Done;

        Handshake handshake;
        handshake.audioPort = accept->audioPort;
        handshake.audioSsrc = accept->audioSsrc;
        handshake.videoSsrc = accept->videoSsrc;
        handshake.peerAddress = socket_.peerAddress();
        // Taken from the welcome's SDP rather than the accept: the accept carries the ports, but
        // the SDP is where the audio format is described, and the accept has no channel count to
        // carry one.
        handshake.audioChannels = protocol::LocalStream::audioChannelsFromSdp(welcomeSdp_);
        // A receiver that offered no video port is in an audio-only session; zero means the
        // video decoder must not be started at all.
        handshake.videoPort = offeredVideoPort_ > 0 ? accept->videoPort : 0;

        setState(State::Connected);
        emit handshakeSucceeded(handshake);
        return true;
    }

    if (stage_ != Stage::Done) {
        return true;
    }

    if (const auto* mode = std::get_if<protocol::ModeChanged>(&message)) {
        mode_ = mode->mode;
        emit modeChanged(mode->mode);
        return true;
    }
    if (const auto* stats = std::get_if<protocol::BroadcasterStats>(&message)) {
        emit broadcasterStatsReceived(*stats);
        return true;
    }
    if (std::holds_alternative<protocol::KeyframeCoalesced>(message)) {
        emit keyframeCoalesced();
        return true;
    }
    return true;
}

void ControlClient::sendOffer()
{
    send(protocol::Offer {sessionId_, offeredAudioPort_, offeredVideoPort_});
}

void ControlClient::submitPassword(const QString& password)
{
    if (stage_ != Stage::AwaitingAuthResult) {
        return;
    }
    send(protocol::AuthRequest {sessionId_, password});
}

void ControlClient::cancelPasswordPrompt()
{
    // Leaves through the normal teardown, so the broadcaster withdraws the half-finished
    // session itself rather than being left to time out a connection nobody is using.
    if (stage_ == Stage::AwaitingAuthResult && state_ == State::AwaitingPassword) {
        disconnectFromBroadcaster();
    }
}

void ControlClient::send(const protocol::ControlMessage& message)
{
    const QByteArray line = protocol::encode(message);
    if (line.isEmpty() || socket_.state() != QAbstractSocket::ConnectedState) {
        return;
    }
    socket_.write(line);
}

void ControlClient::requestKeyframe()
{
    send(protocol::KeyframeRequest {sessionId_});
}

void ControlClient::requestBitrate(int videoKbps, int audioKbps)
{
    send(protocol::BitrateRequest {videoKbps, audioKbps});
}

void ControlClient::requestMode(const QString& mode)
{
    send(protocol::ModeRequest {mode});
}

void ControlClient::sendStats(const protocol::ReceiverStats& stats)
{
    send(stats);
}

void ControlClient::onHandshakeTimeout()
{
    // Reached only from states the broadcaster drives. A password prompt and an approval wait
    // both stop the timer when they begin (see handleMessage), because the next move belongs to a
    // person rather than to the network, and a viewer who is still typing is not stuck.
    if (stage_ == Stage::Done) {
        return;
    }
    // Distinguish the two halves, because the fix differs: no `welcome` means the host was
    // wrong, no `accept` means the media ports were refused.
    if (stage_ == Stage::AwaitingWelcome) {
        fail(QStringLiteral("The broadcaster did not send a greeting."));
    } else {
        fail(QStringLiteral("The broadcaster did not accept the media ports."));
    }
}

void ControlClient::onDisconnected()
{
    if (state_ == State::Idle || terminal_) {
        return;
    }
    const bool duringHandshake = stage_ != Stage::Done;
    const QString reason = QStringLiteral("The broadcaster closed the connection.");
    resetSession();
    setState(State::Disconnected);
    if (duringHandshake) {
        emit handshakeFailed(reason);
    } else {
        // The broadcaster hung up the socket. That is an orderly end from the viewer's point of
        // view, not a transport error, so it does not raise a dialog.
        emit ended(reason, true);
    }
}

void ControlClient::onSocketError()
{
    if (state_ == State::Idle) {
        return;
    }
    const QString reason = QStringLiteral("Could not reach the broadcaster: %1")
                               .arg(socket_.errorString());
    logging::error(QStringLiteral("ControlClient"),
        QStringLiteral("control.socket.error: %1 (%2)")
            .arg(socket_.errorString(), socket_.error() == QAbstractSocket::RemoteHostClosedError
                                              ? QStringLiteral("remote closed")
                                              : QStringLiteral("socket error")));
    const bool duringHandshake = stage_ != Stage::Done;
    teardown();
    setState(State::Failed);
    if (duringHandshake) {
        emit handshakeFailed(reason);
    } else {
        // A socket error mid-session is a real failure: the viewer is told why.
        emit ended(reason, false);
    }
}

void ControlClient::disconnectFromBroadcaster()
{
    if (socket_.state() == QAbstractSocket::ConnectedState) {
        // Tell the broadcaster first so it withdraws our RTP target immediately instead of
        // waiting for a TCP timeout.
        send(protocol::Bye {QString::fromLatin1(protocol::bye::UserLeft)});
        socket_.flush();
    }
    resetSession();
    terminal_ = true;
    // Idle before the abort, not after it. abort() delivers disconnected() synchronously, and
    // onDisconnected() treats anything other than Idle as the broadcaster hanging up: a local
    // Disconnect would otherwise report "the broadcaster closed the connection" back at the
    // user who pressed the button.
    setState(State::Idle);
    socket_.abort();
}

void ControlClient::fail(const QString& reason)
{
    // Every refusal the receiver can hit during the handshake ends here, so this is the one
    // place that has to write it down: "could not connect" on its own says nothing about which
    // of the half-dozen reasons it was.
    logging::error(QStringLiteral("ControlClient"),
        QStringLiteral("control.handshake.failed: %1").arg(reason));
    teardown();
    setState(State::Failed);
    emit handshakeFailed(reason);
}

void ControlClient::resetSession()
{
    handshakeTimer_.stop();
    stage_ = Stage::None;
    readBuffer_.clear();
}

void ControlClient::teardown()
{
    resetSession();
    terminal_ = true;
    socket_.abort();
}

} // namespace localstream::net
