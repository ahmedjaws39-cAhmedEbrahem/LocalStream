#include "net/RtpSender.h"

#include <QDateTime>
#include <QElapsedTimer>
#include <QHostAddress>
#include <QMutexLocker>
#include <QRandomGenerator>
#include <QThread>

#include "logging/Log.h"

#include "protocol/H264Rtp.h"
#include "protocol/LocalStream.h"
#include "protocol/Rtp.h"

namespace localstream::net {

namespace {

QString targetKey(const QHostAddress& address, int audioPort, int videoPort)
{
    return address.toString() + QLatin1Char(':') + QString::number(audioPort) + QLatin1Char('/')
        + QString::number(videoPort);
}

/// A generator that can only wrap after 65536 packets, i.e. every 36 minutes at 30 fps.
quint16 nextSequence(quint16& value)
{
    ++value;
    return value;
}

quint32 randomSsrc()
{
    // A non-zero, non-identifying value. The spec only requires it to be a synchronisation
    // source identifier that is constant for the life of the session.
    return QRandomGenerator::global()->generate() & 0x7FFFFFFFU;
}

} // namespace

RtpSender::RtpSender()
    : audioSsrc_(randomSsrc()), videoSsrc_(randomSsrc())
{
}

RtpSender::~RtpSender()
{
    close();
}

bool RtpSender::open(bool withVideo, QString* error)
{
    if (running_.load(std::memory_order_acquire)) {
        return true;
    }

    if (!audioSocket_.bind(QHostAddress::AnyIPv4, 0, QUdpSocket::ShareAddress)) {
        if (error) {
            *error = QStringLiteral("Could not bind the audio socket: %1").arg(audioSocket_.errorString());
        }
        return false;
    }
    audioPort_ = audioSocket_.localPort();

    if (withVideo) {
        if (!videoSocket_.bind(QHostAddress::AnyIPv4, 0, QUdpSocket::ShareAddress)) {
            if (error) {
                *error = QStringLiteral("Could not bind the video socket: %1").arg(videoSocket_.errorString());
            }
            audioSocket_.close();
            audioPort_ = 0;
            return false;
        }
        videoPort_ = videoSocket_.localPort();
    }

    // The OS default send buffer (as little as 8 KiB on Windows) overflows in the middle of a
    // keyframe burst - a STAP-A plus several FU-A datagrams go out back to back, faster than the
    // network can drain them - and the kernel then drops packets silently. A receiver sees that
    // as periodic ~30-packet gaps exactly on the keyframe cadence, which destroys every IDR and
    // leaves the decoder with nothing. Give both sockets a buffer big enough to hold a whole
    // keyframe's burst plus slack.
    audioSocket_.setSocketOption(
        QAbstractSocket::SendBufferSizeSocketOption, 4 * 1024 * 1024);
    videoSocket_.setSocketOption(
        QAbstractSocket::SendBufferSizeSocketOption, 4 * 1024 * 1024);

    running_.store(true, std::memory_order_release);
    return true;
}

void RtpSender::close()
{
    if (!running_.exchange(false)) {
        return;
    }
    audioSocket_.close();
    videoSocket_.close();
    removeAllTargets();
    audioPort_ = 0;
    videoPort_ = 0;

    // Reset the rate sampler too. Left as-is, a restart within the same sampling window would
    // divide the new session's byte count by the old one and report a wildly wrong bitrate
    // for up to a second.
    sendFailures_.store(0, std::memory_order_relaxed);
    lastAccessUnitLargestPayload_.store(0, std::memory_order_relaxed);
    lastAccessUnitPacketCount_.store(0, std::memory_order_relaxed);
    lastAccessUnitFragmentCount_.store(0, std::memory_order_relaxed);
    QMutexLocker locker(&rateMutex_);
    lastRateSampleAt_ = 0;
    lastRateSampleBytes_ = 0;
    lastBitrateKbps_ = 0;
}

void RtpSender::setFrameRate(int framesPerSecond)
{
    const int rate = qBound(1, framesPerSecond, 240);
    QMutexLocker locker(&rateMutex_);
    frameDuration90kHz_ = static_cast<quint32>(protocol::LocalStream::VideoClockRate / rate);
}

void RtpSender::setMaxPayload(int bytes)
{
    // The lower bound keeps the FU-A header and indicator meaningful; the upper keeps a
    // datagram inside a standard 1500-byte Ethernet MTU once IP, UDP and RTP headers are added.
    maxPayload_.store(qBound(400, bytes, 1400), std::memory_order_relaxed);
}

void RtpSender::setPacing(int thresholdPackets, int spreadFrames)
{
    pacingThresholdPackets_.store(qBound(1, thresholdPackets, 128), std::memory_order_relaxed);
    pacingSpreadFrames_.store(qBound(1, spreadFrames, 8), std::memory_order_relaxed);
}

int RtpSender::lastAccessUnitLargestPayload() const
{
    return lastAccessUnitLargestPayload_.load(std::memory_order_relaxed);
}

int RtpSender::lastAccessUnitPacketCount() const
{
    return lastAccessUnitPacketCount_.load(std::memory_order_relaxed);
}

int RtpSender::lastAccessUnitFragmentCount() const
{
    return lastAccessUnitFragmentCount_.load(std::memory_order_relaxed);
}

void RtpSender::addTarget(const Target& target)
{
    QMutexLocker locker(&targetsMutex_);
    targets_.insert(targetKey(target.address, target.audioPort, target.videoPort), target);
}

void RtpSender::removeTarget(const QHostAddress& address, int audioPort, int videoPort)
{
    QMutexLocker locker(&targetsMutex_);
    targets_.remove(targetKey(address, audioPort, videoPort));
}

void RtpSender::removeAllTargets()
{
    QMutexLocker locker(&targetsMutex_);
    targets_.clear();
}

int RtpSender::targetCount() const
{
    QMutexLocker locker(&targetsMutex_);
    return static_cast<int>(targets_.size());
}

void RtpSender::sendAudio(const QByteArray& frame)
{
    if (!running_.load(std::memory_order_acquire) || frame.isEmpty()) {
        return;
    }

    // The timestamp advances whether or not anyone is listening, so a receiver that joins
    // later is already in step with the audio clock.
    const quint32 timestamp = audioTimestamp_;
    audioTimestamp_ += protocol::LocalStream::OpusSamplesPerFrame;

    const QByteArray packet = protocol::Rtp::build(
        protocol::LocalStream::PayloadTypeAudio, false, nextSequence(audioSequence_), timestamp, audioSsrc_, frame);

    broadcast(audioSocket_, packet, /*isVideo=*/false);
}

void RtpSender::sendVideo(const QByteArray& accessUnit)
{
    if (!running_.load(std::memory_order_acquire)) {
        return;
    }

    const QList<QByteArray> nals = protocol::h264::splitAvcc(accessUnit);
    if (nals.isEmpty()) {
        return;
    }

    const QList<QByteArray> payloads
        = protocol::h264::packetize(nals, maxPayload_.load(std::memory_order_relaxed));

    // The shape of this frame, for the UI's packet readout. Counted here, where the payloads
    // already exist, rather than re-derived from the encoded size: STAP-A aggregation and the
    // dropped FU-A indicator byte mean the packet count is not simply size / maxPayload.
    int fragments = 0;
    int largest = 0;
    for (const QByteArray& payload : payloads) {
        largest = qMax(largest, payload.size());
        // A STAP-A may lead even when fragments follow, so the format is tested per packet. The
        // type is the low five bits of the first byte for every H.264 packet format.
        if (!payload.isEmpty()
            && (static_cast<quint8>(payload.at(0)) & 0x1F) == protocol::h264::TypeFuA) {
            ++fragments;
        }
    }
    lastAccessUnitPacketCount_.store(static_cast<int>(payloads.size()),
        std::memory_order_relaxed);
    lastAccessUnitFragmentCount_.store(fragments, std::memory_order_relaxed);
    lastAccessUnitLargestPayload_.store(largest, std::memory_order_relaxed);

    quint32 frameDuration = 0;
    {
        QMutexLocker locker(&rateMutex_);
        frameDuration = frameDuration90kHz_;
    }

    const quint32 timestamp = videoTimestamp_;
    const int lastIndex = payloads.size() - 1;

    // A keyframe is far larger than the steady-state frames and would otherwise go out as one
    // uninterruptible ~100 kB burst. The kernel send buffer - Windows caps it at 64 KiB no
    // matter what larger value is requested - cannot absorb that faster than a Wi-Fi link to a
    // phone drains it, so the tail of every burst fails with "Unable to send a message", the
    // receiver sees a truncated IDR, and the decoder never starts. Pacing spreads the burst
    // across the frame duration so the instantaneous rate stays near what the link can handle;
    // broadcast() then retries the rare datagram the buffer still rejects until it drains.
    QElapsedTimer pacing;
    pacing.start();
    for (int index = 0; index < payloads.size(); ++index) {
        // RFC 6184 section 5.1: the marker bit goes on the last payload of the access unit.
        const QByteArray packet = protocol::Rtp::build(protocol::LocalStream::PayloadTypeVideo,
            index == lastIndex, nextSequence(videoSequence_), timestamp, videoSsrc_, payloads.at(index));
        broadcast(videoSocket_, packet, /*isVideo=*/true);
        // Only genuinely large access units need pacing: for the one-packet frames the target
        // slot is essentially the current instant, and the extra wakeups just cost CPU.
        if (static_cast<int>(payloads.size())
            >= pacingThresholdPackets_.load(std::memory_order_relaxed)) {
            const int spread = pacingSpreadFrames_.load(std::memory_order_relaxed);
            const qint64 frameNanos = static_cast<qint64>(frameDuration) * 1000000000LL
                / protocol::LocalStream::VideoClockRate;
            const qint64 burstNanos = frameNanos * qMax(1, spread);
            const qint64 targetNanos
                = static_cast<qint64>(index + 1) * burstNanos / payloads.size();
            while (pacing.nsecsElapsed() < targetNanos - 100000) {
                QThread::usleep(50);
            }
        }
    }
    videoTimestamp_ += frameDuration;
}

void RtpSender::requestKeyframe()
{
    if (keyframeHook_) {
        keyframeHook_();
    }
}

void RtpSender::broadcast(QUdpSocket& socket, const QByteArray& packet, bool isVideo)
{
    QList<Target> snapshot;
    {
        QMutexLocker locker(&targetsMutex_);
        snapshot = targets_.values();
    }
    if (snapshot.isEmpty()) {
        return;
    }

    for (const Target& target : snapshot) {
        const int destination = isVideo ? target.videoPort : target.audioPort;
        if (destination <= 0) {
            // A receiver that offered no video port is in an audio-only session; sending it
            // video would land on nothing and only cost bandwidth.
            continue;
        }
        // A "Unable to send a message" from the kernel means its send buffer is momentarily
        // full, not that the network is gone. Dropping the datagram then is what used to kill
        // the tail of every keyframe burst (the buffer is capped at 64 KiB on Windows no matter
        // what larger value is requested), which pushed a truncated IDR down the link, the
        // receiver threw it away mid-fragment, and the decoder never produced a single frame.
        // So instead of giving up, idle briefly to let the buffer drain and retry: the burst is
        // paced to spread across the frame anyway, and this only kicks in when the link is
        // genuinely slower than the encoder wants to talk. A hard cap keeps a dead link from
        // turning the encode thread into a retry spin-wait.
        bool sent = false;
        for (int attempt = 0; attempt < 8 && !sent; ++attempt) {
            if (socket.writeDatagram(packet, target.address, destination)
                == static_cast<qint64>(packet.size())) {
                // Counted per packet on the wire, so the figure matches a packet capture.
                bytesSent_.fetch_add(static_cast<quint64>(packet.size()), std::memory_order_relaxed);
                sent = true;
            } else if (attempt < 7) {
                // Let the kernel drain somewhere between a tenth of a millisecond and a
                // millisecond; that interval is where the default socket drains an entire
                // 1200-byte datagram on even a slow Wi-Fi link to a phone.
                QThread::usleep(100 * (attempt + 1));
            }
        }
        if (!sent) {
            // Only reachable when the kernel send buffer stays full across all retries, i.e. the
            // network really has gone away. Counted so a regression is visible in the session
            // log instead of silently killing keyframes.
            const qint64 dropped = sendFailures_.fetch_add(1, std::memory_order_relaxed) + 1;
            logging::debug("net.rtp.send",
                QStringLiteral("send dropped=%1 addr=%2:%3 err=%4").arg(dropped)
                    .arg(target.address.toString())
                    .arg(destination)
                    .arg(socket.errorString()));
        }
    }
}

int RtpSender::sendFailureCount() const
{
    return static_cast<int>(sendFailures_.load(std::memory_order_relaxed));
}

int RtpSender::currentBitrateKbps() const
{
    const auto now = QDateTime::currentMSecsSinceEpoch();
    quint64 total = bytesSent_.load(std::memory_order_relaxed);

    QMutexLocker locker(&rateMutex_);
    if (lastRateSampleAt_ == 0) {
        lastRateSampleAt_ = now;
        lastRateSampleBytes_ = total;
        return 0;
    }

    const double seconds = static_cast<double>(now - lastRateSampleAt_) / 1000.0;
    if (seconds < 0.5) {
        return lastBitrateKbps_;
    }

    const double bits = static_cast<double>(total - lastRateSampleBytes_) * 8.0;
    lastBitrateKbps_ = static_cast<int>(bits / 1000.0 / seconds);
    lastRateSampleAt_ = now;
    lastRateSampleBytes_ = total;
    return lastBitrateKbps_;
}

} // namespace localstream::net
