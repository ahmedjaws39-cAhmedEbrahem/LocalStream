#include "ui/Theme.h"

#include <QApplication>
#include <QColor>
#include <QGuiApplication>
#include <QPalette>
#include <QSettings>
#include <QStyle>
#include <QStyleHints>

#include <cmath>

#ifdef Q_OS_WIN
// High Contrast is a Windows setting, so the only place that can report it honestly is the
// Windows API. Included here and nowhere else in the UI so the rest of the code stays portable.
#    include <windows.h>
#endif

namespace localstream::ui {
namespace {

constexpr auto kModeKey = "ui/themeMode";

/// True when Windows is in High Contrast mode, where the OS owns every colour.
bool systemForcesColours()
{
#ifdef Q_OS_WIN
    HIGHCONTRASTW highContrast {};
    highContrast.cbSize = sizeof(highContrast);
    if (!SystemParametersInfoW(SPI_GETHIGHCONTRAST, sizeof(highContrast), &highContrast, 0)) {
        return false;
    }
    return (highContrast.dwFlags & HCF_HIGHCONTRASTON) != 0;
#else
    return false;
#endif
}

/// Relative luminance, WCAG definition, on a 0..1 scale. [colour] channels arrive from QColor
/// already normalised to 0..1, so they are not scaled again here - dividing them by 255 as well
/// would report white as black, and both the light/dark fallback and the tick below would
/// pick the wrong end.
qreal relativeLuminance(const QColor& colour)
{
    const auto channel = [](qreal value) {
        return value <= 0.04045 ? value / 12.92 : std::pow((value + 0.055) / 1.055, 2.4);
    };
    return 0.2126 * channel(colour.redF()) + 0.7152 * channel(colour.greenF())
        + 0.0722 * channel(colour.blueF());
}

bool paletteIsDark(const QPalette& palette)
{
    return relativeLuminance(palette.color(QPalette::Window)) < 0.35;
}

Palette lightPalette()
{
    Palette p;
    p.window = QStringLiteral("#EEF2F7");
    p.surface = QStringLiteral("#FFFFFF");
    p.surfaceAlt = QStringLiteral("#E5EBF4");
    p.surfacePress = QStringLiteral("#DBE3EF");
    p.text = QStringLiteral("#16202B");
    p.textMuted = QStringLiteral("#556273");
    p.border = QStringLiteral("#D2DAE6");
    p.accent = QStringLiteral("#0B5FA5");
    p.accentHover = QStringLiteral("#0E71C4");
    p.accentPress = QStringLiteral("#094E88");
    p.accentText = QStringLiteral("#FFFFFF");
    p.accentSoft = QStringLiteral("#D8E9FA");
    p.live = QStringLiteral("#157347");
    p.liveSoft = QStringLiteral("#DCF3E6");
    p.liveText = QStringLiteral("#0C5133");
    p.danger = QStringLiteral("#A3261F");
    p.dangerSoft = QStringLiteral("#FBE7E5");
    p.dangerText = QStringLiteral("#7A1B15");
    p.focus = QStringLiteral("#0B5FA5");
    p.video = QStringLiteral("#0B0E14");
    return p;
}

Palette darkPalette()
{
    Palette p;
    p.window = QStringLiteral("#0F131A");
    p.surface = QStringLiteral("#171C25");
    p.surfaceAlt = QStringLiteral("#222937");
    p.surfacePress = QStringLiteral("#2A3242");
    p.text = QStringLiteral("#E7EAF2");
    p.textMuted = QStringLiteral("#9AA6B8");
    p.border = QStringLiteral("#2C3442");
    p.accent = QStringLiteral("#79BEF8");
    p.accentHover = QStringLiteral("#9ACFFB");
    p.accentPress = QStringLiteral("#5FA9E8");
    p.accentText = QStringLiteral("#06243C");
    p.accentSoft = QStringLiteral("#1C3550");
    p.live = QStringLiteral("#4FCB8B");
    p.liveSoft = QStringLiteral("#16322A");
    p.liveText = QStringLiteral("#B9F0D4");
    p.danger = QStringLiteral("#FF9C93");
    p.dangerSoft = QStringLiteral("#3A1E1E");
    p.dangerText = QStringLiteral("#FFD9D5");
    p.focus = QStringLiteral("#79BEF8");
    p.video = QStringLiteral("#05070B");
    return p;
}

/**
 * The whole interface as one stylesheet.
 *
 * Shapes, surfaces and states live here; text colours come from the palette below, so any
 * widget the stylesheet does not name still reads correctly. Rules are ordered generic first
 * and specific last, because a later matching rule wins for the properties it sets.
 */
QString buildSheet(const Palette& p)
{
    QString sheet = QStringLiteral(R"QSS(
/* ------------------------------------------------------------------ base */
QWidget { font-size: 10.5pt; }
QWidget#mainWindow, QWidget#page { background-color: <WINDOW>; }
QToolTip {
    color: <TEXT>;
    background-color: <SURFACE>;
    border: 1px solid <BORDER>;
    border-radius: 6px;
    padding: 5px 8px;
    font-size: 9.5pt;
}

/* ------------------------------------------------------------------- text */
QLabel { background-color: transparent; color: <TEXT>; }
QLabel#pageTitle { font-size: 17pt; font-weight: 700; }
QLabel#appTitle { font-size: 16pt; font-weight: 700; }
QLabel#appSubtitle { color: <TEXTMUTED>; font-size: 9.5pt; }
QLabel#sectionHeading { font-size: 11pt; font-weight: 650; }
QLabel#hint { color: <TEXTMUTED>; font-size: 9.5pt; }
QLabel#endpoint { font-weight: 650; }
QLabel#statText { color: <TEXTMUTED>; font-size: 10pt; }
QLabel#videoPlaceholder { color: <TEXTMUTED>; font-size: 11pt; }
QWidget#hline { background-color: <BORDER>; }

/* -------------------------------------------------------------- containers */
QWidget#card {
    background-color: <SURFACE>;
    border: 1px solid <BORDER>;
    border-radius: 12px;
}
QWidget#videoSurface {
    background-color: <VIDEO>;
    border: 1px solid <BORDER>;
    border-radius: 12px;
}

/* ------------------------------------------------------------ status pills */
QWidget#statusPill, QWidget#statusPillLive, QWidget#statusPillError {
    border-radius: 15px;
    border: 1px solid <BORDER>;
    background-color: <SURFACEALT>;
}
QWidget#statusPillLive {
    background-color: <LIVESOFT>;
    border-color: <LIVE>;
}
QWidget#statusPillError {
    background-color: <DANGERSOFT>;
    border-color: <DANGER>;
}
QWidget#statusPill QLabel, QWidget#statusPillLive QLabel, QWidget#statusPillError QLabel {
    background-color: transparent;
    color: <TEXT>;
    font-weight: 650;
}
QWidget#statusPillLive QLabel { color: <LIVETEXT>; }
QWidget#statusPillError QLabel { color: <DANGERTEXT>; }

/* ---------------------------------------------------------------- buttons */
QPushButton {
    background-color: <SURFACE>;
    color: <TEXT>;
    border: 1px solid <BORDER>;
    border-radius: 8px;
    padding: 6px 14px;
}
QPushButton:hover { background-color: <SURFACEALT>; }
QPushButton:pressed { background-color: <SURFACEPRESS>; }
QPushButton:disabled {
    background-color: <WINDOW>;
    color: <TEXTMUTED>;
    border: 1px solid <BORDER>;
}
QPushButton:focus { border: 2px solid <FOCUS>; padding: 5px 13px; }
QPushButton:default { border-color: <ACCENT>; }

QPushButton#quietButton {
    background-color: transparent;
    border: 1px solid transparent;
    color: <TEXTMUTED>;
    padding: 6px 10px;
}
QPushButton#quietButton:hover {
    background-color: <SURFACEALT>;
    border-color: <BORDER>;
    color: <TEXT>;
}
QPushButton#quietButton:pressed { background-color: <SURFACEPRESS>; }
QPushButton#quietButton:disabled { background-color: transparent; border-color: transparent; }
QPushButton#quietButton:focus { border: 2px solid <FOCUS>; padding: 5px 9px; }

QPushButton#primaryButton {
    background-color: <ACCENT>;
    color: <ACCENTTEXT>;
    border: 1px solid <ACCENT>;
    font-weight: 650;
}
QPushButton#primaryButton:hover {
    background-color: <ACCENTHOVER>;
    border-color: <ACCENTHOVER>;
}
QPushButton#primaryButton:pressed {
    background-color: <ACCENTPRESS>;
    border-color: <ACCENTPRESS>;
}
QPushButton#primaryButton:disabled {
    background-color: <SURFACEALT>;
    color: <TEXTMUTED>;
    border: 1px solid <BORDER>;
}
QPushButton#primaryButton:focus { border: 2px solid <FOCUS>; padding: 5px 13px; }

QPushButton#dangerButton {
    background-color: <DANGER>;
    color: <SURFACE>;
    border: 1px solid <DANGER>;
    font-weight: 650;
}
QPushButton#dangerButton:hover { background-color: <DANGERTEXT>; border-color: <DANGERTEXT>; }
QPushButton#dangerButton:pressed { background-color: <DANGERTEXT>; border-color: <DANGERTEXT>; }
QPushButton#dangerButton:disabled {
    background-color: <SURFACEALT>;
    color: <TEXTMUTED>;
    border: 1px solid <BORDER>;
}
QPushButton#dangerButton:focus { border: 2px solid <FOCUS>; padding: 5px 13px; }

/* ------------------------------------------------------------ form fields */
QLineEdit, QSpinBox, QComboBox {
    background-color: <SURFACE>;
    color: <TEXT>;
    border: 1px solid <BORDER>;
    border-radius: 8px;
    padding: 5px 10px;
    selection-background-color: <ACCENT>;
    selection-color: <ACCENTTEXT>;
}
QLineEdit:hover, QSpinBox:hover, QComboBox:hover { border-color: <ACCENT>; }
QLineEdit:focus, QSpinBox:focus, QComboBox:focus {
    border: 2px solid <FOCUS>;
    padding: 4px 9px;
}
QLineEdit:disabled, QSpinBox:disabled, QComboBox:disabled {
    background-color: <WINDOW>;
    color: <TEXTMUTED>;
    border: 1px solid <BORDER>;
}
QLineEdit#invalid { border: 2px solid <DANGER>; padding: 4px 9px; }
QSpinBox::up-button, QSpinBox::down-button {
    width: 20px;
    border: none;
    background-color: transparent;
}
QSpinBox::up-button:hover, QSpinBox::down-button:hover { background-color: <SURFACEALT>; }
QSpinBox::up-button:disabled, QSpinBox::down-button:disabled { background-color: transparent; }
QComboBox::drop-down {
    subcontrol-origin: padding;
    subcontrol-position: top right;
    width: 26px;
    border: none;
    background-color: transparent;
}
QComboBox QAbstractItemView {
    background-color: <SURFACE>;
    color: <TEXT>;
    border: 1px solid <BORDER>;
    border-radius: 8px;
    padding: 4px;
    selection-background-color: <ACCENT>;
    selection-color: <ACCENTTEXT>;
    outline: 0;
}

/* -------------------------------------------------------------- check box */
QCheckBox { spacing: 10px; background-color: transparent; color: <TEXT>; }
QCheckBox::indicator {
    width: 19px;
    height: 19px;
    border-radius: 5px;
    border: 2px solid <BORDER>;
    background-color: <SURFACE>;
}
QCheckBox::indicator:hover { border-color: <ACCENT>; }
QCheckBox::indicator:checked {
    background-color: <ACCENT>;
    border-color: <ACCENT>;
    image: url(<TICK>);
}
QCheckBox::indicator:hover:checked {
    background-color: <ACCENTHOVER>;
    border-color: <ACCENTHOVER>;
    image: url(<TICK>);
}
QCheckBox::indicator:disabled {
    background-color: <WINDOW>;
    border-color: <BORDER>;
}
/* A disabled control still has a state, and washing the box out would hide it - so the tick
   stays and the muted label is what says the control cannot be changed right now. Placed after
   the generic :disabled rule, which would otherwise win for a box that is both. */
QCheckBox::indicator:disabled:checked {
    background-color: <ACCENT>;
    border-color: <ACCENT>;
    image: url(<TICK>);
}
QCheckBox:disabled { color: <TEXTMUTED>; }
QCheckBox:focus { color: <FOCUS>; }
QCheckBox:focus::indicator { border-color: <FOCUS>; }

/* ------------------------------------------------------------------- list */
QListWidget {
    background-color: <SURFACE>;
    color: <TEXT>;
    border: 1px solid <BORDER>;
    border-radius: 10px;
    padding: 5px;
    outline: 0;
}
QListWidget::item {
    background-color: transparent;
    color: <TEXT>;
    padding: 9px 10px;
    border-radius: 7px;
}
QListWidget::item:hover { background-color: <SURFACEALT>; }
QListWidget::item:selected { background-color: <ACCENTSOFT>; color: <TEXT>; }
QListWidget::item:selected:active { background-color: <ACCENT>; color: <ACCENTTEXT>; }
QListWidget:disabled { background-color: <WINDOW>; color: <TEXTMUTED>; }

/* ------------------------------------------------------------------- tabs */
QTabWidget::pane { border: none; background-color: transparent; }
QTabBar { background-color: transparent; }
QTabBar::tab {
    background-color: <SURFACEALT>;
    color: <TEXTMUTED>;
    border: 1px solid transparent;
    border-radius: 9px;
    margin-right: 6px;
    padding: 8px 18px;
}
QTabBar::tab:hover:!selected { color: <TEXT>; }
QTabBar::tab:selected {
    background-color: <SURFACE>;
    border: 1px solid <BORDER>;
    color: <ACCENT>;
    font-weight: 650;
}
QTabBar::tab:focus { border: 2px solid <FOCUS>; padding: 7px 17px; }

/* ------------------------------------------------------------- scroll bar */
QScrollBar:vertical { background-color: transparent; width: 12px; margin: 0; }
QScrollBar::groove:vertical { background-color: transparent; border: none; width: 12px; }
QScrollBar::handle:vertical {
    background-color: <BORDER>;
    min-height: 28px;
    border-radius: 5px;
}
QScrollBar::handle:vertical:hover { background-color: <TEXTMUTED>; }
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; width: 0; }
QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical { background-color: transparent; }
QScrollBar:horizontal { background-color: transparent; height: 12px; margin: 0; }
QScrollBar::groove:horizontal { background-color: transparent; border: none; height: 12px; }
QScrollBar::handle:horizontal {
    background-color: <BORDER>;
    min-width: 28px;
    border-radius: 5px;
}
QScrollBar::handle:horizontal:hover { background-color: <TEXTMUTED>; }
QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal { height: 0; width: 0; }
QScrollBar::add-page:horizontal, QScrollBar::sub-page:horizontal { background-color: transparent; }

/* ----------------------------------------------------------------- dialogs */
QMessageBox#messageBox { background-color: <SURFACE>; }
QMessageBox#messageBox QLabel { background-color: transparent; color: <TEXT>; }
QDialogButtonBox { background-color: transparent; }
)QSS");

    const auto replace = [&sheet](const QString& token, const QString& value) {
        sheet.replace(token, value, Qt::CaseInsensitive);
    };
    replace(QStringLiteral("<WINDOW>"), p.window);
    replace(QStringLiteral("<SURFACE>"), p.surface);
    replace(QStringLiteral("<SURFACEALT>"), p.surfaceAlt);
    replace(QStringLiteral("<SURFACEPRESS>"), p.surfacePress);
    replace(QStringLiteral("<TEXT>"), p.text);
    replace(QStringLiteral("<TEXTMUTED>"), p.textMuted);
    replace(QStringLiteral("<BORDER>"), p.border);
    replace(QStringLiteral("<ACCENT>"), p.accent);
    replace(QStringLiteral("<ACCENTHOVER>"), p.accentHover);
    replace(QStringLiteral("<ACCENTPRESS>"), p.accentPress);
    replace(QStringLiteral("<ACCENTTEXT>"), p.accentText);
    replace(QStringLiteral("<ACCENTSOFT>"), p.accentSoft);
    replace(QStringLiteral("<LIVE>"), p.live);
    replace(QStringLiteral("<LIVESOFT>"), p.liveSoft);
    replace(QStringLiteral("<LIVETEXT>"), p.liveText);
    replace(QStringLiteral("<DANGER>"), p.danger);
    replace(QStringLiteral("<DANGERSOFT>"), p.dangerSoft);
    replace(QStringLiteral("<DANGERTEXT>"), p.dangerText);
    replace(QStringLiteral("<FOCUS>"), p.focus);
    replace(QStringLiteral("<VIDEO>"), p.video);
    // The tick inside a checked box, drawn in the palette's on-accent colour: white on the light
    // palette's dark blue, ink on the dark palette's pale blue. Chosen by the contrast of the
    // colour the tick sits on rather than by a theme flag, so the two cannot drift apart.
    replace(QStringLiteral("<TICK>"),
            relativeLuminance(QColor(p.accentText)) > 0.5
                ? QStringLiteral(":/ui/check-light.png")
                : QStringLiteral(":/ui/check-dark.png"));
    return sheet;
}

/**
 * The palette that backs the stylesheet.
 *
 * Stylesheets name shapes and surfaces; everything they do not name - plain labels, native
 * scroll bars, the item views Qt draws itself, the dialogs - takes its colours from here. Both
 * have to agree, which is why they are built from the same value.
 */
QPalette buildPalette(const Palette& p, bool dark)
{
    QPalette palette = QApplication::style()->standardPalette();

    const QColor window(p.window);
    const QColor surface(p.surface);
    const QColor surfaceAlt(p.surfaceAlt);
    const QColor text(p.text);
    const QColor muted(p.textMuted);
    const QColor accent(p.accent);
    const QColor accentText(p.accentText);
    const QColor danger(p.danger);

    palette.setColor(QPalette::Window, window);
    palette.setColor(QPalette::WindowText, text);
    palette.setColor(QPalette::Base, surface);
    palette.setColor(QPalette::AlternateBase, surfaceAlt);
    palette.setColor(QPalette::Text, text);
    palette.setColor(QPalette::Button, surface);
    palette.setColor(QPalette::ButtonText, text);
    palette.setColor(QPalette::BrightText, danger);
    palette.setColor(QPalette::Highlight, accent);
    palette.setColor(QPalette::HighlightedText, accentText);
    palette.setColor(QPalette::ToolTipBase, surface);
    palette.setColor(QPalette::ToolTipText, text);
    palette.setColor(QPalette::PlaceholderText, muted);
    palette.setColor(QPalette::Link, accent);
    palette.setColor(QPalette::LinkVisited, accent);

    palette.setColor(QPalette::Disabled, QPalette::WindowText, muted);
    palette.setColor(QPalette::Disabled, QPalette::Text, muted);
    palette.setColor(QPalette::Disabled, QPalette::ButtonText, muted);
    palette.setColor(QPalette::Disabled, QPalette::Highlight, surfaceAlt);

    if (dark) {
        palette.setColor(QPalette::Light, QColor(p.border));
        palette.setColor(QPalette::Midlight, surfaceAlt);
        palette.setColor(QPalette::Mid, p.border);
        palette.setColor(QPalette::Dark, p.window);
        palette.setColor(QPalette::Shadow, QStringLiteral("#000000"));
    }
    return palette;
}

} // namespace

Theme& Theme::instance()
{
    static Theme theme;
    return theme;
}

void Theme::install(QApplication* app)
{
    app_ = app;

    const int saved = QSettings().value(kModeKey, int(ThemeMode::System)).toInt();
    mode_ = saved == int(ThemeMode::Light) ? ThemeMode::Light
        : saved == int(ThemeMode::Dark)   ? ThemeMode::Dark
                                          : ThemeMode::System;

    apply();

    // Both matter: colorSchemeChanged is the light/dark switch, and the application palette
    // change is what High Contrast and a changed system accent arrive through. Re-applying on
    // either keeps the window honest without a restart.
    if (auto* hints = app->styleHints()) {
        connect(hints, &QStyleHints::colorSchemeChanged, this,
            [this](Qt::ColorScheme) { apply(); });
    }
    app->installEventFilter(this);
}

bool Theme::eventFilter(QObject* watched, QEvent* event)
{
    Q_UNUSED(watched);
    if (event->type() == QEvent::ApplicationPaletteChange && !applying_) {
        // Only re-apply when the OS has actually taken or returned colour control: the
        // application palette also changes whenever this app sets its own, and re-entering
        // apply() from inside it is how a theme switch loops.
        if (systemForcesColours() != forced_) {
            apply();
        }
    }
    return QObject::eventFilter(watched, event);
}

ThemeMode Theme::cycleMode()
{
    mode_ = mode_ == ThemeMode::System ? ThemeMode::Light
        : mode_ == ThemeMode::Light    ? ThemeMode::Dark
                                       : ThemeMode::System;
    saveMode();
    apply();
    return mode_;
}

void Theme::apply()
{
    if (app_ == nullptr) {
        return;
    }
    applying_ = true;
    forced_ = systemForcesColours();

    const Qt::ColorScheme scheme = app_->styleHints() != nullptr
        ? app_->styleHints()->colorScheme()
        : Qt::ColorScheme::Unknown;
    bool dark = mode_ == ThemeMode::Dark
        || (mode_ == ThemeMode::System && scheme == Qt::ColorScheme::Dark);
    if (mode_ == ThemeMode::System && scheme == Qt::ColorScheme::Unknown) {
        dark = paletteIsDark(app_->palette());
    }
    dark_ = dark;
    loadPalette(dark_);

    if (forced_) {
        // Windows High Contrast wins. Withdraw every colour this app chose and let the system
        // theme paint, which is the whole point of that setting.
        app_->setStyleSheet(QString());
        app_->setPalette(QApplication::style()->standardPalette());
    } else {
        app_->setStyleSheet(buildSheet(palette_));
        app_->setPalette(buildPalette(palette_, dark_));
    }

    applying_ = false;
    emit changed(dark_);
}

void Theme::loadPalette(bool dark)
{
    palette_ = dark ? darkPalette() : lightPalette();
}

void Theme::saveMode() const
{
    QSettings().setValue(kModeKey, int(mode_));
}

} // namespace localstream::ui
