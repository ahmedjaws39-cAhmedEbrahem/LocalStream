#pragma once

#include "ui/UiKit.h"

#include <QWidget>

namespace localstream::engine {
class BroadcastEngine;
}

class QCheckBox;
class QComboBox;
class QLabel;
class QLineEdit;
class QPushButton;
class QShowEvent;
class QSpinBox;

/**
 * Broadcast tab: picks a mode and a bitrate, starts the engine, and reports what it is doing.
 *
 * The page owns the engine so that stopping and restarting is a normal state transition rather
 * than construction and destruction. A broadcast that has to tear down a live encoder to change
 * a slider is a broadcast that drops its viewers.
 *
 * Controls follow that rule exactly: the engine reads resolution, bitrate, microphone, test
 * pattern and normalisation once, at start(), so those are disabled while running rather than
 * left free to move with no effect. Only "include video" reaches a running engine through
 * setMode(), so it is the one switch that stays live.
 */
class BroadcastPage : public QWidget
{
    Q_OBJECT

public:
    explicit BroadcastPage(QWidget* parent = nullptr);
    ~BroadcastPage() override;

    /// Stops a running broadcast if there is one. Safe to call when idle.
    void stopBroadcast();

    /// True while the engine is up. Used by the window before it closes over a live session.
    [[nodiscard]] bool isBroadcastRunning() const noexcept { return running_; }

signals:
    /// Emitted whenever a broadcast starts or stops, so the controls can follow the session.
    void runningChanged(bool running);

protected:
    /// Re-reads the machine's addresses when the tab is shown: a laptop that just joined a
    /// network has a different one than it did when the window opened.
    void showEvent(QShowEvent* event) override;

private:
    void startBroadcast();
    void setRunning(bool running);
    /**
     * Reports a failure.
     *
     * [wasRunning] is what separates "the port was already taken" from "the session dropped
     * half way through", and the two say different things: one is about getting started, the
     * other is about something the viewer may already be watching end.
     */
    void showError(const QString& reason, bool wasRunning);
    /// Re-scans for microphones, keeping the selection if it is still there.
    void refreshMicrophones();
    /// One definition of "this control can still do something", shared by every place that can
    /// change it, so the running state and the test-pattern state cannot drift apart.
    void refreshControls();
    /// Rebuilds the address line, including the control port once there is one.
    void refreshEndpoint();
    /// Pushes the access controls into a running engine. A no-op while idle, where start() takes
    /// the same values from the settings it is built from.
    void applyAccess();
    /// Combo index for an access-mode constant, falling back to the first (public) entry.
    [[nodiscard]] int indexForAccessMode(const QString& mode) const;
    /// Asks the user whether [name] may watch, then answers the request either way.
    void promptForAccess(quint64 requestKey, const QString& name);

    localstream::engine::BroadcastEngine* engine_ = nullptr;
    QPushButton* startButton_ = nullptr;
    localstream::ui::StatusPill* status_ = nullptr;
    QLabel* statistics_ = nullptr;
    QLabel* endpoint_ = nullptr;
    QCheckBox* includeVideo_ = nullptr;
    QCheckBox* includeTestPattern_ = nullptr;
    QCheckBox* normalizeAudio_ = nullptr;
    QComboBox* microphone_ = nullptr;
    QPushButton* microphoneRefresh_ = nullptr;
    QComboBox* resolution_ = nullptr;
    QSpinBox* videoBitrate_ = nullptr;
    QSpinBox* audioBitrate_ = nullptr;
    QWidget* qualityCard_ = nullptr;
    QWidget* packetsCard_ = nullptr;
    QComboBox* maxPayload_ = nullptr;
    QSpinBox* pacingThreshold_ = nullptr;
    QSpinBox* pacingSpread_ = nullptr;
    QComboBox* accessMode_ = nullptr;
    QLineEdit* accessPassword_ = nullptr;
    QPushButton* accessApplyPassword_ = nullptr;
    QWidget* accessCard_ = nullptr;
    /// Label text for the password form row, so it can be re-read after the theme object is built.
    QString accessPasswordRow_;
    /**
     * The password the broadcast is currently using, held so the apply button can tell "the same
     * password again" from a real change. Cleared along with the field: the engine keeps the live
     * copy, and a page that kept its own would be a second copy to fall out of step.
     */
    QString lastAppliedPassword_;
    /// Kept so the running status can name the broadcaster without asking the engine again.
    QString displayName_;
    bool running_ = false;
};
