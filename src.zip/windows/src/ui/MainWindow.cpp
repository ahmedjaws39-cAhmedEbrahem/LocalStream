#include "ui/MainWindow.h"

#include "logging/Log.h"
#include "ui/AppSettings.h"
#include "ui/BroadcastPage.h"
#include "ui/HelpPage.h"
#include "ui/ReceivePage.h"
#include "ui/Theme.h"
#include "ui/UiKit.h"

#include <QAction>
#include <QCloseEvent>
#include <QCoreApplication>
#include <QHBoxLayout>
#include <QKeySequence>
#include <QLabel>
#include <QMenu>
#include <QMessageBox>
#include <QPushButton>
#include <QShortcut>
#include <QSystemTrayIcon>
#include <QTabWidget>
#include <QVBoxLayout>

using localstream::ui::Theme;
using localstream::ui::ThemeMode;

MainWindow::MainWindow(QWidget* parent) : QWidget(parent)
{
    setObjectName(QStringLiteral("mainWindow"));
    setWindowTitle(QStringLiteral("LocalStream"));
    // Wide enough that the Receive tab's two panes never crush each other, and a sensible
    // starting size for the Broadcast tab's single column.
    resize(980, 700);
    setMinimumSize(800, 560);

    auto* layout = new QVBoxLayout(this);
    layout->setContentsMargins(20, 16, 20, 16);
    layout->setSpacing(12);

    // ------------------------------------------------------------------ header
    auto* header = new QWidget(this);
    auto* headerLayout = new QHBoxLayout(header);
    headerLayout->setContentsMargins(0, 0, 0, 0);
    headerLayout->setSpacing(12);

    logo_ = new QLabel(header);
    logo_->setFixedSize(30, 30);
    logo_->setAlignment(Qt::AlignCenter);
    // Decorative, but a screen reader has nothing better to call it than the app's name.
    logo_->setAccessibleName(QStringLiteral("LocalStream"));
    headerLayout->addWidget(logo_);

    auto* titles = new QVBoxLayout;
    titles->setSpacing(0);
    titles->setContentsMargins(0, 0, 0, 0);

    auto* title = new QLabel(QStringLiteral("LocalStream"), header);
    title->setObjectName(QStringLiteral("appTitle"));
    titles->addWidget(title);

    auto* subtitle = new QLabel(tr("Share this computer on the network, or watch "
                                   "someone who is."),
                                header);
    subtitle->setObjectName(QStringLiteral("appSubtitle"));
    titles->addWidget(subtitle);

    headerLayout->addLayout(titles);
    headerLayout->addStretch(1);

    themeButton_ = new QPushButton(header);
    themeButton_->setObjectName(QStringLiteral("quietButton"));
    themeButton_->setCursor(Qt::PointingHandCursor);
    headerLayout->addWidget(themeButton_, 0, Qt::AlignTop);

    layout->addWidget(header);
    layout->addWidget(localstream::ui::makeHLine(this));

    // -------------------------------------------------------------------- tabs
    tabs_ = new QTabWidget(this);
    tabs_->setDocumentMode(true);

auto* broadcast = new BroadcastPage(tabs_);
    auto* receive = new ReceivePage(tabs_);
    auto* help = new HelpPage(tabs_);
    tabs_->addTab(broadcast, tr("Broadcast"));
    tabs_->addTab(receive, tr("Receive"));
    tabs_->addTab(help, tr("Help"));
    tabs_->setTabToolTip(0, tr("Share this computer's screen or audio."));
    tabs_->setTabToolTip(1, tr("Watch a broadcast from another computer."));
    tabs_->setTabToolTip(2, tr("Open the tutorial in your web browser."));
    layout->addWidget(tabs_, 1);

connect(tabs_, &QTabWidget::currentChanged, this, &MainWindow::refreshTabIcons);

    // Ctrl+1 / Ctrl+2 / Ctrl+3 reach the tabs without the pointer, and without the focus
    // having to be in the tab bar first - which it will not be, because focus goes to the
    // page's controls. The loop covers every tab, so adding one needs no change here.
    for (int index = 0; index < tabs_->count(); ++index) {
        auto* shortcut = new QShortcut(QKeySequence(Qt::CTRL | (Qt::Key_1 + index)), this);
        shortcut->setContext(Qt::WindowShortcut);
        const int target = index;
        connect(shortcut, &QShortcut::activated, this, [this, target] {
            tabs_->setCurrentIndex(target);
        });
    }

    connect(themeButton_, &QPushButton::clicked, this, [] { Theme::instance().cycleMode(); });
    connect(&Theme::instance(), &Theme::changed, this, [this](bool) {
        refreshThemeButton();
        refreshTabIcons();
        refreshTrayIcon();
    });

    refreshThemeButton();
    refreshTabIcons();
}

MainWindow::~MainWindow() = default;

void MainWindow::shutdown()
{
    // Stop the session that is actually running, not both: the inactive tab's engine was never
    // started, and asking an unstarted engine to stop is how a stopped broadcast turns into a
    // crash on exit.
    if (auto* page = qobject_cast<BroadcastPage*>(tabs_->widget(0))) {
        page->stopBroadcast();
    }
    if (auto* page = qobject_cast<ReceivePage*>(tabs_->widget(1))) {
        page->disconnectFromBroadcaster();
    }
}

QStringList MainWindow::activeSessions() const
{
    QStringList reasons;
    if (auto* page = qobject_cast<BroadcastPage*>(tabs_->widget(0))) {
        if (page->isBroadcastRunning()) {
            reasons << tr("a broadcast is running");
        }
    }
    if (auto* page = qobject_cast<ReceivePage*>(tabs_->widget(1))) {
        if (page->isConnected()) {
            reasons << tr("you are watching a broadcast");
        }
    }
    return reasons;
}

bool MainWindow::confirmExit(const QStringList& reasons)
{
    QMessageBox box(this);
    box.setObjectName(QStringLiteral("messageBox"));
    box.setAttribute(Qt::WA_StyledBackground, true);
    box.setWindowTitle(tr("Close LocalStream"));
    box.setText(tr("LocalStream is still busy: %1.").arg(
        reasons.join(tr(" and "))));
    box.setInformativeText(tr("Close the app and stop?"));
    box.setStandardButtons(QMessageBox::Yes | QMessageBox::No);
    box.setDefaultButton(QMessageBox::No);
    box.setIcon(QMessageBox::Warning);
    return box.exec() == QMessageBox::Yes;
}

void MainWindow::closeEvent(QCloseEvent* event)
{
    const QStringList reasons = activeSessions();
    // The tray's Quit asks first and then sets this flag, so the close it triggers is not
    // asked about a second time on the way out, and cannot turn into another hiding.
    const bool background = !quitting_ && localstream::ui::runInBackground();

    if (background && reasons.isEmpty()) {
        // Closing the window is not exiting: the app carries on behind the tray icon, which is
        // the whole point of the switch on the Help tab. The close itself is refused, so Qt
        // never sees a window closing and has no reason to quit on the last one.
        if (hideToTray()) {
            event->ignore();
            return;
        }
        // No tray to hide behind on this machine: fall through and exit, as it always has.
    } else if (!reasons.isEmpty() && !quitting_) {
        if (!background) {
            if (!confirmExit(reasons)) {
                event->ignore();
                return;
            }
        } else {
            // Busy *and* set to run in the background. Hiding is the useful answer, so it is
            // offered as one - but carrying on behind the user's back while a broadcast is up
            // has to be a choice, not the only outcome, which is why the exit is asked about
            // here exactly as it is when the switch is off.
            QMessageBox box(this);
            box.setObjectName(QStringLiteral("messageBox"));
            box.setAttribute(Qt::WA_StyledBackground, true);
            box.setWindowTitle(tr("Close LocalStream"));
            box.setText(tr("LocalStream is still busy: %1.")
                            .arg(reasons.join(tr(" and "))));
            box.setInformativeText(
                tr("Hide it in the system tray and keep it running, or exit and "
                   "stop?"));
            box.setIcon(QMessageBox::Warning);
            QPushButton* hideButton =
                box.addButton(tr("Hide in the system tray"), QMessageBox::AcceptRole);
            QPushButton* exitButton =
                box.addButton(tr("Exit and stop"), QMessageBox::DestructiveRole);
            QPushButton* cancelButton =
                box.addButton(tr("Cancel"), QMessageBox::RejectRole);
            box.setDefaultButton(hideButton);
            box.setEscapeButton(cancelButton);
            box.exec();

            if (box.clickedButton() == hideButton) {
                // Called even when this machine turns out to have no tray to hide behind:
                // doing the opposite of what was asked for - leaving - is worse than staying
                // put and doing nothing.
                (void)hideToTray();
                event->ignore();
                return;
            }
            if (box.clickedButton() != exitButton) {
                event->ignore();
                return;
            }
            // Exit and stop: falls through to the same shutdown every other exit uses.
        }
    }

    shutdown();
    event->accept();
}

bool MainWindow::ensureTrayIcon()
{
    if (trayIcon_ != nullptr) {
        trayIcon_->show();
        return trayIcon_->isVisible();
    }
    if (!QSystemTrayIcon::isSystemTrayAvailable()) {
        return false;
    }

    trayIcon_ = new QSystemTrayIcon(this);
    trayIcon_->setToolTip(
        tr("LocalStream is running in the background. Double-click to open it."));
    refreshTrayIcon();

    auto* menu = new QMenu(this);
    QAction* showAction = menu->addAction(tr("Show LocalStream"));
    QAction* quitAction = menu->addAction(tr("Quit"));
    connect(showAction, &QAction::triggered, this, &MainWindow::showFromTray);
    connect(quitAction, &QAction::triggered, this, &MainWindow::quitFromTray);
    trayIcon_->setContextMenu(menu);

    connect(trayIcon_, &QSystemTrayIcon::activated, this,
        [this](QSystemTrayIcon::ActivationReason reason) {
            // Double-click is the gesture this is documented as. A single click does the same
            // on Windows, where an icon beside the clock that answers nothing to a click looks
            // broken rather than reserved.
            if (reason == QSystemTrayIcon::Trigger || reason == QSystemTrayIcon::DoubleClick) {
                showFromTray();
            }
        });

    trayIcon_->show();
    return trayIcon_->isVisible();
}

bool MainWindow::hideToTray()
{
    if (!ensureTrayIcon()) {
        return false;
    }
    hide();
    localstream::logging::event(QStringLiteral("app.minimizedToTray"));
    return true;
}

void MainWindow::refreshTrayIcon()
{
    if (trayIcon_ == nullptr) {
        return;
    }
    const localstream::ui::Palette& colours = Theme::instance().palette();
    trayIcon_->setIcon(localstream::ui::broadcastIcon(QColor(colours.accent), 22));
}

void MainWindow::showFromTray()
{
    // A double-click delivers a single-click activation first, so the window is only reported
    // as restored when it actually was: one line in the log per return, not two.
    const bool wasHidden = !isVisible();
    show();
    raise();
    activateWindow();
    if (wasHidden) {
        localstream::logging::event(QStringLiteral("app.restoredFromTray"));
    }
}

void MainWindow::quitFromTray()
{
    const QStringList reasons = activeSessions();
    if (!reasons.isEmpty() && !confirmExit(reasons)) {
        return;
    }
    // closeEvent sees this flag and exits for real instead of hiding the window behind the
    // tray again, and does not ask the question that was just answered here.
    quitting_ = true;
    if (isVisible()) {
        close();
        return;
    }
    // Quit is picked from the tray precisely when the window is hidden, and Qt sends a close
    // event only to a window that is open: closing here would do nothing and leave the
    // process running with no window at all. So the exit is finished by hand, in the order
    // closeEvent would have done it - stop the pages, then leave the event loop, which is
    // what makes main() log the stop and close the log file.
    shutdown();
    QCoreApplication::quit();
}

void MainWindow::refreshTabIcons()
{
    const localstream::ui::Palette& colours = Theme::instance().palette();
    const QColor selected(colours.accent);
    const QColor idle(colours.textMuted);
    const int current = tabs_->currentIndex();
    tabs_->setTabIcon(0, localstream::ui::broadcastIcon(current == 0 ? selected : idle));
    tabs_->setTabIcon(1, localstream::ui::receiveIcon(current == 1 ? selected : idle));
    tabs_->setTabIcon(2, localstream::ui::helpIcon(current == 2 ? selected : idle));
}

void MainWindow::refreshThemeButton()
{
    const ThemeMode mode = Theme::instance().mode();
    const localstream::ui::Palette& colours = Theme::instance().palette();

    const QString text = mode == ThemeMode::System ? tr("Theme: follow system")
        : mode == ThemeMode::Light                 ? tr("Theme: light")
                                                   : tr("Theme: dark");
    const bool locked = Theme::instance().systemForcesColours();

    themeButton_->setText(locked ? text + tr(" (Windows decides)")
                                 : text);
    themeButton_->setIcon(localstream::ui::themeIcon(mode, QColor(colours.textMuted), 18));
    themeButton_->setToolTip(
        locked
            ? tr("Windows High Contrast is on, so it decides the colours. "
                 "Click to keep the preference for when it switches off.")
            : tr("Switch to the next colour theme. Ctrl+1 and Ctrl+2 switch tabs."));
    logo_->setPixmap(localstream::ui::broadcastIcon(QColor(colours.accent), 26)
                         .pixmap(logo_->size()));
}
