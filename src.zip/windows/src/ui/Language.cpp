#include "ui/Language.h"

#include "logging/Log.h"

#include <QApplication>
#include <QCoreApplication>
#include <QFile>
#include <QLocale>
#include <QProcess>
#include <QSettings>
#include <QTranslator>

#include <iterator>

namespace localstream::ui {
namespace {

/// The key the choice is stored under, beside the theme mode and the other app-wide switches.
constexpr auto kLanguageKey = "ui/language";

/// One entry per language with a translation. Kept in step with `windows/translations/` and with
/// `docs/TRANSLATING.md`, which documents both this table and the wording to use.
const Language kLanguages[] = {
    {QStringLiteral("en"), QStringLiteral("English")},
    {QStringLiteral("ar"), QStringLiteral("العربية")},
    {QStringLiteral("fr"), QStringLiteral("Français")},
    {QStringLiteral("ru"), QStringLiteral("Русский")},
    {QStringLiteral("tr"), QStringLiteral("Türkçe")},
};

/// The installed translation, owned here so that replacing it cannot leak. Null when the app is
/// running in English, which has no translation file.
QTranslator* g_translator = nullptr;

/// The language part of the system locale, e.g. "ar" for `ar_EG`. Empty when the system locale
/// has no language part at all, which QLocale reports as "C".
QString systemLanguageCode()
{
    QString code = QLocale::system().name();
    const int separator = code.indexOf(QLatin1Char('_'));
    if (separator > 0) {
        code.truncate(separator);
    }
    if (code == QLatin1String("C") || code.isEmpty()) {
        return QString();
    }
    return code.toLower();
}

/// The table entry for `code`, or nullptr. The single place that decides what counts as a
/// language this build has.
const Language* find(const QString& code)
{
    for (const Language& language : kLanguages) {
        if (language.code == code) {
            return &language;
        }
    }
    return nullptr;
}

} // namespace

QVector<Language> availableLanguages()
{
    QVector<Language> languages;
    languages.reserve(int(std::size(kLanguages)));
    for (const Language& language : kLanguages) {
        languages.append(language);
    }
    return languages;
}

QString preferredLanguageCode()
{
    return QSettings().value(kLanguageKey, QString()).toString();
}

void setPreferredLanguageCode(const QString& code)
{
    QSettings settings;
    const QString previous = settings.value(kLanguageKey, QString()).toString();
    settings.setValue(kLanguageKey, code);
    if (previous != code) {
        logging::event(QStringLiteral("app.language"),
            {{QStringLiteral("code"), code.isEmpty() ? QStringLiteral("system") : code}});
    }
}

QString effectiveLanguageCode()
{
    const QString preferred = preferredLanguageCode();
    if (!preferred.isEmpty() && find(preferred) != nullptr) {
        return preferred;
    }
    const QString fromSystem = systemLanguageCode();
    if (!fromSystem.isEmpty() && find(fromSystem) != nullptr) {
        return fromSystem;
    }
    return QStringLiteral("en");
}

QString systemLanguageNativeName()
{
    const Language* language = find(systemLanguageCode());
    return language != nullptr ? language->nativeName : QString();
}

bool installTranslation(const QString& code)
{
    if (g_translator != nullptr) {
        QCoreApplication::removeTranslator(g_translator);
        delete g_translator;
        g_translator = nullptr;
    }

    // English is the source language: its strings are already in the binary, and a missing
    // translation is an empty string rather than an error anywhere else in this file.
    if (code.isEmpty() || code == QLatin1String("en")) {
        return false;
    }

    auto* translator = new QTranslator;
    const QString path =
        QStringLiteral(":/i18n/localstream_") + code + QStringLiteral(".qm");
    if (!translator->load(path)) {
        // Not fatal by design: a build made without LinguistTools, or a language whose file was
        // left out, reads in English rather than showing empty labels everywhere.
        delete translator;
        logging::event(QStringLiteral("app.languageMissing"),
            {{QStringLiteral("code"), code}, {QStringLiteral("resource"), path}});
        return false;
    }
    QCoreApplication::installTranslator(translator);
    g_translator = translator;
    return true;
}

void applyEffectiveLanguage()
{
    const QString code = effectiveLanguageCode();
    const bool translated = installTranslation(code);
    QApplication::setLayoutDirection(isRightToLeft(code) ? Qt::RightToLeft : Qt::LeftToRight);
    logging::event(QStringLiteral("app.languageApplied"),
        {{QStringLiteral("code"), code},
         {QStringLiteral("translated"), translated ? QStringLiteral("true") : QStringLiteral("false")}});
}

bool isRightToLeft(const QString& code)
{
    // The languages that read right to left and are shipped or are the obvious next addition.
    // Kept as a list rather than a range check on the first letter, which no code point ordering
    // makes correct.
    static const QStringList rightToLeft{
        QStringLiteral("ar"), QStringLiteral("fa"), QStringLiteral("he"),
        QStringLiteral("ur"), QStringLiteral("fa_AF")};
    return rightToLeft.contains(code);
}

bool restartApplication()
{
    // The working directory is set explicitly: the app resolves its FFmpeg and Qt DLLs from its
    // own directory, and a copy started from wherever this process happened to be run would
    // still find them - but a copy started from a *deleted* directory would not start at all.
    return QProcess::startDetached(QCoreApplication::applicationFilePath(), QStringList(),
        QCoreApplication::applicationDirPath());
}

QString tutorialResource(const QString& code)
{
    const QString english = QStringLiteral(":/ui/Tutorial.html");
    if (code.isEmpty() || code == QLatin1String("en")) {
        return english;
    }
    const QString translated = QStringLiteral(":/ui/Tutorial-") + code + QStringLiteral(".html");
    // Checked rather than assumed: a language may be added to the interface before its tutorial
    // is translated, and a Help tab pointing at a document that does not exist would offer the
    // reader nothing at all.
    return QFile::exists(translated) ? translated : english;
}

} // namespace localstream::ui
