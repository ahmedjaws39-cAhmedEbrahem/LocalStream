#pragma once

#include <QWidget>

namespace localstream::logging {
struct Settings;
struct ReportOptions;
struct ReportResult;
} // namespace localstream::logging

class QCheckBox;
class QComboBox;
class QLabel;
class QPushButton;
class QSpinBox;

/**
 * The Help tab.
 *
 * The tutorial is a single offline HTML page rather than text rebuilt from C++ strings, because
 * it has to be readable in a real browser: it carries its own navigation, tables and light/dark
 * styling, and it stays one file that both apps can ship instead of two copies of the same words
 * drifting apart.
 *
 * It is compiled into the binary and written out to the user's app-data folder on demand, so the
 * help works from a copy of the app started from anywhere on disk, and an updated page is never
 * shadowed by an older one left behind by a previous run.
 *
 * The report card sits here for a reason rather than in a menu of its own: this is the tab people
 * already open when something has gone wrong, and a report is only worth anything if the settings
 * that decide what the log contains are changed where the log is explained.
 *
 * The general switch and the About card are here for the same reason by a shorter route: this is
 * the tab that already holds everything a person reads rather than presses, and a background-mode
 * switch is read far more often than it is changed.
 */
class HelpPage : public QWidget
{
    Q_OBJECT

public:
    explicit HelpPage(QWidget* parent = nullptr);

private:
    /// Hands the tutorial to the default browser, and says so when there is not one.
    void openTutorial();
    /// Opens the folder holding the tutorial in File Explorer, for a machine whose web-page
    /// association is broken: the shell accepts the folder even when it silently drops the file.
    void revealTutorialFile();
    /// Copies the embedded tutorial into app data and returns its path, or an empty string.
    static QString writeTutorialFile();
    /// Where [writeTutorialFile] will put the file, without writing anything.
    static QString tutorialPath();
    /// Puts the location of the file in the label, so it is never a stale promise.
    void showTutorialLocation();

    /// Persists the run-in-background switch, which is what decides whether closing the
    /// window hides the app behind the tray icon or exits it.
    void applyRunInBackgroundSetting();
    /// Collects the log controls into one settings object and applies it.
    void applyLoggingSettings();
    /// Reads the controls into the settings currently in force, without writing anything.
    [[nodiscard]] localstream::logging::Settings loggingSettingsFromControls() const;
    /// Collects the report controls into the options [writeReport] is given.
    [[nodiscard]] localstream::logging::ReportOptions reportOptionsFromControls() const;
    /// Writes a report and reports where it went, out loud as well as on screen.
    void writeReportNow();
    /// Shows a folder in the file browser, explaining the failure if it cannot.
    void openFolder(const QString& directory, const QString& what);
    void applyLanguageSetting();

    /// Selectable so the path can be copied into a mail or a chat when a browser refuses.
    QLabel* location_ = nullptr;

    /// The general switch: does closing the window keep the app running behind the tray icon.
    QCheckBox* runInBackground_ = nullptr;

    /// The switch the rest of these settings hang off, and the first control in this card.
    QCheckBox* recordAutomatically_ = nullptr;
    QComboBox* minimumLevel_ = nullptr;
    QCheckBox* milliseconds_ = nullptr;
    QComboBox* clockFormat_ = nullptr;
    QSpinBox* keepDays_ = nullptr;
    QSpinBox* maxFileSizeMiB_ = nullptr;

    QComboBox* language_ = nullptr;

    QCheckBox* includeSystemInfo_ = nullptr;
    QCheckBox* includeLogLines_ = nullptr;
    QSpinBox* logTailKib_ = nullptr;
    QCheckBox* includeEarlierDays_ = nullptr;
    QCheckBox* includeSettings_ = nullptr;

    /// Where the last report was written, or why there was not one.
    QLabel* reportStatus_ = nullptr;
};