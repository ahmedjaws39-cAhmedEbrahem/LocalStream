#include "ui/ReceivePage.h"

#include "engine/PlaybackEngine.h"
#include "protocol/ControlMessage.h"
#include "protocol/LocalStream.h"
#include "ui/UiKit.h"

#include <QComboBox>
#include <QCoreApplication>
#include <QDialog>
#include <QDialogButtonBox>
#include <QFormLayout>
#include <QHBoxLayout>
#include <QIntValidator>
#include <QKeyEvent>
#include <QLabel>
#include <QLineEdit>
#include <QListWidget>
#include <QMessageBox>
#include <QMouseEvent>
#include <QNetworkInformation>
#include <QPainter>
#include <QPushButton>
#include <QResizeEvent>
#include <QShowEvent>
#include <QSizePolicy>
#include <QStackedWidget>
#include <QStyle>
#include <QSysInfo>
#include <QVBoxLayout>

using localstream::ui::StatusKind;

namespace {

/// "SM-A137F - 1280x720" for the list, and enough detail to spot the wrong entry.
QString describe(const localstream::net::ServiceDiscovery::Service& service)
{
    const localstream::protocol::LocalStream::Description& description = service.description;
    if (description.isAudioOnly()) {
        return QCoreApplication::translate("ReceivePage", "%1 - audio only").arg(service.name);
    }
    return QCoreApplication::translate("ReceivePage", "%1 - %2x%3")
        .arg(service.name)
        .arg(description.width)
        .arg(description.height);
}

/// This machine's name, with a fallback for a host that reports none.
QString thisMachineName()
{
    const QString name = QSysInfo::machineHostName();
    return name.isEmpty() ? QCoreApplication::translate("ReceivePage", "Windows PC") : name;
}

} // namespace

/**
 * The fullscreen picture.
 *
 * Frameless and aspect-fit: the frame is scaled to the largest rectangle that fits while keeping
 * its shape, and the rest of the display stays black, so a picture in one aspect ratio on a screen
 * in another is letterboxed rather than stretched. Escape, a double-click and the on-screen button
 * all leave; there is no chrome to aim at, which is the point.
 */
class VideoWindow : public QWidget
{
public:
    explicit VideoWindow(QWidget* parent = nullptr)
        : QWidget(parent, Qt::Window | Qt::FramelessWindowHint)
    {
        setWindowTitle(QStringLiteral("LocalStream"));
        setFocusPolicy(Qt::StrongFocus);
        setCursor(Qt::BlankCursor);

        exitButton_ = new QPushButton(tr("Exit fullscreen"), this);
        exitButton_->setCursor(Qt::ArrowCursor);
        // Deliberately not themed: this sits over the picture, where the app's own palette does
        // not apply and a themed control would be unreadable against an unknown frame.
        exitButton_->setStyleSheet(QStringLiteral(
            "QPushButton { background: rgba(0, 0, 0, 160); color: white; "
            "border: 1px solid rgba(255, 255, 255, 120); border-radius: 4px; "
            "padding: 6px 12px; } "
            "QPushButton:hover { background: rgba(60, 60, 60, 200); }"));
        connect(exitButton_, &QPushButton::clicked, this, &QWidget::close);
    }

    void setFrame(const QImage& frame)
    {
        frame_ = frame;
        update();
    }

protected:
    void paintEvent(QPaintEvent*) override
    {
        QPainter painter(this);
        painter.fillRect(rect(), Qt::black);
        if (frame_.isNull()) {
            return;
        }
        // Fitted, not filled: a stretched picture is worse than black bars, and the broadcast's
        // shape is not something this window gets to decide.
        const QSize scaled = frame_.size().scaled(size(), Qt::KeepAspectRatio);
        const QRect target(QPoint((width() - scaled.width()) / 2, (height() - scaled.height()) / 2),
                           scaled);
        painter.setRenderHint(QPainter::SmoothPixmapTransform, true);
        painter.drawImage(target, frame_);
    }

    void resizeEvent(QResizeEvent*) override
    {
        constexpr int margin = 16;
        exitButton_->adjustSize();
        exitButton_->move(width() - exitButton_->width() - margin, margin);
        exitButton_->raise();
    }

    void keyPressEvent(QKeyEvent* event) override
    {
        if (event->key() == Qt::Key_Escape) {
            close();
            return;
        }
        QWidget::keyPressEvent(event);
    }

    void mouseDoubleClickEvent(QMouseEvent*) override { close(); }

private:
    QImage frame_;
    QPushButton* exitButton_ = nullptr;
};

/**
 * Asks for the password a password-protected broadcast demanded.
 *
 * A `QDialog` rather than a card on the page, because the handshake is already blocked on the
 * answer: the connection is open and waiting, and there is nothing on the page the viewer could
 * usefully do instead. It stays open when a password is refused -- the rejection is shown in it
 * and the field cleared, so the correction can be typed straight away -- and only closes once the
 * answer has been handed over.
 */
class PasswordDialog : public QDialog
{
public:
    /// Called with the answer. Returning does not close the dialog: a refused password arrives
    /// through [setError] and the user gets to try again in place.
    using AcceptedHandler = std::function<void(const QString&)>;

    PasswordDialog(const QString& broadcasterName, QWidget* parent, AcceptedHandler onAccepted,
        std::function<void()> onRejected)
        : QDialog(parent, Qt::Dialog)
        , field_(new QLineEdit(this))
        , error_(new QLabel(this))
        , confirm_(new QPushButton(tr("Watch"), this))
        , onAccepted_(std::move(onAccepted))
        , onRejected_(std::move(onRejected))
    {
        setWindowTitle(tr("Password required"));
        setModal(true);
        setMinimumWidth(380);

        auto* heading = new QLabel(this);
        heading->setTextFormat(Qt::PlainText);
        heading->setWordWrap(true);
        heading->setText(tr("%1 is broadcasting privately.")
                             .arg(broadcasterName.isEmpty() ? tr("The broadcaster")
                                                            : broadcasterName));

        // Bounded to what the broadcaster accepts, and never longer, so the answer cannot be
        // typed wrong in a way the peer would only report as a generic failure.
        field_->setEchoMode(QLineEdit::Password);
        field_->setMaxLength(localstream::protocol::accesslimits::MaxPasswordLength);

        error_->setObjectName(QStringLiteral("hint"));
        error_->setWordWrap(true);
        error_->setVisible(false);

        auto* buttons = new QDialogButtonBox(QDialogButtonBox::Cancel, this);
        confirm_->setObjectName(QStringLiteral("primaryButton"));
        buttons->addButton(confirm_, QDialogButtonBox::AcceptRole);

        auto* form = new QFormLayout;
        form->setContentsMargins(0, 0, 0, 0);
        form->addRow(localstream::ui::makeLabel(this, tr("Password"), field_), field_);
        form->addRow(QString(), error_);

        auto* body = new QVBoxLayout(this);
        body->setSpacing(12);
        body->addWidget(heading);
        body->addLayout(form);
        body->addWidget(buttons);

        connect(buttons, &QDialogButtonBox::rejected, this, &QDialog::reject);
        connect(confirm_, &QPushButton::clicked, this, &PasswordDialog::submit);
        connect(field_, &QLineEdit::returnPressed, this, &PasswordDialog::submit);
        connect(this, &QDialog::rejected, this, [this] {
            // Reported rather than acted on here, so the page tears the connection down through
            // the same path in every case: the dialog closing, or the page going away first.
            if (onRejected_) {
                onRejected_();
            }
        });
        // Enter submits from the field, which is what a viewer expects from a one-field prompt.
        field_->setFocus();

        localstream::ui::announce(this,
            tr("%1 requires a password.")
                .arg(broadcasterName.isEmpty() ? tr("The broadcaster")
                                               : broadcasterName));
    }

    /// Shows why the last attempt failed and clears the field for a retype.
    void setError(const QString& reason)
    {
        error_->setText(reason);
        error_->setVisible(true);
        // Cleared deliberately: leaving rejected text in place invites the same wrong password
        // to be submitted again, and this time with less attention.
        field_->clear();
        field_->setFocus();
        localstream::ui::announce(this, reason, true);
    }

private:
    void submit()
    {
        const QString password = field_->text();
        // Refused locally rather than sent: the broadcaster's limit is published, so an
        // impossible password should not cost a round trip and a rejection on its record.
        if (!localstream::protocol::isValidAccessPassword(password)) {
            setError(tr("The password must be between %1 and %2 characters.")
                         .arg(localstream::protocol::accesslimits::MinPasswordLength)
                         .arg(localstream::protocol::accesslimits::MaxPasswordLength));
            return;
        }
        if (onAccepted_) {
            onAccepted_(password);
        }
    }

    QLineEdit* field_;
    QLabel* error_;
    QPushButton* confirm_;
    AcceptedHandler onAccepted_;
    std::function<void()> onRejected_;
};

ReceivePage::ReceivePage(QWidget* parent)
    : QWidget(parent),
      discovery_(new localstream::net::ServiceDiscovery(this)),
      playback_(new localstream::engine::PlaybackEngine(this))
{
    setObjectName(QStringLiteral("page"));
    setAttribute(Qt::WA_StyledBackground, true);

    list_ = new QListWidget(this);
    list_->setSelectionMode(QAbstractItemView::SingleSelection);
    list_->setAccessibleName(tr("Available broadcasters"));
    list_->setAccessibleDescription(
        tr("Broadcasters found on this network. Select one, then choose Connect."));
    list_->setMinimumHeight(170);

    connectButton_ = new QPushButton(tr("Connect"), this);
    connectButton_->setObjectName(QStringLiteral("primaryButton"));
    connectButton_->setMinimumHeight(38);
    connectButton_->setEnabled(false);
    connectButton_->setDefault(true);

    searchAgainButton_ = new QPushButton(tr("Search again"), this);
    searchAgainButton_->setObjectName(QStringLiteral("quietButton"));
    searchAgainButton_->setAccessibleName(tr("Search for broadcasters again"));
    searchAgainButton_->setToolTip(
        tr("Ask the network again. Useful when a broadcaster has just come online, "
                       "or when nothing has appeared for a while."));

    // How much of the stream is buffered before it plays, audio and video together. Each entry
    // trades latency against the amount of network jitter that can be absorbed without a break;
    // the value is milliseconds.
    bufferCombo_ = new QComboBox(this);
    bufferCombo_->setAccessibleName(tr("Receive buffer"));
    bufferCombo_->addItem(tr("Low latency (200 ms)"), 200);
    bufferCombo_->addItem(tr("Balanced (500 ms)"), 500);
    bufferCombo_->addItem(tr("Smooth (1 second)"), 1000);
    bufferCombo_->addItem(tr("Maximum (2 seconds)"), 2000);
    bufferCombo_->setCurrentIndex(1);
    bufferCombo_->setMinimumWidth(180);
    receiveBufferMs_ = 500;

    status_ = new localstream::ui::StatusPill(this);

    statistics_ = new QLabel(QString(), this);
    statistics_->setTextFormat(Qt::PlainText);
    statistics_->setWordWrap(true);

    // Split from `statistics_` because they answer different questions. The broadcaster's counters
    // only say what it is sending, and they stay perfectly healthy when a firewall drops every
    // media packet on the way here, so showing them alone makes a dead link look like a working
    // one. These count what actually arrived.
    reception_ = new QLabel(QString(), this);
    reception_->setTextFormat(Qt::PlainText);
    reception_->setWordWrap(true);

    video_ = new QLabel(this);
    video_->setAlignment(Qt::AlignCenter);
    video_->setMinimumSize(480, 270);
    video_->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    video_->setAccessibleName(tr("Video from the broadcaster"));

    // Hidden until the first frame arrives, which is when the page learns that this broadcast
    // carries video at all -- strictly later than `started`, and before which there is nothing to
    // enlarge. An audio-only stream therefore never shows it.
    fullscreenButton_ = new QPushButton(tr("Fullscreen"), this);
    fullscreenButton_->setAccessibleName(tr("Enter fullscreen"));
    fullscreenButton_->setVisible(false);

    auto* placeholder = new QLabel(
        tr("Connect to a broadcaster to see the picture here."), this);
    placeholder->setAlignment(Qt::AlignCenter);
    placeholder->setWordWrap(true);
    placeholder->setObjectName(QStringLiteral("videoPlaceholder"));

    stack_ = new QStackedWidget(this);
    // Named for both pages of the stack, so the empty state and the picture sit on the same
    // dark rectangle rather than one floating on the page background.
    stack_->setObjectName(QStringLiteral("videoSurface"));
    video_->setObjectName(QStringLiteral("videoSurface"));
    stack_->setMinimumHeight(300);
    stack_->addWidget(placeholder);
    stack_->addWidget(video_);

    // The fallback for when the list is empty, which is also the only route that works when
    // discovery is blocked outright. Always visible rather than revealed when the list is empty:
    // hiding it meant the fallback was unavailable in the exact case it exists for - a network
    // where discovery never finds anything never produces a row-removal either, so the condition
    // that was supposed to reveal it never fired.
    manualPanel_ = new QWidget(this);
    auto* manualLayout = new QVBoxLayout(manualPanel_);
    manualLayout->setContentsMargins(0, 0, 0, 0);
    manualLayout->setSpacing(8);
    manualLayout->addWidget(localstream::ui::makeHint(
        manualPanel_,
        tr("If the list is empty, enter the broadcaster's address and the control "
                       "port shown on its Broadcast screen.")));

    addressField_ = new QLineEdit(manualPanel_);
    addressField_->setPlaceholderText(tr("Broadcaster address"));
    addressField_->setAccessibleName(tr("Broadcaster address"));
    portField_ = new QLineEdit(manualPanel_);
    portField_->setPlaceholderText(tr("Control port"));
    portField_->setAccessibleName(tr("Control port"));
    // A port is a number between 1 and 65535, and letting letters in only gets as far as the
    // check in connectToManual(). The validator keeps them out entirely; the check stays, because
    // 70000 types perfectly well as digits.
    portField_->setValidator(new QIntValidator(1, 65535, portField_));
    // The port is up to five digits and the address is a hostname or an IPv4 literal, so both
    // fit without the row being the width of the window.
    portField_->setMaximumWidth(120);
    manualConnectButton_ = new QPushButton(tr("Connect manually"), manualPanel_);
    manualConnectButton_->setObjectName(QStringLiteral("primaryButton"));

    auto* manualRow = new QHBoxLayout();
    manualRow->setSpacing(8);
    manualRow->addWidget(addressField_, 1);
    manualRow->addWidget(portField_);
    manualLayout->addLayout(manualRow);
    manualLayout->addWidget(manualConnectButton_, 0, Qt::AlignLeft);

    // ------------------------------------------------------------------ layout
    auto* layout = new QVBoxLayout(this);
    layout->setContentsMargins(0, 12, 0, 0);
    layout->setSpacing(14);

    auto* columns = new QHBoxLayout;
    columns->setSpacing(14);

    auto* left = new QVBoxLayout;
    left->setSpacing(14);

    auto browse = localstream::ui::makeCard(tr("Broadcasters"), this);
    browse.body->addWidget(list_);

    auto* browseTools = new QHBoxLayout;
    browseTools->setSpacing(8);
    browseTools->addWidget(searchAgainButton_);
    browseTools->addStretch(1);
    browse.body->addLayout(browseTools);

    browse.body->addWidget(connectButton_);
    browse.body->addWidget(localstream::ui::makeHint(
        browse.box,
        tr("Select a broadcaster, then choose Connect. Enter connects to the one "
                       "highlighted.")));
    left->addWidget(browse.box);

    auto manual = localstream::ui::makeCard(tr("Connect by address"), this);
    manual.body->addWidget(manualPanel_);
    left->addWidget(manual.box);
    left->addStretch(1);

    columns->addLayout(left, 0);

    auto* right = new QVBoxLayout;
    right->setSpacing(14);

    auto picture = localstream::ui::makeCard(tr("Picture"), this);
    picture.body->addWidget(stack_, 1);

    auto* pictureTools = new QHBoxLayout;
    pictureTools->setSpacing(8);
    pictureTools->addWidget(fullscreenButton_);
    pictureTools->addStretch(1);
    pictureTools->addWidget(
        localstream::ui::makeLabel(picture.box, tr("Receive buffer"), bufferCombo_));
    pictureTools->addWidget(bufferCombo_);
    picture.body->addLayout(pictureTools);

    right->addWidget(picture.box, 1);

    auto session = localstream::ui::makeCard(tr("Session"), this);
    session.body->addWidget(status_);
    session.body->addWidget(statistics_);
    session.body->addWidget(reception_);
    right->addWidget(session.box, 0);

    columns->addLayout(right, 1);
    layout->addLayout(columns, 1);

    browse.box->setFixedWidth(360);
    manual.box->setFixedWidth(360);

    status_->setStatus(tr("Scanning for broadcasters on this network."),
                       StatusKind::Idle);

    connect(list_, &QListWidget::currentRowChanged, this, [this](int row) {
        // Enabling the button from the selection rather than from discovery state is what
        // keeps the two honest: the user can only connect to a row that actually exists.
        connectButton_->setEnabled(row >= 0 && !running_);
    });

    connect(connectButton_, &QPushButton::clicked, this, [this] {
        if (running_) {
            disconnectFromBroadcaster();
        } else {
            connectToSelected();
        }
    });

    // Activated covers both a double-click and Enter on the highlighted row, which is the
    // keyboard half of the same gesture and has no other meaning in a list.
    connect(list_, &QListWidget::itemActivated, this, [this](QListWidgetItem*) {
        if (!running_) {
            connectToSelected();
        }
    });

    connect(searchAgainButton_, &QPushButton::clicked, this, [this] {
        status_->setStatus(tr("Searching for broadcasters..."), StatusKind::Idle);
        discovery_->rescan();
    });

    connect(bufferCombo_, QOverload<int>::of(&QComboBox::currentIndexChanged), this,
        [this](int index) {
            receiveBufferMs_ = bufferCombo_->itemData(index).toInt();
            // Applied live when a session is running; remembered for the next connection otherwise.
            playback_->setReceiveBufferMs(receiveBufferMs_);
        });

    connect(manualConnectButton_, &QPushButton::clicked, this, &ReceivePage::connectToManual);
    connect(fullscreenButton_, &QPushButton::clicked, this, &ReceivePage::showFullscreen);

    // Enter in either field submits, which is what a user does after typing a port and does not
    // make a mental model out of which of the two Connect buttons is the right one.
    for (QLineEdit* field : {addressField_, portField_}) {
        connect(field, &QLineEdit::returnPressed, this, [this] {
            if (!running_ && manualConnectButton_->isEnabled()) {
                connectToManual();
            }
        });
    }

    // An address with no port is not a broadcaster, and a port with no address is not either, so
    // the button follows whichever field the user is actually filling in.
    refreshManualConnectButton();
    connect(addressField_, &QLineEdit::textChanged, this,
            [this] { refreshManualConnectButton(); });
    connect(portField_, &QLineEdit::textChanged, this,
            [this] { refreshManualConnectButton(); });

    connect(discovery_, &localstream::net::ServiceDiscovery::serviceAdded, this,
        [this](const localstream::net::ServiceDiscovery::Service& service) { onServiceAdded(service); });
    connect(discovery_, &localstream::net::ServiceDiscovery::serviceRemoved, this, &ReceivePage::onServiceRemoved);
    connect(discovery_, &localstream::net::ServiceDiscovery::warning, this, [this](const QString& message) {
        // A browse that cannot bind the mDNS port still leaves direct connecting possible, so
        // this is reported without claiming the list is empty. The firewall is named because it
        // is by far the most common reason, and an empty list with no explanation is the one
        // failure a user cannot act on.
        status_->setStatus(list_->count() == 0
                               ? tr("%1 Windows Firewall may also be blocking "
                                                "incoming connections to LocalStream.")
                                     .arg(message)
                               : message,
                           StatusKind::Error);
    });

    connect(playback_, &localstream::engine::PlaybackEngine::started, this, [this] {
        // A password prompt left open across a successful attempt would sit in front of the
        // picture that attempt unlocked. Closed here rather than on submit, because a submit is
        // only a guess until the broadcaster agrees to it.
        if (passwordDialog_) {
            // `accept()` rather than `close()`: the reject handler must not run, or the session
            // that was just established would be torn down as if the user had given up on it.
            passwordDialog_->accept();
            passwordDialog_->deleteLater();
            passwordDialog_ = nullptr;
        }
        setRunning(true);
        stack_->setCurrentIndex(1);
        status_->setStatus(tr("Connected."), StatusKind::Live);
    });

    connect(playback_, &localstream::engine::PlaybackEngine::stopped, this, [this] {
        setRunning(false);
        stack_->setCurrentIndex(0);
        resetVideo();
        clearStats();
        status_->setStatus(tr("Disconnected."), StatusKind::Idle);
        // The session that just ended is also the one that was in the list a moment ago. Leaving
        // the tab, or the broadcaster having stopped, both arrive here, so this is the one place
        // that has to put the page back into a searching state.
        discovery_->rescan();
    });

    connect(playback_, &localstream::engine::PlaybackEngine::failed, this, [this](const QString& reason) {
        setRunning(false);
        stack_->setCurrentIndex(0);
        resetVideo();
        // A failed session means the broadcaster or the path to it is gone; search again rather
        // than leave the user looking at the entry that just failed. Must happen before the
        // error dialog below, which is modal and would otherwise block this line until dismissed.
        discovery_->rescan();
        showError(reason);
    });

    // The broadcaster wants a password. A modal input rather than a card on the page, because the
// handshake is already waiting and the viewer has nothing else to do but answer it.
connect(playback_, &localstream::engine::PlaybackEngine::passwordRequired, this,
        [this](const QString& broadcasterName) { promptForPassword(broadcasterName); });

// Waiting on a person, so the status says who is deciding rather than showing a spinner that
// implies the network is at fault.
connect(playback_, &localstream::engine::PlaybackEngine::accessRequested, this,
        [this](const QString& broadcasterName) {
            status_->setStatus(
                tr("Asking %1 for permission to watch...").arg(broadcasterName),
                StatusKind::Idle);
        });

// A wrong password keeps the prompt open, so the message goes to the dialog and the field is
// cleared for a retype. Clearing it matters: leaving the rejected text in place invites the
// user to submit the same wrong password again.
connect(playback_, &localstream::engine::PlaybackEngine::passwordRejected, this,
        [this](const QString& reason) {
            if (passwordDialog_) {
                passwordDialog_->setError(reason);
                return;
            }
            status_->setStatus(reason, StatusKind::Error);
        });

// Terminal refusal. Told apart from `failed` because retrying is the wrong thing to offer, and
// the message has to say so rather than leaving the viewer to try again and be refused forever.
connect(playback_, &localstream::engine::PlaybackEngine::blocked, this, [this](const QString& reason) {
    stack_->setCurrentIndex(0);
    resetVideo();
    clearStats();
    discovery_->rescan();
    status_->setStatus(reason, StatusKind::Error);
    localstream::ui::showMessage(this, tr("Blocked by the broadcaster"), reason);
});

connect(playback_, &localstream::engine::PlaybackEngine::videoFrameReady, this, &ReceivePage::showFrame);
    connect(playback_, &localstream::engine::PlaybackEngine::statsChanged, this,
        [this](int framesPerSecond, int kilobitsPerSecond) {
            // The broadcaster's own counters, which say what it is sending. Never announced:
            // this line moves every second, and repeating it would drown out everything else.
            statistics_->setText(tr("%1 fps - %2 kbps")
                                     .arg(framesPerSecond)
                                     .arg(kilobitsPerSecond));
        });

    connect(playback_, &localstream::engine::PlaybackEngine::receptionStatsChanged, this,
        [this](quint64 audioPackets, quint64 videoPackets, quint64 lostPackets,
               bool haveVideoParameters, quint64 decodedFrames, quint64 audioPlayed, bool audioOpen,
               const QString& audioError) {
            Q_UNUSED(audioPlayed);
            // The audio line reports the pipeline stage that is failing rather than just a
            // playing/not-playing verdict: "no audio" on a stream that has audio packets is the
            // single most confusing symptom, and these three numbers localise it to the device,
            // the decoder, or the wire.
            const auto audio = playback_->audioStats();
            QString audioText = tr("%1/%2 audio played").arg(audio.decoded).arg(audio.submitted);
            if (!audioError.isEmpty()) {
                audioText = tr("no audio: %1").arg(audioError);
            } else if (!audioOpen && audioPackets > 0) {
                audioText = tr("audio device not open");
            } else if (audio.submitted > 0 && audio.decoded == 0) {
                audioText = tr("audio not decoding (%1 sent, %2 rejected)")
                                .arg(audio.decodeCalls)
                                .arg(audio.sendFailed);
            }
            reception_->setText(
                tr("Received: %1 audio, %2 video, %3 lost%4 - decoded: %5 video, %6")
                    .arg(audioPackets)
                    .arg(videoPackets)
                    .arg(lostPackets)
                    .arg(haveVideoParameters ? QString()
                                             : tr(" - waiting for keyframe header"))
                    .arg(decodedFrames)
                    .arg(audioText));
        });

    discovery_->start();

    // A LAN that dropped and came back leaves the browse socket bound to an adapter that may no
    // longer exist, and the periodic query timer cannot recover from that. Reachability is the
    // cue for it; interface add/remove does not fire when Wi-Fi simply re-associates.
    if (QNetworkInformation::loadDefaultBackend()) {
        if (auto* network = QNetworkInformation::instance()) {
            connect(network, &QNetworkInformation::reachabilityChanged, this,
                [this](QNetworkInformation::Reachability reachability) {
                    // Going down is not the moment to search: nothing is reachable yet.
                    if (reachability == QNetworkInformation::Reachability::Disconnected) {
                        return;
                    }
                    // A live session ends through the engine and rescans there, so this only has
                    // to cover the idle case to avoid re-binding under an active picture.
                    if (!running_) {
                        discovery_->rescan();
                    }
                });
        }
    }
}

ReceivePage::~ReceivePage()
{
    disconnectFromBroadcaster();
}

void ReceivePage::showEvent(QShowEvent* event)
{
    QWidget::showEvent(event);
    // The network may have changed while this tab was in the background. Re-running the browse
    // on the way back in is what makes the list reflect that, without paying for a teardown.
    if (!running_) {
        discovery_->rescan();
    }
}

void ReceivePage::resizeEvent(QResizeEvent* event)
{
    QWidget::resizeEvent(event);
    renderFrame();
}

void ReceivePage::onServiceAdded(const localstream::net::ServiceDiscovery::Service& service)
{
    // Keyed on the instance label rather than the name: a broadcaster is free to rename itself
    // at any time, and a list keyed on the display name would then show the same device twice.
    // Kept alongside the list rather than inside the item: an item's user data ends up in
    // Qt::UserRole and is expected to stay a plain value, and the whole service record is more
    // than a row needs to carry around.
    services_.insert(service.instanceKey, service);
    for (int row = 0; row < list_->count(); ++row) {
        if (list_->item(row)->data(Qt::UserRole).toString() == service.instanceKey) {
            list_->item(row)->setText(describe(service));
            return;
        }
    }

    auto* item = new QListWidgetItem(describe(service), list_);
    item->setData(Qt::UserRole, service.instanceKey);
    if (list_->currentRow() < 0) {
        // Select the first one to arrive, so a single broadcaster on the network needs one
        // click rather than two.
        list_->setCurrentRow(0);
    }
    if (list_->count() == 1) {
        status_->setStatus(tr("Found a broadcaster. Choose Connect to watch."),
                           StatusKind::Idle);
    }
}

void ReceivePage::onServiceRemoved(const QString& instanceKey)
{
    services_.remove(instanceKey);
    for (int row = 0; row < list_->count(); ++row) {
        if (list_->item(row)->data(Qt::UserRole).toString() != instanceKey) {
            continue;
        }
        const bool wasSelected = list_->currentRow() == row;
        delete list_->takeItem(row);
        if (list_->count() == 0) {
            status_->setStatus(
                tr("No broadcasters found. Check that both devices are on the same "
                               "Wi-Fi network, and that Windows Firewall is letting LocalStream "
                               "receive network traffic."),
                StatusKind::Idle);
        } else if (wasSelected) {
            // Qt leaves currentRow pointing past the end after a removal, which would leave the
            // Connect button enabled with nothing behind it.
            list_->setCurrentRow(qMin(row, list_->count() - 1));
        }
        return;
    }
}

void ReceivePage::connectToSelected()
{
    QListWidgetItem* item = list_->currentItem();
    if (item == nullptr) {
        return;
    }

    const QString instanceKey = item->data(Qt::UserRole).toString();

    // The address and port are re-read from discovery rather than cached in the item: a TXT
    // record can be updated in place, and connecting to a stale port is a failure that looks
    // like a dead broadcaster.
    const auto it = services_.constFind(instanceKey);
    if (it == services_.constEnd()) {
        // Removed between the click and here. The list is about to lose this row anyway, so
        // say so rather than reporting a connection error for a device that is simply gone.
        status_->setStatus(tr("That broadcaster is no longer on the network."),
                           StatusKind::Error);
        return;
    }
    const localstream::net::ServiceDiscovery::Service& service = *it;

    localstream::engine::PlaybackEngine::Settings settings;
    settings.receiverName = thisMachineName();
    settings.receiveBufferMs = receiveBufferMs_;

    const int controlPort = service.description.controlPort != 0
        ? service.description.controlPort
        : static_cast<int>(service.port);
    if (controlPort <= 0) {
        showError(tr("That broadcaster did not advertise a control port."));
        return;
    }

    status_->setStatus(tr("Connecting..."), StatusKind::Idle);

    QString error;
    if (!playback_->start(service.address.toString(), controlPort, settings, &error)) {
        showError(error);
    }
}

void ReceivePage::connectToManual()
{
    if (running_) {
        return;
    }

    const QString address = addressField_->text().trimmed();
    if (address.isEmpty()) {
        showError(tr("Enter the broadcaster's address first."));
        return;
    }

    // Accepted as a string rather than a number, because a port is not a quantity to reason
    // about but a literal from the other machine's screen: 70000 is a typo, not a number to be
    // rounded, and Qt's parser would happily return 0 for it and blame the network instead.
    bool portOk = false;
    const int port = portField_->text().trimmed().toInt(&portOk);
    if (!portOk || port <= 0 || port > 65535) {
        showError(tr("Enter the control port shown on the broadcaster's screen."));
        return;
    }

    localstream::engine::PlaybackEngine::Settings settings;
    settings.receiverName = thisMachineName();
    settings.receiveBufferMs = receiveBufferMs_;

    status_->setStatus(tr("Connecting..."), StatusKind::Idle);

    QString error;
    if (!playback_->start(address, port, settings, &error)) {
        showError(error);
    }
}

void ReceivePage::disconnectFromBroadcaster()
{
    if (!running_) {
        return;
    }
    status_->setStatus(tr("Disconnecting..."), StatusKind::Idle);
    playback_->stop();
}

void ReceivePage::setRunning(bool running)
{
    running_ = running;
    connectButton_->setText(running ? tr("Disconnect")
                                    : tr("Connect"));
    // Red while it is the thing that ends a live session, blue while it is the thing that
    // begins one. The label alone does not carry that at a glance.
    const QString buttonKind = running ? QStringLiteral("dangerButton")
                                       : QStringLiteral("primaryButton");
    if (connectButton_->objectName() != buttonKind) {
        connectButton_->style()->unpolish(connectButton_);
        connectButton_->setObjectName(buttonKind);
        connectButton_->style()->polish(connectButton_);
    }
    connectButton_->setEnabled(running || list_->currentRow() >= 0);
    // A running session owns the picture; letting the user start a second one from the list
    // would leave two receivers competing for the same slot.
    list_->setEnabled(!running);
    searchAgainButton_->setEnabled(!running);
    // Same reasoning for the fallback: a second receiver would race the first for the same
    // broadcaster's streams.
    manualPanel_->setEnabled(!running);
    refreshManualConnectButton();
}

void ReceivePage::refreshManualConnectButton()
{
    manualConnectButton_->setEnabled(
        !running_ && !addressField_->text().trimmed().isEmpty()
        && !portField_->text().trimmed().isEmpty());
}

void ReceivePage::clearStats()
{
    statistics_->clear();
    reception_->clear();
}

void ReceivePage::promptForPassword(const QString& broadcasterName)
{
    // One dialog at a time. Two would leave the viewer guessing which answer went to which
    // attempt, and the second would be answering a session the first had already replaced.
    if (passwordDialog_) {
        return;
    }

    // The dialog stays open until the answer is handed over; a refused password comes back
    // through setError and the user retries in place.
    auto* dialog = new PasswordDialog(broadcasterName, this,
        [this](const QString& password) {
            status_->setStatus(tr("Checking the password..."), StatusKind::Idle);
            playback_->submitPassword(password);
        },
        [this] {
            // Cleared first: the dialog is destroyed as this returns, and a later password
            // rejection arriving after teardown would touch a dead pointer.
            passwordDialog_ = nullptr;
            // Leaves the connection rather than idling on it: the broadcaster is holding a
            // session open for a viewer who has gone, and only this side can end it cleanly.
            playback_->cancelPasswordPrompt();
            status_->setStatus(tr("Disconnected."), StatusKind::Idle);
            discovery_->rescan();
        });
    passwordDialog_ = dialog;
    connect(dialog, &QObject::destroyed, this, [this] { passwordDialog_ = nullptr; });
    dialog->show();
}

void ReceivePage::showError(const QString& reason)
{
    status_->setStatus(tr("Could not connect."), StatusKind::Error);
    clearStats();
    localstream::ui::showMessage(this, tr("Could not connect"), reason);
}

void ReceivePage::showFrame(const QImage& frame)
{
    if (frame.isNull()) {
        return;
    }
    lastFrame_ = frame;
    renderFrame();
    if (!videoSeen_) {
        // The first frame is the moment this page learns the broadcast carries video at all,
        // which for every stream with a picture is later than `started`.
        videoSeen_ = true;
        fullscreenButton_->setVisible(true);
    }
    // Kept in step quietly: the fullscreen window is optional, and a frame arriving while it is
    // closed must not be held back from the inline view while that is checked.
    if (videoWindow_ != nullptr && videoWindow_->isVisible()) {
        videoWindow_->setFrame(frame);
    }
}

void ReceivePage::renderFrame()
{
    if (lastFrame_.isNull()) {
        video_->clear();
        return;
    }

    const QSize box = video_->size();
    if (box.isEmpty()) {
        // Not laid out yet. Showing the frame at its own size is still better than showing
        // nothing, and the next resize fits it properly.
        video_->setPixmap(QPixmap::fromImage(lastFrame_));
        return;
    }

    const QSize fitted = lastFrame_.size().scaled(box, Qt::KeepAspectRatio);
    if (fitted == lastFrame_.size()) {
        video_->setPixmap(QPixmap::fromImage(lastFrame_));
        return;
    }
    video_->setPixmap(QPixmap::fromImage(lastFrame_)
                          .scaled(fitted, Qt::KeepAspectRatio, Qt::SmoothTransformation));
}

void ReceivePage::showFullscreen()
{
    if (lastFrame_.isNull()) {
        return;
    }
    if (videoWindow_ == nullptr) {
        videoWindow_ = new VideoWindow(this);
    }
    videoWindow_->setFrame(lastFrame_);
    videoWindow_->showFullScreen();
    videoWindow_->raise();
    videoWindow_->activateWindow();
}

void ReceivePage::resetVideo()
{
    videoSeen_ = false;
    lastFrame_ = QImage();
    video_->clear();
    fullscreenButton_->setVisible(false);
    if (videoWindow_ != nullptr && videoWindow_->isVisible()) {
        videoWindow_->close();
    }
}
