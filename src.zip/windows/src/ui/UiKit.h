#pragma once

#include "ui/Theme.h"

#include <QColor>
#include <QIcon>
#include <QWidget>

class QLabel;
class QPaintEvent;
class QVBoxLayout;

namespace localstream::ui {

/**
 * A titled surface that the stylesheet paints as a raised card.
 *
 * Plain `QWidget` rather than `QGroupBox`: a group box drags a legend and a focus policy that
 * neither the layout nor a screen reader wants, while a named widget with `WA_StyledBackground`
 * paints exactly the same rectangle and keeps the heading as an ordinary label in the reading
 * order.
 */
struct Card
{
    QWidget* box = nullptr;
    QVBoxLayout* body = nullptr;
};

/// Builds a card with [title] as its first row. Add the contents to `body`.
Card makeCard(const QString& title, QWidget* parent);

/// A one-pixel rule, used between groups of controls inside a card.
QWidget* makeHLine(QWidget* parent);

/// Small, muted explanatory text. The colour is what separates it from the label above.
QLabel* makeHint(QWidget* parent, const QString& text);

/**
 * The label half of a form row, wired to [field] as its buddy.
 *
 * The buddy is the part that matters: it makes Alt+letter jump to the field, and it makes the
 * two read as one control instead of a stray word followed by a box.
 */
QLabel* makeLabel(QWidget* parent, const QString& text, QWidget* field);

/// State behind a [StatusPill]. Coloured *and* named, so colour is never the only signal.
enum class StatusKind { Idle, Live, Error };

/**
 * The one line of text that says what the app is doing right now.
 *
 * A single accessible node on purpose: the status dot is painted into the pill rather than
 * added as a child widget, so a screen reader hears "Broadcasting as DESKTOP, control port
 * 36987" as one utterance instead of "graphic" followed by the sentence. Every text change is
 * announced through the platform's live-region equivalent, so the outcome of a button press
 * reaches a screen-reader user without them having to go and look for it.
 */
class StatusPill final : public QWidget
{
    Q_OBJECT

public:
    explicit StatusPill(QWidget* parent = nullptr);

    /// Sets the text, restyles the pill for [kind], and announces the change when it differs.
    void setStatus(const QString& text, StatusKind kind = StatusKind::Idle);

    [[nodiscard]] QString text() const;
    [[nodiscard]] StatusKind kind() const noexcept { return kind_; }

protected:
    void paintEvent(QPaintEvent* event) override;

private:
    void applyKind(StatusKind kind);

    QLabel* label_ = nullptr;
    StatusKind kind_ = StatusKind::Idle;
    QString lastAnnounced_;
};

/**
 * Speaks [message] through the active screen reader.
 *
 * The Qt/Windows equivalent of an ARIA live region: status text that only changes in a label
 * is invisible to a user who is not already reading that label, so every state transition the
 * user triggered is pushed out explicitly. Quiet when no accessibility client is connected.
 */
void announce(QWidget* target, const QString& message, bool assertive = false);

/**
 * A themed modal message.
 *
 * Wraps [QMessageBox] so the box picks up the active palette - an unthemed dialog over a dark
 * window is the classic way for an error to look like a different application.
 */
void showMessage(QWidget* parent, const QString& title, const QString& text);

/**
 * Asks a yes/no question and blocks until it is answered.
 *
 * A dedicated function rather than a call site building a `QMessageBox`, because a modal that
 * has to break through to the front of the desktop needs its window flags and its activation
 * handled in one place. Returns true for "yes".
 *
 * Application-modal, not window-modal: the request has to be answered even if the broadcast tab
 * is not the visible one, which is the normal case when the app is in the background.
 */
bool confirm(QWidget* parent, const QString& title, const QString& text,
    const QString& acceptText, const QString& rejectText);

// ---------------------------------------------------------------------------------------
// Hand-drawn icons.
//
// Drawn rather than shipped as assets so they can be tinted from the active palette: an icon
// is a graphic, but it still has to clear 3:1 against whatever it sits on, in both themes.
// ---------------------------------------------------------------------------------------

/// Concentric waves and a dot: a signal going out.
QIcon broadcastIcon(const QColor& colour, int px = 22);

/// A screen with a play triangle: a picture coming in.
QIcon receiveIcon(const QColor& colour, int px = 22);

/// A disc with a question mark cleared out of it: the Help tab.
QIcon helpIcon(const QColor& colour, int px = 22);

/// Sun, crescent, or half-filled disc - whichever matches [mode].
QIcon themeIcon(ThemeMode mode, const QColor& colour, int px = 18);

} // namespace localstream::ui
