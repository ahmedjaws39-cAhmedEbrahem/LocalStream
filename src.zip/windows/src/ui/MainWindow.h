#pragma once

#include <QStringList>
#include <QWidget>

class QCloseEvent;
class QLabel;
class QPushButton;
class QSystemTrayIcon;
class QTabWidget;

/**
 * The application shell: a header, and a Broadcast tab and a Receive tab under it.
 *
 * Both engines live in the tabs rather than here, so switching tabs can never tear down a
 * running broadcast or drop a live session. Closing the window is the only thing that stops
 * them, and it does so through the same path the Stop buttons use - after asking, because a
 * broadcast that disappears because someone hit Ctrl+W is a broadcast the viewer never saw end.
 *
 * Unless the run-in-background switch is on: then closing the window hides it behind a tray
 * icon instead of stopping anything, and the app only really ends through the tray's Quit or
 * through a close the switch has turned back into an exit.
 */
class MainWindow : public QWidget
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget* parent = nullptr);
    ~MainWindow() override;

    /// Asks the active tab to stop its session. Called from closeEvent().
    void shutdown();

protected:
    void closeEvent(QCloseEvent* event) override;

private:
    /// One sentence per session that closing would interrupt; empty when the app is idle.
    [[nodiscard]] QStringList activeSessions() const;
    /// The yes/no box shown before the app exits while a session is running. True for "yes".
    [[nodiscard]] bool confirmExit(const QStringList& reasons);
    /// Creates the tray icon with its Show/Quit menu, if it does not exist yet. Returns false
    /// when this machine has no system tray to put an icon in.
    [[nodiscard]] bool ensureTrayIcon();
    /// Hides the window behind the tray icon, creating it first, and records the hiding in the
    /// log. Returns false when there is no tray to hide behind, in which case nothing is hidden.
    [[nodiscard]] bool hideToTray();
    /// Recolours the tray icon: it is drawn from the palette, and the palette moves.
    void refreshTrayIcon();
    /// Brings the window back from the tray and records it in the log.
    void showFromTray();
    /// The tray menu's Quit: asks about a running session, then leaves - through the window
    /// when it is open, and directly when it is hidden behind the tray.
    void quitFromTray();
    /// Recolours the tab icons: they are drawn from the palette, and the palette moves.
    void refreshTabIcons();
    /// Puts the current mode into the theme button's label and icon.
    void refreshThemeButton();

    QTabWidget* tabs_ = nullptr;
    QPushButton* themeButton_ = nullptr;
    QLabel* logo_ = nullptr;

    /// Created the first time the window hides behind it, and not before: an icon by the clock
    /// while the window is still open would promise a background run nobody has asked for yet.
    QSystemTrayIcon* trayIcon_ = nullptr;
    /// Set just before the tray's Quit closes the window, so closeEvent exits rather than
    /// hiding again, and does not ask a second time about a session Quit has already asked
    /// about.
    bool quitting_ = false;
};
