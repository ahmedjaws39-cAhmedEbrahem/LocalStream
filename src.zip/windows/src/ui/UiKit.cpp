#include "ui/UiKit.h"

#include <QAccessible>
#include <QApplication>
#include <QHBoxLayout>
#include <QLabel>
#include <QMessageBox>
#include <QPainter>
#include <QPainterPath>
#include <QPixmap>
#include <QPolygonF>
#include <QPushButton>
#include <QStyle>
#include <QVBoxLayout>

#include <cmath>

namespace localstream::ui {

namespace {

/// A transparent square to draw an icon into. ARGB so the parts we never touch stay empty.
QImage iconSurface(int px)
{
    QImage image(px, px, QImage::Format_ARGB32_Premultiplied);
    image.fill(Qt::transparent);
    return image;
}

qreal strokeWidth(int px)
{
    return std::max<qreal>(1.5, px * 0.085);
}

constexpr qreal kPi = 3.14159265358979323846;

} // namespace

Card makeCard(const QString& title, QWidget* parent)
{
    auto* box = new QWidget(parent);
    box->setObjectName(QStringLiteral("card"));
    // Subclasses of QWidget do not get styled backgrounds by default, and without this the
    // card would be a rectangle the stylesheet describes but the widget never paints.
    box->setAttribute(Qt::WA_StyledBackground, true);

    auto* body = new QVBoxLayout(box);
    body->setContentsMargins(16, 14, 16, 16);
    body->setSpacing(10);

    if (!title.isEmpty()) {
        auto* heading = new QLabel(title, box);
        heading->setObjectName(QStringLiteral("sectionHeading"));
        body->addWidget(heading);
    }
    return {box, body};
}

QWidget* makeHLine(QWidget* parent)
{
    auto* line = new QWidget(parent);
    line->setObjectName(QStringLiteral("hline"));
    line->setAttribute(Qt::WA_StyledBackground, true);
    line->setFixedHeight(1);
    return line;
}

QLabel* makeHint(QWidget* parent, const QString& text)
{
    auto* hint = new QLabel(text, parent);
    hint->setObjectName(QStringLiteral("hint"));
    hint->setWordWrap(true);
    hint->setAlignment(Qt::AlignLeading | Qt::AlignTop);
    return hint;
}

QLabel* makeLabel(QWidget* parent, const QString& text, QWidget* field)
{
    auto* label = new QLabel(text, parent);
    label->setObjectName(QStringLiteral("fieldLabel"));
    label->setAlignment(Qt::AlignRight | Qt::AlignVCenter);
    if (field != nullptr) {
        label->setBuddy(field);
    }
    return label;
}

// --------------------------------------------------------------------- StatusPill

StatusPill::StatusPill(QWidget* parent) : QWidget(parent)
{
    label_ = new QLabel(this);
    label_->setObjectName(QStringLiteral("statusText"));
    label_->setWordWrap(true);
    label_->setAlignment(Qt::AlignLeading | Qt::AlignVCenter);
    label_->setContentsMargins(0, 0, 0, 0);

    // The left margin is the gutter the dot is painted into: text never runs under it, and the
    // dot never becomes a node a screen reader has to step over.
    auto* layout = new QHBoxLayout(this);
    layout->setContentsMargins(28, 6, 16, 6);
    layout->setSpacing(0);
    layout->addWidget(label_);

    setMinimumHeight(34);
    applyKind(StatusKind::Idle);
}

void StatusPill::setStatus(const QString& text, StatusKind kind)
{
    const bool changed = label_->text() != text;
    label_->setText(text);
    if (kind != kind_) {
        applyKind(kind);
    }
    if (!changed) {
        return;
    }
    // Only what actually changed is spoken. A poll that re-sets the same sentence every second
    // would have TalkBack talking over the user instead of confirming their last action.
    announce(this, text, kind == StatusKind::Error);
    lastAnnounced_ = text;
}

QString StatusPill::text() const
{
    return label_->text();
}

void StatusPill::applyKind(StatusKind kind)
{
    kind_ = kind;
    const QString name = kind == StatusKind::Live    ? QStringLiteral("statusPillLive")
        : kind == StatusKind::Error                  ? QStringLiteral("statusPillError")
                                                     : QStringLiteral("statusPill");
    if (objectName() != name) {
        // A stylesheet selector is matched when a widget is polished, so renaming it at
        // runtime does nothing on its own: unpolish, rename, polish.
        if (style() != nullptr) {
            style()->unpolish(this);
        }
        setObjectName(name);
        if (style() != nullptr) {
            style()->polish(this);
        }
    }
    update();
}

void StatusPill::paintEvent(QPaintEvent* event)
{
    QWidget::paintEvent(event);

    const Palette& colours = Theme::instance().palette();
    const QColor dot = kind_ == StatusKind::Live    ? QColor(colours.live)
        : kind_ == StatusKind::Error                ? QColor(colours.danger)
                                                    : QColor(colours.textMuted);

    QPainter painter(this);
    painter.setRenderHint(QPainter::Antialiasing, true);
    painter.setPen(Qt::NoPen);
    painter.setBrush(dot);
    const qreal radius = 5.0;
    painter.drawEllipse(QPointF(13.0, rect().center().y()), radius, radius);
}

// ------------------------------------------------------------------ announcements

void announce(QWidget* target, const QString& message, bool assertive)
{
    // A hidden widget is one the user is not looking at: discovery keeps updating the Receive
    // tab while the Broadcast tab is in front, and announcing that would talk over whatever
    // they are actually doing.
    if (target == nullptr || message.isEmpty() || !target->isVisible()
        || !QAccessible::isActive()) {
        return;
    }
    QAccessibleInterface* interface = QAccessible::queryAccessibleInterface(target);
    if (interface == nullptr) {
        return;
    }
    // Heap allocated and handed over: Qt dispatches the event to whatever accessibility client
    // is attached, and some backends keep it for the duration of the notification.
    auto* event = new QAccessibleAnnouncementEvent(interface, message);
    event->setPoliteness(assertive ? QAccessible::AnnouncementPoliteness::Assertive
                                   : QAccessible::AnnouncementPoliteness::Polite);
    QAccessible::updateAccessibility(event);
}

void showMessage(QWidget* parent, const QString& title, const QString& text)
{
    QMessageBox box(parent);
    box.setObjectName(QStringLiteral("messageBox"));
    box.setAttribute(Qt::WA_StyledBackground, true);
    box.setWindowTitle(title);
    box.setText(text);
    box.setIcon(QMessageBox::Warning);
    box.setStandardButtons(QMessageBox::Ok);
    box.exec();
}

bool confirm(QWidget* parent, const QString& title, const QString& text, const QString& acceptText,
    const QString& rejectText)
{
    QMessageBox box(parent);
    box.setObjectName(QStringLiteral("messageBox"));
    box.setAttribute(Qt::WA_StyledBackground, true);
    box.setWindowTitle(title);
    box.setText(text);
    // A question, not a warning: the styling of the buttons should not imply that one answer is
    // the wrong one, when allowing and refusing are equally ordinary here.
    box.setIcon(QMessageBox::Question);

    QPushButton* accept = box.addButton(acceptText, QMessageBox::AcceptRole);
    QPushButton* reject = box.addButton(rejectText, QMessageBox::RejectRole);
    // The default has to be accept, so that pressing Enter or Escape does the expected thing --
    // and Escape maps to reject, because a viewer waiting should not be admitted by a reflexive
    // keypress.
    box.setDefaultButton(accept);
    box.setEscapeButton(reject);

    // Raised and focused explicitly. A request that arrives while the app is in the background
    // otherwise opens behind the windows the user is actually looking at, and the viewer is left
    // waiting with no visible reason.
    box.setWindowModality(Qt::ApplicationModal);
    box.setWindowFlag(Qt::WindowStaysOnTopHint, true);
    box.raise();
    box.activateWindow();

    // The one thing the taskbar flash is for. raise() and activateWindow() are silent when the
    // window is already visible - which it is, on the session the presenter is watching - so
    // without this a viewer asking to be let in produces no sign at all, and the presenter has to
    // notice a viewer counting down a dialog on a screen across the room.
    QApplication::alert(QApplication::activeWindow() != nullptr ? QApplication::activeWindow()
                                                               : box.parentWidget());

    box.exec();
    return box.clickedButton() == accept;
}

// ------------------------------------------------------------------------ icons

QIcon broadcastIcon(const QColor& colour, int px)
{
    QImage image = iconSurface(px);
    QPainter painter(&image);
    painter.setRenderHint(QPainter::Antialiasing, true);

    const QPointF centre(px / 2.0, px / 2.0);
    painter.setPen(Qt::NoPen);
    painter.setBrush(colour);
    painter.drawEllipse(centre, px * 0.11, px * 0.11);

    painter.setBrush(Qt::NoBrush);
    painter.setPen(QPen(colour, strokeWidth(px), Qt::SolidLine, Qt::RoundCap));
    const qreal radii[] = {px * 0.26, px * 0.40};
    for (qreal radius : radii) {
        const QRectF ring(centre.x() - radius, centre.y() - radius, radius * 2, radius * 2);
        // Two mirrored arcs around the dot: the shape of something radiating outward.
        painter.drawArc(ring, -55 * 16, 110 * 16);
        painter.drawArc(ring, 125 * 16, 110 * 16);
    }
    painter.end();
    return QIcon(QPixmap::fromImage(image));
}

QIcon receiveIcon(const QColor& colour, int px)
{
    QImage image = iconSurface(px);
    QPainter painter(&image);
    painter.setRenderHint(QPainter::Antialiasing, true);

    const QRectF screen(px * 0.07, px * 0.10, px * 0.86, px * 0.58);
    painter.setBrush(Qt::NoBrush);
    painter.setPen(QPen(colour, strokeWidth(px), Qt::SolidLine, Qt::RoundCap));
    painter.drawRoundedRect(screen, px * 0.10, px * 0.10);
    painter.drawLine(QPointF(px * 0.5, screen.bottom()), QPointF(px * 0.5, px * 0.84));
    painter.drawLine(QPointF(px * 0.34, px * 0.87), QPointF(px * 0.66, px * 0.87));

    const QPointF centre = screen.center();
    const qreal halfHeight = screen.height() * 0.34;
    const qreal halfWidth = screen.height() * 0.26;
    QPolygonF triangle;
    triangle << QPointF(centre.x() - halfWidth * 0.5, centre.y() - halfHeight)
             << QPointF(centre.x() - halfWidth * 0.5, centre.y() + halfHeight)
             << QPointF(centre.x() + halfWidth * 1.0, centre.y());
    painter.setPen(Qt::NoPen);
    painter.setBrush(colour);
    painter.drawPolygon(triangle);

    painter.end();
    return QIcon(QPixmap::fromImage(image));
}

QIcon helpIcon(const QColor& colour, int px)
{
    QImage image = iconSurface(px);
    QPainter painter(&image);
    painter.setRenderHint(QPainter::Antialiasing, true);

    // A filled disc with the question mark cleared out of it, rather than drawn in the
    // background colour: the mark has to survive being tinted by the palette and shrunk to a
    // tab icon, and knocking it out keeps it legible in both themes without a second colour.
    painter.setPen(Qt::NoPen);
    painter.setBrush(colour);
    painter.drawEllipse(QPointF(px / 2.0, px / 2.0), px * 0.44, px * 0.44);

    painter.setCompositionMode(QPainter::CompositionMode_Clear);
    QPen mark(Qt::white, strokeWidth(px) * 1.15, Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin);
    painter.setPen(mark);
    painter.setBrush(Qt::NoBrush);
    // Hook, stem, dot: three strokes, drawn as one path so they meet cleanly at the joints.
    QPainterPath path;
    const qreal left = px * 0.38;
    const qreal right = px * 0.62;
    path.moveTo(left, px * 0.33);
    path.cubicTo(left, px * 0.22, right, px * 0.22, right, px * 0.34);
    path.cubicTo(right, px * 0.43, px * 0.50, px * 0.44, px * 0.50, px * 0.53);
    path.lineTo(px * 0.50, px * 0.60);
    painter.drawPath(path);
    painter.drawEllipse(QPointF(px * 0.50, px * 0.69), px * 0.055, px * 0.055);

    painter.end();
    return QIcon(QPixmap::fromImage(image));
}

QIcon themeIcon(ThemeMode mode, const QColor& colour, int px)
{
    QImage image = iconSurface(px);
    QPainter painter(&image);
    painter.setRenderHint(QPainter::Antialiasing, true);

    const QPointF centre(px / 2.0, px / 2.0);

    if (mode == ThemeMode::Dark) {
        // A disc with a second disc cleared out of it: the overlap is what makes the crescent,
        // and clearing rather than painting keeps the edge antialiased.
        painter.setPen(Qt::NoPen);
        painter.setBrush(colour);
        painter.drawEllipse(QPointF(px * 0.46, px * 0.55), px * 0.33, px * 0.33);
        painter.setCompositionMode(QPainter::CompositionMode_Clear);
        painter.drawEllipse(QPointF(px * 0.68, px * 0.36), px * 0.31, px * 0.31);
        painter.setCompositionMode(QPainter::CompositionMode_SourceOver);
    } else if (mode == ThemeMode::Light) {
        painter.setPen(Qt::NoPen);
        painter.setBrush(colour);
        painter.drawEllipse(centre, px * 0.20, px * 0.20);
        painter.setPen(QPen(colour, strokeWidth(px), Qt::SolidLine, Qt::RoundCap));
        painter.setBrush(Qt::NoBrush);
        for (int i = 0; i < 8; ++i) {
            const qreal angle = i * kPi / 4.0;
            const QPointF direction(std::cos(angle), std::sin(angle));
            painter.drawLine(centre + direction * (px * 0.30), centre + direction * (px * 0.42));
        }
    } else {
        // System mode: one disc, half filled. Neither palette is claimed, which is the point.
        const qreal radius = px * 0.36;
        const QRectF ring(centre.x() - radius, centre.y() - radius, radius * 2, radius * 2);
        painter.setBrush(Qt::NoBrush);
        painter.setPen(QPen(colour, strokeWidth(px), Qt::SolidLine, Qt::RoundCap));
        painter.drawEllipse(ring);
        painter.setPen(Qt::NoPen);
        painter.setBrush(colour);
        painter.drawPie(ring, -90 * 16, 180 * 16);
    }

    painter.end();
    return QIcon(QPixmap::fromImage(image));
}

} // namespace localstream::ui
