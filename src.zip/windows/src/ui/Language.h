#pragma once

#include <QString>
#include <QVector>

namespace localstream::ui {

/**
 * The languages the app can be read in.
 *
 * Only the languages there is a real translation for appear here: the list is what the combo box
 * on the Help tab offers, and offering a language that falls back to English would be a promise
 * the build cannot keep. Adding one is a single entry here plus the `.ts` file it names - see
 * `docs/TRANSLATING.md`.
 */
struct Language {
    /// The code the translation file is named after: `ar` for `localstream_ar.ts`. Never empty.
    QString code;
    /// The language's own name, and never the English one: someone looking for their language
    /// looks for *Français*, not for *French*.
    QString nativeName;
};

/**
 * English first - it is the language the source is written in, and the fallback for everything
 * else - then the translated languages in the order `docs/TRANSLATING.md` lists them.
 *
 * The "follow the system language" entry is deliberately *not* in this list: its label is
 * translatable text, so the Help tab builds it where `tr()` is available.
 */
QVector<Language> availableLanguages();

/// The language the user chose on the Help tab, or empty when the app follows Windows.
QString preferredLanguageCode();

/// Records the choice. Empty means "follow the system language".
void setPreferredLanguageCode(const QString& code);

/**
 * The language actually in effect: the stored choice when it names a language this build has,
 * otherwise the system's language when it is one of them, otherwise English.
 *
 * The system's language is resolved rather than trusted: `QLocale::system().name()` returns
 * `ar_EG` and an app that looked up `ar_EG.qm` would silently stay English.
 */
QString effectiveLanguageCode();

/// The system language's own name, or empty when this build has no translation for it. Used to
/// label the "follow the system language" entry so the reader can see what that means today.
QString systemLanguageNativeName();

/**
 * Loads and installs the translation for `code`.
 *
 * English is the language the sources are written in, so it has no translation file and this
 * reports false for it without that being an error. Any previously installed translation is
 * removed first, which is what makes this safe to call again after the user changes the setting.
 */
bool installTranslation(const QString& code);

/**
 * Puts the effective language into force: installs its translator and sets the application's
 * layout direction to match, so an Arabic window is laid out right to left and not merely
 * written in Arabic. Call once, in `main()`, before the first window is built: widget text is
 * fixed when the widget is built, which is why changing the language later restarts the app.
 */
void applyEffectiveLanguage();

/// True when `code` reads right to left (Arabic, and the languages that would join it).
bool isRightToLeft(const QString& code);

/**
 * Starts a second copy of the app and reports whether it launched. The caller is expected to
 * quit: this is how a language change is applied without a per-widget retranslation pass.
 */
bool restartApplication();

/// The tutorial document for a language, as a path inside the Qt resource system. Falls back to
/// the English document when that language has no translated copy.
QString tutorialResource(const QString& code);
} // namespace localstream::ui
