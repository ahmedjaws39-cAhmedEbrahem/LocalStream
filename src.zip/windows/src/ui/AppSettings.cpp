#include "ui/AppSettings.h"

#include "logging/Log.h"
#include "protocol/LocalStream.h"

#include <QSettings>

namespace localstream::ui {
namespace {

/// The key the run-in-background switch lives under, in the same file as `ui/themeMode`.
constexpr auto kRunInBackgroundKey = "app/runInBackground";

/// Fragmentation controls. Defaults and bounds live here so the read and the clamp cannot drift.
constexpr auto kRtpMaxPayloadKey = "broadcast/rtpMaxPayload";
constexpr auto kPacingThresholdKey = "broadcast/pacingThresholdPackets";
constexpr auto kPacingSpreadKey = "broadcast/pacingSpreadFrames";

constexpr int kRtpMaxPayloadMin = 400;
constexpr int kRtpMaxPayloadMax = 1400;
constexpr int kPacingThresholdMin = 1;
constexpr int kPacingThresholdMax = 128;
constexpr int kPacingSpreadMin = 1;
constexpr int kPacingSpreadMax = 8;

} // namespace

bool runInBackground()
{
    // On by default: closing the window should not take a broadcast down behind the viewer's
    // back, and a person who wants the old behaviour can say so once on the Help tab.
    return QSettings().value(kRunInBackgroundKey, true).toBool();
}

void setRunInBackground(bool enabled)
{
    QSettings settings;
    const bool previous = settings.value(kRunInBackgroundKey, true).toBool();
    settings.setValue(kRunInBackgroundKey, enabled);

    if (previous == enabled) {
        return;
    }
    logging::event(QStringLiteral("app.backgroundMode"),
        {{QStringLiteral("enabled"), enabled ? QStringLiteral("true") : QStringLiteral("false")}});
}

int rtpMaxPayload()
{
    const int value = QSettings()
        .value(kRtpMaxPayloadKey, protocol::LocalStream::RtpMaxPayload).toInt();
    return qBound(kRtpMaxPayloadMin, value, kRtpMaxPayloadMax);
}

void setRtpMaxPayload(int bytes)
{
    QSettings().setValue(kRtpMaxPayloadKey, qBound(kRtpMaxPayloadMin, bytes, kRtpMaxPayloadMax));
}

int pacingThresholdPackets()
{
    const int value = QSettings().value(kPacingThresholdKey, 8).toInt();
    return qBound(kPacingThresholdMin, value, kPacingThresholdMax);
}

void setPacingThresholdPackets(int packets)
{
    QSettings().setValue(kPacingThresholdKey,
        qBound(kPacingThresholdMin, packets, kPacingThresholdMax));
}

int pacingSpreadFrames()
{
    const int value = QSettings().value(kPacingSpreadKey, 1).toInt();
    return qBound(kPacingSpreadMin, value, kPacingSpreadMax);
}

void setPacingSpreadFrames(int frames)
{
    QSettings().setValue(kPacingSpreadKey, qBound(kPacingSpreadMin, frames, kPacingSpreadMax));
}

} // namespace localstream::ui
