#pragma once

namespace localstream::ui {

/**
 * The app-wide switches that are neither about the colour theme nor about the log.
 *
 * Read and written directly through QSettings, the same way the theme keeps its mode: one
 * value, one key, no settings structure to keep in step with it. They are not logging
 * settings - a switch that decides what the app *does* must not be buried in the card that
 * decides what the log *contains* - but a change to one is still recorded in the log, because
 * "the app was still running in the background" is exactly the fact a later report needs.
 */

/// Closing the window keeps the app running behind the system tray icon instead of exiting it.
/// True unless the user has turned it off; the switch is remembered between runs.
[[nodiscard]] bool runInBackground();

/**
 * Persists the run-in-background switch as `app/runInBackground`.
 *
 * Records `app.backgroundMode enabled=...` when the value actually changes, so the log can
 * distinguish "the app was closed to the tray on purpose" from "the app was configured never
 * to go there". Writing the same value again is not a change and is not logged.
 */
void setRunInBackground(bool enabled);

/**
 * The Windows broadcaster's fragmentation controls, remembered between runs.
 *
 * Read at start() from the Broadcast tab's own controls, not from here: these accessors exist so
 * the tab can show what it used last time and so a value chosen once survives a restart. A value
 * outside the usable range is clamped on read, so a hand-edited settings file cannot put the
 * packetiser into a state the UI could never have offered.
 */
[[nodiscard]] int rtpMaxPayload();
void setRtpMaxPayload(int bytes);

[[nodiscard]] int pacingThresholdPackets();
void setPacingThresholdPackets(int packets);

[[nodiscard]] int pacingSpreadFrames();
void setPacingSpreadFrames(int frames);

} // namespace localstream::ui
