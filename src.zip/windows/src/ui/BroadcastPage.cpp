#include "ui/BroadcastPage.h"

#include "capture/FrameSource.h"
#include "engine/BroadcastEngine.h"
#include "protocol/ControlMessage.h"
#include "protocol/LocalStream.h"
#include "ui/AppSettings.h"
#include "ui/UiKit.h"

#include <QAbstractSocket>
#include <QCheckBox>
#include <QComboBox>
#include <QFormLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QShowEvent>
#include <QSignalBlocker>
#include <QSpinBox>
#include <QStyle>
#include <QSysInfo>
#include <QVBoxLayout>

using localstream::ui::StatusKind;

BroadcastPage::BroadcastPage(QWidget* parent)
    : QWidget(parent)
    , engine_(new localstream::engine::BroadcastEngine(this))
{
    setObjectName(QStringLiteral("page"));
    setAttribute(Qt::WA_StyledBackground, true);

    auto* layout = new QVBoxLayout(this);
    layout->setContentsMargins(0, 12, 0, 0);
    layout->setSpacing(14);

    auto* columns = new QHBoxLayout;
    columns->setSpacing(14);

    auto* left = new QVBoxLayout;
    left->setSpacing(14);

    // ------------------------------------------------------------ what to send
    auto stream = localstream::ui::makeCard(tr("What to send"), this);

    includeVideo_ = new QCheckBox(tr("Include video"), stream.box);
    includeVideo_->setChecked(true);
    includeVideo_->setToolTip(
        tr("Turn this off to broadcast audio only. The video encoder stays warm, "
                       "so turning it back on does not have to wait for a keyframe."));
    stream.body->addWidget(includeVideo_);

    includeTestPattern_ = new QCheckBox(
        tr("Show a test pattern instead of the screen"), stream.box);
    includeTestPattern_->setToolTip(
        tr("Broadcast a generated pattern and tone instead of capturing this "
                       "desktop. Useful on a machine with nothing worth sharing. Available "
                       "before the broadcast starts."));
    stream.body->addWidget(includeTestPattern_);

    normalizeAudio_ = new QCheckBox(tr("Normalize audio level"), stream.box);
    normalizeAudio_->setChecked(true);
    normalizeAudio_->setToolTip(
        tr("Keep the broadcast at a steady volume even when the system volume or "
                       "the capture device changes. Turn this off to send the captured level "
                       "untouched. Available before the broadcast starts."));
    stream.body->addWidget(normalizeAudio_);

    stream.body->addWidget(localstream::ui::makeHLine(stream.box));

    // A picker rather than a hardcoded default, because the machine may have a webcam
    // microphone, a headset and an aggregate device, and only the user knows which carries the
    // voice they intend to broadcast.
    microphone_ = new QComboBox(stream.box);
    microphone_->setToolTip(
        tr("Which microphone to capture. The first one is used when this is left "
                       "alone. Available before the broadcast starts."));

    microphoneRefresh_ = new QPushButton(tr("Refresh"), stream.box);
    microphoneRefresh_->setObjectName(QStringLiteral("quietButton"));
    microphoneRefresh_->setAccessibleName(tr("Refresh the microphone list"));
    microphoneRefresh_->setToolTip(
        tr("Scan again for microphones plugged in since this window opened."));

    auto* micRow = new QHBoxLayout;
    micRow->setSpacing(8);
    micRow->addWidget(localstream::ui::makeLabel(stream.box, tr("Microphone"),
                                                 microphone_));
    micRow->addWidget(microphone_, 1);
    micRow->addWidget(microphoneRefresh_);
    stream.body->addLayout(micRow);

    left->addWidget(stream.box);

    // ---------------------------------------------------------------- quality
    auto quality = localstream::ui::makeCard(tr("Quality"), this);
    qualityCard_ = quality.box;

    resolution_ = new QComboBox(quality.box);
    resolution_->addItem(tr("1280 x 720"), QVariant::fromValue(QSize(1280, 720)));
    resolution_->addItem(tr("1920 x 1080"), QVariant::fromValue(QSize(1920, 1080)));
    resolution_->setToolTip(tr("The size sent to viewers, before they scale it to "
                                          "their own window."));

    videoBitrate_ = new QSpinBox(quality.box);
    videoBitrate_->setRange(200, 8000);
    videoBitrate_->setValue(1500);
    videoBitrate_->setSuffix(tr(" kbps"));
    videoBitrate_->setToolTip(tr("How much detail to send. More looks sharper and "
                                             "uses more of the network."));

    audioBitrate_ = new QSpinBox(quality.box);
    audioBitrate_->setRange(8, 320);
    audioBitrate_->setValue(48);
    audioBitrate_->setSuffix(tr(" kbps"));
    audioBitrate_->setToolTip(tr("How much detail to give the sound. 48 kbps is "
                                             "enough for speech."));

    auto* form = new QFormLayout;
    form->setContentsMargins(0, 0, 0, 0);
    form->setHorizontalSpacing(14);
    form->setVerticalSpacing(10);
    form->setLabelAlignment(Qt::AlignRight | Qt::AlignVCenter);
    form->setFieldGrowthPolicy(QFormLayout::AllNonFixedFieldsGrow);
    form->addRow(localstream::ui::makeLabel(quality.box, tr("Resolution"),
                                            resolution_),
                 resolution_);
    form->addRow(localstream::ui::makeLabel(quality.box, tr("Video bitrate"),
                                            videoBitrate_),
                 videoBitrate_);
    form->addRow(localstream::ui::makeLabel(quality.box, tr("Audio bitrate"),
                                            audioBitrate_),
                 audioBitrate_);
    quality.body->addLayout(form);
    quality.body->addWidget(localstream::ui::makeHint(
        quality.box,
        tr("These are read when the broadcast starts, so they wait until it is "
                       "stopped to take effect.")));

    left->addWidget(quality.box);

    // ---------------------------------------------------------------- packets
    auto packets = localstream::ui::makeCard(tr("Packets"), this);
    packetsCard_ = packets.box;

    maxPayload_ = new QComboBox(packets.box);
    // Offered as named presets rather than a free number: each is a known-good point on the
    // size/loss trade-off, and a keyboard or screen reader steps through them far faster than a
    // spin box full of bytes.
    maxPayload_->addItem(tr("1200 bytes (default)"),
        localstream::protocol::LocalStream::RtpMaxPayload);
    maxPayload_->addItem(tr("1400 bytes"), 1400);
    maxPayload_->addItem(tr("1000 bytes"), 1000);
    maxPayload_->addItem(tr("800 bytes"), 800);
    maxPayload_->setToolTip(
        tr("The largest datagram the video is split into. Smaller packets survive a "
                       "weak Wi-Fi link more reliably; larger ones send fewer packets. Available "
                       "before the broadcast starts."));

    pacingThreshold_ = new QSpinBox(packets.box);
    pacingThreshold_->setRange(1, 128);
    pacingThreshold_->setValue(8);
    pacingThreshold_->setSuffix(tr(" packets"));
    pacingThreshold_->setToolTip(
        tr("A frame that splits into at least this many packets is spread across the "
                       "frame time instead of sent in one burst, which reduces loss on a slow "
                       "link. Available before the broadcast starts."));

    pacingSpread_ = new QSpinBox(packets.box);
    pacingSpread_->setRange(1, 8);
    pacingSpread_->setValue(1);
    pacingSpread_->setSuffix(tr(" x frame time"));
    pacingSpread_->setToolTip(
        tr("How slowly to spread a paced burst. Higher values add a little latency "
                       "but cope with a more congested link. Available before the broadcast "
                       "starts."));

    auto* packetsForm = new QFormLayout;
    packetsForm->setContentsMargins(0, 0, 0, 0);
    packetsForm->setHorizontalSpacing(14);
    packetsForm->setVerticalSpacing(10);
    packetsForm->setLabelAlignment(Qt::AlignRight | Qt::AlignVCenter);
    packetsForm->setFieldGrowthPolicy(QFormLayout::AllNonFixedFieldsGrow);
    packetsForm->addRow(localstream::ui::makeLabel(packets.box,
        tr("Maximum packet"), maxPayload_), maxPayload_);
    packetsForm->addRow(localstream::ui::makeLabel(packets.box,
        tr("Start pacing at"), pacingThreshold_), pacingThreshold_);
    packetsForm->addRow(localstream::ui::makeLabel(packets.box,
        tr("Spread over"), pacingSpread_), pacingSpread_);
    packets.body->addLayout(packetsForm);
    packets.body->addWidget(localstream::ui::makeHint(packets.box,
        tr("How the video is split into datagrams. These are read when the broadcast "
                       "starts, so they wait until it is stopped to take effect.")));

    left->addWidget(packets.box);

    // Restore the remembered fragmentation choices before wiring the save handlers, so setting
    // the controls below does not immediately write them back. A stored value with no matching
    // preset (a hand-edited settings file, or a value this build no longer offers) falls back to
    // the default entry rather than leaving the combo pointing at nothing.
    {
        const int savedPayload = localstream::ui::rtpMaxPayload();
        int payloadIndex = maxPayload_->findData(savedPayload);
        if (payloadIndex < 0) {
            payloadIndex = maxPayload_->findData(localstream::protocol::LocalStream::RtpMaxPayload);
        }
        maxPayload_->setCurrentIndex(payloadIndex);
        pacingThreshold_->setValue(localstream::ui::pacingThresholdPackets());
        pacingSpread_->setValue(localstream::ui::pacingSpreadFrames());
    }

    connect(maxPayload_, &QComboBox::currentIndexChanged, this, [this](int) {
        localstream::ui::setRtpMaxPayload(maxPayload_->currentData().toInt());
    });
    connect(pacingThreshold_, &QSpinBox::valueChanged, this, [this](int value) {
        localstream::ui::setPacingThresholdPackets(value);
    });
    connect(pacingSpread_, &QSpinBox::valueChanged, this, [this](int value) {
        localstream::ui::setPacingSpreadFrames(value);
    });

    // ---------------------------------------------------------------- access
    auto access = localstream::ui::makeCard(tr("Who can watch"), this);
    accessCard_ = access.box;

    accessMode_ = new QComboBox(access.box);
    accessMode_->addItem(tr("Anyone on the network"),
        QString::fromLatin1(localstream::protocol::access::Public));
    accessMode_->addItem(tr("Ask me first"),
        QString::fromLatin1(localstream::protocol::access::Approval));
    accessMode_->addItem(tr("Only with a password"),
        QString::fromLatin1(localstream::protocol::access::Password));

    accessPassword_ = new QLineEdit(access.box);
    accessPassword_->setEchoMode(QLineEdit::Password);
    // Bounded to what the engine accepts, so the user cannot type a password the broadcaster will
    // refuse to start with.
    accessPassword_->setMaxLength(localstream::protocol::accesslimits::MaxPasswordLength);
    accessPassword_->setPlaceholderText(
        tr("Between %1 and %2 characters")
            .arg(localstream::protocol::accesslimits::MinPasswordLength)
            .arg(localstream::protocol::accesslimits::MaxPasswordLength));

    auto* accessForm = new QFormLayout;
    accessForm->setContentsMargins(0, 0, 0, 0);
    accessForm->setHorizontalSpacing(14);
    accessForm->setVerticalSpacing(10);
    accessForm->setLabelAlignment(Qt::AlignRight | Qt::AlignVCenter);
    accessForm->setFieldGrowthPolicy(QFormLayout::AllNonFixedFieldsGrow);
    accessForm->addRow(localstream::ui::makeLabel(access.box, tr("Access"), accessMode_),
        accessMode_);
    // Added as a row rather than shown or hidden so the layout does not jump when the mode
    // changes, and only the password row is enabled when the mode needs it.
    accessPasswordRow_ = tr("Password");
    accessForm->addRow(
        localstream::ui::makeLabel(access.box, accessPasswordRow_, accessPassword_),
        accessPassword_);

    // A button beside the field rather than an apply-on-return, because a running password-mode
    // broadcast offers no other moment to apply a new password: the combo has not changed, and a
    // return-key handler would be invisible and unreachable for anyone not using a keyboard.
    accessApplyPassword_ = new QPushButton(tr("Use this password"), access.box);
    accessApplyPassword_->setEnabled(false);
    accessApplyPassword_->setAccessibleName(
        tr("Use this password for viewers who connect from now on"));
    accessForm->addRow(QString(), accessApplyPassword_);

    access.body->addLayout(accessForm);
    access.body->addWidget(localstream::ui::makeHint(access.box,
        tr("This takes effect straight away, so you can lock a broadcast you have "
                       "already started. Viewers already watching keep their stream.")));

    left->addWidget(access.box);
    left->addStretch(1);
    columns->addLayout(left, 1);

    // ------------------------------------------------------------------- status
    auto* right = new QVBoxLayout;
    right->setSpacing(14);

    auto panel = localstream::ui::makeCard(tr("Broadcast"), this);
    panel.box->setFixedWidth(360);

    status_ = new localstream::ui::StatusPill(panel.box);
    panel.body->addWidget(status_);

    statistics_ = new QLabel(panel.box);
    statistics_->setObjectName(QStringLiteral("statText"));
    statistics_->setTextFormat(Qt::PlainText);
    statistics_->setWordWrap(true);
    panel.body->addWidget(statistics_);

    endpoint_ = new QLabel(panel.box);
    endpoint_->setObjectName(QStringLiteral("endpoint"));
    endpoint_->setWordWrap(true);
    endpoint_->setTextInteractionFlags(Qt::TextSelectableByMouse);
    panel.body->addWidget(endpoint_);

    startButton_ = new QPushButton(tr("Start broadcast"), panel.box);
    startButton_->setObjectName(QStringLiteral("primaryButton"));
    startButton_->setMinimumHeight(40);
    startButton_->setDefault(true);
    startButton_->setToolTip(tr("Start sharing this computer on the local network."));
    panel.body->addWidget(startButton_);

    panel.body->addWidget(localstream::ui::makeHint(
        panel.box,
        tr("Give viewers the address and control port above if they cannot see this "
                       "broadcast in their list.")));

    right->addWidget(panel.box);
    right->addStretch(1);
    columns->addLayout(right, 0);

    layout->addLayout(columns, 1);

    status_->setStatus(tr("Ready to broadcast"), StatusKind::Idle);
    refreshEndpoint();

    // The quality card is only meaningful when video is being sent, and a setting that cannot
    // take effect until the session ends should look like it. One rule, applied from every
    // place that can change it, so wiring `runningChanged` straight to setEnabled cannot
    // re-enable the card while broadcasting with video switched off.
    connect(includeVideo_, &QCheckBox::toggled, this, [this](bool includeVideo) {
        refreshControls();
        if (!running_) {
            return;
        }
        engine_->setMode(includeVideo
            ? QString::fromLatin1(localstream::protocol::LocalStream::ModeAudioVideo)
            : QString::fromLatin1(localstream::protocol::LocalStream::ModeAudioOnly));
        status_->setStatus(includeVideo
                ? tr("Switched to audio and video. A keyframe follows shortly.")
                : tr("Switched to audio only. The video encoder stays warm."),
            StatusKind::Live);
    });
    connect(includeTestPattern_, &QCheckBox::toggled, this, &BroadcastPage::refreshControls);

    // The mode drives the engine live, so it stays enabled while running, unlike everything on
    // this page. A change is applied as soon as it is chosen, and a refusal from the engine --
    // an unknown mode, or a password that does not fit -- is reported rather than silently
    // ignored, because the user would otherwise believe a broadcast is locked when it is not.
    connect(accessMode_, &QComboBox::currentIndexChanged, this, [this](int) {
        refreshControls();
        applyAccess();
    });

    // The password is applied by this button rather than by the combo, so a running broadcast
    // can be given a new password without first being switched away from password mode - which
    // would let anyone who arrived in between walk in.
    connect(accessApplyPassword_, &QPushButton::clicked, this, [this] { applyAccess(); });
    connect(accessPassword_, &QLineEdit::textChanged, this, [this] { refreshControls(); });

    connect(this, &BroadcastPage::runningChanged, this, [this](bool) {
        refreshControls();
        refreshEndpoint();
    });
    connect(microphoneRefresh_, &QPushButton::clicked, this,
            &BroadcastPage::refreshMicrophones);

    connect(startButton_, &QPushButton::clicked, this, [this] {
        if (running_) {
            stopBroadcast();
        } else {
            startBroadcast();
        }
    });

    connect(engine_, &localstream::engine::BroadcastEngine::started, this, [this] {
        setRunning(true);
        // The control port is on screen because it is the one thing a viewer cannot work out on
        // their own: discovery can be blocked by a firewall, and a typed address plus this number
        // gets them watching anyway.
        status_->setStatus(
            tr("Broadcasting as %1. Control port %2 - viewers who cannot find this "
                           "automatically can connect manually.")
                .arg(displayName_)
                .arg(engine_->controlPort()),
            StatusKind::Live);
    });

    connect(engine_, &localstream::engine::BroadcastEngine::stopped, this, [this] {
        setRunning(false);
        status_->setStatus(tr("Broadcast stopped."), StatusKind::Idle);
        statistics_->clear();
    });

    connect(engine_, &localstream::engine::BroadcastEngine::failed, this,
        [this](const QString& reason) {
            const bool wasRunning = running_;
            setRunning(false);
            showError(reason, wasRunning);
        });

    connect(engine_, &localstream::engine::BroadcastEngine::warning, this,
        [this](const QString& message) {
            // A warning must not tear the session down, but it cannot be silent either: a viewer
            // seeing a frozen picture deserves to know the broadcaster knows. It is shown as an
            // error state because the session is degraded, and announced as one.
            status_->setStatus(message, StatusKind::Error);
        });

    connect(engine_, &localstream::engine::BroadcastEngine::statsChanged, this,
        [this](int framesPerSecond, int kilobitsPerSecond, int receiverCount, int packetsPerFrame,
            int fragmentsPerFrame, int largestPayloadBytes) {
            // Never announced: this line changes every second, and a screen reader that repeated
            // it would drown out everything else. The joins and leaves below carry the same
            // information as events instead.
            QString text = tr("%1 fps - %2 kbps - %3 receiver(s)")
                .arg(framesPerSecond)
                .arg(kilobitsPerSecond)
                .arg(receiverCount);
            // The packet shape is only meaningful while video is being sent; in audio only it
            // would report a stale figure from the last video frame.
            if (includeVideo_->isChecked() && packetsPerFrame > 0) {
                text += tr("\nLast frame: %1 packet(s), %2 FU-A, largest %3 bytes")
                    .arg(packetsPerFrame)
                    .arg(fragmentsPerFrame)
                    .arg(largestPayloadBytes);
            }
            statistics_->setText(text);
        });

    connect(engine_, &localstream::engine::BroadcastEngine::receiverJoined, this,
        [this](const QString& name) {
            status_->setStatus(tr("Broadcasting. %1 joined.").arg(name),
                               StatusKind::Live);
        });

    connect(engine_, &localstream::engine::BroadcastEngine::receiverLeft, this,
        [this](const QString& name) {
            status_->setStatus(tr("Broadcasting. %1 left.").arg(name),
                               StatusKind::Live);
        });

    // A viewer asking to watch. The prompt is modal and parented to the window, and the request
    // key travels with it so the answer can be matched to the right viewer even if two prompts
    // are somehow open at once.
    connect(engine_, &localstream::engine::BroadcastEngine::accessRequested, this,
        [this](quint64 requestKey, const QString& name) { promptForAccess(requestKey, name); });

    // Last: this repopulates the microphone list and, through refreshControls(), reads every
    // other control on the page, so it has to run once the page is fully built.
    refreshMicrophones();
    refreshControls();
}

BroadcastPage::~BroadcastPage()
{
    stopBroadcast();
}

void BroadcastPage::showEvent(QShowEvent* event)
{
    QWidget::showEvent(event);
    refreshEndpoint();
}

void BroadcastPage::startBroadcast()
{
    localstream::engine::BroadcastEngine::Settings settings;
    displayName_ = QSysInfo::machineHostName().isEmpty()
        ? tr("Windows PC")
        : QSysInfo::machineHostName();
    settings.displayName = displayName_;

    const QSize size = resolution_->currentData().toSize();
    settings.width = size.width();
    settings.height = size.height();
    settings.videoBitrateKbps = videoBitrate_->value();
    settings.audioBitrateKbps = audioBitrate_->value();
    settings.rtpMaxPayload = maxPayload_->currentData().toInt();
    settings.pacingThresholdPackets = pacingThreshold_->value();
    settings.pacingSpreadFrames = pacingSpread_->value();
    settings.useTestSources = includeTestPattern_->isChecked();
    settings.audioDeviceName = microphone_->currentData().toString();
    settings.normalizeAudio = normalizeAudio_->isChecked();
    settings.accessMode = accessMode_->currentData().toString();
    settings.accessPassword = accessPassword_->text();

    status_->setStatus(tr("Starting the broadcast..."), StatusKind::Idle);

    QString error;
    if (!engine_->start(settings, &error)) {
        showError(error, false);
        return;
    }

    // Set after start() succeeds so the controls only lock once there is something to protect.
    // The engine applies the mode itself, and asking twice would be two chances to disagree.
    if (!includeVideo_->isChecked()) {
        engine_->setMode(QString::fromLatin1(localstream::protocol::LocalStream::ModeAudioOnly));
    }

    // The engine has the same password now, so the field is cleared and the apply button has
    // nothing left to offer until a different one is typed.
    if (settings.accessMode
        == QLatin1String(localstream::protocol::access::Password)) {
        lastAppliedPassword_ = settings.accessPassword;
        accessPassword_->clear();
    }
    refreshControls();
}

void BroadcastPage::applyAccess()
{
    const QString mode = accessMode_->currentData().toString();
    const QString password = accessPassword_->text();

    // Not broadcast, and not while starting: both are applied by start() from the same settings,
    // and calling the live setter then would be a second chance for the two to disagree.
    if (!running_) {
        return;
    }
    if (!engine_->setAccess(mode, password)) {
        if (mode == QLatin1String(localstream::protocol::access::Password)) {
            localstream::ui::showMessage(this, tr("That password cannot be used"),
                tr("The broadcast password must be between %1 and %2 characters.")
                    .arg(localstream::protocol::accesslimits::MinPasswordLength)
                    .arg(localstream::protocol::accesslimits::MaxPasswordLength));
        } else {
            localstream::ui::showMessage(this, tr("Could not change who can watch"),
                                         tr("The access mode was not accepted."));
        }
        // Put the control back where it was, so the shown state matches the broadcast. Without
        // this the panel would claim a password is in force while no password is being checked.
        const QSignalBlocker blocker(accessMode_);
        accessMode_->setCurrentIndex(indexForAccessMode(engine_->accessMode()));
        refreshControls();
        return;
    }
    // The password is not echoed anywhere, so the field is cleared once the engine holds it.
    // It stays in the engine for the life of the broadcast and goes when it stops.
    lastAppliedPassword_ = password;
    accessPassword_->clear();
    refreshControls();
    status_->setStatus(tr("Access set to: %1. It applies to viewers who connect from "
                                      "now on.")
                           .arg(accessMode_->currentText()),
                       StatusKind::Live);
}

int BroadcastPage::indexForAccessMode(const QString& mode) const
{
    const int index = accessMode_->findData(mode);
    return index >= 0 ? index : 0;
}

void BroadcastPage::stopBroadcast()
{
    if (!running_) {
        return;
    }
    status_->setStatus(tr("Stopping the broadcast..."), StatusKind::Idle);
    engine_->stop();
}

void BroadcastPage::setRunning(bool running)
{
    running_ = running;
    startButton_->setText(running ? tr("Stop broadcast")
                                  : tr("Start broadcast"));
    // Red while it is the thing that ends a live session, blue while it is the thing that
    // begins one. The label alone does not carry that at a glance.
    const QString buttonKind = running ? QStringLiteral("dangerButton")
                                       : QStringLiteral("primaryButton");
    if (startButton_->objectName() != buttonKind) {
        startButton_->style()->unpolish(startButton_);
        startButton_->setObjectName(buttonKind);
        startButton_->style()->polish(startButton_);
    }
    startButton_->setDefault(!running);
    refreshControls();
    refreshEndpoint();
    emit runningChanged(running);
}

void BroadcastPage::promptForAccess(quint64 requestKey, const QString& name)
{
    // The name is what the viewer typed in, and it is the only thing that identifies them: the
    // connection's IP is not shown, because a name is what the user recognises and what a wrong
    // answer is judged against.
    const QString viewer = name.trimmed().isEmpty() ? tr("A device") : name.trimmed();

    const bool allowed = localstream::ui::confirm(this,
        tr("Allow %1 to watch?").arg(viewer),
        tr("%1 wants to view your broadcast.").arg(viewer),
        tr("Allow"), tr("Reject"));

    // Always answered, including when the broadcast has stopped while the dialog was up: the
    // engine drops unanswered requests on stop, so an answer after the fact would be a no-op.
    // Answering anyway keeps the two paths in step and cannot admit anyone into a dead session.
    engine_->resolveAccessRequest(requestKey, allowed);
    status_->setStatus(allowed ? tr("Broadcasting. %1 was allowed in.").arg(viewer)
                               : tr("Broadcasting. %1 was rejected.").arg(viewer),
        StatusKind::Live);
}

void BroadcastPage::showError(const QString& reason, bool wasRunning)
{
    statistics_->clear();
    if (wasRunning) {
        status_->setStatus(tr("The broadcast stopped."), StatusKind::Error);
        localstream::ui::showMessage(
            this, tr("The broadcast stopped"),
            tr("Viewers have been disconnected.\n\n%1").arg(reason));
    } else {
        status_->setStatus(tr("Could not start broadcasting."),
                           StatusKind::Error);
        localstream::ui::showMessage(this, tr("Could not start broadcasting"),
                                     reason);
    }
}

void BroadcastPage::refreshMicrophones()
{
    const QString selected = microphone_->currentData().toString();

    microphone_->clear();
    const QList<localstream::capture::DeviceOption> devices
        = localstream::capture::listMicrophones();
    for (const auto& device : devices) {
        microphone_->addItem(device.name, device.name);
    }

    if (devices.isEmpty()) {
        // Not an error here: the list is built on demand, and a microphone plugged in after
        // this window opened would otherwise be permanently invisible.
        microphone_->addItem(tr("No microphone found"), QString());
    } else if (const int keep = microphone_->findData(selected); keep >= 0) {
        // Losing the choice because the list was rescanned is a silent change to what the
        // user is about to broadcast.
        microphone_->setCurrentIndex(keep);
    }

    refreshControls();
}

void BroadcastPage::refreshControls()
{
    const bool video = includeVideo_->isChecked();
    const bool microphoneUsable = microphone_->count() > 0
        && !microphone_->currentData().toString().isEmpty();

    // Everything the engine reads once, at start(): letting it move while running would be a
    // control that says one thing and a stream that does another.
    qualityCard_->setEnabled(!running_ && video);
    packetsCard_->setEnabled(!running_ && video);
    includeTestPattern_->setEnabled(!running_);
    normalizeAudio_->setEnabled(!running_);
    microphoneRefresh_->setEnabled(!running_);
    microphone_->setEnabled(!running_ && !includeTestPattern_->isChecked()
        && microphoneUsable);

    // The access mode is applied live, so unlike everything above it is never disabled. Only the
    // password follows the mode: shown and editable when the broadcast is locked by password,
    // and readable-looking but inert otherwise, so the field does not vanish from under a
    // half-typed password when the user goes back to change their mind about the mode.
    const bool passwordMode = accessMode_->currentData().toString()
        == QLatin1String(localstream::protocol::access::Password);
    accessPassword_->setEnabled(passwordMode);
    accessPassword_->setToolTip(passwordMode
        ? QString()
        : tr("Only used when access is set to a password."));
    // Only offered when there is something to apply: a password the engine would refuse, or one
    // that has already been applied, leaves the button disabled rather than throwing an error
    // at someone who has done nothing wrong.
    const QString typed = accessPassword_->text();
    // Dropped with the broadcast, as the engine's own copy is: this one exists only to recognise
    // a password that has already been applied, so once there is no broadcast to apply it to it is
    // a plaintext secret the page has no reason to be holding.
    if (!running_) {
        lastAppliedPassword_.clear();
    }
    accessApplyPassword_->setEnabled(running_ && passwordMode
        && localstream::protocol::isValidAccessPassword(typed)
        && typed != lastAppliedPassword_);
}

void BroadcastPage::refreshEndpoint()
{
    // Read from the engine rather than chosen here: the announcement publishes this same address
    // under mDNS, so the line the viewer is told to use and the name that appears in their list
    // are one answer. Choosing independently was what let this page print a virtual adapter's
    // 172.x address while discovery published the real 192.168 one -- two correct-looking
    // answers, and the one handed to a viewer was the one that could not be reached.
    const QString address =
        localstream::engine::BroadcastEngine::localAddress().toString();
    QString text = address.isEmpty()
        ? tr("No network address - is this computer on a network?")
        : tr("Address %1").arg(address);
    if (running_) {
        text += tr("  ·  control port %1").arg(engine_->controlPort());
    }
    endpoint_->setText(text);
}
