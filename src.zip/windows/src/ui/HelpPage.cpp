#include "ui/HelpPage.h"

#include "logging/Diagnostics.h"
#include "logging/Log.h"
#include "ui/AppSettings.h"
#include "ui/Language.h"
#include "ui/UiKit.h"

#include <QCheckBox>
#include <QComboBox>
#include <QDesktopServices>
#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QFormLayout>
#include <QFrame>
#include <QLabel>
#include <QProcess>
#include <QPushButton>
#include <QScrollArea>
#include <QSpinBox>
#include <QStandardPaths>
#include <QUrl>
#include <QVBoxLayout>
#include <QCoreApplication>

namespace {

/// The tutorial as compiled into the binary. The canonical file lives in docs/ at the repo root.
constexpr char kTutorialResource[] = ":/ui/Tutorial.html";

/// The name it keeps on disk, so the browser tab reads "Tutorial" rather than a hash.
constexpr char kTutorialFileName[] = "Tutorial.html";

} // namespace

HelpPage::HelpPage(QWidget* parent) : QWidget(parent)
{
    setObjectName(QStringLiteral("page"));
    setAttribute(Qt::WA_StyledBackground, true);
    setAccessibleName(tr("LocalStream tutorial"));

    auto* pageLayout = new QVBoxLayout(this);
    pageLayout->setContentsMargins(0, 12, 0, 0);
    pageLayout->setSpacing(14);

    // The cards go into a scrolling column rather than straight onto the page. This tab has
    // always been taller than a short window, and a control below the fold - the report
    // buttons, the About card - is a control that does not exist: the page was clipped with
    // no way to reach what was clipped. The column is sized by its contents, so the scrollbar
    // appears exactly when the window is too short for them and not otherwise.
    auto* scroller = new QScrollArea(this);
    scroller->setObjectName(QStringLiteral("helpScroller"));
    scroller->setWidgetResizable(true);
    scroller->setFrameShape(QFrame::NoFrame);
    scroller->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);

    auto* content = new QWidget(scroller);
    // The same object name as the page, so the column paints the window colour behind the gaps
    // between the cards instead of showing whatever the viewport would otherwise leave there.
    content->setObjectName(QStringLiteral("page"));
    content->setAttribute(Qt::WA_StyledBackground, true);

    auto* layout = new QVBoxLayout(content);
    layout->setContentsMargins(0, 0, 0, 0);
    layout->setSpacing(14);

    scroller->setWidget(content);
    pageLayout->addWidget(scroller, 1);

    // ------------------------------------------------------------- the tutorial itself
    auto tutorial = localstream::ui::makeCard(tr("LocalStream Tutorial"), this);
    tutorial.body->setSpacing(10);

    auto* intro = localstream::ui::makeHint(
        tutorial.box,
        tr("A guide that opens in your web browser: what the app is for, what each "
           "device needs, how to use it step by step, what every setting means, and "
           "what you can really do with it."));
    intro->setMaximumWidth(680);

    auto* openButton = new QPushButton(tr("Open the tutorial"), tutorial.box);
    openButton->setObjectName(QStringLiteral("primaryButton"));
    openButton->setCursor(Qt::PointingHandCursor);
    openButton->setMinimumHeight(44);
    openButton->setAccessibleName(tr("Open the tutorial in your web browser"));
    openButton->setToolTip(tr("Opens the tutorial in the program you use for web pages. It works offline."));
    connect(openButton, &QPushButton::clicked, this, &HelpPage::openTutorial);
    tutorial.body->addWidget(openButton);

    auto* note = localstream::ui::makeHint(
        tutorial.box,
        tr("The page is stored inside this app and opens without an internet "
           "connection. Ctrl+3 brings you back to this tab."));
    note->setMaximumWidth(680);
    tutorial.body->addWidget(note);

    layout->addWidget(tutorial.box);

    // ---------------------------------------------------------------- what is in it
    auto contents = localstream::ui::makeCard(tr("What is inside"), this);
    contents.body->setSpacing(6);

    // Plain text with bullet characters rather than rich text: a screen reader reads the list
    // in order either way, and this cannot turn a stray character into markup.
    auto* topics = new QLabel(this);
    topics->setObjectName(QStringLiteral("hint"));
    topics->setWordWrap(true);
    topics->setMaximumWidth(680);
    topics->setText(
        tr("\u2022 What LocalStream is for: sharing a screen and a sound, following "
           "a computer from your phone, watching the same thing at the same time\n"
           "\u2022 What you need on Windows, on Android, and on the network between "
           "them\n"
           "\u2022 Using it step by step, as if you were doing it now\n"
           "\u2022 Every setting on both tabs, explained in plain words\n"
           "\u2022 Running in the background: what the switch on this tab does, and "
           "how the app stays alive beside the clock\n"
           "\u2022 What this build is: version, date, creator and license\n"
           "\u2022 Scenarios the apps really support, and what they do not do\n"
           "\u2022 What to do when the list stays empty or the picture breaks up"));
    contents.body->addWidget(topics);

    layout->addWidget(contents.box);

    // ------------------------------------------------------------ where the file is
    auto location = localstream::ui::makeCard(tr("Where the file is"), this);
    auto* locationHint = localstream::ui::makeHint(
        location.box,
        tr("The tutorial is kept with this app's settings. If your computer has no "
           "program set up for web pages, open this file yourself:"));
    locationHint->setMaximumWidth(680);

    location_ = new QLabel(location.box);
    location_->setObjectName(QStringLiteral("hint"));
    location_->setWordWrap(true);
    location_->setTextInteractionFlags(Qt::TextSelectableByMouse | Qt::TextSelectableByKeyboard);
    // No accessible name: the label's own text is the path, and a name here would be read
    // *instead* of it. "Tutorial file location" is the kind of sentence that tells a
    // screen-reader user nothing they cannot see, and it would hide the part they need.
    location_->setMaximumWidth(680);

    location.body->addWidget(locationHint);
    location.body->addWidget(location_);

    auto* revealButton = new QPushButton(tr("Show the file in File Explorer"), location.box);
    // No object name: the theme styles a plain QPushButton as the secondary button, which is what
    // this is next to the accent-coloured Open the tutorial above.
    revealButton->setCursor(Qt::PointingHandCursor);
    revealButton->setMinimumHeight(40);
    revealButton->setAccessibleName(tr("Show the tutorial file in File Explorer"));
    revealButton->setToolTip(tr("Useful when clicking Open the tutorial does nothing, "
                                "because this computer has no program set up for web "
                                "pages."));
    connect(revealButton, &QPushButton::clicked, this, &HelpPage::revealTutorialFile);
    location.body->addWidget(revealButton);

    layout->addWidget(location.box);

    // ------------------------------------------------------------------- general
    auto general = localstream::ui::makeCard(tr("General"), this);
    general.body->setSpacing(10);

    auto* generalIntro = localstream::ui::makeHint(
        general.box,
        tr("What closing the window means. The choice is remembered, so it has to "
           "be made once."));
    generalIntro->setMaximumWidth(680);
    general.body->addWidget(generalIntro);

    runInBackground_ =
        new QCheckBox(tr("Run in background (continue when closed)"), general.box);
    runInBackground_->setAccessibleName(
        tr("Run in background (continue when closed)"));
    runInBackground_->setToolTip(
        tr("Closing the window hides LocalStream beside the clock instead of "
           "exiting it, so a broadcast keeps running while the window is gone. "
           "Double-click the tray icon, or choose Show on it, to bring the window "
           "back; Quit leaves."));
    // Read before the connection is made, so building the page is not a change to log.
    runInBackground_->setChecked(localstream::ui::runInBackground());
    connect(runInBackground_, &QCheckBox::toggled, this,
        &HelpPage::applyRunInBackgroundSetting);
    general.body->addWidget(runInBackground_);

    auto* backgroundHint = localstream::ui::makeHint(
        general.box,
        tr("While it is on, the app's icon sits by the clock with Show and Quit on "
           "it. Switching it on or off, and hiding or restoring the window, is "
           "written to the log, so a report can say whether the app was still "
           "running at the time."));
    backgroundHint->setMaximumWidth(680);
    general.body->addWidget(backgroundHint);

    layout->addWidget(general.box);

    // ------------------------------------------------------------------ language
    {
        auto languageCard = localstream::ui::makeCard(tr("Language"), this);
        languageCard.body->setSpacing(10);

        auto* languageIntro = localstream::ui::makeHint(
            languageCard.box,
            tr("The language the app is written in. Changing it restarts LocalStream so "
               "the whole window is in the new language."));
        languageIntro->setMaximumWidth(680);
        languageCard.body->addWidget(languageIntro);

        language_ = new QComboBox(languageCard.box);
        language_->setAccessibleName(tr("Language"));

        {
            const QString systemName = localstream::ui::systemLanguageNativeName();
            const QString systemLabel = systemName.isEmpty()
                ? tr("System language")
                : tr("System language (%1)").arg(systemName);
            language_->addItem(systemLabel, QString());
        }

        for (const localstream::ui::Language& entry : localstream::ui::availableLanguages()) {
            language_->addItem(entry.nativeName, entry.code);
        }

        const QString preferred = localstream::ui::preferredLanguageCode();
        const int idx = language_->findData(preferred);
        language_->setCurrentIndex(idx >= 0 ? idx : 0);

        connect(language_, &QComboBox::currentIndexChanged, this,
                &HelpPage::applyLanguageSetting);

        languageCard.body->addWidget(language_);
        layout->addWidget(languageCard.box);
    }

    // ------------------------------------------------------------- report a problem
    auto report = localstream::ui::makeCard(tr("Report a problem"), this);
    report.body->setSpacing(10);

    auto* reportIntro = localstream::ui::makeHint(
        report.box,
        tr("LocalStream keeps a detailed log of what it does, with the exact date and "
           "time of every event. Turn it on here, and then write a report you can "
           "attach to a message or keep for yourself."));
    reportIntro->setMaximumWidth(680);
    report.body->addWidget(reportIntro);

    // The recording switch comes first in the card, before anything that shapes the log: every
    // other control here decides what the log contains, and none of that matters while nothing
    // is being written.
    recordAutomatically_ = new QCheckBox(tr("Record a log automatically"), report.box);
    recordAutomatically_->setAccessibleName(tr("Record a log automatically"));
    recordAutomatically_->setToolTip(
        tr("Writes what the app does to a log file while you use it. Turn this on "
           "before the problem happens, because a report written afterwards cannot "
           "describe it."));
    report.body->addWidget(recordAutomatically_);

    const localstream::logging::Settings current = localstream::logging::settings();
    recordAutomatically_->setChecked(current.recordAutomatically);

    minimumLevel_ = new QComboBox(report.box);
    for (const localstream::logging::Level level :
         {localstream::logging::Level::Debug, localstream::logging::Level::Info,
             localstream::logging::Level::Warning, localstream::logging::Level::Error}) {
        minimumLevel_->addItem(localstream::logging::levelName(level), static_cast<int>(level));
    }
    minimumLevel_->setToolTip(tr("Lines below this level are left out. Warning is the "
                                 "quieter choice; Debug records everything."));

    milliseconds_ = new QCheckBox(tr("Include milliseconds"), report.box);
    milliseconds_->setToolTip(tr("Records the fraction of a second, which is often "
                                 "the whole explanation for a stall."));

    clockFormat_ = new QComboBox(report.box);
    clockFormat_->addItem(tr("24-hour, with time zone"), false);
    clockFormat_->addItem(tr("12-hour, am/pm"), true);
    clockFormat_->setToolTip(tr("The 24-hour form also writes the time zone offset, "
                                "so a report can be lined up against other logs."));

    keepDays_ = new QSpinBox(report.box);
    keepDays_->setRange(1, 90);
    keepDays_->setSuffix(tr(" days"));
    keepDays_->setToolTip(tr("Log files older than this are deleted. Seven days is "
                             "usually enough to notice a problem that comes and goes."));

    maxFileSizeMiB_ = new QSpinBox(report.box);
    maxFileSizeMiB_->setRange(1, 64);
    maxFileSizeMiB_->setSuffix(tr(" MiB"));
    maxFileSizeMiB_->setToolTip(tr("The ceiling for one day's log. Past it the file "
                                   "rolls over, so a long session cannot fill the "
                                   "disk."));

    minimumLevel_->setCurrentIndex(minimumLevel_->findData(static_cast<int>(current.minimumLevel)));
    milliseconds_->setChecked(current.milliseconds);
    clockFormat_->setCurrentIndex(current.twelveHourClock ? 1 : 0);
    keepDays_->setValue(current.keepDays);
    maxFileSizeMiB_->setValue(current.maxFileSizeMiB);

    auto* logForm = new QFormLayout;
    logForm->setContentsMargins(0, 0, 0, 0);
    logForm->setHorizontalSpacing(14);
    logForm->setVerticalSpacing(10);
    logForm->setLabelAlignment(Qt::AlignRight | Qt::AlignVCenter);
    logForm->setFieldGrowthPolicy(QFormLayout::AllNonFixedFieldsGrow);
    logForm->addRow(localstream::ui::makeLabel(report.box, tr("Record from level"),
                                               minimumLevel_),
        minimumLevel_);
    logForm->addRow(QString(), milliseconds_);
    logForm->addRow(localstream::ui::makeLabel(report.box, tr("Time format"),
                                               clockFormat_),
        clockFormat_);
    logForm->addRow(localstream::ui::makeLabel(report.box, tr("Keep log files"),
                                               keepDays_),
        keepDays_);
    logForm->addRow(localstream::ui::makeLabel(report.box, tr("Maximum size a day"),
                                               maxFileSizeMiB_),
        maxFileSizeMiB_);
    report.body->addLayout(logForm);

    // Initialised from the defaults rather than from literals here, so a change to
    // ReportOptions cannot leave the controls disagreeing with what the report writer expects.
    const localstream::logging::ReportOptions reportDefaults;
    includeSystemInfo_ = new QCheckBox(tr("Include this computer's details"),
                                       report.box);
    includeSystemInfo_->setToolTip(tr("The Windows version, the app version, the "
                                      "display and the free space on disk."));

    includeLogLines_ = new QCheckBox(tr("Include the log itself"), report.box);
    includeLogLines_->setToolTip(tr("The most recent lines of the log, which is where "
                                    "the answer usually is."));

    logTailKib_ = new QSpinBox(report.box);
    logTailKib_->setRange(16, 8192);
    logTailKib_->setSingleStep(64);
    logTailKib_->setSuffix(tr(" KiB"));
    logTailKib_->setToolTip(tr("How much of the log to include. 256 KiB is a few "
                               "minutes of a normal session."));

    includeEarlierDays_ = new QCheckBox(tr("Include the days before today"),
                                        report.box);
    includeEarlierDays_->setToolTip(tr("For a problem that started yesterday and was "
                                       "only noticed this morning."));

    includeSettings_ = new QCheckBox(tr("Include these settings"), report.box);
    includeSettings_->setToolTip(tr("The settings above, which decide what the log "
                                    "contains in the first place."));

    // A report with nothing in it is not worth writing, so the three parts that make one useful
    // start included; the day before today does not, because it is several times the size for a
    // problem that is usually still happening.
    includeSystemInfo_->setChecked(reportDefaults.includeSystemInfo);
    includeLogLines_->setChecked(reportDefaults.includeLogLines);
    includeSettings_->setChecked(reportDefaults.includeSettings);
    includeEarlierDays_->setChecked(reportDefaults.includeEarlierDays);

    logTailKib_->setValue(reportDefaults.logTailKib);
    logTailKib_->setEnabled(includeLogLines_->isChecked());

    auto* contentsForm = new QFormLayout;
    contentsForm->setContentsMargins(0, 0, 0, 0);
    contentsForm->setHorizontalSpacing(14);
    contentsForm->setVerticalSpacing(10);
    contentsForm->setLabelAlignment(Qt::AlignRight | Qt::AlignVCenter);
    contentsForm->setFieldGrowthPolicy(QFormLayout::AllNonFixedFieldsGrow);
    contentsForm->addRow(QString(), includeSystemInfo_);
    contentsForm->addRow(QString(), includeLogLines_);
    contentsForm->addRow(localstream::ui::makeLabel(report.box, tr("Log lines to "
                                                                  "include"),
                                                    logTailKib_),
        logTailKib_);
    contentsForm->addRow(QString(), includeEarlierDays_);
    contentsForm->addRow(QString(), includeSettings_);
    report.body->addLayout(contentsForm);

    // One place that turns every control into the settings object, so what is written to disk
    // can never depend on which control the user touched last.
    for (QComboBox* box : {minimumLevel_, clockFormat_}) {
        connect(box, &QComboBox::currentIndexChanged, this, [this] { applyLoggingSettings(); });
    }
    for (QCheckBox* box : {recordAutomatically_, milliseconds_, includeSystemInfo_,
             includeLogLines_, includeEarlierDays_, includeSettings_}) {
        connect(box, &QCheckBox::toggled, this, [this] { applyLoggingSettings(); });
    }
    for (QSpinBox* box : {keepDays_, maxFileSizeMiB_}) {
        connect(box, &QSpinBox::valueChanged, this, [this] { applyLoggingSettings(); });
    }

    // The size of the log excerpt is meaningless without the log itself, so it greys out with
    // it rather than staying enabled and quietly doing nothing.
    connect(includeLogLines_, &QCheckBox::toggled, this,
        [this](bool includeLines) { logTailKib_->setEnabled(includeLines); });

    auto* reportButtons = new QHBoxLayout;
    reportButtons->setSpacing(8);

    auto* saveReportButton = new QPushButton(tr("Save a report now"), report.box);
    saveReportButton->setObjectName(QStringLiteral("primaryButton"));
    saveReportButton->setCursor(Qt::PointingHandCursor);
    saveReportButton->setMinimumHeight(44);
    saveReportButton->setAccessibleName(tr("Save a report now"));
    saveReportButton->setToolTip(tr("Writes a report you can attach to a message. "
                                    "Nothing is sent anywhere."));
    connect(saveReportButton, &QPushButton::clicked, this, &HelpPage::writeReportNow);
    reportButtons->addWidget(saveReportButton);

    auto* openLogsButton = new QPushButton(tr("Open the log folder"), report.box);
    openLogsButton->setCursor(Qt::PointingHandCursor);
    openLogsButton->setMinimumHeight(44);
    openLogsButton->setAccessibleName(tr("Open the log folder"));
    openLogsButton->setToolTip(tr("Where the log files are kept."));
    connect(openLogsButton, &QPushButton::clicked, this, [this] {
        openFolder(localstream::logging::directory(), tr("log"));
    });
    reportButtons->addWidget(openLogsButton);

    auto* openReportsButton = new QPushButton(tr("Open the reports folder"), report.box);
    openReportsButton->setCursor(Qt::PointingHandCursor);
    openReportsButton->setMinimumHeight(44);
    openReportsButton->setAccessibleName(tr("Open the reports folder"));
    openReportsButton->setToolTip(tr("Where reports are saved."));
    connect(openReportsButton, &QPushButton::clicked, this, [this] {
        openFolder(localstream::logging::defaultReportDirectory(), tr("report"));
    });
    reportButtons->addWidget(openReportsButton);
    reportButtons->addStretch(1);

    report.body->addLayout(reportButtons);

    reportStatus_ = new QLabel(report.box);
    reportStatus_->setObjectName(QStringLiteral("hint"));
    reportStatus_->setWordWrap(true);
    reportStatus_->setTextInteractionFlags(
        Qt::TextSelectableByMouse | Qt::TextSelectableByKeyboard);
    reportStatus_->setMaximumWidth(680);
    report.body->addWidget(reportStatus_);

    layout->addWidget(report.box);

    // --------------------------------------------------------------------- about
    auto about = localstream::ui::makeCard(tr("About"), this);
    about.body->setSpacing(8);

    auto* aboutForm = new QFormLayout;
    aboutForm->setContentsMargins(0, 0, 0, 0);
    aboutForm->setHorizontalSpacing(14);
    aboutForm->setVerticalSpacing(8);
    aboutForm->setLabelAlignment(Qt::AlignRight | Qt::AlignVCenter);
    aboutForm->setFieldGrowthPolicy(QFormLayout::AllNonFixedFieldsGrow);

    // The values are selectable: a version number and a date are the two things people copy
    // out of an About box and into a message.
    const auto addAboutRow = [&about, aboutForm](const QString& key, const QString& value) {
        auto* field = new QLabel(value, about.box);
        field->setTextInteractionFlags(
            Qt::TextSelectableByMouse | Qt::TextSelectableByKeyboard);
        aboutForm->addRow(localstream::ui::makeLabel(about.box, key, field), field);
    };
    addAboutRow(tr("Project"), QStringLiteral("LocalStream"));
    addAboutRow(tr("Version"), QStringLiteral(LOCALSTREAM_VERSION));
    addAboutRow(tr("Date"), tr("October 2026"));
    addAboutRow(tr("Creator"), tr("Ahmed Ibrahim"));
    addAboutRow(tr("License"), tr("GNU GPLv3"));
    about.body->addLayout(aboutForm);

    auto* aboutHint = localstream::ui::makeHint(
        about.box,
        tr("Everything this app sends stays on your own network: no account, no "
           "upload, and no internet connection needed."));
    aboutHint->setMaximumWidth(680);
    about.body->addWidget(aboutHint);

    layout->addWidget(about.box);

    layout->addStretch(1);

    showTutorialLocation();
    // The status line starts empty rather than claiming a report exists: nothing has been
    // written yet, and a path shown before it exists is a promise the app cannot keep.
}

void HelpPage::openTutorial()
{
    const QString path = writeTutorialFile();
    if (path.isEmpty()) {
        localstream::ui::showMessage(
            this, tr("Tutorial"),
            tr("The tutorial could not be saved to this computer's settings folder, "
               "so it cannot be opened right now."));
        return;
    }

    showTutorialLocation();

    if (!QDesktopServices::openUrl(QUrl::fromLocalFile(path))) {
        // No browser, or one that refused this file type. The path is on screen and selectable,
        // so the user can open it by hand instead of being told only that it failed.
        localstream::ui::showMessage(
            this, tr("Tutorial"),
            tr("This computer has no program set up to open web pages.\n\nOpen this "
               "file yourself:\n%1").arg(path));
        return;
    }

    // Spoken, not just shown: the browser window can appear behind the app or on another
    // monitor, and a screen-reader user needs to know the press did something.
    localstream::ui::announce(this, tr("The tutorial is opening in your web browser."));
}

void HelpPage::revealTutorialFile()
{
    const QString path = writeTutorialFile();
    if (path.isEmpty()) {
        localstream::ui::showMessage(
            this, tr("Tutorial"),
            tr("The tutorial could not be saved to this computer's settings folder, "
               "so it cannot be shown right now."));
        return;
    }

    showTutorialLocation();

    // Opening the folder, not the file: on a machine whose web-page association is broken, the
    // shell discards a request to open the file without telling anyone, and the button looks
    // like it did nothing. Explorer always opens, and the file is right there in the folder.
    const QString folder = QFileInfo(path).absolutePath();
    if (!QProcess::startDetached(QStringLiteral("explorer.exe"), {QDir::toNativeSeparators(folder)})) {
        localstream::ui::showMessage(
            this, tr("Tutorial"),
            tr("File Explorer could not be opened.\n\nThe tutorial is here:\n%1").arg(path));
        return;
    }

    localstream::ui::announce(this, tr("The tutorial's folder is open in File Explorer."));
}

localstream::logging::Settings HelpPage::loggingSettingsFromControls() const
{
    localstream::logging::Settings next = localstream::logging::settings();
    // Read every control rather than changing one field on the object already in force: the
    // settings are written to disk as one blob, and a half-updated copy could put a value in
    // that the user never chose.
    next.recordAutomatically = recordAutomatically_->isChecked();
    next.minimumLevel = static_cast<localstream::logging::Level>(minimumLevel_->currentData().toInt());
    next.milliseconds = milliseconds_->isChecked();
    next.twelveHourClock = clockFormat_->currentData().toBool();
    next.keepDays = keepDays_->value();
    next.maxFileSizeMiB = maxFileSizeMiB_->value();
    return next;
}

void HelpPage::applyRunInBackgroundSetting()
{
    localstream::ui::setRunInBackground(runInBackground_->isChecked());
}

void HelpPage::applyLanguageSetting()
{
    const QString previousEffective = localstream::ui::effectiveLanguageCode();
    const QString code = language_->currentData().toString();
    localstream::ui::setPreferredLanguageCode(code);
    if (localstream::ui::effectiveLanguageCode() == previousEffective) {
        return;
    }
    if (!localstream::ui::confirm(this, tr("Restart LocalStream"),
            tr("LocalStream has to restart before the new language takes effect.\n\n"
               "Restart now? The window will close and open again."),
            tr("Restart now"), tr("Not now"))) {
        localstream::ui::announce(this,
            tr("The language will change the next time LocalStream starts."));
        return;
    }
    if (!localstream::ui::restartApplication()) {
        localstream::ui::showMessage(this, tr("Restart LocalStream"),
            tr("The app could not restart itself. Close it and open it again to see the "
               "new language."));
        return;
    }
    QCoreApplication::quit();
}

void HelpPage::applyLoggingSettings()
{
    localstream::logging::setSettings(loggingSettingsFromControls());
}

localstream::logging::ReportOptions HelpPage::reportOptionsFromControls() const
{
    localstream::logging::ReportOptions options;
    options.includeSystemInfo = includeSystemInfo_->isChecked();
    options.includeLogLines = includeLogLines_->isChecked();
    options.logTailKib = logTailKib_->value();
    options.includeEarlierDays = includeEarlierDays_->isChecked();
    options.includeSettings = includeSettings_->isChecked();
    return options;
}

void HelpPage::writeReportNow()
{
    const localstream::logging::ReportResult result = localstream::logging::writeReport(reportOptionsFromControls());

    if (!result.ok) {
        reportStatus_->setText(tr("The report could not be saved: %1").arg(result.error));
        localstream::ui::showMessage(this, tr("Report"),
            tr("The report could not be saved.\n\n%1").arg(result.error));
        localstream::logging::error(QStringLiteral("HelpPage"),
            QStringLiteral("report.write failed: %1").arg(result.error));
        return;
    }

    // The file list matters as much as the path: it says which logs actually went in, which is
    // the difference between a report that describes the failure and one that quietly has none.
    reportStatus_->setText(
        tr("Saved: %1\n%2 KiB, from %3 log file(s).")
            .arg(QDir::toNativeSeparators(result.path))
            .arg(result.bytes / 1024)
            .arg(result.includedFiles.size()));

    localstream::ui::announce(this,
        tr("Report saved as %1.").arg(QDir::toNativeSeparators(result.path)));
}

void HelpPage::openFolder(const QString& directory, const QString& what)
{
    if (directory.isEmpty()) {
        localstream::ui::showMessage(this, tr("Folders"),
            tr("This computer has no folder available for the %1 files.").arg(what));
        return;
    }
    if (!QDesktopServices::openUrl(QUrl::fromLocalFile(directory))) {
        localstream::ui::showMessage(this, tr("Folders"),
            tr("The folder could not be opened.\n\n%1")
                .arg(QDir::toNativeSeparators(directory)));
    }
}

QString HelpPage::tutorialPath()
{
    const QString directory =
        QStandardPaths::writableLocation(QStandardPaths::AppDataLocation);
    if (directory.isEmpty()) {
        return {};
    }
    return QDir(directory).filePath(QString::fromLatin1(kTutorialFileName));
}

QString HelpPage::writeTutorialFile()
{
    const QString code = localstream::ui::effectiveLanguageCode();
    QFile source(localstream::ui::tutorialResource(code));
    if (!source.open(QIODevice::ReadOnly)) {
        QFile fallback(QString::fromLatin1(kTutorialResource));
        if (!fallback.open(QIODevice::ReadOnly)) {
            return {};
        }
        const QString path = tutorialPath();
        if (path.isEmpty() || !QDir().mkpath(QFileInfo(path).absolutePath())) {
            return {};
        }
        QFile target(path);
        if (!target.open(QIODevice::WriteOnly | QIODevice::Truncate) ||
            target.write(fallback.readAll()) < 0) {
            return {};
        }
        return path;
    }

    const QString path = tutorialPath();
    if (path.isEmpty() || !QDir().mkpath(QFileInfo(path).absolutePath())) {
        return {};
    }

    QFile target(path);
    if (!target.open(QIODevice::WriteOnly | QIODevice::Truncate)) {
        return {};
    }
    if (target.write(source.readAll()) < 0) {
        return {};
    }
    return path;
}

void HelpPage::showTutorialLocation()
{
    if (location_ == nullptr) {
        return;
    }
    // The path is shown, not created: pressing the button writes the file, so a reader who only
    // ever wants to know where it will end up is not left with a copy they never asked for.
    const QString path = tutorialPath();
    location_->setText(path.isEmpty()
                           ? tr("No settings folder is available on this computer.")
                           : path);
}