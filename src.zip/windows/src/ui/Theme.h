#pragma once

#include <QObject>
#include <QString>

class QApplication;

namespace localstream::ui {

/**
 * The colours the interface is painted with.
 *
 * Kept as one value type so the stylesheet and the hand-drawn icons cannot drift apart: an icon
 * drawn from the active palette is legible on the background it ends up on, and one drawn from
 * a hard-coded grey is not.
 *
 * Every text/background pair here clears WCAG AA (4.5:1) against the surface it is used on, in
 * both palettes. A screen-reader user is often also a low-vision user, and the two
 * accommodations have to coexist rather than take turns.
 */
struct Palette
{
    /// App background.
    QString window;
    /// Cards, inputs, list - the surfaces text is read from.
    QString surface;
    /// Hover state of [surface].
    QString surfaceAlt;
    /// Pressed state of [surface].
    QString surfacePress;
    QString text;
    QString textMuted;
    QString border;
    /// Primary action colour.
    QString accent;
    QString accentHover;
    QString accentPress;
    /// Text drawn on top of [accent].
    QString accentText;
    /// Tinted accent, for a selection that is not the focused one.
    QString accentSoft;
    /// "Live" state.
    QString live;
    QString liveSoft;
    QString liveText;
    /// Failure state.
    QString danger;
    QString dangerSoft;
    QString dangerText;
    /// Keyboard focus ring.
    QString focus;
    /// Background of the video area, never tinted: a picture must not be colour-cast.
    QString video;
};

/// Which palette the app follows.
enum class ThemeMode { System, Light, Dark };

/**
 * The colour system: one stylesheet, one palette, both following the operating system.
 *
 * The mode is remembered between runs so a user who prefers the light palette keeps it, and the
 * System mode tracks the OS live rather than only at startup.
 *
 * When Windows is in High Contrast mode the stylesheet is withdrawn entirely and the native
 * palette is used instead. A hand-picked palette is the opposite of what that accessibility
 * setting is asking for, and overriding it would undo the one theme the user explicitly chose.
 */
class Theme final : public QObject
{
    Q_OBJECT

public:
    /// Process-wide instance. Constructed on first use and lives as long as the process.
    static Theme& instance();

    /// Applies the saved mode and follows the OS from here on. Call before any window exists.
    void install(QApplication* app);

    [[nodiscard]] ThemeMode mode() const noexcept { return mode_; }
    [[nodiscard]] bool isDark() const noexcept { return dark_; }

    /// System -> Light -> Dark -> System. Returns the mode now in force.
    ThemeMode cycleMode();

    [[nodiscard]] const Palette& palette() const noexcept { return palette_; }

    /// True when the system has taken colour control away (High Contrast) and this app is
    /// deliberately not styling anything.
    [[nodiscard]] bool systemForcesColours() const noexcept { return forced_; }

signals:
    /// Emitted whenever the effective palette changes, so drawn icons can be redrawn.
    void changed(bool dark);

protected:
    /// Catches the operating system changing its palette under us - High Contrast switching on
    /// or off, and a changed system accent both arrive this way.
    bool eventFilter(QObject* watched, QEvent* event) override;

private:
    Theme() = default;

    void apply();
    void loadPalette(bool dark);
    void saveMode() const;

    QApplication* app_ = nullptr;
    /// Guards against applying the palette from inside the palette-changed signal it emits.
    bool applying_ = false;
    ThemeMode mode_ = ThemeMode::System;
    bool dark_ = false;
    bool forced_ = false;
    Palette palette_{};
};

} // namespace localstream::ui
