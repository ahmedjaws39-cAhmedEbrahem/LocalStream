#pragma once

#include "ui/UiKit.h"

#include <QHash>
#include <QImage>
#include <QWidget>

#include "discovery/ServiceDiscovery.h"

namespace localstream::engine {
class PlaybackEngine;
}

class QComboBox;
class QLabel;
class QLineEdit;
class QListWidget;
class QPushButton;
class QResizeEvent;
class QShowEvent;
class QStackedWidget;
/// The frameless fullscreen picture. Defined in ReceivePage.cpp: it is entirely private to this
/// page, carries no signals, and would only add noise to the header.
class VideoWindow;

/**
 * Receive tab: browses for broadcasters, connects to one, and shows the picture.
 *
 * Two panes: everything that chooses a broadcaster on the left, everything that shows the result
 * on the right. The choice and the outcome are never on top of each other, which is the whole
 * reason the split exists - the list stays usable while a picture is playing, and the status of
 * the session is next to the picture it is about.
 *
 * Discovery runs for the lifetime of the page rather than only while the tab is visible, so a
 * broadcaster that appears while the user is on the Broadcast tab is still in the list when
 * they come back. Rather than tear discovery down and back up on every tab switch, the browse is
 * re-run when the tab is shown, when a session ends, and when the network comes back: each of
 * those is a moment the list can be stale, and a re-run is cheaper than a full teardown.
 */
class ReceivePage : public QWidget
{
    Q_OBJECT

public:
    explicit ReceivePage(QWidget* parent = nullptr);
    ~ReceivePage() override;

    /// Disconnects a live session if there is one. Safe to call when idle.
    void disconnectFromBroadcaster();

    /// True while a session is up. Used by the window before it closes over a live session.
    [[nodiscard]] bool isConnected() const noexcept { return running_; }

protected:
    /// Re-searches when the tab is brought to the front. Discovery runs for the page's whole
    /// life so the list stays warm, but the network may have moved on while the user was on the
    /// Broadcast tab, so coming back re-runs the browse rather than trusting a stale cache.
    void showEvent(QShowEvent* event) override;
    /// Keeps the picture inside its card instead of growing past the edge of it.
    void resizeEvent(QResizeEvent* event) override;

private:
    void connectToSelected();
    /**
     * Connects to a broadcaster given by hand.
     *
     * Discovery is a convenience, not a requirement: it depends on both machines being on one
     * network segment and on nothing else holding UDP 5353, and each of those can fail for
     * reasons the user cannot see. The broadcaster's own screen always shows its control port,
     * so an address and port typed in is enough to watch.
     */
    void connectToManual();
    void setRunning(bool running);
    void showError(const QString& reason);
    void onServiceAdded(const localstream::net::ServiceDiscovery::Service& service);
    void onServiceRemoved(const QString& instanceKey);
    void showFrame(const QImage& frame);
    /**
     * Puts [frame] into the picture, scaled to the box it is going into.
     *
     * Unscaled would show the top-left corner of a frame bigger than the card, which is not a
     * smaller picture - it is a cropped one. The box is re-fitted on resize as well, so the
     * letterboxing moves with the window rather than being frozen at the size it was first
     * drawn at.
     */
    void renderFrame();
    /// Opens (or re-raises) the fullscreen window on the most recent frame. Does nothing before
    /// the first frame has arrived, because there is no picture to show.
    void showFullscreen();
    /// Returns the page to its pre-video state: no frame, no fullscreen control, no window. Used
    /// whenever a session ends, so a later connection cannot inherit any of it.
    void resetVideo();
    /// One definition of "the manual button is usable", shared by the field watchers and by
    /// setRunning(), so the two cannot drift apart.
    void refreshManualConnectButton();
    /// Blanks the two statistics lines. One definition, shared by the stopped handler and
    /// showError(), so the two cannot drift apart.
    void clearStats();
    /// Asks for the password a password-protected broadcast demanded. Modal, because the
    /// handshake is blocked on the answer and there is nothing else on the page to do.
    void promptForPassword(const QString& broadcasterName);

    localstream::net::ServiceDiscovery* discovery_ = nullptr;
    localstream::engine::PlaybackEngine* playback_ = nullptr;
    QListWidget* list_ = nullptr;
    QPushButton* connectButton_ = nullptr;
    QPushButton* searchAgainButton_ = nullptr;
    /// Chooses how much audio is buffered before playback. Kept as a value so connecting uses
    /// whatever is selected even when the live engine is not running yet.
    QComboBox* bufferCombo_ = nullptr;
    int receiveBufferMs_ = 500;
    QLineEdit* addressField_ = nullptr;
    QLineEdit* portField_ = nullptr;
    QPushButton* manualConnectButton_ = nullptr;
    QWidget* manualPanel_ = nullptr;
    localstream::ui::StatusPill* status_ = nullptr;
    QLabel* statistics_ = nullptr;
    QLabel* reception_ = nullptr;
    QStackedWidget* stack_ = nullptr;
    QLabel* video_ = nullptr;
    /// Hidden until the first frame arrives, so an audio-only broadcast never offers a control
    /// that would open onto a blank window.
    QPushButton* fullscreenButton_ = nullptr;
    /// Created on first use and parented to this page, so the window goes away with the page.
    VideoWindow* videoWindow_ = nullptr;
    /// Open only while a password is being asked for. Null means no prompt, which is also what
    /// stops a second one being opened while the first is still up.
    class PasswordDialog* passwordDialog_ = nullptr;
    /// Most recent frame, kept so fullscreen can open on a picture the instant it is asked for
    /// rather than on the next one, which may be a keyframe interval away, and so a resize can
    /// re-fit it without waiting for one.
    QImage lastFrame_;
    /// Whether any frame has arrived in the current session.
    bool videoSeen_ = false;
    /// The full record behind each list row, so connecting does not depend on a row carrying
    /// an address and port that discovery may since have corrected.
    QHash<QString, localstream::net::ServiceDiscovery::Service> services_;
    bool running_ = false;
};
