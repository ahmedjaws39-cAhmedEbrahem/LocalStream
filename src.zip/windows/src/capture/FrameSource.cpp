#include "capture/FrameSource.h"

#include <QElapsedTimer>
#include <QThread>

extern "C" {
#include <libavdevice/avdevice.h>
#include <libavformat/avformat.h>
#include <libavutil/avutil.h>
#include <libavutil/opt.h>
}

#include <cmath>
#include <mutex>

namespace localstream::capture {

namespace {

/// FFmpeg's global state may only be initialised once per process, and only under the lock its
/// documentation requires. Device enumeration and capture both need it, so every entry point
/// goes through this one guard rather than each initialising separately.
void ensureInitialised()
{
    static std::once_flag once;
    std::call_once(once, [] {
        av_log_set_level(AV_LOG_ERROR);
        avdevice_register_all();
        avformat_network_init();
    });
}

/// Turns an FFmpeg error code into something worth putting in front of a user.
QString describeError(int code)
{
    char buffer[AV_ERROR_MAX_STRING_SIZE] = {};
    av_strerror(code, buffer, sizeof(buffer));
    return QString::fromUtf8(buffer);
}

/// Enumerates the DirectShow audio capture devices.
QList<DeviceOption> listDshow()
{
    QList<DeviceOption> devices;
    ensureInitialised();

    AVDeviceInfoList* list = nullptr;
    const AVInputFormat* dshowFormat = av_find_input_format("dshow");
    if (avdevice_list_input_sources(dshowFormat, nullptr, nullptr, &list) < 0 || !list) {
        return devices;
    }
    for (int i = 0; i < list->nb_devices; ++i) {
        const AVDeviceInfo* info = list->devices[i];
        if (!info || !info->device_name) {
            continue;
        }
        const QString alternate = QString::fromUtf8(info->device_name);
        if (!isAudioDeviceName(alternate)) {
            continue;
        }
        DeviceOption option;
        // The friendly name is what the user recognises; the alternative name is the opaque PnP
        // path FFmpeg actually opens. Keeping the latter in `path` avoids a name containing a
        // separator that the `class=name` URL grammar would misread.
        option.name = info->device_description && *info->device_description
            ? QString::fromUtf8(info->device_description)
            : alternate;
        option.path = QString::fromLatin1("audio=%1").arg(alternate);
        devices.append(option);
    }
    avdevice_free_list_devices(&list);
    return devices;
}

/**
 * Sleeps until [targetMicros] after [clock] started, unless the source is stopped first.
 *
 * A plain sleep would keep a stopped source blocked for up to a whole frame interval, which is
 * a long time to wait in a destructor. Polling at 5 ms keeps shutdown responsive without
 * spinning a core.
 */
void sleepUntil(const QElapsedTimer& clock, qint64 targetMicros, const std::atomic<bool>& running)
{
    while (running.load()) {
        const qint64 remaining = targetMicros - clock.nsecsElapsed() / 1000;
        if (remaining <= 0) {
            return;
        }
        QThread::msleep(static_cast<unsigned long>(qMin<qint64>(remaining, 5)));
    }
}

} // namespace

// ---------------------------------------------------------------- device enumeration

bool isAudioDeviceName(const QString& alternateName)
{
    // An audio capture filter is registered under the audio input category, which leaves a
    // `wave_` token (and that category GUID) in the alternative name; a camera has neither.
    return alternateName.contains(QStringLiteral("wave_"), Qt::CaseInsensitive)
        || alternateName.contains(QStringLiteral("33D9A762-90C8-11D0-BD43-00A0C911CE86"),
            Qt::CaseInsensitive);
}

QList<DeviceOption> listMicrophones()
{
    return listDshow();
}

// ---------------------------------------------------------------- shared device loop

namespace {

/**
 * Opens a device and pumps its packets until stopped.
 *
 * Shared by the screen and DirectShow sources because the read loop is identical: FFmpeg's
 * device API hands over self-contained packets, and the only difference between the two is how
 * the format context was opened.
 */
bool pumpDevice(const AVInputFormat* format, const char* url, AVDictionary* options,
    bool audio, std::atomic<bool>& running,
    const std::function<void(const VideoSample&)>& onVideo,
    const std::function<void(const AudioSample&)>& onAudio, int* outWidth, int* outHeight,
    int* outSampleRate, int* outChannels, QString* error)
{
    AVFormatContext* context = nullptr;
    const int opened = avformat_open_input(&context, url, format, &options);
    if (opened < 0) {
        if (error) {
            *error = QStringLiteral("Could not open the device: %1").arg(describeError(opened));
        }
        if (context) {
            avformat_close_input(&context);
        }
        return false;
    }

    if (avformat_find_stream_info(context, nullptr) < 0) {
        if (error) {
            *error = QStringLiteral("Could not read the device's stream format.");
        }
        avformat_close_input(&context);
        return false;
    }

    // Picks the first stream of the requested kind, so a camera that also exposes a status
    // stream does not hand over the wrong one.
    const AVCodecParameters* parameters = nullptr;
    int streamIndex = -1;
    for (unsigned i = 0; i < context->nb_streams; ++i) {
        const AVCodecParameters* candidate = context->streams[i]->codecpar;
        const bool candidateIsAudio
            = candidate->codec_type == AVMEDIA_TYPE_AUDIO;
        if (candidateIsAudio == audio) {
            parameters = candidate;
            streamIndex = static_cast<int>(i);
            break;
        }
    }
    if (!parameters) {
        if (error) {
            *error = audio ? QStringLiteral("The device exposes no audio stream.")
                           : QStringLiteral("The device exposes no video stream.");
        }
        avformat_close_input(&context);
        return false;
    }

    if (outWidth) {
        *outWidth = parameters->width;
    }
    if (outHeight) {
        *outHeight = parameters->height;
    }
    if (outSampleRate) {
        *outSampleRate = parameters->sample_rate;
    }
    if (outChannels) {
        *outChannels = parameters->ch_layout.nb_channels;
    }

    AVPacket* packet = av_packet_alloc();
    if (!packet) {
        if (error) {
            *error = QStringLiteral("Out of memory.");
        }
        avformat_close_input(&context);
        return false;
    }

    running.store(true);
    QElapsedTimer clock;
    clock.start();

    while (running.load()) {
        const int received = av_read_frame(context, packet);
        if (received < 0) {
            // Live devices report EAGAIN between frames. Treating that as the end of the
            // stream would stop a camera that is working perfectly well.
            if (received == AVERROR(EAGAIN) || received == AVERROR(EWOULDBLOCK)) {
                QThread::msleep(1);
                continue;
            }
            if (received == AVERROR_EXIT) {
                break;
            }
            if (error) {
                *error = QStringLiteral("Reading from the device failed: %1")
                             .arg(describeError(received));
            }
            break;
        }

        if (packet->stream_index == streamIndex) {
            // A device's packets are raw samples, so the presentation time is in the stream's
            // own time base. Rescaled to microseconds once here so everything above this layer
            // works in one unit.
            const AVRational timeBase = context->streams[streamIndex]->time_base;
            const qint64 ptsMicros = packet->pts != AV_NOPTS_VALUE
                ? static_cast<qint64>(
                      av_rescale_q(packet->pts, timeBase, AVRational {1, 1000000}))
                : static_cast<qint64>(clock.nsecsElapsed() / 1000);

            if (audio) {
                AudioSample sample;
                sample.data = QByteArray(reinterpret_cast<const char*>(packet->data),
                    packet->size);
                sample.samples = parameters->frame_size > 0 ? parameters->frame_size : 0;
                sample.sampleRate = parameters->sample_rate;
                sample.channels = parameters->ch_layout.nb_channels;
                sample.format = parameters->format;
                sample.ptsMicros = ptsMicros;
                onAudio(sample);
            } else {
                // A device delivers BGRA on most drivers and a packed YUV on some, so the
                // pixel size comes from the reported format rather than being assumed. The
                // engine converts from whatever this says to something the encoder accepts.
                //
                // An AVPacket holds one buffer with no per-row stride, so a device frame is
                // already tightly packed: width * height * pixelSize bytes, no row copying.
                const int bytesPerPixel
                    = parameters->format == AV_PIX_FMT_BGRA ? 4 : 2;
                VideoSample sample;
                sample.data = QByteArray(reinterpret_cast<const char*>(packet->data),
                    static_cast<qsizetype>(parameters->width) * parameters->height
                        * bytesPerPixel);
                sample.width = parameters->width;
                sample.height = parameters->height;
                sample.format = parameters->format;
                sample.ptsMicros = ptsMicros;
                sample.linesize = parameters->width * bytesPerPixel;
                onVideo(sample);
            }
        }
        av_packet_unref(packet);
    }

    av_packet_free(&packet);
    avformat_close_input(&context);
    return error == nullptr || error->isEmpty();
}

} // namespace

// ---------------------------------------------------------------- screen

ScreenCapture::ScreenCapture(int width, int height, int framesPerSecond)
    : width_(width > 0 ? width : 1280)
    , height_(height > 0 ? height : 720)
    , framesPerSecond_(framesPerSecond > 0 ? framesPerSecond : 30)
{
}

ScreenCapture::~ScreenCapture()
{
    stop();
}

bool ScreenCapture::start(const std::function<void(const VideoSample&)>& onVideo,
    const std::function<void(const AudioSample&)>&, QString* error)
{
    if (running_.load()) {
        return true;
    }
    ensureInitialised();

    const AVInputFormat* format = av_find_input_format("gdigrab");
    if (!format) {
        if (error) {
            *error = QStringLiteral("This FFmpeg build has no GDI screen grabber.");
        }
        return false;
    }

    AVDictionary* options = nullptr;
    const QByteArray rate = QByteArray::number(framesPerSecond_);
    av_dict_set(&options, "framerate", rate.constData(), 0);
    // high_quality does the scaling in the grabber rather than by point sampling, which is the
    // difference between readable text and mush when downscaling to the encode resolution.
    av_dict_set(&options, "high_quality", "1", 0);
    if (width_ > 0 && height_ > 0) {
        const QByteArray size
            = QByteArray::number(width_) + 'x' + QByteArray::number(height_);
        av_dict_set(&options, "video_size", size.constData(), 0);
    }

    int width = 0;
    int height = 0;
    // The real size is what the desktop actually is, not what was requested: gdigrab silently
    // falls back when asked for a resolution the display cannot produce, and publishing the
    // requested size would put the wrong dimensions in the session description.
    QString deviceError;
    const bool ok = pumpDevice(format, "desktop", options, false, running_, onVideo,
        [](const AudioSample&) {}, &width, &height, nullptr, nullptr, &deviceError);
    if (ok && width > 0) {
        width_ = width;
        height_ = height;
    }
    if (!deviceError.isEmpty()) {
        if (error) {
            *error = deviceError;
        }
        return false;
    }
    return true;
}

void ScreenCapture::stop()
{
    running_.store(false);
}

// ---------------------------------------------------------------- DirectShow device

DeviceCapture::DeviceCapture(DeviceOption device, bool audio)
    : device_(std::move(device))
    , audio_(audio)
{
}

DeviceCapture::~DeviceCapture()
{
    stop();
}

bool DeviceCapture::start(const std::function<void(const VideoSample&)>& onVideo,
    const std::function<void(const AudioSample&)>& onAudio, QString* error)
{
    if (running_.load()) {
        return true;
    }
    ensureInitialised();

    if (device_.path.isEmpty()) {
        if (error) {
            *error = QStringLiteral("No device was selected.");
        }
        return false;
    }

    const AVInputFormat* format = av_find_input_format("dshow");
    if (!format) {
        if (error) {
            *error = QStringLiteral("This FFmpeg build has no DirectShow support.");
        }
        return false;
    }

    // DirectShow blocks in open until the device is ready, and some drivers never are. A
    // thread here keeps a wedged driver from freezing the whole application.
    AVDictionary* options = nullptr;
    const QByteArray url = device_.path.toUtf8();

    QString deviceError;
    if (audio_) {
        pumpDevice(format, url.constData(), options, true, running_, onVideo, onAudio, nullptr,
            nullptr, &sampleRate_, &channels_, &deviceError);
    } else {
        pumpDevice(format, url.constData(), options, false, running_, onVideo, onAudio,
            &width_, &height_, nullptr, nullptr, &deviceError);
    }

    if (!deviceError.isEmpty()) {
        if (error) {
            *error = deviceError;
        }
        return false;
    }
    if (sampleRate_ <= 0) {
        sampleRate_ = 48000;
    }
    if (channels_ <= 0) {
        channels_ = 1;
    }
    return true;
}

void DeviceCapture::stop()
{
    running_.store(false);
}

// ---------------------------------------------------------------- test pattern

TestPatternSource::TestPatternSource(int width, int height, int framesPerSecond)
    : width_(width > 0 ? width : 640)
    , height_(height > 0 ? height : 360)
    , framesPerSecond_(framesPerSecond > 0 ? framesPerSecond : 30)
{
}

TestPatternSource::~TestPatternSource()
{
    stop();
}

bool TestPatternSource::start(const std::function<void(const VideoSample&)>& onVideo,
    const std::function<void(const AudioSample&)>&, QString*)
{
    // Cannot fail: the pattern is generated in memory, so there is nothing to open and no
    // failure path to report. [error] is unnamed for that reason.
    if (running_.load()) {
        return true;
    }
    running_.store(true);

    QElapsedTimer clock;
    clock.start();
    const qint64 frameMicros = 1000000 / framesPerSecond_;
    quint64 frameIndex = 0;

    while (running_.load()) {
        const qint64 target = static_cast<qint64>(frameIndex) * frameMicros;
        sleepUntil(clock, target, running_);

        VideoSample sample;
        sample.width = width_;
        sample.height = height_;
        // BGRA, because that is what a Windows device delivers and what the engine's scaler is
        // configured for. Testing against the real input format means the conversion path the
        // tests exercise is the one the hardware uses.
        sample.format = AV_PIX_FMT_BGRA;
        sample.linesize = width_ * 4;
        sample.ptsMicros = clock.nsecsElapsed() / 1000;
        sample.data.resize(static_cast<qsizetype>(sample.linesize) * height_);

        auto* pixels = reinterpret_cast<uchar*>(sample.data.data());
        // A colour bar that shifts hue each frame plus a moving block. Static bars alone would
        // look identical frame to frame, so a frozen pipeline would not be distinguishable
        // from a working one.
        const int shift = static_cast<int>(frameIndex % 60) * 4;
        for (int y = 0; y < height_; ++y) {
            auto* row = pixels + static_cast<qsizetype>(y) * sample.linesize;
            for (int x = 0; x < width_; ++x) {
                const int bar = (x * 8) / width_ % 2;
                row[x * 4 + 0] = static_cast<uchar>(bar ? 235 : 16);
                row[x * 4 + 1] = static_cast<uchar>(bar ? 16 : (128 + shift) % 256);
                row[x * 4 + 2] = static_cast<uchar>(bar ? 128 : 220);
                row[x * 4 + 3] = 0xFF;
            }
        }
        // A block that walks across the frame: its position is the frame counter, visible.
        const int blockSize = qMax(8, width_ / 16);
        const int blockX = static_cast<int>((frameIndex * 4) % qMax(1, width_ - blockSize));
        const int blockY = static_cast<int>((frameIndex * 2) % qMax(1, height_ - blockSize));
        for (int y = blockY; y < qMin(blockY + blockSize, height_); ++y) {
            auto* row = pixels + static_cast<qsizetype>(y) * sample.linesize;
            for (int x = blockX; x < qMin(blockX + blockSize, width_); ++x) {
                row[x * 4 + 0] = 0x00;
                row[x * 4 + 1] = 0x00;
                row[x * 4 + 2] = 0x00;
                row[x * 4 + 3] = 0xFF;
            }
        }

        onVideo(sample);
        ++frameIndex;
    }
    running_.store(false);
    return true;
}

void TestPatternSource::stop()
{
    running_.store(false);
}

// ---------------------------------------------------------------- test tone

TestToneSource::TestToneSource(int sampleRate, int channels)
    : sampleRate_(sampleRate > 0 ? sampleRate : 48000)
    , channels_(channels > 0 ? channels : 1)
{
}

TestToneSource::~TestToneSource()
{
    stop();
}

bool TestToneSource::start(const std::function<void(const VideoSample&)>&,
    const std::function<void(const AudioSample&)>& onAudio, QString* error)
{
    Q_UNUSED(error);
    if (running_.load()) {
        return true;
    }
    running_.store(true);

    // 20 ms at the source's own rate, but the protocol specifies 960 samples at 48 kHz. Scaled
    // to the actual rate so a non-48 kHz source still emits 20 ms per packet.
    const int samplesPerFrame = sampleRate_ * 20 / 1000;
    QElapsedTimer clock;
    clock.start();
    qint64 frameIndex = 0;
    double phase = 0.0;
    const double increment = 2.0 * M_PI * 440.0 / sampleRate_;

    while (running_.load()) {
        const qint64 target = frameIndex * 20000; // 20 ms per packet
        sleepUntil(clock, target, running_);

        AudioSample sample;
        sample.samples = samplesPerFrame;
        sample.sampleRate = sampleRate_;
        sample.channels = channels_;
        sample.format = AV_SAMPLE_FMT_S16;
        sample.ptsMicros = clock.nsecsElapsed() / 1000;
        sample.data.resize(static_cast<qsizetype>(samplesPerFrame) * channels_ * 2);

        auto* out = reinterpret_cast<qint16*>(sample.data.data());
        for (int i = 0; i < samplesPerFrame; ++i) {
            const auto value = static_cast<qint16>(std::sin(phase) * 8000.0);
            for (int c = 0; c < channels_; ++c) {
                out[i * channels_ + c] = value;
            }
            phase += increment;
            if (phase > 2.0 * M_PI) {
                phase -= 2.0 * M_PI;
            }
        }

        onAudio(sample);
        ++frameIndex;
    }
    running_.store(false);
    return true;
}

void TestToneSource::stop()
{
    running_.store(false);
}

} // namespace localstream::capture
