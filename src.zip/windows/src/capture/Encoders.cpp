#include "capture/Encoders.h"

extern "C" {
#include <libavutil/opt.h>
#include <libswresample/swresample.h>
}

#include <cmath>

#include "protocol/H264Rtp.h"

namespace localstream::capture {

// The FfOwned deleters. Outside the anonymous namespace because Encoders.h names them as
// template arguments, and a declaration there would be a different function.

void freeCodecContext(AVCodecContext* context)
{
    avcodec_free_context(&context);
}

void freeSwsContext(SwsContext* context)
{
    sws_freeContext(context);
}

void freeSwrContext(SwrContext* context)
{
    swr_free(&context);
}

void freeFrame(AVFrame* frame)
{
    av_frame_free(&frame);
}

void freePacket(AVPacket* packet)
{
    av_packet_free(&packet);
}

namespace {

/// Pulls the SPS and PPS out of a codec's extradata, returning each as a bare NAL unit.
///
/// Both container forms are accepted, because the caller does not get to choose:
///
///  - Annex B, where each NAL is introduced by a 3- or 4-byte start code. This is what libx264
///    actually writes into extradata, and it is what this function was originally written not to
///    expect. Reading those start codes as a 4-byte big-endian length yields a length of 1, so
///    the first "NAL" came back as the single byte 0x67 -- a valid-looking SPS header with no
///    payload -- and the scan then ran off into the middle of the SPS and stopped. sps() and
///    pps() were therefore non-empty-looking and wrong, which is worse than empty: an empty one
///    is obviously missing, a one-byte one gets published into the SDP and offered to decoders.
///  - AVCC, where each NAL is introduced by a 4-byte big-endian length, which is the format
///    `annexBToAvcc` writes and `protocol::h264::splitAvcc` reads.
///
/// Which one is present is decided by looking at the first four bytes rather than by a flag,
/// since extradata carries no reliable marker.
void splitParameterSets(const QByteArray& extradata, QByteArray& sps, QByteArray& pps)
{
    const auto isStartCodeAt = [&extradata](int at) {
        if (at + 3 > extradata.size()) {
            return false;
        }
        return extradata.at(at) == '\0' && extradata.at(at + 1) == '\0'
            && static_cast<quint8>(extradata.at(at + 2)) == 1;
    };

    const bool annexB = isStartCodeAt(0) || isStartCodeAt(1);

    // Both branches return a bare NAL, with any start code stripped. That is the single contract
    // for sps() and pps(): protocol::h264::splitAvcc returns bare NALs, Depacketizer::sps()
    // returns bare NALs, and rememberParameterSets stores bare NALs, so a caller that got a
    // start-code-prefixed pair from here and a bare pair from a received keyframe would rebuild
    // the decoder extradata differently depending on which path filled it.
    int at = 0;
    while (at < extradata.size()) {
        int length = 0;
        int headerAt = 0;
        if (annexB) {
            // The next start code terminates this NAL.
            int end = -1;
            for (int scan = at; scan + 2 < extradata.size(); ++scan) {
                if (isStartCodeAt(scan)) {
                    end = scan;
                    break;
                }
            }
            length = (end >= 0 ? end : extradata.size()) - at;
            if (length <= 0) {
                break;
            }
        } else {
            if (at + 4 > extradata.size()) {
                break;
            }
            length = (static_cast<quint8>(extradata.at(at)) << 24)
                | (static_cast<quint8>(extradata.at(at + 1)) << 16)
                | (static_cast<quint8>(extradata.at(at + 2)) << 8)
                | static_cast<quint8>(extradata.at(at + 3));
            at += 4;
            if (length <= 0 || at + length > extradata.size()) {
                break;
            }
        }

        const QByteArray nal = extradata.mid(at, length);
        if (!nal.isEmpty()) {
            const int type = static_cast<quint8>(nal.at(headerAt)) & 0x1F;
            if (type == 7 && sps.isEmpty()) {
                sps = nal;
            } else if (type == 8 && pps.isEmpty()) {
                pps = nal;
            }
        }

        at += length;
    }
}

} // namespace

// ---------------------------------------------------------------- video

VideoEncoder::VideoEncoder(int width, int height, int framesPerSecond, int bitrateKbps)
    : width_(width > 0 ? width : 1280)
    , height_(height > 0 ? height : 720)
    , framesPerSecond_(framesPerSecond > 0 ? framesPerSecond : 30)
{
    // YUV420p needs even dimensions, and rounding silently is better than refusing to start:
    // a device that reports 1279x719 should still broadcast.
    width_ -= width_ % 2;
    height_ -= height_ % 2;

    const AVCodec* codec = avcodec_find_encoder_by_name("libx264");
    if (!codec) {
        codec = avcodec_find_encoder(AV_CODEC_ID_H264);
    }
    if (!codec) {
        return;
    }

    context_.reset(avcodec_alloc_context3(codec));
    if (!context_) {
        return;
    }

    context_->width = width_;
    context_->height = height_;
    context_->pix_fmt = AV_PIX_FMT_YUV420P;
    context_->time_base = AVRational {1, framesPerSecond_};
    context_->framerate = AVRational {framesPerSecond_, 1};
    context_->gop_size = framesPerSecond_ * 2; // a keyframe every two seconds
    context_->max_b_frames = 0;
    // Bitrate in bits per second, not kilobits: passing kilobits here gives a stream a
    // thousandth of the intended size, which looks like a network fault rather than a unit
    // error.
    context_->bit_rate = bitrateKbps > 0 ? static_cast<int64_t>(bitrateKbps) * 1000 : 1500000;
    // Without this the SPS and PPS are repeated inside every keyframe, which inflates the
    // bitrate and leaves the receiver's parameter sets ambiguous.
    context_->flags |= AV_CODEC_FLAG_GLOBAL_HEADER;

    // What colour the picture is, said in the stream rather than left to the receiver.
    //
    // These four fields are the whole fix, and where they sit matters: the libavcodec wrapper
    // translates them into x264's own VUI settings when the encoder opens, so they are the only
    // route through this code that reaches the bitstream. It used to say this through
    // x264-params instead, and x264 threw every word away -- "bt601" is not a colour it knows,
    // it spells it "smpte170m" -- and a parameter x264 rejects is only a line in its log.
    // avcodec_open2 still returned success, the tests still passed, and the stream still went out
    // declaring no colour at all, which is the problem these words were added to solve.
    //
    // HD uses BT.709; SD uses the BT.601/SMPTE 170M matrix. The swscale input conversion below
    // uses the same matrix and limited range, so the VUI describes the samples actually emitted.
    const bool useBt709 = height_ >= 720;
    const AVColorSpace colorSpace = useBt709 ? AVCOL_SPC_BT709 : AVCOL_SPC_SMPTE170M;
    const AVColorPrimaries colorPrimaries = useBt709 ? AVCOL_PRI_BT709 : AVCOL_PRI_SMPTE170M;
    const AVColorTransferCharacteristic colorTransfer = useBt709 ? AVCOL_TRC_BT709 : AVCOL_TRC_SMPTE170M;
    context_->color_primaries = colorPrimaries;
    context_->color_trc = colorTransfer;
    context_->colorspace = colorSpace;
    context_->color_range = AVCOL_RANGE_MPEG;

    AVDictionary* options = nullptr;
    // zerolatency keeps output flowing frame by frame. Without it x264 buffers a full
    // lookahead, which adds a second of delay to a broadcast that is supposed to be live.
    av_dict_set(&options, "preset", "veryfast", 0);
    av_dict_set(&options, "tune", "zerolatency", 0);
    av_dict_set(&options, "profile", "baseline", 0);
    // Headers repeated in every keyframe, rather than left in the codec's extradata only.
    // This is not redundant: the extradata is not transmitted in the SDP at all -- the fmtp line
    // carries no parameter sets -- and a receiver that joins later, or one whose SDP is lost,
    // would have no way to decode the first frame after the broadcaster's. Repeating the
    // parameter sets in each IDR makes every keyframe self-contained, which is also what lets
    // protocol::h264::packetize aggregate SPS and PPS into the STAP-A that precedes a keyframe.
    // The cost is a few bytes per keyframe, at most once per keyint.
    //
    // It has to go through x264-params: the libavcodec wrapper does not expose repeat_headers as
    // its own option, and passing "repeat-headers" to avcodec_open2 is silently ignored -- the
    // dictionary entry just goes unused, with no error. The wrapper's own name for the setting is
    // AV_CODEC_FLAG_GLOBAL_HEADER plus this x264 option, and only the second one makes the
    // parameter sets appear in the packets themselves. Note that anything x264 does not
    // recognise here is discarded without failing the open, which is why the colour above is set
    // on the context instead.
    av_dict_set(&options, "x264-params", "repeat_headers=1", 0);

    const int opened = avcodec_open2(context_.get(), codec, &options);
    av_dict_free(&options);
    if (opened < 0) {
        context_.reset();
        return;
    }

    // FfOwned has no default deleter to inherit, so the pointer is set explicitly rather than
    // through reset() on a null instance.
    SwsContext* scaler = sws_getContext(width_, height_, AV_PIX_FMT_BGRA, width_, height_,
        AV_PIX_FMT_YUV420P, SWS_BILINEAR, nullptr, nullptr, nullptr);
    if (!scaler) {
        context_.reset();
        return;
    }
    const int swsColorSpace = useBt709 ? SWS_CS_ITU709 : SWS_CS_ITU601;
    const int* colorCoefficients = sws_getCoefficients(swsColorSpace);
    if (!colorCoefficients ||
        sws_setColorspaceDetails(scaler, colorCoefficients, 1, colorCoefficients, 0, 0,
            1 << 16, 1 << 16) < 0) {
        sws_freeContext(scaler);
        context_.reset();
        return;
    }
    scaler_.reset(scaler);

    scaled_.reset(av_frame_alloc());
    packet_.reset(av_packet_alloc());
    if (!scaled_ || !packet_) {
        context_.reset();
        scaler_.reset();
        return;
    }

    scaled_->format = AV_PIX_FMT_YUV420P;
    scaled_->width = width_;
    scaled_->height = height_;
    scaled_->color_range = AVCOL_RANGE_MPEG;
    scaled_->colorspace = colorSpace;
    scaled_->color_primaries = colorPrimaries;
    scaled_->color_trc = colorTransfer;
    // get_buffer allocates the plane array; the pointers are then stable for the frame's life.
    if (av_frame_get_buffer(scaled_.get(), 0) < 0) {
        context_.reset();
        scaler_.reset();
        return;
    }
}

VideoEncoder::~VideoEncoder() = default;

bool VideoEncoder::isOpen() const
{
    return static_cast<bool>(context_);
}

QByteArray VideoEncoder::sps() const
{
    return parameterSet(true);
}

QByteArray VideoEncoder::pps() const
{
    return parameterSet(false);
}

QByteArray VideoEncoder::parameterSet(bool wantSps) const
{
    const QByteArray& cached = wantSps ? sps_ : pps_;
    if (!cached.isEmpty()) {
        return cached;
    }
    if (!context_ || !context_->extradata) {
        return {};
    }
    QByteArray sps;
    QByteArray pps;
    splitParameterSets(
        QByteArray(reinterpret_cast<const char*>(context_->extradata),
            context_->extradata_size),
        sps, pps);
    return wantSps ? sps : pps;
}

void VideoEncoder::requestKeyframe()
{
    if (!context_) {
        return;
    }
    // libx264 honours an explicit picture type on the next frame it encodes, which is what
    // makes this a request for an IDR rather than merely a preference. The flag that used to
    // do this (AV_CODEC_FLAG2_FORCE_KEY_FRAME) was removed from libavcodec, so the picture
    // type is the supported route.
    forcedPictureType_ = AV_PICTURE_TYPE_I;
}

QByteArray annexBToAvcc(const QByteArray& annexB)
{
    // libx264 emits Annex B: each NAL preceded by a start code. Everything downstream -- the
    // RTP packetiser, the STAP-A aggregator, and the receiver's splitAvcc -- expects AVCC,
    // where each NAL carries a 4-byte big-endian length instead. Verified empirically rather
    // than assumed: this build's libx264 output began 00 00 00 01 41, an Annex B start code.
    //
    // Converting here rather than making the packetiser accept both is deliberate: one format on
    // the wire is the whole point of PROTOCOL.md, and a packetiser that guesses would silently
    // mis-parse one of the two rather than failing loudly.
    QByteArray avcc;
    avcc.reserve(annexB.size());

    const auto* base = reinterpret_cast<const quint8*>(annexB.constData());
    const int end = annexB.size();

    // Locates the next start code at or after [from], reporting its length through [length].
    // Both the 4-byte and the 3-byte form are legal in Annex B, and the 4-byte form is checked
    // first so that 00 00 00 01 is not misread as a 3-byte code one byte in -- which would then
    // leave a stray leading zero inside the NAL and corrupt every length that follows.
    auto findStartCode = [end, &base](int from, int& length) {
        for (int at = from; at + 3 <= end; ++at) {
            if (at + 4 <= end && base[at] == 0 && base[at + 1] == 0 && base[at + 2] == 0
                && base[at + 3] == 1) {
                length = 4;
                return at;
            }
            if (base[at] == 0 && base[at + 1] == 0 && base[at + 2] == 1) {
                length = 3;
                return at;
            }
        }
        return end;
    };

    int codeLength = 0;
    int codePos = findStartCode(0, codeLength);
    // No start code at all means this is not Annex B, so there is nothing safe to convert.
    if (codePos == end) {
        return {};
    }

    while (codePos < end) {
        const int nalStart = codePos + codeLength;
        // The next start code, or the end of the buffer.
        int nextLength = 0;
        const int next = findStartCode(nalStart + 1, nextLength);
        const int nalSize = next - nalStart;
        if (nalSize > 0) {
            // Trailing zero bytes before a start code are legal in Annex B and are not part of
            // the NAL, so they are excluded from the length.
            int trimmed = nalSize;
            while (trimmed > 0 && base[nalStart + trimmed - 1] == 0) {
                --trimmed;
            }
            if (trimmed > 0) {
                avcc.append(static_cast<char>((trimmed >> 24) & 0xFF));
                avcc.append(static_cast<char>((trimmed >> 16) & 0xFF));
                avcc.append(static_cast<char>((trimmed >> 8) & 0xFF));
                avcc.append(static_cast<char>(trimmed & 0xFF));
                avcc.append(reinterpret_cast<const char*>(base + nalStart), trimmed);
            }
        }
        if (next >= end) {
            break;
        }
        codePos = next;
        codeLength = nextLength;
    }
    return avcc;
}

int VideoEncoder::encode(const capture::VideoSample& sample,
    const std::function<void(const EncodedVideo&)>& out)
{
    if (!context_ || !scaler_) {
        return 0;
    }

    // The scaler reads exactly width * 4 bytes per row from the source, so a sample narrower
    // or shorter than the encoder wants is padded rather than read past its end.
    const uint8_t* source[4] = {reinterpret_cast<const uint8_t*>(sample.data.constData()),
        nullptr, nullptr, nullptr};
    const int sourceStride[4] = {sample.linesize > 0 ? sample.linesize : sample.width * 4, 0,
        0, 0};

    uint8_t* destination[4] = {scaled_->data[0], scaled_->data[1], scaled_->data[2], nullptr};
    const int destinationStride[4] = {scaled_->linesize[0], scaled_->linesize[1],
        scaled_->linesize[2], 0};

    // Region size clamped to the sample: a device that changes resolution mid-session would
    // otherwise make the scaler read past the end of the buffer.
    const int usableHeight = qMin(sample.height, height_);

    sws_scale(scaler_.get(), source, sourceStride, 0, usableHeight, destination, destinationStride);

    scaled_->pts = nextPts_++;
    if (forcedPictureType_ != AV_PICTURE_TYPE_NONE) {
        scaled_->pict_type = static_cast<AVPictureType>(forcedPictureType_);
        forcedPictureType_ = AV_PICTURE_TYPE_NONE;
    }

    const int sent = avcodec_send_frame(context_.get(), scaled_.get());
    if (sent < 0) {
        return 0;
    }

    int emitted = 0;
    for (;;) {
        const int received = avcodec_receive_packet(context_.get(), packet_.get());
        if (received == AVERROR(EAGAIN) || received == AVERROR_EOF) {
            break;
        }
        if (received < 0) {
            break;
        }
        EncodedVideo frame;
        frame.accessUnit = annexBToAvcc(
            QByteArray(reinterpret_cast<const char*>(packet_->data), packet_->size));
        frame.keyframe = (packet_->flags & AV_PKT_FLAG_KEY) != 0;
        if (!frame.accessUnit.isEmpty()) {
            rememberParameterSets(frame.accessUnit);
            out(frame);
            ++emitted;
        }
        av_packet_unref(packet_.get());
    }
    return emitted;
}

/// Keeps the SPS and PPS seen in [avcc] so sps() and pps() can answer before the codec's
/// extradata is populated.
///
/// With repeat-headers on, the parameter sets arrive inside the first keyframe rather than in
/// the extradata that avcodec_open2 writes, and libav does not copy them there. A caller that
/// asks for the parameter sets after the first frame would otherwise get an empty answer, which
/// looks exactly like "this encoder cannot produce parameter sets at all".
void VideoEncoder::rememberParameterSets(const QByteArray& avcc)
{
    const QList<QByteArray> nals = protocol::h264::splitAvcc(avcc);
    for (const QByteArray& nal : nals) {
        if (nal.isEmpty()) {
            continue;
        }
        const int type = static_cast<quint8>(nal.at(0)) & 0x1F;
        if (type == 7 && sps_.isEmpty()) {
            sps_ = nal;
        } else if (type == 8 && pps_.isEmpty()) {
            pps_ = nal;
        }
    }
}

void VideoEncoder::flush(const std::function<void(const EncodedVideo&)>& out)
{
    if (!context_) {
        return;
    }
    // A null frame is the documented way to signal end of stream; the encoder then emits
    // whatever it is still holding.
    if (avcodec_send_frame(context_.get(), nullptr) < 0) {
        return;
    }
    for (;;) {
        const int received = avcodec_receive_packet(context_.get(), packet_.get());
        if (received < 0) {
            break;
        }
        EncodedVideo frame;
        frame.accessUnit = annexBToAvcc(
            QByteArray(reinterpret_cast<const char*>(packet_->data), packet_->size));
        frame.keyframe = (packet_->flags & AV_PKT_FLAG_KEY) != 0;
        if (!frame.accessUnit.isEmpty()) {
            out(frame);
        }
        av_packet_unref(packet_.get());
    }
}

// ---------------------------------------------------------------- audio

namespace {

// Automatic gain control, so a receiver hears the broadcast at a consistent level no matter how
// loud the broadcaster's machine is set or which device is being captured.
constexpr double AgcTargetRms = 0.10; // -20 dBFS: a comfortable average, loud without being hot
constexpr double AgcGateRms = 0.0015; // -56 dBFS: below this it is silence, not quiet audio
constexpr double AgcMinGain = 0.25;   // -12 dB: never bury a genuinely loud source
constexpr double AgcMaxGain = 16.0;   // +24 dB: recover a device the system volume has crushed
// Both rates are per 20 ms frame. The level is followed over roughly a third of a second and the
// gain eased over a tenth of one: slow enough to leave speech and music intact, quick enough to
// follow a volume slider being dragged.
constexpr double AgcLevelRate = 0.06;
constexpr double AgcGainRate = 0.12;
constexpr double AgcCeiling = 0.95; // a frame is scaled back below this, so it cannot clip

} // namespace

AudioEncoder::AudioEncoder(int sampleRate, int channels, int bitrateKbps, bool normalize)
    : sampleRate_(sampleRate > 0 ? sampleRate : 48000)
    , channels_(channels > 0 ? channels : 1)
{
    agcEnabled_ = normalize;
    // 20 ms, per PROTOCOL.md section 3.2. Computed from the rate rather than hard-coded so a
    // non-48 kHz device still produces frames of the right duration.
    samplesPerFrame_ = sampleRate_ * 20 / 1000;

    const AVCodec* codec = avcodec_find_encoder_by_name("libopus");
    if (!codec) {
        codec = avcodec_find_encoder(AV_CODEC_ID_OPUS);
    }
    if (!codec) {
        return;
    }

    context_.reset(avcodec_alloc_context3(codec));
    if (!context_) {
        return;
    }

    context_->sample_rate = sampleRate_;
    av_channel_layout_default(&context_->ch_layout, channels_);
    // Set explicitly rather than left for libavcodec to guess. libopus rejects the context
    // outright if this is still AV_SAMPLE_FMT_NONE (-1) when a frame arrives, which it prints
    // as "Invalid audio sample format: -1" and then encodes nothing at all.
    context_->sample_fmt = AV_SAMPLE_FMT_S16;
    // The bitrate is in bits per second; libopus would otherwise default to a rate chosen for
    // stereo speech, which is far too low for what the broadcaster is sending.
    context_->bit_rate = bitrateKbps > 0 ? static_cast<int64_t>(bitrateKbps) * 1000 : 48000;
    // Opened with a frame size so libopus knows how much audio to expect per call, which is
    // what lets it pick a matching internal packet duration instead of buffering.
    context_->frame_size = samplesPerFrame_;
    context_->time_base = AVRational {1, sampleRate_};

    AVDictionary* options = nullptr;
    // VoIP mode tunes the encoder for speech latency rather than for music fidelity, which is
    // the right trade for a control-room-style broadcast.
    av_dict_set(&options, "application", "voip", 0);
    const int opened = avcodec_open2(context_.get(), codec, &options);
    av_dict_free(&options);
    if (opened < 0) {
        context_.reset();
        return;
    }

    // Capture devices deliver S16 interleaved; libopus wants S16 at the encoder's rate. The
    // resampler is what makes a 44.1 kHz microphone and a 48 kHz one both work without the
    // caller having to know which it has.
    SwrContext* raw = nullptr;
    AVChannelLayout outLayout;
    // inputLayout_ must be filled in before it is handed over. It is the *input* side of the
    // conversion, and leaving it at the empty default made swr reject the whole request with
    // 'ochl channel layout "" is invalid or unsupported', so no resampler existed and the
    // encoder could never open.
    av_channel_layout_default(&inputLayout_, channels_);
    av_channel_layout_default(&outLayout, channels_);
    // Output side first (the encoder's), input side second (the device's), matching
    // swr_alloc_set_opts2's argument order. They are equal here because the device format is
    // not known until the first sample; ensureResampler() rebuilds with the real input format.
    if (swr_alloc_set_opts2(&raw, &outLayout, AV_SAMPLE_FMT_S16, sampleRate_, &inputLayout_,
            AV_SAMPLE_FMT_S16, sampleRate_, 0, nullptr)
        < 0) {
        context_.reset();
        return;
    }
    if (swr_init(raw) < 0) {
        freeSwrContext(raw);
        context_.reset();
        return;
    }
    resampler_.reset(raw);
    inputSampleRate_ = sampleRate_;
    inputChannels_ = channels_;

    input_.reset(av_frame_alloc());
    packet_.reset(av_packet_alloc());
    if (!input_ || !packet_) {
        context_.reset();
        return;
    }
    input_->format = AV_SAMPLE_FMT_S16;
    input_->sample_rate = sampleRate_;
    av_channel_layout_default(&input_->ch_layout, channels_);
    input_->nb_samples = samplesPerFrame_;
    if (av_frame_get_buffer(input_.get(), 0) < 0) {
        context_.reset();
        return;
    }
}

AudioEncoder::~AudioEncoder() = default;

bool AudioEncoder::isOpen() const
{
    return static_cast<bool>(context_);
}

bool AudioEncoder::ensureResampler(int sampleRate, int channels)
{
    if (resampler_ && sampleRate == inputSampleRate_ && channels == inputChannels_) {
        return true;
    }

    SwrContext* raw = nullptr;
    AVChannelLayout outLayout;
    av_channel_layout_uninit(&inputLayout_);
    av_channel_layout_default(&inputLayout_, channels);
    av_channel_layout_default(&outLayout, channels_);
    // swr_alloc_set_opts2 takes the output side first and the input side second, with the rates
    // in the same order. The output is the encoder's fixed rate and layout; the input is the
    // device's. Swapping them makes swr write the device's channel count into this side's buffer
    // and overrun it.
    if (swr_alloc_set_opts2(&raw, &outLayout, AV_SAMPLE_FMT_S16, sampleRate_, &inputLayout_,
            AV_SAMPLE_FMT_S16, sampleRate, 0, nullptr)
        < 0) {
        return false;
    }
    if (swr_init(raw) < 0) {
        freeSwrContext(raw);
        return false;
    }
    resampler_.reset(raw);
    inputSampleRate_ = sampleRate;
    inputChannels_ = channels;
    return true;
}

void AudioEncoder::applyAutoGain(qint16* destination, const qint16* source, int samples)
{
    if (samples <= 0) {
        return;
    }

    // Normalisation off means the captured level goes to the encoder as captured.
    if (!agcEnabled_) {
        for (int i = 0; i < samples; ++i) {
            destination[i] = source[i];
        }
        return;
    }

    double sumSquares = 0.0;
    double peak = 0.0;
    for (int i = 0; i < samples; ++i) {
        const double value = source[i] / 32768.0;
        sumSquares += value * value;
        const double magnitude = value < 0.0 ? -value : value;
        if (magnitude > peak) {
            peak = magnitude;
        }
    }
    const double frameLevel = std::sqrt(sumSquares / samples);

    // The first frame with real audio seeds the envelope directly instead of easing up from zero,
    // which would otherwise command the maximum gain for the first third of a second.
    if (agcLevel_ <= 0.0) {
        agcLevel_ = frameLevel;
    } else {
        agcLevel_ += (frameLevel - agcLevel_) * AgcLevelRate;
    }

    // Silence holds the last gain rather than being driven to the maximum. Without the gate the
    // envelope decays toward zero, the desired gain runs to the ceiling and the device's noise
    // floor is lifted into every pause.
    if (agcLevel_ > AgcGateRms) {
        const double desired = qBound(AgcMinGain, AgcTargetRms / agcLevel_, AgcMaxGain);
        agcGain_ += (desired - agcGain_) * AgcGainRate;
    }

    // A per-frame ceiling applied without touching the smoothed gain, so one transient does not
    // pull the long-term level down with it. The clamp below is the last resort if it still
    // overshoots.
    double gain = agcGain_;
    if (peak > 0.0 && peak * gain > AgcCeiling) {
        gain = AgcCeiling / peak;
    }

    for (int i = 0; i < samples; ++i) {
        const long scaled = std::lround(source[i] * gain);
        destination[i] = static_cast<qint16>(qBound(-32768L, scaled, 32767L));
    }
}

void AudioEncoder::encodeFrames(const std::function<void(const EncodedAudio&)>& out)
{
    const qsizetype frameBytes
        = static_cast<qsizetype>(samplesPerFrame_) * channels_ * sizeof(qint16);
    int offset = 0;
    while (offset + frameBytes <= converted_.size()) {
        applyAutoGain(reinterpret_cast<qint16*>(input_->data[0]),
            reinterpret_cast<const qint16*>(converted_.constData() + offset),
            samplesPerFrame_ * channels_);
        input_->nb_samples = samplesPerFrame_;
        input_->pts = nextPts_;

        if (avcodec_send_frame(context_.get(), input_.get()) >= 0) {
            for (;;) {
                const int received = avcodec_receive_packet(context_.get(), packet_.get());
                if (received < 0) {
                    break;
                }
                EncodedAudio audio;
                audio.packet = QByteArray(reinterpret_cast<const char*>(packet_->data),
                    packet_->size);
                if (!audio.packet.isEmpty()) {
                    out(audio);
                }
                av_packet_unref(packet_.get());
            }
        }
        nextPts_ += samplesPerFrame_;
        offset += static_cast<int>(frameBytes);
    }

    if (offset > 0) {
        converted_.remove(0, offset);
    }
}

void AudioEncoder::encode(const capture::AudioSample& sample,
    const std::function<void(const EncodedAudio&)>& out)
{
    if (!context_ || sample.data.isEmpty()) {
        return;
    }

    // The resampler's input side is the *device's* format and its output side the encoder's, so
    // a 44.1 kHz stereo microphone is converted to the 48 kHz mono the wire format expects.
    // Assuming the two matched is what made a 44.1 kHz stereo device play back at roughly half
    // speed. The format is re-derived from every sample so a device that is reconfigured mid
    // session is followed rather than silently mis-read.
    const int inRate = sample.sampleRate > 0 ? sample.sampleRate : sampleRate_;
    const int inChannels = sample.channels > 0 ? sample.channels : channels_;
    if (!ensureResampler(inRate, inChannels)) {
        return;
    }

    // Carried across calls, so a block that is not a whole number of frames does not lose the
    // tail: a device delivering 1024 samples per callback would otherwise drop 64 samples
    // every time, which is an audible stutter.
    pending_.append(sample.data);

    const int inputStride = inChannels * static_cast<int>(sizeof(qint16));
    const int inSamples = static_cast<int>(pending_.size() / inputStride);
    if (inSamples <= 0) {
        return;
    }
    const int consumedBytes = inSamples * inputStride;

    // swr_convert takes arrays of pointers, so the single input buffer is passed through a
    // one-element array rather than as a bare pointer. The output is written into scratch sized
    // by swr_get_out_samples, which is the worst case for this much input, so a single call
    // consumes every input sample and leaves nothing buffered inside swr.
    const int capacity = swr_get_out_samples(resampler_.get(), inSamples);
    if (capacity <= 0) {
        return;
    }
    QByteArray produced(capacity * channels_ * static_cast<int>(sizeof(qint16)),
        Qt::Uninitialized);
    uint8_t* producedPtr = reinterpret_cast<uint8_t*>(produced.data());
    const uint8_t* source = reinterpret_cast<const uint8_t*>(pending_.constData());
    const int converted
        = swr_convert(resampler_.get(), &producedPtr, capacity, &source, inSamples);
    pending_.remove(0, consumedBytes);
    if (converted <= 0) {
        return;
    }
    produced.resize(converted * channels_ * static_cast<int>(sizeof(qint16)));
    converted_.append(produced);

    encodeFrames(out);
}

void AudioEncoder::flush(const std::function<void(const EncodedAudio&)>& out)
{
    if (!context_) {
        return;
    }

    // The resampler holds a few samples of filter delay from the last conversion. Draining it
    // with a null input recovers them, so the very end of the session is not clipped.
    if (resampler_) {
        const int capacity = swr_get_out_samples(resampler_.get(), 0);
        if (capacity > 0) {
            QByteArray tail(capacity * channels_ * static_cast<int>(sizeof(qint16)),
                Qt::Uninitialized);
            uint8_t* tailPtr = reinterpret_cast<uint8_t*>(tail.data());
            const uint8_t* noInput = nullptr;
            const int converted
                = swr_convert(resampler_.get(), &tailPtr, capacity, &noInput, 0);
            if (converted > 0) {
                converted_.append(tail.constData(),
                    converted * channels_ * static_cast<int>(sizeof(qint16)));
            }
        }
    }

    // The leftover is padded to a whole frame rather than dropped: dropping it would clip the
    // last syllable of a session, which is exactly the moment a user is listening for.
    const qsizetype frameBytes
        = static_cast<qsizetype>(samplesPerFrame_) * channels_ * sizeof(qint16);
    if (!converted_.isEmpty()) {
        const qsizetype remainder = converted_.size() % frameBytes;
        if (remainder != 0) {
            converted_.append(QByteArray(frameBytes - remainder, '\0'));
        }
        encodeFrames(out);
    }

    // libopus holds more from its own lookahead. It is real audio that would be cut off at the
    // end of the session, so it is drained with a null frame.
    if (avcodec_send_frame(context_.get(), nullptr) >= 0) {
        for (;;) {
            const int received = avcodec_receive_packet(context_.get(), packet_.get());
            if (received < 0) {
                break;
            }
            EncodedAudio audio;
            audio.packet = QByteArray(reinterpret_cast<const char*>(packet_->data), packet_->size);
            if (!audio.packet.isEmpty()) {
                out(audio);
            }
            av_packet_unref(packet_.get());
        }
    }
}

} // namespace localstream::capture
