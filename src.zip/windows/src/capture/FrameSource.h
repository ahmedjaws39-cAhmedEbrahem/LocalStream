#pragma once

#include <QByteArray>
#include <QList>
#include <QString>

#include <atomic>
#include <functional>

extern "C" {
#include <libavutil/pixfmt.h>
#include <libavutil/samplefmt.h>
}

namespace localstream::capture {

/**
 * One frame of video as the device produced it: raw pixels, no conversion applied yet.
 *
 * Deliberately not an `AVFrame`. A capture device hands over a byte buffer plus a description
 * of what is in it, and wrapping that in libav's reference-counted frame would mean either
 * copying every frame or leaking the packet that backs it. The conversion to something the
 * encoder accepts happens in the engine, with swscale, where the target format is already
 * known.
 */
struct VideoSample
{
    QByteArray data;
    int width = 0;
    int height = 0;
    int format = 0; // an AV_PIX_FMT_* value
    /// Presentation time in microseconds, relative to the start of capture.
    qint64 ptsMicros = 0;
    /// Bytes per row of the top plane, for sources whose stride is not width * pixel size.
    int linesize = 0;
};

/**
 * One block of audio as the device produced it: interleaved samples, no conversion applied.
 */
struct AudioSample
{
    QByteArray data;
    /// Samples per channel in this block, not the total across channels.
    int samples = 0;
    int sampleRate = 48000;
    int channels = 1;
    int format = 0; // an AV_SAMPLE_FMT_* value
    qint64 ptsMicros = 0;
};

/**
 * A source of media samples, independent of FFmpeg.
 *
 * The engines are written against this rather than against libavdevice, which is what lets the
 * whole broadcast path be tested on a machine with no camera, no microphone and no display: a
 * test substitutes [TestPatternSource] and everything above it runs exactly as it would with
 * real hardware.
 */
class FrameSource
{
public:
    virtual ~FrameSource() = default;

    /// Shown in the UI, e.g. "Desktop" or "Integrated Camera".
    [[nodiscard]] virtual QString sourceName() const = 0;

    [[nodiscard]] virtual bool isVideo() const = 0;

    /// Dimensions for video; 0 for audio.
    [[nodiscard]] virtual int width() const = 0;
    [[nodiscard]] virtual int height() const = 0;

    /// Sample rate and channel count for audio; 0 for video.
    [[nodiscard]] virtual int sampleRate() const = 0;
    [[nodiscard]] virtual int channels() const = 0;

    /**
     * Opens the device and delivers samples through the callbacks until [stop] is called.
     *
     * Blocking by design. The caller runs it on its own thread, which keeps the device's
     * native pacing instead of a Qt event loop having to guess at it, and it means a slow
     * consumer applies backpressure to the capture rather than growing an unbounded queue.
     *
     * @return false with [error] set if the device could not be opened. Returns true if the
     *         source ran and then stopped, which is not an error.
     */
    virtual bool start(const std::function<void(const VideoSample&)>& onVideo,
        const std::function<void(const AudioSample&)>& onAudio, QString* error) = 0;

    /// Stops the source and closes the device. Safe to call when not started, and safe twice.
    virtual void stop() = 0;

    [[nodiscard]] virtual bool isRunning() const = 0;
};

/**
 * Where a device should be opened.
 *
 * Named by string rather than by index, because an index is silently wrong the moment a device
 * is plugged in or the order the system enumerates them changes.
 */
struct DeviceOption
{
    QString name;
    /// The DirectShow `video=Name` / `audio=Name` form. Empty for a screen.
    QString path;
};

/// Microphones available for capture.
[[nodiscard]] QList<DeviceOption> listMicrophones();

/**
 * Whether a DirectShow alternative device name belongs to the audio capture class.
 *
 * Exposed because DirectShow's enumeration API hands back cameras and microphones in one list
 * whatever class is asked for, which leaves this predicate as the only thing that tells them
 * apart. A regression here does not fail loudly: the microphone picker simply offers a camera,
 * and opening it fails at broadcast start.
 */
[[nodiscard]] bool isAudioDeviceName(const QString& alternateName);

/// The whole desktop, captured through FFmpeg's GDI frame grabber.
class ScreenCapture : public FrameSource
{
public:
    ScreenCapture(int width, int height, int framesPerSecond);
    ~ScreenCapture() override;

    [[nodiscard]] QString sourceName() const override { return QStringLiteral("Desktop"); }
    [[nodiscard]] bool isVideo() const override { return true; }
    [[nodiscard]] int width() const override { return width_; }
    [[nodiscard]] int height() const override { return height_; }
    [[nodiscard]] int sampleRate() const override { return 0; }
    [[nodiscard]] int channels() const override { return 0; }

    bool start(const std::function<void(const VideoSample&)>& onVideo,
        const std::function<void(const AudioSample&)>& onAudio, QString* error) override;
    void stop() override;
    [[nodiscard]] bool isRunning() const override { return running_.load(); }

private:
    int width_ = 0;
    int height_ = 0;
    int framesPerSecond_ = 30;
    std::atomic<bool> running_ {false};
};

/**
 * A DirectShow device: a camera for video, a microphone for audio.
 *
 * One class for both because the FFmpeg code is identical apart from the device class string.
 * The delivered format is whatever the driver reports; converting it to a format the encoder
 * accepts is the engine's job, using swscale or swresample.
 */
class DeviceCapture : public FrameSource
{
public:
    DeviceCapture(DeviceOption device, bool audio);
    ~DeviceCapture() override;

    [[nodiscard]] QString sourceName() const override { return device_.name; }
    [[nodiscard]] bool isVideo() const override { return !audio_; }
    [[nodiscard]] int width() const override { return audio_ ? 0 : width_; }
    [[nodiscard]] int height() const override { return audio_ ? 0 : height_; }
    [[nodiscard]] int sampleRate() const override { return audio_ ? sampleRate_ : 0; }
    [[nodiscard]] int channels() const override { return audio_ ? channels_ : 0; }

    bool start(const std::function<void(const VideoSample&)>& onVideo,
        const std::function<void(const AudioSample&)>& onAudio, QString* error) override;
    void stop() override;
    [[nodiscard]] bool isRunning() const override { return running_.load(); }

private:
    DeviceOption device_;
    bool audio_ = false;
    std::atomic<bool> running_ {false};
    int width_ = 0;
    int height_ = 0;
    int sampleRate_ = 48000;
    int channels_ = 1;
};

/**
 * A moving test pattern, for video.
 *
 * Exists so the encoder, the RTP packetiser and the control handshake can all be exercised on
 * a machine with no camera and no display. The pattern moves on every frame, so a pipeline that
 * has stalled shows up as a frozen image rather than as a plausible-looking still.
 */
class TestPatternSource : public FrameSource
{
public:
    TestPatternSource(int width = 640, int height = 360, int framesPerSecond = 30);
    ~TestPatternSource() override;

    [[nodiscard]] QString sourceName() const override { return QStringLiteral("Test pattern"); }
    [[nodiscard]] bool isVideo() const override { return true; }
    [[nodiscard]] int width() const override { return width_; }
    [[nodiscard]] int height() const override { return height_; }
    [[nodiscard]] int sampleRate() const override { return 0; }
    [[nodiscard]] int channels() const override { return 0; }

    bool start(const std::function<void(const VideoSample&)>& onVideo,
        const std::function<void(const AudioSample&)>& onAudio, QString* error) override;
    void stop() override;
    [[nodiscard]] bool isRunning() const override { return running_.load(); }

private:
    int width_ = 0;
    int height_ = 0;
    int framesPerSecond_ = 30;
    std::atomic<bool> running_ {false};
};

/**
 * A sine tone, for audio.
 *
 * Emits exactly 960 samples per frame at 48 kHz, which is 20 ms and is the frame size the
 * protocol specifies. Using that exact size means the engine's pacing and the RTP timestamp
 * advance are exercised on their real values rather than on an arbitrary block size that would
 * never occur in practice.
 */
class TestToneSource : public FrameSource
{
public:
    TestToneSource(int sampleRate = 48000, int channels = 1);
    ~TestToneSource() override;

    [[nodiscard]] QString sourceName() const override { return QStringLiteral("Test tone"); }
    [[nodiscard]] bool isVideo() const override { return false; }
    [[nodiscard]] int width() const override { return 0; }
    [[nodiscard]] int height() const override { return 0; }
    [[nodiscard]] int sampleRate() const override { return sampleRate_; }
    [[nodiscard]] int channels() const override { return channels_; }

    bool start(const std::function<void(const VideoSample&)>& onVideo,
        const std::function<void(const AudioSample&)>& onAudio, QString* error) override;
    void stop() override;
    [[nodiscard]] bool isRunning() const override { return running_.load(); }

private:
    int sampleRate_ = 48000;
    int channels_ = 1;
    std::atomic<bool> running_ {false};
};

} // namespace localstream::capture
