#pragma once

#include <QByteArray>
#include <QString>

extern "C" {
#include <libavcodec/avcodec.h>
#include <libavutil/frame.h>
#include <libswresample/swresample.h>
#include <libswscale/swscale.h>
}

#include "capture/FrameSource.h"

namespace localstream::capture {

/**
 * An owning pointer for the FFmpeg types whose free function is not `delete`.
 *
 * std::unique_ptr<T, void(*)(T*)> would need a deleter supplied at construction, and these
 * members are default-constructed in the class. A tiny wrapper keeps the member a plain
 * pointer, so the constructors stay readable and the free function cannot be forgotten.
 */
template <typename T, void (*Free)(T*)>
struct FfOwned
{
    FfOwned() = default;
    explicit FfOwned(T* pointer) : value(pointer) {}
    ~FfOwned() { reset(); }

    FfOwned(const FfOwned&) = delete;
    FfOwned& operator=(const FfOwned&) = delete;

    FfOwned(FfOwned&& other) noexcept : value(other.value) { other.value = nullptr; }
    FfOwned& operator=(FfOwned&& other) noexcept
    {
        if (this != &other) {
            reset();
            value = other.value;
            other.value = nullptr;
        }
        return *this;
    }

    void reset(T* pointer = nullptr)
    {
        if (value) {
            Free(value);
        }
        value = pointer;
    }

    T* get() const { return value; }
    explicit operator bool() const { return value != nullptr; }
    T& operator*() const { return *value; }
    T* operator->() const { return value; }

    T* value = nullptr;
};

/// avcodec_free_context, which also releases the extradata hanging off the context.
void freeCodecContext(AVCodecContext* context);
void freeSwsContext(SwsContext* context);
void freeSwrContext(SwrContext* context);

/// libav's own frame and packet free functions take a double pointer, so they need wrapping
/// before they can be used as an FfOwned deleter.
void freeFrame(AVFrame* frame);
void freePacket(AVPacket* packet);

/**
 * One access unit out of an encoder: H.264 in AVCC form, ready for the RTP packetiser.
 *
 * AVCC, because that is what `net::RtpSender::sendVideo` and `protocol::H264Rtp::packetize`
 * already take. libx264 natively emits Annex B, so the encoder converts it here; see
 * `annexBToAvcc` in Encoders.cpp. This was confirmed empirically rather than assumed: this
 * build's libx264 output begins with an Annex B start code, so without the conversion
 * `splitAvcc` would parse one bogus one-byte NAL and no receiver would decode anything.
 */
struct EncodedVideo
{
    QByteArray accessUnit;
    bool keyframe = false;
};

/// One Opus packet, per RFC 7587: the payload is the packet itself, with no OpusHead.
struct EncodedAudio
{
    QByteArray packet;
};

/**
 * Encodes video frames to H.264 with libx264.
 *
 * Owns its own scaler, because a Windows capture device delivers BGRA and x264 wants YUV420p;
 * without the conversion the encoder either fails or silently negotiates a format that does
 * not survive the RTP path.
 *
 * The encoder is fed and drained from one thread only. libavcodec contexts are not
 * thread-safe, and this one has the encoder's internal delay frames queued, so handing it
 * frames from two threads would corrupt the bitstream rather than merely race.
 */
class VideoEncoder
{
public:
    /// [width] and [height] must be even: YUV420p is chroma-subsampled, and an odd dimension
    /// makes the encoder reject the frame.
    VideoEncoder(int width, int height, int framesPerSecond, int bitrateKbps);
    ~VideoEncoder();

    VideoEncoder(const VideoEncoder&) = delete;
    VideoEncoder& operator=(const VideoEncoder&) = delete;

    /// The SPS and PPS as bare NAL units, with no length prefix and no Annex B start code.
    ///
    /// Empty until the encoder has produced its first keyframe. libav writes an H.264 encoder's
    /// extradata lazily, when the first packet leaves it, so with `repeat_headers` on the
    /// parameter sets are captured from that keyframe rather than read from the codec. A caller
    /// that needs them before the first picture therefore has to ask for a keyframe first.
    ///
    /// Stable once populated, and refreshed by a later keyframe for a broadcaster that changes
    /// resolution. A receiver can cache them and use them to open a decoder.
    [[nodiscard]] QByteArray sps() const;
    [[nodiscard]] QByteArray pps() const;

    [[nodiscard]] bool isOpen() const;

    /**
     * Converts and encodes one frame.
     *
     * A return of zero frames is normal, not a failure: x264 buffers input to build lookahead,
     * so most frames produce nothing until the pipeline fills. Treating zero as an error would
     /// make the first few seconds of every broadcast look broken.
     */
    int encode(const capture::VideoSample& sample, const std::function<void(const EncodedVideo&)>& out);

    /**
     * Drains whatever the encoder is still holding.
     *
     * Must be called before the session is published as finished, or the last second of video
     * is lost: those frames exist inside the encoder and will never be emitted otherwise.
     */
    void flush(const std::function<void(const EncodedVideo&)>& out);

    /**
     * Asks for an IDR on the next frame.
     *
     * Sets an explicit I-frame rather than a scene-change heuristic, because the trigger is a
     * receiver that just joined and has no picture at all.
     */
    void requestKeyframe();

private:
    int width_ = 0;
    int height_ = 0;
    int framesPerSecond_ = 30;

    // FFmpeg objects, each released by the function its own library documents. AVFrame and
    // AVPacket have default deleters in modern libav, but the codec context and the scaler
    // do not, so all four go through FfOwned for consistency.
    FfOwned<AVCodecContext, freeCodecContext> context_;
    FfOwned<SwsContext, freeSwsContext> scaler_;
    FfOwned<AVFrame, freeFrame> scaled_;
    FfOwned<AVPacket, freePacket> packet_;

    /// Index of the last input frame. Presentation times must be strictly increasing, and the
    /// frame rate is exact, so a counter is more reliable than a wall clock.
    int64_t nextPts_ = 0;

    /// Set by [requestKeyframe] and cleared once it has been honoured by an I-frame, so the
    /// request applies to exactly one frame rather than pinning every frame to I.
    int forcedPictureType_ = AV_PICTURE_TYPE_NONE;

    /// Captured from the first keyframe's bitstream, because with repeat-headers enabled the
    /// parameter sets arrive in the encoded frames rather than in the codec's extradata.
    QByteArray sps_;
    QByteArray pps_;

    void rememberParameterSets(const QByteArray& avcc);
    [[nodiscard]] QByteArray parameterSet(bool wantSps) const;
};

/**
 * Encodes audio to Opus with libopus.
 *
 * Fixed at 20 ms frames because the protocol specifies 960 samples at 48 kHz (PROTOCOL.md
 * section 3.2), and a receiver's jitter buffer is sized for exactly that. A variable frame size
 * would work on the wire and still leave the receiver guessing.
 */
class AudioEncoder
{
public:
    /// [normalize] enables automatic gain control, which steadies the encoded level against a
    /// changing system volume or capture device. Off sends the captured level untouched.
    AudioEncoder(int sampleRate, int channels, int bitrateKbps, bool normalize = true);
    ~AudioEncoder();

    AudioEncoder(const AudioEncoder&) = delete;
    AudioEncoder& operator=(const AudioEncoder&) = delete;

    [[nodiscard]] bool isOpen() const;

    /// Converts and encodes. Emits one packet per complete 20 ms frame of input.
    void encode(const capture::AudioSample& sample, const std::function<void(const EncodedAudio&)>& out);

    /// Emits a final partial frame, if any samples remain.
    void flush(const std::function<void(const EncodedAudio&)>& out);

private:
    /// Rebuilds the resampler when the device's rate or layout differs from the last one seen.
    /// The input side is the *device's* format and the output side the encoder's, so a 44.1 kHz
    /// stereo microphone is converted to the 48 kHz mono the wire format expects instead of
    /// being mis-read as if it already matched. Returns false only when swr refuses the
    /// conversion; the previous resampler is left in place so a later sample can retry.
    bool ensureResampler(int sampleRate, int channels);

    /// Sends every complete 20 ms frame held in [converted_] to libopus, keeping any remainder.
    void encodeFrames(const std::function<void(const EncodedAudio&)>& out);

    /// Steers the frame's level toward a fixed loudness and writes the result to [destination].
    ///
    /// The level a Windows capture device delivers is not a property of this app: a loopback
    /// device such as "Stereo Mix" carries the post-volume signal, so turning the system volume
    /// down turns the broadcast down with it, and different devices have different native
    /// loudness. Normalising here, before Opus, is the only place that works for every source.
    /// One gain is computed for the whole frame and applied to every channel, which keeps a
    /// stereo image intact; normalising the channels separately would drift them apart.
    void applyAutoGain(qint16* destination, const qint16* source, int samples);

    int sampleRate_ = 48000;
    int channels_ = 1;
    int samplesPerFrame_ = 960;

    FfOwned<AVCodecContext, freeCodecContext> context_;
    FfOwned<AVFrame, freeFrame> input_;
    FfOwned<AVPacket, freePacket> packet_;
    FfOwned<SwrContext, freeSwrContext> resampler_;

    /// Source layout for the resampler. swr_alloc_set_opts2 fills this in, and passing an
    /// uninitialised one would make the conversion start from whatever was on the stack. It is
    /// re-derived whenever [ensureResampler] sees a new device format.
    AVChannelLayout inputLayout_ {};

    /// The rate and layout the current resampler was built for, so a change is noticed.
    int inputSampleRate_ = 0;
    int inputChannels_ = 0;

    /// Raw device samples carried over between calls, so an input block that is not a whole
    /// number of frames does not lose or duplicate audio at the boundary.
    QByteArray pending_;

    /// Converted, encoder-rate samples waiting to be cut into 20 ms frames.
    QByteArray converted_;

    /// Automatic gain control state, carried across frames. [agcLevel_] is the smoothed RMS of
    /// the input on the same 0..1 scale as the samples, so a change in source loudness is
    /// followed rather than reset; [agcGain_] is the gain currently being applied.
    double agcLevel_ = 0.0;
    double agcGain_ = 1.0;
    /// When false the captured samples are copied through and the state above is left alone.
    bool agcEnabled_ = true;

    int64_t nextPts_ = 0;
};

} // namespace localstream::capture
