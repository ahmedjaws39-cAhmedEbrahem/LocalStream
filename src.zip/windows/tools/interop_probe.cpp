// Temporary manual probe: browses for a live broadcast and plays it, printing what it sees.
// Not registered with CTest; it needs a broadcaster on the LAN to mean anything.

#include <QCoreApplication>
#include <QElapsedTimer>
#include <QTextStream>
#include <QTimer>

#include "discovery/ServiceDiscovery.h"
#include "engine/PlaybackEngine.h"

using namespace localstream;

int main(int argc, char** argv)
{
    QCoreApplication app(argc, argv);
    QTextStream out(stdout);

    const int seconds = argc > 1 ? QString(argv[1]).toInt() : 25;
    const QString direct = argc > 2 ? QString(argv[2]) : QString();

    net::ServiceDiscovery discovery;
    engine::PlaybackEngine playback;
    playback.requestKeyframe();

    int frames = 0;
    int connectableSeen = 0;
    QElapsedTimer clock;
    clock.start();
    bool joined = false;

    QObject::connect(&discovery, &net::ServiceDiscovery::serviceAdded,
        [&](const net::ServiceDiscovery::Service& service) {
            out << "found: " << service.name << " at " << service.address.toString() << ':'
                << service.port << " mode=" << service.description.mode
                << " video=" << service.description.videoPort
                << " audio=" << service.description.audioPort
                << " dim=" << service.description.width << 'x' << service.description.height
                << "\n";
            out.flush();
            if (!service.isConnectable()) {
                return;
            }
            ++connectableSeen;
            if (joined) {
                return;
            }
            joined = true;
            QString error;
            if (!playback.start(service.address.toString(), service.port, {}, &error)) {
                out << "start failed: " << error << "\n";
                out.flush();
            } else {
                out << "handshake sent to " << service.address.toString() << ':' << service.port
                    << "\n";
                out.flush();
            }
        });

    QObject::connect(&discovery, &net::ServiceDiscovery::warning, [](const QString& text) {
        QTextStream err(stderr);
        err << "discovery: " << text << "\n";
        err.flush();
    });

    QObject::connect(&playback, &engine::PlaybackEngine::started, [&] {
        out << "HANDSHAKE OK\n";
        out.flush();
    });
    QObject::connect(&playback, &engine::PlaybackEngine::failed, [](const QString& reason) {
        QTextStream err(stderr);
        err << "playback failed: " << reason << "\n";
        err.flush();
    });
    QObject::connect(&playback, &engine::PlaybackEngine::videoFrameReady,
        [&](const QImage& frame) {
            ++frames;
            if (frames == 1) {
                out << "FIRST FRAME " << frame.width() << 'x' << frame.height() << "\n";
                out.flush();
            }
        });
    QObject::connect(&playback, &engine::PlaybackEngine::statsChanged,
        [&](int fps, int kbps) {
            out << "broadcaster reports " << fps << " fps, " << kbps << " kbps\n";
            out.flush();
        });
    QObject::connect(&playback, &engine::PlaybackEngine::receptionStatsChanged,
        [&](quint64 audioPackets, quint64 videoPackets, quint64 lost, bool, quint64 decoded,
            quint64 audioPlayed, bool audioOpen, const QString& audioError) {
            const engine::AudioPlayer::Stats audio = playback.audioStats();
            const net::RtpReceiver::Stats received = playback.receptionStats();
            out << "reception: audioPkts=" << audioPackets << " videoPkts=" << videoPackets
                << " lost=" << lost << " burstMax=" << received.audioMaxBurst
                << " jitter=" << received.jitterMillis << " decodedFrames=" << decoded
                << " audio[submitted=" << audio.submitted << " dropped=" << audio.dropped
                << " decoded=" << audio.decoded << " sendFailed=" << audio.sendFailed
                << " queued=" << audio.queued << " peak=" << audio.peak
                << " played=" << audioPlayed << " open=" << (audioOpen ? "yes" : "no")
                << " err=" << (audioError.isEmpty() ? QStringLiteral("-") : audioError) << "]\n";
            out.flush();
        });

    if (direct.isEmpty()) {
        discovery.start();
    } else {
        const QStringList parts = direct.split(':');
        QTextStream err(stderr);
        QString error;
        if (parts.size() != 2
            || !playback.start(parts.at(0), parts.at(1).toInt(), {}, &error)) {
            err << "direct start failed: " << error << "\n";
            err.flush();
        } else {
            out << "direct handshake sent to " << direct << "\n";
            out.flush();
        }
        joined = true;
    }

    QTimer::singleShot(seconds * 1000, [&] {
        const net::RtpReceiver::Stats received = playback.receptionStats();
        out << "--- after " << seconds << "s: connectable=" << connectableSeen
            << " frames=" << frames
            << " audioPackets=" << received.audioPackets
            << " videoPackets=" << received.videoPackets
            << " lost=" << received.lostPackets
            << " haveSpsPps=" << (received.haveVideoParameters ? "yes" : "no")
            << " ---\n";
        out.flush();
        playback.stop();
        app.quit();
    });

    return app.exec();
}
